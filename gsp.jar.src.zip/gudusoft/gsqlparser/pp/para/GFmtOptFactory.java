package gudusoft.gsqlparser.pp.para;

import java.util.Hashtable;
import java.util.Map;

public class GFmtOptFactory
{
  private static volatile Map<String, GFmtOpt> a = new Hashtable();
  
  public static GFmtOpt newInstance(String paramString)
  {
    if (!a.containsKey(paramString)) {
      synchronized (GFmtOptFactory.class)
      {
        if (!a.containsKey(paramString)) {
          a.put(paramString, new GFmtOpt(paramString));
        }
      }
    }
    return (GFmtOpt)a.get(paramString);
  }
  
  public static GFmtOpt newInstance()
  {
    return newInstance(Long.valueOf(Thread.currentThread().getId()).toString());
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\para\GFmtOptFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */