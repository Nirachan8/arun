package gudusoft.gsqlparser.pp.para;

public enum GOutputFmt
{
  private GOutputFmt() {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\para\GOutputFmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */