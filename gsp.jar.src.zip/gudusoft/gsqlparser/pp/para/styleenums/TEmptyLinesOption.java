package gudusoft.gsqlparser.pp.para.styleenums;

public enum TEmptyLinesOption
{
  private TEmptyLinesOption() {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\para\styleenums\TEmptyLinesOption.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */