package gudusoft.gsqlparser.pp.para.styleenums;

public enum TCaseOption
{
  private TCaseOption() {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\para\styleenums\TCaseOption.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */