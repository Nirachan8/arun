package gudusoft.gsqlparser.pp.para;

import gudusoft.gsqlparser.pp.para.styleenums.TAlignOption;
import gudusoft.gsqlparser.pp.para.styleenums.TAlignStyle;
import gudusoft.gsqlparser.pp.para.styleenums.TCaseOption;
import gudusoft.gsqlparser.pp.para.styleenums.TCompactMode;
import gudusoft.gsqlparser.pp.para.styleenums.TEmptyLinesOption;
import gudusoft.gsqlparser.pp.para.styleenums.TLinefeedsCommaOption;

public class GFmtOpt
{
  public final String sessionId;
  public boolean opearateSourceToken = true;
  public TAlignStyle selectColumnlistStyle = TAlignStyle.AsStacked;
  public TLinefeedsCommaOption selectColumnlistComma = TLinefeedsCommaOption.LfAfterComma;
  public boolean selectItemInNewLine = false;
  public boolean alignAliasInSelectList = true;
  public boolean treatDistinctAsVirtualColumn = false;
  public TAlignStyle selectFromclauseStyle = TAlignStyle.AsStacked;
  public TLinefeedsCommaOption selectFromclauseComma = TLinefeedsCommaOption.LfAfterComma;
  public boolean fromClauseInNewLine = false;
  public boolean selectFromclauseJoinOnInNewline = true;
  public boolean alignJoinWithFromKeyword = false;
  public boolean andOrUnderWhere = false;
  public TAlignStyle insertColumnlistStyle = TAlignStyle.AsStacked;
  public TAlignStyle insertValuelistStyle = TAlignStyle.AsStacked;
  public boolean beStyleCreatetableLeftBEOnNewline = false;
  public boolean beStyleCreatetableRightBEOnNewline = false;
  public boolean createtableListitemInNewLine = false;
  public TAlignOption createtableFieldlistAlignOption = TAlignOption.AloLeft;
  public TLinefeedsCommaOption defaultCommaOption = TLinefeedsCommaOption.LfAfterComma;
  public TAlignStyle defaultAligntype = TAlignStyle.AsStacked;
  public Integer indentLen = Integer.valueOf(2);
  public Boolean useTab = Boolean.valueOf(false);
  public Integer tabSize = Integer.valueOf(2);
  public Integer beStyleFunctionBodyIndent = Integer.valueOf(2);
  public Boolean beStyleBlockLeftBEOnNewline = Boolean.valueOf(true);
  public Integer beStyleBlockLeftBEIndentSize = Integer.valueOf(2);
  public Integer beStyleBlockRightBEIndentSize = Integer.valueOf(2);
  public Integer beStyleBlockIndentSize = Integer.valueOf(2);
  public Integer beStyleIfElseSingleStmtIndentSize = Integer.valueOf(2);
  public Boolean caseWhenThenInSameLine = Boolean.valueOf(false);
  public Integer indentCaseFromSwitch = Integer.valueOf(2);
  public Integer indentCaseThen = Integer.valueOf(0);
  public TAlignOption selectKeywordsAlignOption = TAlignOption.AloLeft;
  public TCaseOption caseKeywords = TCaseOption.CoUppercase;
  public TCaseOption caseIdentifier = TCaseOption.CoLowercase;
  public TCaseOption caseQuotedIdentifier = TCaseOption.CoNoChange;
  public TCaseOption caseFuncname = TCaseOption.CoInitCap;
  public TCaseOption caseDatatype = TCaseOption.CoUppercase;
  public Boolean wsPaddingOperatorArithmetic = Boolean.valueOf(true);
  public Boolean wsPaddingParenthesesInFunction = Boolean.valueOf(false);
  public Boolean wsPaddingParenthesesInExpression = Boolean.valueOf(true);
  public Boolean wsPaddingParenthesesOfSubQuery = Boolean.valueOf(false);
  public Boolean wsPaddingParenthesesInFunctionCall = Boolean.valueOf(false);
  public Boolean wsPaddingParenthesesOfTypename = Boolean.valueOf(false);
  public Boolean cteNewlineBeforeAs = Boolean.valueOf(true);
  public Boolean linebreakAfterDeclare = Boolean.valueOf(false);
  public TAlignStyle parametersStyle = TAlignStyle.AsStacked;
  public TLinefeedsCommaOption parametersComma = TLinefeedsCommaOption.LfAfterComma;
  public Boolean beStyleFunctionLeftBEOnNewline = Boolean.valueOf(false);
  public Integer beStyleFunctionLeftBEIndentSize = Integer.valueOf(0);
  public Boolean beStyleFunctionRightBEOnNewline = Boolean.valueOf(true);
  public Integer beStyleFunctionRightBEIndentSize = Integer.valueOf(0);
  public Boolean beStyleFunctionFirstParamInNewline = Boolean.valueOf(false);
  public Boolean linebreakBeforeParamInExec = Boolean.valueOf(true);
  public TEmptyLinesOption emptyLines = TEmptyLinesOption.EloMergeIntoOne;
  public Boolean insertBlankLineInBatchSqls = Boolean.valueOf(false);
  public Boolean noEmptyLinesBetweenMultiSetStmts = Boolean.valueOf(false);
  public Boolean linenumberEnabled = Boolean.valueOf(false);
  public Boolean linenumberZeroBased = Boolean.valueOf(false);
  public Integer linenumberLeftMargin = Integer.valueOf(0);
  public Integer linenumberRightMargin = Integer.valueOf(2);
  public TAlignStyle functionCallParametersStyle = TAlignStyle.AsWrapped;
  public TLinefeedsCommaOption functionCallParametersComma = TLinefeedsCommaOption.LfAfterComma;
  public Boolean removeComment = Boolean.valueOf(false);
  public TCompactMode compactMode = TCompactMode.CpmNone;
  public Integer lineWidth = Integer.valueOf(99);
  private static final GOutputFmt a = GOutputFmt.ofSql;
  public GOutputFmt outputFmt = a;
  public String tabHtmlString = "&nbsp;&nbsp;&nbsp;&nbsp;";
  
  public GFmtOpt(String paramString)
  {
    this.sessionId = paramString;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\para\GFmtOpt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */