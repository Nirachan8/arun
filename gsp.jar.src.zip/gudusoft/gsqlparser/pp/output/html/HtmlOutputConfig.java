package gudusoft.gsqlparser.pp.output.html;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.pp.output.HighlightingElement;
import gudusoft.gsqlparser.pp.output.HighlightingElementRender;
import gudusoft.gsqlparser.pp.output.OutputConfig;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import java.awt.Color;
import java.awt.Font;
import java.util.HashMap;
import java.util.Map;

public class HtmlOutputConfig
  implements OutputConfig
{
  private String a = "Courier New";
  private int b = 10;
  private Map<HighlightingElement, HighlightingElementRender> c = new HashMap();
  private HtmlRenderUtil d;
  private boolean e = false;
  
  private void a()
  {
    this.e = true;
    Font localFont1 = new Font(this.a, 0, this.b);
    Font localFont2 = new Font(this.a, 1, this.b);
    Font localFont3 = new Font(this.a, 2, this.b);
    Color localColor1 = new Color(128, 0, 0);
    Color localColor2 = new Color(0, 0, 255);
    Color localColor3 = new Color(0, 0, 0);
    Color localColor4 = new Color(192, 192, 192);
    Color localColor5 = new Color(255, 0, 128);
    Color localColor6 = new Color(16711935);
    Color localColor7 = new Color(16711808);
    Color localColor8 = new Color(255, 0, 0);
    Color localColor9 = new Color(0, 128, 0);
    a(HighlightingElement.sfkSpan, new HtmlHighlightingElementRender(HighlightingElement.sfkSpan, Color.WHITE, localFont1), false);
    a(HighlightingElement.sfkDefault, new HtmlHighlightingElementRender(HighlightingElement.sfkDefault, Color.BLACK, localFont1), false);
    a(HighlightingElement.sfkIdentifer, new HtmlHighlightingElementRender(HighlightingElement.sfkIdentifer, localColor1, localFont1), false);
    a(HighlightingElement.sfkStandardkeyword, new HtmlHighlightingElementRender(HighlightingElement.sfkStandardkeyword, localColor2, localFont1), false);
    a(HighlightingElement.sfkNumber, new HtmlHighlightingElementRender(HighlightingElement.sfkNumber, localColor3, localFont1), false);
    a(HighlightingElement.sfkDelimitedIdentifier, new HtmlHighlightingElementRender(HighlightingElement.sfkDelimitedIdentifier, localColor1, localFont1), false);
    a(HighlightingElement.sfkSymbol, new HtmlHighlightingElementRender(HighlightingElement.sfkSymbol, localColor4, localFont1), false);
    a(HighlightingElement.sfkFunction, new HtmlHighlightingElementRender(HighlightingElement.sfkFunction, localColor5, localFont2), false);
    a(HighlightingElement.sfkBuiltInFunction, new HtmlHighlightingElementRender(HighlightingElement.sfkBuiltInFunction, localColor6, localFont3), false);
    a(HighlightingElement.sfkDatatype, new HtmlHighlightingElementRender(HighlightingElement.sfkDatatype, Color.BLACK, localFont3), false);
    a(HighlightingElement.sfkParameter, new HtmlHighlightingElementRender(HighlightingElement.sfkParameter, localColor1, localFont1), false);
    a(HighlightingElement.sfkbindvar, new HtmlHighlightingElementRender(HighlightingElement.sfkbindvar, localColor1, localFont1), false);
    a(HighlightingElement.sfkVendordbkeyword, new HtmlHighlightingElementRender(HighlightingElement.sfkVendordbkeyword, localColor2, localFont1), false);
    a(HighlightingElement.sfkSQString, new HtmlHighlightingElementRender(HighlightingElement.sfkSQString, localColor8, localFont1), false);
    a(HighlightingElement.sfkDQString, new HtmlHighlightingElementRender(HighlightingElement.sfkDQString, localColor8, localFont1), false);
    a(HighlightingElement.sfkComment_dh, new HtmlHighlightingElementRender(HighlightingElement.sfkComment_dh, localColor9, localFont3), false);
    a(HighlightingElement.sfkComment_ss, new HtmlHighlightingElementRender(HighlightingElement.sfkComment_ss, localColor9, localFont3), false);
    a(HighlightingElement.sfkComment_sign, new HtmlHighlightingElementRender(HighlightingElement.sfkComment_sign, localColor9, localFont3), false);
    a(HighlightingElement.sfkMssqlsystemvar, new HtmlHighlightingElementRender(HighlightingElement.sfkMssqlsystemvar, localColor6, localFont3), false);
    a(HighlightingElement.sfksqlvar, new HtmlHighlightingElementRender(HighlightingElement.sfksqlvar, localColor7, localFont1), false);
    a(HighlightingElement.sfkMssqlst1, new HtmlHighlightingElementRender(HighlightingElement.sfkMssqlst1, localColor7, localFont1), false);
    a(HighlightingElement.sfkMssqlst2, new HtmlHighlightingElementRender(HighlightingElement.sfkMssqlst2, localColor7, localFont1), false);
    a(HighlightingElement.sfkMssqlst3, new HtmlHighlightingElementRender(HighlightingElement.sfkMssqlst3, localColor7, localFont1), false);
    a(HighlightingElement.sfkOracleplsqlkeyword, new HtmlHighlightingElementRender(HighlightingElement.sfkOracleplsqlkeyword, localColor1, localFont1), false);
    a(HighlightingElement.sfkOraclepackage, new HtmlHighlightingElementRender(HighlightingElement.sfkOraclepackage, localColor1, localFont1), false);
    a(HighlightingElement.sfkOraclecommand, new HtmlHighlightingElementRender(HighlightingElement.sfkOraclecommand, localColor1, localFont1), false);
    a(HighlightingElement.sfkOracleplsqlmethod, new HtmlHighlightingElementRender(HighlightingElement.sfkOracleplsqlmethod, localColor1, localFont1), false);
    a(HighlightingElement.sfkOraclerem, new HtmlHighlightingElementRender(HighlightingElement.sfkOraclerem, localColor1, localFont1), false);
    a(HighlightingElement.sfkOraclesqlplus, new HtmlHighlightingElementRender(HighlightingElement.sfkOraclesqlplus, localColor1, localFont1), false);
    a(HighlightingElement.sfkSybasesystemobj, new HtmlHighlightingElementRender(HighlightingElement.sfkSybasesystemobj, localColor1, localFont1), false);
    a(HighlightingElement.sfkSybasest, new HtmlHighlightingElementRender(HighlightingElement.sfkSybasest, localColor1, localFont1), false);
    a(HighlightingElement.sfkSybaseglobalvar, new HtmlHighlightingElementRender(HighlightingElement.sfkSybaseglobalvar, localColor1, localFont1), false);
    a(HighlightingElement.sfkopenbracket, new HtmlHighlightingElementRender(HighlightingElement.sfkopenbracket, localColor1, localFont1), false);
    a(HighlightingElement.sfkclosebracket, new HtmlHighlightingElementRender(HighlightingElement.sfkclosebracket, localColor1, localFont1), false);
    a(HighlightingElement.sfkUserCustomized, new HtmlHighlightingElementRender(HighlightingElement.sfkUserCustomized, localColor1, localFont1), false);
  }
  
  public HtmlOutputConfig(GFmtOpt paramGFmtOpt, EDbVendor paramEDbVendor)
  {
    this.d = new HtmlRenderUtil(this, paramGFmtOpt, paramEDbVendor);
  }
  
  public void addHighlightingElementRender(HighlightingElement paramHighlightingElement, HighlightingElementRender paramHighlightingElementRender)
  {
    a(paramHighlightingElement, paramHighlightingElementRender, true);
  }
  
  private void a(HighlightingElement paramHighlightingElement, HighlightingElementRender paramHighlightingElementRender, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      this.c.put(paramHighlightingElement, paramHighlightingElementRender);
      return;
    }
    if (!this.c.containsKey(paramHighlightingElement)) {
      this.c.put(paramHighlightingElement, paramHighlightingElementRender);
    }
  }
  
  public boolean containsHighlightingElementRender(HighlightingElement paramHighlightingElement)
  {
    return this.c.containsKey(paramHighlightingElement);
  }
  
  public String getGlobalFontName()
  {
    return this.a;
  }
  
  public int getGlobalFontSize()
  {
    return this.b;
  }
  
  public HighlightingElementRender getHighlightingElementRender(HighlightingElement paramHighlightingElement)
  {
    return (HighlightingElementRender)this.c.get(paramHighlightingElement);
  }
  
  public void removeHighlightingElementRender(HighlightingElement paramHighlightingElement)
  {
    this.c.remove(paramHighlightingElement);
  }
  
  public void setGlobalFontName(String paramString)
  {
    this.a = paramString;
  }
  
  public void setGlobalFontSize(int paramInt)
  {
    this.b = paramInt;
  }
  
  public String renderHighlightingElement(TSourceToken paramTSourceToken)
  {
    if (!this.e) {
      a();
    }
    return this.d.renderToken(paramTSourceToken);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\output\html\HtmlOutputConfig.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */