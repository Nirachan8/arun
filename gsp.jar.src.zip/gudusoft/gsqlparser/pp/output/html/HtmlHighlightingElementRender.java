package gudusoft.gsqlparser.pp.output.html;

import gudusoft.gsqlparser.pp.output.HighlightingElement;
import gudusoft.gsqlparser.pp.output.HighlightingElementRender;
import java.awt.Color;
import java.awt.Font;
import java.awt.font.TextAttribute;
import java.util.Map;

public class HtmlHighlightingElementRender
  implements HighlightingElementRender
{
  private Color a;
  private HighlightingElement b;
  private String c;
  private int d;
  private int e;
  private Color f;
  private boolean g;
  private boolean h;
  
  public HtmlHighlightingElementRender(HighlightingElement paramHighlightingElement)
  {
    this.b = paramHighlightingElement;
  }
  
  public HtmlHighlightingElementRender(HighlightingElement paramHighlightingElement, Font paramFont)
  {
    this.b = paramHighlightingElement;
    this.d = paramFont.getSize();
    this.e = paramFont.getStyle();
    this.c = paramFont.getName();
    this.h = TextAttribute.UNDERLINE_ON.equals(paramFont.getAttributes().get(TextAttribute.UNDERLINE));
    this.g = TextAttribute.STRIKETHROUGH_ON.equals(paramFont.getAttributes().get(TextAttribute.STRIKETHROUGH));
    this.f = ((Color)paramFont.getAttributes().get(TextAttribute.FOREGROUND));
    this.a = ((Color)paramFont.getAttributes().get(TextAttribute.BACKGROUND));
  }
  
  public HtmlHighlightingElementRender(HighlightingElement paramHighlightingElement, Color paramColor, Font paramFont, boolean paramBoolean1, boolean paramBoolean2)
  {
    this.b = paramHighlightingElement;
    this.d = paramFont.getSize();
    this.e = paramFont.getStyle();
    this.c = paramFont.getName();
    this.h = paramBoolean1;
    this.g = paramBoolean2;
    this.a = paramColor;
  }
  
  public HtmlHighlightingElementRender(HighlightingElement paramHighlightingElement, Color paramColor, Font paramFont)
  {
    this.b = paramHighlightingElement;
    this.d = paramFont.getSize();
    this.e = paramFont.getStyle();
    this.c = paramFont.getName();
    this.f = paramColor;
  }
  
  public Color getBackgroundColor()
  {
    return this.a;
  }
  
  public HighlightingElement getElement()
  {
    return this.b;
  }
  
  public String getFontName()
  {
    return this.c;
  }
  
  public int getFontSize()
  {
    return this.d;
  }
  
  public int getFontStyle()
  {
    return this.e;
  }
  
  public Color getForegroundColor()
  {
    return this.f;
  }
  
  public boolean isStrikeOut()
  {
    return this.g;
  }
  
  public boolean isUnderLine()
  {
    return this.h;
  }
  
  public void setBackgroundColor(Color paramColor)
  {
    this.a = paramColor;
  }
  
  public void setFontName(String paramString)
  {
    this.c = paramString;
  }
  
  public void setFontSize(int paramInt)
  {
    this.d = paramInt;
  }
  
  public void setFontStyle(int paramInt)
  {
    this.e = paramInt;
  }
  
  public void setForegroundColor(Color paramColor)
  {
    this.f = paramColor;
  }
  
  public void setStrikeOut(boolean paramBoolean)
  {
    this.g = paramBoolean;
  }
  
  public void setUnderLine(boolean paramBoolean)
  {
    this.h = paramBoolean;
  }
  
  public String render(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    if (this.c != null) {
      localStringBuffer.append("font-family:").append(this.c).append(";");
    }
    if (this.d != 0) {
      localStringBuffer.append("font-size:").append(this.d).append("pt;");
    }
    if (this.e == 2) {
      localStringBuffer.append("font-sytle:italic;");
    }
    if (this.e == 1) {
      localStringBuffer.append("font-weight:bold;");
    }
    if (isUnderLine()) {
      localStringBuffer.append("text-decoration: underline;");
    }
    if (isStrikeOut()) {
      localStringBuffer.append("text-decoration: line-through;");
    }
    if (this.f != null) {
      localStringBuffer.append("color: " + color2String(this.f) + ";");
    }
    if (this.a != null) {
      localStringBuffer.append("background-color: " + color2String(this.a) + ";");
    }
    return "<span style=\"" + localStringBuffer.toString() + "\">" + paramString + "</span>";
  }
  
  public static String color2String(Color paramColor)
  {
    String str1 = (str1 = Integer.toHexString(paramColor.getRed())).length() < 2 ? '0' + str1 : str1;
    String str2 = (str2 = Integer.toHexString(paramColor.getBlue())).length() < 2 ? '0' + str2 : str2;
    paramColor = (paramColor = Integer.toHexString(paramColor.getGreen())).length() < 2 ? '0' + paramColor : paramColor;
    return '#' + str1 + paramColor + str2;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\output\html\HtmlHighlightingElementRender.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */