package gudusoft.gsqlparser.pp.output.html;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ETokenType;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.pp.output.HighlightingElement;
import gudusoft.gsqlparser.pp.output.HighlightingElementRender;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.styleenums.TCompactMode;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

public class HtmlRenderUtil
{
  private HtmlOutputConfig a;
  private GFmtOpt b;
  private EDbVendor c;
  
  public HtmlRenderUtil(HtmlOutputConfig paramHtmlOutputConfig, GFmtOpt paramGFmtOpt, EDbVendor paramEDbVendor)
  {
    this.a = paramHtmlOutputConfig;
    this.b = paramGFmtOpt;
    this.c = paramEDbVendor;
  }
  
  public String renderToken(TSourceToken paramTSourceToken)
  {
    int i = 0;
    String str = paramTSourceToken.astext;
    ETokenType localETokenType = paramTSourceToken.tokentype;
    str = (str = str.replaceAll(" ", "&nbsp;")).replaceAll("\t", this.b.tabHtmlString);
    if (ETokenType.ttwhitespace.equals(localETokenType))
    {
      str = this.a.getHighlightingElementRender(HighlightingElement.sfkSpan).render(str);
    }
    else if (ETokenType.ttreturn.equals(localETokenType))
    {
      if (str.contains("\r\n")) {
        str = str.replaceAll("\r\n", "\r\n</br>");
      } else {
        str = str.replaceAll("\n", "\r\n</br>");
      }
      str = this.a.getHighlightingElementRender(HighlightingElement.sfkSpan).render(str);
      i = 1;
    }
    else if (ETokenType.ttsimplecomment.equals(localETokenType))
    {
      str = str.replaceAll(Pattern.quote("--"), "&#45;&#45;");
      if (TCompactMode.Cpmugly.equals(this.b.compactMode)) {
        str = "/* " + str + "*/";
      }
      str = this.a.getHighlightingElementRender(HighlightingElement.sfkComment_dh).render(str);
    }
    else if (ETokenType.ttbracketedcomment.equals(localETokenType))
    {
      if (str.contains("\r\n")) {
        str = str.replaceAll("\r\n", "\r\n</br>");
      } else {
        str = str.replaceAll("\n", "\r\n</br>");
      }
      str = this.a.getHighlightingElementRender(HighlightingElement.sfkComment_dh).render(str);
    }
    else
    {
      if ((ETokenType.ttidentifier.equals(localETokenType)) || (ETokenType.ttdqstring.equals(localETokenType)) || (ETokenType.ttdbstring.equals(localETokenType)) || (ETokenType.ttbrstring.equals(localETokenType))) {
        if ((ETokenType.ttdqstring.equals(localETokenType)) || (ETokenType.ttdbstring.equals(localETokenType))) {
          str = str.replaceAll("\"", "&quot;");
        }
      }
      switch (paramTSourceToken = paramTSourceToken.getDbObjType())
      {
      case 13: 
        if (a(str, this.c)) {
          str = this.a.getHighlightingElementRender(HighlightingElement.sfkBuiltInFunction).render(str);
        } else {
          str = this.a.getHighlightingElementRender(HighlightingElement.sfkFunction).render(str);
        }
        break;
      case 30: 
        str = this.a.getHighlightingElementRender(HighlightingElement.sfkDatatype).render(str);
        break;
      default: 
        EDbVendor.dbvmssql.equals(this.c);
        str = this.a.getHighlightingElementRender(HighlightingElement.sfkIdentifer).render(str);
        break;
        if (ETokenType.ttnumber.equals(localETokenType))
        {
          str = this.a.getHighlightingElementRender(HighlightingElement.sfkNumber).render(str);
        }
        else if (ETokenType.ttsqstring.equals(localETokenType))
        {
          if ((str = (str = (str = (str = (str = str.replaceAll("&nbsp;", " ")).replaceAll("&", "&#38;")).replaceAll(" ", "&nbsp;")).replaceAll("\"", "&quot;")).replaceAll("<", "&#60;")).contains("\r\n")) {
            str = str.replaceAll("\r\n", "\r\n</br>");
          } else {
            str = str.replaceAll("\n", "\r\n</br>");
          }
          str = this.a.getHighlightingElementRender(HighlightingElement.sfkSQString).render(str);
        }
        else if (ETokenType.ttkeyword.equals(localETokenType))
        {
          switch (paramTSourceToken = paramTSourceToken.getDbObjType())
          {
          case 13: 
            if (a(str, this.c)) {
              str = this.a.getHighlightingElementRender(HighlightingElement.sfkBuiltInFunction).render(str);
            } else {
              str = this.a.getHighlightingElementRender(HighlightingElement.sfkFunction).render(str);
            }
            break;
          case 30: 
            str = this.a.getHighlightingElementRender(HighlightingElement.sfkDatatype).render(str);
            break;
          default: 
            EDbVendor.dbvmssql.equals(this.c);
            str = this.a.getHighlightingElementRender(HighlightingElement.sfkStandardkeyword).render(str);
            break;
          }
        }
        else if (ETokenType.ttsqlvar.equals(localETokenType))
        {
          str = this.a.getHighlightingElementRender(HighlightingElement.sfksqlvar).render(str);
        }
        else if (ETokenType.ttbindvar.equals(localETokenType))
        {
          str = this.a.getHighlightingElementRender(HighlightingElement.sfkbindvar).render(str);
        }
        else if (ETokenType.ttmulticharoperator.equals(localETokenType))
        {
          str = (str = str.replaceAll("<", "&lt;")).replaceAll(">", "&gt;");
          str = this.a.getHighlightingElementRender(HighlightingElement.sfkSymbol).render(str);
        }
        else if (ETokenType.ttsinglecharoperator.equals(localETokenType))
        {
          str = this.a.getHighlightingElementRender(HighlightingElement.sfkSymbol).render(str);
        }
        else if ((ETokenType.ttcomma.equals(localETokenType)) || (ETokenType.ttperiod.equals(localETokenType)) || (ETokenType.ttsemicolon.equals(localETokenType)) || (ETokenType.ttdolorsign.equals(localETokenType)) || (ETokenType.ttcolon.equals(localETokenType)) || (ETokenType.ttplussign.equals(localETokenType)) || (ETokenType.ttminussign.equals(localETokenType)) || (ETokenType.ttasterisk.equals(localETokenType)) || (ETokenType.ttslash.equals(localETokenType)) || (ETokenType.ttstmt_delimiter.equals(localETokenType)) || (ETokenType.ttequals.equals(localETokenType)) || (ETokenType.ttatsign.equals(localETokenType)) || (ETokenType.ttsemicolon2.equals(localETokenType)) || (ETokenType.ttsemicolon3.equals(localETokenType)) || (ETokenType.ttquestionmark.equals(localETokenType)))
        {
          str = this.a.getHighlightingElementRender(HighlightingElement.sfkSymbol).render(str);
        }
        else if (ETokenType.ttlessthan.equals(localETokenType))
        {
          str = "&lt;";
          str = this.a.getHighlightingElementRender(HighlightingElement.sfkSymbol).render(str);
        }
        else if (ETokenType.ttgreaterthan.equals(localETokenType))
        {
          str = "&gt;";
          str = this.a.getHighlightingElementRender(HighlightingElement.sfkSymbol).render(str);
        }
        else if (ETokenType.ttleftparenthesis.equals(localETokenType))
        {
          str = this.a.getHighlightingElementRender(HighlightingElement.sfkopenbracket).render(str);
        }
        else if (ETokenType.ttrightparenthesis.equals(localETokenType))
        {
          str = this.a.getHighlightingElementRender(HighlightingElement.sfkclosebracket).render(str);
        }
        else if (ETokenType.ttsqlpluscmd.equals(localETokenType))
        {
          str = this.a.getHighlightingElementRender(HighlightingElement.sfkOraclesqlplus).render(str);
        }
        else
        {
          str = this.a.getHighlightingElementRender(HighlightingElement.sfkDefault).render(str);
        }
        break;
      }
    }
    if ((TCompactMode.Cpmugly.equals(this.b.compactMode)) && (i != 0)) {
      str = str + "\r\n";
    }
    return str;
  }
  
  private boolean a(String paramString, EDbVendor paramEDbVendor)
  {
    if (EDbVendor.dbvoracle.equals(paramEDbVendor)) {
      return false;
    }
    if (EDbVendor.dbvmssql.equals(paramEDbVendor)) {
      return false;
    }
    if (EDbVendor.dbvmysql.equals(paramEDbVendor)) {
      return a(paramString);
    }
    return false;
  }
  
  private static boolean a(String paramString)
  {
    String[] arrayOfString;
    return Arrays.asList(arrayOfString = new String[] { "@@CONNECTIONS", "@@CPU_BUSY", "@@CURSOR_ROWS", "@@DATEFIRST", "@@DBTS", "@@ERROR", "@@FETCH_STATUS", "@@IDENTITY", "@@IDLE", "@@IO_BUSY", "@@LANGID", "@@LANGUAGE", "@@LOCK_TIMEOUT", "@@MAX_CONNECTIONS", "@@MAX_PRECISION", "@@NESTLEVEL", "@@OPTIONS", "@@PACKET_ERRORS", "@@PACK_RECEIVED", "@@PACK_SENT", "@@PROCID", "@@REMSERVER", "@@ROWCOUNT", "@@SERVERNAME", "@@SERVICENAME", "@@SPID", "@@TEXTSIZE", "@@TIMETICKS", "@@TOTAL_ERRORS", "@@TOTAL_READ", "@@TOTAL_WRITE", "@@TRANCOUNT", "@@VERSION", "ABS", "ACOS", "APP_NAME", "ASCII", "ASIN", "ATAN", "ATN2", "AVG", "BINARY_CHECKSUM", "CASE", "CAST", "CEILING", "CHAR", "CHARINDEX", "CHECKSUM", "CHECKSUM_AGG", "COALESCE", "COLLATIONPROPERTY", "COLUMNPROPERTY", "COL_LENGTH", "COL_NAME", "CONTAINSTABLE", "CONVERT", "COS", "COT", "COUNT", "COUNT_BIG", "CURRENT_TIMESTAMP", "CURRENT_USER", "CURSOR_STATUS", "DATABASEPROPERTY", "DATABASEPROPERTYEX", "DATALENGTH", "DATEADD", "DATEDIFF", "DATENAME", "DATEPART", "DAY", "DB_ID", "DB_NAME", "DEGREES", "DIFFERENCE", "EXP", "FILEGROUPPROPERTY", "FILEGROUP_ID", "FILEGROUP_NAME", "FILEPROPERTY", "FILE_ID", "FILE_NAME", "FLOOR", "FN_HELPCOLLATIONS", "FN_LISTEXTENDEDPROPERTY", "FN_SERVERSHAREDDRIVES", "FN_TRACE_GETEVENTINFO", "FN_TRACE_GETFILTERINFO", "FN_TRACE_GETINFO", "FN_TRACE_GETTABLE", "FN_VIRTUALFILESTATS", "FN_VIRTUALFILESTATS", "FORMATMESSAGE", "FREETEXTTABLE", "FULLTEXTCATALOGPROPERTY", "FULLTEXTSERVICEPROPERTY", "GETANSINULL", "GETDATE", "GETUTCDATE", "GROUPING", "HAS_DBACCESS", "HOST_ID", "HOST_NAME", "IDENTITY", "IDENT_CURRENT", "IDENT_INCR", "IDENT_SEED", "INDEXKEY_PROPERTY", "INDEXPROPERTY", "INDEX_COL", "ISDATE", "ISNULL", "ISNUMERIC", "IS_MEMBER", "IS_SRVROLEMEMBER", "LEFT", "LEN", "LOG", "LOG10", "LOWER", "LTRIM", "MAX", "MIN", "MONTH", "NCHAR", "NEWID", "NULLIF", "OBJECTPROPERTY", "OBJECT_ID", "OBJECT_NAME", "OPENDATASOURCE", "OPENQUERY", "OPENROWSET", "OPENXML", "PARSENAME", "PATINDEX", "PATINDEX", "PERMISSIONS", "PI", "POWER", "QUOTENAME", "RADIANS", "RAND", "REPLACE", "REPLICATE", "REVERSE", "RIGHT", "ROUND", "ROWCOUNT_BIG", "RTRIM", "SCOPE_IDENTITY", "SERVERPROPERTY", "SESSIONPROPERTY", "SESSION_USER", "SIGN", "SIN", "SOUNDEX", "SPACE", "SQL_VARIANT_PROPERTY", "SQRT", "SQUARE", "STATS_DATE", "STDEV", "STDEVP", "STR", "STUFF", "SUBSTRING", "SUM", "SUSER_SID", "SUSER_SNAME", "SYSTEM_USER", "TAN", "TEXTPTR", "TEXTVALID", "TYPEPROPERTY", "UNICODE", "UPPER", "USER", "USER_ID", "USER_NAME", "VAR", "VARP", "YEAR" }).contains(paramString.toUpperCase());
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\output\html\HtmlRenderUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */