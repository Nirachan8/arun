package gudusoft.gsqlparser.pp.output;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.pp.output.html.HtmlOutputConfig;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.GOutputFmt;

public class OutputConfigFactory
{
  public static OutputConfig getOutputConfig(GFmtOpt paramGFmtOpt, EDbVendor paramEDbVendor)
  {
    if ((GOutputFmt.ofSql.equals(paramGFmtOpt.outputFmt)) || (GOutputFmt.ofUnknown.equals(paramGFmtOpt.outputFmt))) {
      return null;
    }
    if (GOutputFmt.ofhtml.equals(paramGFmtOpt.outputFmt)) {
      return new HtmlOutputConfig(paramGFmtOpt, paramEDbVendor);
    }
    throw new UnsupportedOperationException("Not implemented yet");
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\output\OutputConfigFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */