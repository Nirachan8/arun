package gudusoft.gsqlparser.pp.output;

public enum HighlightingElement
{
  private HighlightingElement() {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\output\HighlightingElement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */