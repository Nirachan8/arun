package gudusoft.gsqlparser.pp.output;

import gudusoft.gsqlparser.TSourceToken;

public abstract interface OutputConfig
{
  public abstract void addHighlightingElementRender(HighlightingElement paramHighlightingElement, HighlightingElementRender paramHighlightingElementRender);
  
  public abstract boolean containsHighlightingElementRender(HighlightingElement paramHighlightingElement);
  
  public abstract void removeHighlightingElementRender(HighlightingElement paramHighlightingElement);
  
  public abstract HighlightingElementRender getHighlightingElementRender(HighlightingElement paramHighlightingElement);
  
  public abstract String renderHighlightingElement(TSourceToken paramTSourceToken);
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\output\OutputConfig.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */