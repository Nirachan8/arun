package gudusoft.gsqlparser.pp.output;

public abstract interface HighlightingElementRender
{
  public abstract String render(String paramString);
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\output\HighlightingElementRender.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */