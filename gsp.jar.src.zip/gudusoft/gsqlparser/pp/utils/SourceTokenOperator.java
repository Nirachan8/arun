package gudusoft.gsqlparser.pp.utils;

import gudusoft.gsqlparser.ETokenType;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.pp.logger.PPLogger;
import gudusoft.gsqlparser.pp.para.GFmtOpt;

public class SourceTokenOperator
{
  private static TSourceToken a = null;
  
  public static int removeWhitespaceBackward(GFmtOpt paramGFmtOpt, TSourceTokenList paramTSourceTokenList, int paramInt)
  {
    if (paramInt == 0) {
      return 0;
    }
    StringBuilder localStringBuilder;
    (localStringBuilder = new StringBuilder()).append("removeWhitespaceAndReturnFromEnd:\ntargetToken:").append(paramTSourceTokenList.get(paramInt).astext).append(" newToken:").append(paramTSourceTokenList.get(paramInt).astext.replaceAll("\\n", "\\\\n")).append("(type:").append(paramTSourceTokenList.get(paramInt).tokentype).append(")");
    int i = 0;
    paramInt -= 1;
    for (paramTSourceTokenList = paramTSourceTokenList.get(paramInt); paramTSourceTokenList.tokentype == ETokenType.ttwhitespace; paramTSourceTokenList = paramTSourceTokenList.container.get(paramInt))
    {
      if (paramTSourceTokenList.tokentype == ETokenType.ttwhitespace) {
        i++;
      }
      if (paramGFmtOpt.opearateSourceToken) {
        paramTSourceTokenList.setReplaceToken(SourceTokenConstant.EMPTY);
      }
      paramInt--;
      if (paramInt < 0) {
        break;
      }
    }
    if (paramTSourceTokenList.tokentype == ETokenType.ttreturn)
    {
      paramGFmtOpt = new StringBuilder();
      for (int j = 0; j < paramTSourceTokenList.astext.length(); j++)
      {
        char c;
        if ((c = paramTSourceTokenList.astext.charAt(j)) != ' ') {
          paramGFmtOpt.append(c);
        }
      }
      paramTSourceTokenList.astext = paramGFmtOpt.toString();
    }
    localStringBuilder.append("\nDeleteWhiteSpace:").append(i);
    PPLogger.info(2, localStringBuilder.toString(), null);
    return paramInt;
  }
  
  public static int removeWhitespaceAndReturnFromEnd(GFmtOpt paramGFmtOpt, TSourceTokenList paramTSourceTokenList, int paramInt)
  {
    if (paramInt == 0) {
      return 0;
    }
    StringBuilder localStringBuilder;
    (localStringBuilder = new StringBuilder()).append("removeWhitespaceAndReturnFromEnd:\ntargetToken:").append(paramTSourceTokenList.get(paramInt).astext).append(" newToken:").append(paramTSourceTokenList.get(paramInt).astext.replaceAll("\\n", "\\\\n")).append("(type:").append(paramTSourceTokenList.get(paramInt).tokentype).append(")");
    int i = 0;
    int j = 0;
    paramInt -= 1;
    for (paramTSourceTokenList = paramTSourceTokenList.get(paramInt); (paramTSourceTokenList.tokentype == ETokenType.ttwhitespace) || (paramTSourceTokenList.tokentype == ETokenType.ttreturn); paramTSourceTokenList = paramTSourceTokenList.container.get(paramInt))
    {
      if (paramTSourceTokenList.tokentype == ETokenType.ttwhitespace) {
        i++;
      }
      if (paramTSourceTokenList.tokentype == ETokenType.ttreturn) {
        j++;
      }
      if (paramGFmtOpt.opearateSourceToken) {
        paramTSourceTokenList.setReplaceToken(SourceTokenConstant.EMPTY);
      }
      paramInt--;
      if (paramInt < 0) {
        break;
      }
    }
    localStringBuilder.append("\nDeleteWhiteSpace:").append(i).append(", DeleteReturn:").append(j);
    PPLogger.info(2, localStringBuilder.toString(), null);
    return paramInt;
  }
  
  public static int removeWhitespaceAndReturnFromEnd(GFmtOpt paramGFmtOpt, TSourceToken paramTSourceToken)
  {
    if (paramTSourceToken == null) {
      return -1;
    }
    return removeWhitespaceAndReturnFromEnd(paramGFmtOpt, paramTSourceToken.container, paramTSourceToken.posinlist);
  }
  
  public static void removeWhitespaceAndReturnFormBeforeAndAfter(GFmtOpt paramGFmtOpt, TSourceToken paramTSourceToken)
  {
    if (paramTSourceToken == null) {
      return;
    }
    removeWhitespaceAndReturnFromEnd(paramGFmtOpt, paramTSourceToken);
    removeWhitespaceAndReturnFromStart(paramGFmtOpt, paramTSourceToken.container, paramTSourceToken.posinlist + 1);
  }
  
  public static void removeWhitespaceAndReturn(GFmtOpt paramGFmtOpt, TSourceTokenList paramTSourceTokenList, int paramInt1, int paramInt2)
  {
    StringBuilder localStringBuilder;
    (localStringBuilder = new StringBuilder()).append("removeWhitespaceAndReturn:\ntargetToken:").append(paramTSourceTokenList.get(paramInt2).astext).append(" newToken:").append(paramTSourceTokenList.get(paramInt2).astext.replaceAll("\\n", "\\\\n")).append("(type:").append(paramTSourceTokenList.get(paramInt2).tokentype).append(")");
    int i = 0;
    int j = 0;
    for (paramInt1 = paramInt1; paramInt1 < paramInt2; paramInt1++)
    {
      if ((paramInt1 < 0) || (paramInt1 > paramTSourceTokenList.size())) {
        return;
      }
      TSourceToken localTSourceToken;
      if (((localTSourceToken = paramTSourceTokenList.get(paramInt1)).tokentype == ETokenType.ttwhitespace) || (localTSourceToken.tokentype == ETokenType.ttreturn))
      {
        if (localTSourceToken.tokentype == ETokenType.ttwhitespace) {
          i++;
        }
        if (localTSourceToken.tokentype == ETokenType.ttreturn) {
          j++;
        }
        if (paramGFmtOpt.opearateSourceToken) {
          localTSourceToken.setReplaceToken(SourceTokenConstant.EMPTY);
        }
      }
    }
    localStringBuilder.append("\nDeleteWhiteSpace:").append(i).append(", DeleteReturn:").append(j);
    PPLogger.info(2, localStringBuilder.toString(), null);
  }
  
  public static int removeWhitespaceAndReturnFromStart(GFmtOpt paramGFmtOpt, TSourceTokenList paramTSourceTokenList, int paramInt)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if (paramTSourceTokenList.size() <= paramInt) {
      return paramTSourceTokenList.size() - 1;
    }
    localStringBuilder.append("removeWhitespaceAndReturnFromStart:\ntargetToken:").append(paramTSourceTokenList.get(paramInt).astext).append(" newToken:").append(paramTSourceTokenList.get(paramInt).astext.replaceAll("\\n", "\\\\n")).append("(type:").append(paramTSourceTokenList.get(paramInt).tokentype).append(")");
    int i = 0;
    int j = 0;
    int k = paramInt;
    for (paramInt = paramTSourceTokenList.get(paramInt); (paramInt.tokentype == ETokenType.ttwhitespace) || (paramInt.tokentype == ETokenType.ttreturn); paramInt = paramInt.container.get(k))
    {
      if (paramInt.tokentype == ETokenType.ttwhitespace) {
        i++;
      }
      if (paramInt.tokentype == ETokenType.ttreturn) {
        j++;
      }
      if (paramGFmtOpt.opearateSourceToken) {
        paramInt.setReplaceToken(SourceTokenConstant.EMPTY);
      }
      k++;
      if (k >= paramTSourceTokenList.size()) {
        break;
      }
    }
    localStringBuilder.append("\nDeleteWhiteSpace:").append(i).append(", DeleteReturn:").append(j);
    PPLogger.info(2, localStringBuilder.toString(), null);
    return k;
  }
  
  public static int textLengthVT(TSourceTokenList paramTSourceTokenList, int paramInt1, int paramInt2)
  {
    int i = 0;
    for (paramInt1 = paramInt1; paramInt1 < paramInt2; paramInt1++)
    {
      TSourceToken localTSourceToken;
      if ((localTSourceToken = paramTSourceTokenList.get(paramInt1)).getTokensBefore().size() > 0) {
        i += textLengthVT(localTSourceToken.getTokensBefore(), 0, localTSourceToken.getTokensBefore().size());
      }
      if (localTSourceToken.getReplaceToken() != null) {
        i += (localTSourceToken.getReplaceToken().astext != null ? localTSourceToken.getReplaceToken().astext.length() : 0);
      } else {
        i += (localTSourceToken.astext != null ? localTSourceToken.astext.length() : 0);
      }
      if (localTSourceToken.getTokensAfter().size() > 0) {
        i += textLengthVT(localTSourceToken.getTokensAfter(), 0, localTSourceToken.getTokensAfter().size());
      }
    }
    return i;
  }
  
  public static int curColumnNumberVT(TSourceTokenList paramTSourceTokenList, int paramInt)
  {
    int i = 0;
    for (int j = paramInt; j >= 0; j--)
    {
      TSourceToken localTSourceToken1 = paramTSourceTokenList.get(j);
      int k;
      TSourceToken localTSourceToken2;
      if ((j != paramInt) && (localTSourceToken1.getTokensAfter().size() > 0)) {
        for (k = localTSourceToken1.getTokensAfter().size() - 1; k >= 0; k--) {
          if ((localTSourceToken2 = localTSourceToken1.getTokensAfter().get(k)).tokentype != ETokenType.ttreturn) {
            i += (localTSourceToken2.astext != null ? localTSourceToken2.astext.length() : 0);
          } else {
            return i;
          }
        }
      }
      if (j != paramInt) {
        if (localTSourceToken1.getReplaceToken() != null)
        {
          if (localTSourceToken1.getReplaceToken().tokentype != ETokenType.ttreturn) {
            i += (localTSourceToken1.getReplaceToken().astext != null ? localTSourceToken1.getReplaceToken().astext.length() : 0);
          } else {
            return i;
          }
        }
        else if (localTSourceToken1.tokentype != ETokenType.ttreturn) {
          i += (localTSourceToken1.astext != null ? localTSourceToken1.astext.length() : 0);
        } else {
          return i;
        }
      }
      if (localTSourceToken1.getTokensBefore().size() > 0) {
        for (k = localTSourceToken1.getTokensBefore().size() - 1; k >= 0; k--) {
          if ((localTSourceToken2 = localTSourceToken1.getTokensBefore().get(k)).tokentype != ETokenType.ttreturn) {
            i += (localTSourceToken2.astext != null ? localTSourceToken2.astext.length() : 0);
          } else {
            return i;
          }
        }
      }
    }
    return i;
  }
  
  public static int curColumnNumberVT(TSourceToken paramTSourceToken)
  {
    return curColumnNumberVT(paramTSourceToken.container, paramTSourceToken.posinlist);
  }
  
  public static int curIndentLenVT(TSourceTokenList paramTSourceTokenList, int paramInt)
  {
    int i = 0;
    for (int j = paramInt; j >= 0; j--)
    {
      TSourceToken localTSourceToken1 = paramTSourceTokenList.get(j);
      int k;
      TSourceToken localTSourceToken2;
      if ((j != paramInt) && (localTSourceToken1.getTokensAfter().size() > 0)) {
        for (k = localTSourceToken1.getTokensAfter().size() - 1; k >= 0; k--)
        {
          if ((localTSourceToken2 = localTSourceToken1.getTokensAfter().get(k)).tokentype == ETokenType.ttreturn) {
            return i;
          }
          if (localTSourceToken2.tokentype == ETokenType.ttwhitespace) {
            i += (localTSourceToken2.astext != null ? localTSourceToken2.astext.length() : 0);
          } else {
            i = 0;
          }
        }
      }
      if (j != paramInt) {
        if (localTSourceToken1.getReplaceToken() != null)
        {
          if (localTSourceToken1.getReplaceToken().tokentype == ETokenType.ttreturn) {
            return i;
          }
          if (localTSourceToken1.getReplaceToken().tokentype == ETokenType.ttwhitespace) {
            i += (localTSourceToken1.getReplaceToken().astext != null ? localTSourceToken1.getReplaceToken().astext.length() : 0);
          } else {
            i = 0;
          }
        }
        else
        {
          if (localTSourceToken1.tokentype == ETokenType.ttreturn) {
            return i;
          }
          if (localTSourceToken1.tokentype == ETokenType.ttwhitespace) {
            i += (localTSourceToken1.astext != null ? localTSourceToken1.astext.length() : 0);
          } else {
            i = 0;
          }
        }
      }
      if (localTSourceToken1.getTokensBefore().size() > 0) {
        for (k = localTSourceToken1.getTokensBefore().size() - 1; k >= 0; k--)
        {
          if ((localTSourceToken2 = localTSourceToken1.getTokensBefore().get(k)).tokentype == ETokenType.ttreturn) {
            return i;
          }
          if (localTSourceToken2.tokentype == ETokenType.ttwhitespace) {
            i += (localTSourceToken2.astext != null ? localTSourceToken2.astext.length() : 0);
          } else {
            i = 0;
          }
        }
      }
    }
    return i;
  }
  
  public static int curIndentLenVT(TSourceToken paramTSourceToken)
  {
    return curIndentLenVT(paramTSourceToken.container, paramTSourceToken.posinlist);
  }
  
  public static TSourceToken createWhitespaceSourceToken(int paramInt)
  {
    return a.a(paramInt);
  }
  
  public static TSourceToken createNoFormatFlagToken()
  {
    return a;
  }
  
  public static TSourceToken createReturnSourceToken()
  {
    TSourceToken localTSourceToken;
    (localTSourceToken = new TSourceToken("\n")).tokentype = ETokenType.ttreturn;
    return localTSourceToken;
  }
  
  public static void combineWhitespace(TSourceTokenList paramTSourceTokenList, int paramInt1, int paramInt2)
  {
    int i = 0;
    for (paramInt1 = paramInt1; paramInt1 < paramInt2; paramInt1++)
    {
      TSourceToken localTSourceToken;
      if ((paramInt1 >= 0) && (paramInt1 < paramTSourceTokenList.size()) && ((localTSourceToken = paramTSourceTokenList.get(paramInt1)).tokentype == ETokenType.ttwhitespace))
      {
        localTSourceToken.setReplaceToken(SourceTokenConstant.EMPTY);
        i = 1;
      }
    }
    if (i != 0) {
      paramTSourceTokenList.get(paramInt2).getTokensBefore().add(createWhitespaceSourceToken(1));
    }
  }
  
  public static void addBefore(GFmtOpt paramGFmtOpt, TSourceToken paramTSourceToken1, TSourceToken paramTSourceToken2)
  {
    if (paramTSourceToken2 == null) {
      return;
    }
    StringBuilder localStringBuilder;
    (localStringBuilder = new StringBuilder()).append("AddBefore:\ntargetToken:").append(paramTSourceToken1.astext).append("(pos:").append(paramTSourceToken1.posinlist).append(")").append(" newToken:").append(paramTSourceToken2.astext.replaceAll("\\n", "\\\\n")).append("(type:").append(paramTSourceToken2.tokentype).append(")");
    if (paramTSourceToken1.getTokensBefore().size() > 0)
    {
      localStringBuilder.append("\noldTokenBefore:");
      for (int i = 0; i < paramTSourceToken1.getTokensBefore().size(); i++)
      {
        TSourceToken localTSourceToken = paramTSourceToken1.getTokensBefore().get(i);
        localStringBuilder.append("[").append(localTSourceToken.astext != null ? localTSourceToken.astext.replaceAll("\\n", "\\\\n") : "").append("] ").append("(type:").append(localTSourceToken.tokentype).append(")");
      }
    }
    PPLogger.info(2, localStringBuilder.toString(), null);
    if (paramGFmtOpt.opearateSourceToken) {
      paramTSourceToken1.getTokensBefore().add(paramTSourceToken2);
    }
  }
  
  public static void addAfter(GFmtOpt paramGFmtOpt, TSourceToken paramTSourceToken1, TSourceToken paramTSourceToken2)
  {
    if (paramTSourceToken2 == null) {
      return;
    }
    StringBuilder localStringBuilder;
    (localStringBuilder = new StringBuilder()).append("AddAfter:\ntargetToken:").append(paramTSourceToken1.astext).append("(pos:").append(paramTSourceToken1.posinlist).append(")").append(" newToken:").append(paramTSourceToken2.astext != null ? paramTSourceToken2.astext.replaceAll("\\n", "\\\\n") : "").append("(type:").append(paramTSourceToken2.tokentype).append(")");
    if (paramTSourceToken1.getTokensAfter().size() > 0)
    {
      localStringBuilder.append("\noldTokenAfter:");
      for (int i = 0; i < paramTSourceToken1.getTokensAfter().size(); i++)
      {
        TSourceToken localTSourceToken = paramTSourceToken1.getTokensAfter().get(i);
        localStringBuilder.append("[").append(localTSourceToken.astext != null ? localTSourceToken.astext.replaceAll("\\n", "\\\\n") : "").append("] ").append("(type:").append(localTSourceToken.tokentype).append(")");
      }
    }
    PPLogger.info(2, localStringBuilder.toString(), null);
    if (paramGFmtOpt.opearateSourceToken) {
      paramTSourceToken1.getTokensAfter().add(paramTSourceToken2);
    }
  }
  
  public static void removeAllBeforeTokenVT(GFmtOpt paramGFmtOpt, TSourceToken paramTSourceToken)
  {
    StringBuilder localStringBuilder;
    (localStringBuilder = new StringBuilder()).append("RemoveAllBeforeTokenVT:");
    while (paramTSourceToken.getTokensBefore().size() > 0)
    {
      TSourceToken localTSourceToken = paramTSourceToken.getTokensBefore().get(0);
      localStringBuilder.append("\nremoveToken:").append("[").append(localTSourceToken.astext != null ? localTSourceToken.astext.replaceAll("\\n", "\\\\n") : "").append("] ").append("(type:").append(localTSourceToken.tokentype).append(")");
      if (paramGFmtOpt.opearateSourceToken) {
        paramTSourceToken.getTokensBefore().remove(0);
      }
    }
    PPLogger.info(2, localStringBuilder.toString(), null);
  }
  
  public static void removeThisToken(TSourceToken paramTSourceToken)
  {
    paramTSourceToken.setReplaceToken(createWhitespaceSourceToken(1));
  }
  
  static
  {
    (a = new TSourceToken("")).tokentype = ETokenType.ttwhitespace;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\utils\SourceTokenOperator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */