package gudusoft.gsqlparser.pp.utils;

import gudusoft.gsqlparser.ETokenType;
import gudusoft.gsqlparser.TSourceToken;

public class SourceTokenConstant
{
  public static final TSourceToken RETURN2 = new TSourceToken("\n");
  public static final TSourceToken EMPTY = new TSourceToken("");
  public static final TSourceToken WHITESPACE;
  
  static
  {
    (WHITESPACE = new TSourceToken(" ")).tokentype = ETokenType.ttwhitespace;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\utils\SourceTokenConstant.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */