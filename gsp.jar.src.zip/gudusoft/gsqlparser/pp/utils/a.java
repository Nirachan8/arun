package gudusoft.gsqlparser.pp.utils;

import gudusoft.gsqlparser.ETokenType;
import gudusoft.gsqlparser.TSourceToken;
import java.util.Arrays;

final class a
{
  public static TSourceToken a(int paramInt)
  {
    if (paramInt == 0) {
      return null;
    }
    if (paramInt <= 32) {
      return a.a[(paramInt - 1)];
    }
    char[] arrayOfChar;
    Arrays.fill(arrayOfChar = new char[paramInt], 0, paramInt, ' ');
    (paramInt = new TSourceToken(String.copyValueOf(arrayOfChar))).tokentype = ETokenType.ttwhitespace;
    return paramInt;
  }
  
  private static class a
  {
    static final TSourceToken[] a = new TSourceToken[32];
    
    static
    {
      char[] arrayOfChar;
      Arrays.fill(arrayOfChar = new char[32], 0, 32, ' ');
      for (int i = 0; i < a.length; i++)
      {
        a[i] = new TSourceToken(String.copyValueOf(arrayOfChar, 0, i + 1));
        a[i].tokentype = ETokenType.ttwhitespace;
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\utils\a.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */