package gudusoft.gsqlparser.pp.utils;

public class SourceTokenNameConstant
{
  public static final String DISTINCT = "distinct";
  public static final String AS = "as";
  public static final String FROM = "from";
  public static final String SELECT = "select";
  public static final String GROUP = "group";
  public static final String ORDER = "order";
  public static final String BY = "by";
  public static final String WHERE = "where";
  public static final String VALUES = "values";
  public static final String INSERT = "insert";
  public static final String INTO = "into";
  public static final String ALL = "all";
  public static final String FIRST = "first";
  public static final String DELETE = "delete";
  public static final String UPDATE = "update";
  public static final String DECLARE = "declare";
  public static final String JOIN = "join";
  public static final String ON = "on";
  public static final String UNION = "union";
  public static final String OR = "or";
  public static final String AND = "and";
  public static final String CASE = "case";
  public static final String WHEN = "when";
  public static final String THEN = "then";
  public static final String ELSE = "else";
  public static final String END = "end";
  public static final String SET = "set";
  public static final String HAVING = "having";
  public static final String WITH = "with";
  public static final String LEFT_BE = "(";
  public static final String RIGHT_BE = ")";
  public static final String BEGIN_NO_FORMAT = "--begin_no_format";
  public static final String END_NO_FORMAT = "--end_no_format";
  public static final String RETURNS = "returns";
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\utils\SourceTokenNameConstant.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */