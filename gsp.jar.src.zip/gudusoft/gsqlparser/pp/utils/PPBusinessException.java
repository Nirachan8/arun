package gudusoft.gsqlparser.pp.utils;

public class PPBusinessException
  extends RuntimeException
{
  public PPBusinessException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\utils\PPBusinessException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */