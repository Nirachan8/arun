package gudusoft.gsqlparser.pp.utils;

import gudusoft.gsqlparser.ETokenType;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;

public class SourceTokenSearcher
{
  public static int indexOf(TSourceTokenList paramTSourceTokenList, int paramInt1, int paramInt2, String paramString)
  {
    if (paramString == null) {
      return -1;
    }
    for (paramInt1 = paramInt1; paramInt1 < paramInt2; paramInt1++) {
      if ((paramInt1 >= 0) && (paramInt1 < paramTSourceTokenList.size()))
      {
        if ((paramTSourceTokenList.get(paramInt1).astext != null) && (paramTSourceTokenList.get(paramInt1).astext.trim().equalsIgnoreCase(paramString))) {
          return paramInt1;
        }
      }
      else {
        return -1;
      }
    }
    return -1;
  }
  
  public static int indexOf(TSourceTokenList paramTSourceTokenList, int paramInt1, int paramInt2, ETokenType paramETokenType)
  {
    for (paramInt1 = paramInt1; paramInt1 < paramInt2; paramInt1++) {
      if ((paramInt1 >= 0) && (paramInt1 < paramTSourceTokenList.size()))
      {
        if (paramETokenType == paramTSourceTokenList.get(paramInt1).tokentype) {
          return paramInt1;
        }
      }
      else {
        return -1;
      }
    }
    return -1;
  }
  
  public static int indexOf(TSourceTokenList paramTSourceTokenList, int paramInt, String paramString)
  {
    return indexOf(paramTSourceTokenList, paramInt, paramTSourceTokenList.size() - 1, paramString);
  }
  
  public static TSourceToken backforwardSearch(TSourceToken paramTSourceToken, int paramInt, String paramString)
  {
    if ((paramInt = lastIndexOf(paramTSourceToken.container, paramTSourceToken.posinlist - paramInt, paramTSourceToken.posinlist, paramString)) == -1) {
      return null;
    }
    return paramTSourceToken.container.get(paramInt);
  }
  
  public static TSourceToken forwardSearch(TSourceToken paramTSourceToken, int paramInt, String paramString)
  {
    if ((paramInt = indexOf(paramTSourceToken.container, paramTSourceToken.posinlist, paramTSourceToken.posinlist + paramInt, paramString)) == -1) {
      return null;
    }
    return paramTSourceToken.container.get(paramInt);
  }
  
  public static int lastIndexOf(TSourceTokenList paramTSourceTokenList, int paramInt1, int paramInt2, String paramString)
  {
    if (paramString == null) {
      return -1;
    }
    if (paramInt1 < 0) {
      paramInt1 = 0;
    }
    if (paramInt2 - 1 > paramTSourceTokenList.size()) {
      paramInt2 = paramTSourceTokenList.size();
    }
    paramInt2 -= 1;
    while (paramInt2 >= paramInt1)
    {
      if ((paramInt2 >= 0) && (paramInt2 < paramTSourceTokenList.size()))
      {
        if ((paramTSourceTokenList.get(paramInt2).astext != null) && (paramTSourceTokenList.get(paramInt2).astext.trim().equalsIgnoreCase(paramString))) {
          return paramInt2;
        }
      }
      else {
        return -1;
      }
      paramInt2--;
    }
    return -1;
  }
  
  public static int lastIndexOf(TSourceTokenList paramTSourceTokenList, int paramInt, String paramString)
  {
    return lastIndexOf(paramTSourceTokenList, 0, paramInt, paramString);
  }
  
  public static TSourceToken lastNotWhitespaceAndReturnToken(TSourceTokenList paramTSourceTokenList, int paramInt1, int paramInt2)
  {
    paramInt2 -= 1;
    while (paramInt2 >= paramInt1)
    {
      if ((paramInt2 >= 0) && (paramInt2 < paramTSourceTokenList.size()))
      {
        if ((paramTSourceTokenList.get(paramInt2).tokentype != ETokenType.ttwhitespace) && (paramTSourceTokenList.get(paramInt2).tokentype != ETokenType.ttreturn) && (paramTSourceTokenList.get(paramInt2).tokentype != ETokenType.ttsimplecomment) && (paramTSourceTokenList.get(paramInt2).tokentype != ETokenType.ttbracketedcomment)) {
          return paramTSourceTokenList.get(paramInt2);
        }
      }
      else {
        return null;
      }
      paramInt2--;
    }
    return null;
  }
  
  public static TSourceToken lastNotWhitespaceAndReturnToken(TSourceTokenList paramTSourceTokenList, int paramInt)
  {
    return lastNotWhitespaceAndReturnToken(paramTSourceTokenList, 0, paramInt);
  }
  
  public static TSourceToken lastSelectedNotWhitespaceAndReturnToken(TSourceTokenList paramTSourceTokenList, int paramInt, String paramString)
  {
    if (((paramTSourceTokenList = lastNotWhitespaceAndReturnToken(paramTSourceTokenList, paramInt)) != null) && (paramTSourceTokenList.astext != null) && (paramTSourceTokenList.astext.trim().equalsIgnoreCase(paramString))) {
      return paramTSourceTokenList;
    }
    return null;
  }
  
  public static TSourceToken firstNotWhitespaceAndReturnToken(TSourceTokenList paramTSourceTokenList, int paramInt1, int paramInt2)
  {
    for (paramInt1 = paramInt1; paramInt1 < paramInt2; paramInt1++) {
      if ((paramInt1 >= 0) && (paramInt1 < paramTSourceTokenList.size()))
      {
        if ((paramTSourceTokenList.get(paramInt1).tokentype != ETokenType.ttwhitespace) && (paramTSourceTokenList.get(paramInt1).tokentype != ETokenType.ttreturn) && (paramTSourceTokenList.get(paramInt1).tokentype != ETokenType.ttsimplecomment) && (paramTSourceTokenList.get(paramInt1).tokentype != ETokenType.ttbracketedcomment)) {
          return paramTSourceTokenList.get(paramInt1);
        }
      }
      else {
        return null;
      }
    }
    return null;
  }
  
  public static TSourceToken firstSelectNotWhitespaceAndReturnToken(TSourceTokenList paramTSourceTokenList, int paramInt, String paramString)
  {
    for (paramInt = paramInt; paramInt < paramTSourceTokenList.size(); paramInt++)
    {
      TSourceToken localTSourceToken;
      if ((paramInt >= 0) && (paramInt < paramTSourceTokenList.size()) && ((localTSourceToken = paramTSourceTokenList.get(paramInt)).tokentype != ETokenType.ttwhitespace) && (localTSourceToken.tokentype != ETokenType.ttreturn) && (paramTSourceTokenList.get(paramInt).tokentype != ETokenType.ttsimplecomment) && (paramTSourceTokenList.get(paramInt).tokentype != ETokenType.ttbracketedcomment))
      {
        if ((localTSourceToken.astext != null) && (localTSourceToken.astext.trim().equalsIgnoreCase(paramString))) {
          return localTSourceToken;
        }
        return null;
      }
    }
    return null;
  }
  
  public static TSourceToken lastSelectedNotWhitespaceAndReturnToken(TSourceToken paramTSourceToken, String paramString)
  {
    if (paramTSourceToken == null) {
      return null;
    }
    return lastSelectedNotWhitespaceAndReturnToken(paramTSourceToken.container, paramTSourceToken.posinlist, paramString);
  }
  
  public static boolean isNewLineToken(TSourceToken paramTSourceToken)
  {
    return (paramTSourceToken != null) && (paramTSourceToken.tokentype == ETokenType.ttreturn);
  }
  
  public static boolean isSimpleComment(TSourceToken paramTSourceToken)
  {
    return (paramTSourceToken != null) && (paramTSourceToken.tokentype == ETokenType.ttsimplecomment);
  }
  
  public static TSourceToken backforwardSearchNotWhitespaceAndReturnToken(TSourceToken paramTSourceToken, int paramInt, String paramString)
  {
    paramTSourceToken = paramTSourceToken;
    while (paramInt > 0)
    {
      if (((paramTSourceToken = lastNotWhitespaceAndReturnToken(paramTSourceToken.container, paramTSourceToken.posinlist)) != null) && (paramTSourceToken.astext != null) && (paramTSourceToken.astext.trim().equalsIgnoreCase(paramString))) {
        return paramTSourceToken;
      }
      paramInt--;
    }
    return null;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\utils\SourceTokenSearcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */