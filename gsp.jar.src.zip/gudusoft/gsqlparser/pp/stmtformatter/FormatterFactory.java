package gudusoft.gsqlparser.pp.stmtformatter;

import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TGSqlParser;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.pp.mediator.MediatorFactory;
import gudusoft.gsqlparser.pp.output.OutputConfig;
import gudusoft.gsqlparser.pp.output.OutputConfigFactory;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.styleenums.TCompactMode;
import gudusoft.gsqlparser.pp.print.IPrinter;
import gudusoft.gsqlparser.pp.print.PrinterFactory;
import gudusoft.gsqlparser.pp.print.TextPrinter;
import gudusoft.gsqlparser.pp.processor.ProcessorFactory;
import gudusoft.gsqlparser.pp.stmtformatter.builder.AbstractStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.AllStmtsFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.AlterTableStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.CompactModeStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.CreateFunctionStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.CreateTableStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.CreateViewStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.DeclareStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.DeleteStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.ExecuteStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.GoStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.IfStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.InsertStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.ReturnStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.SelectStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.SetStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.builder.comm.UpdateStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.AllStmtsFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.AlterTableStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.CompactModeStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.CreateFunctionStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.CreateTableStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.CreateViewStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.DeclareStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.DeleteStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.ExecuteStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.GoStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.IfStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.InsertStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.ReturnStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.SelectStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.SetStmtFormatter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.UpdateStmtFormatter;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.stmt.TAlterTableStatement;
import gudusoft.gsqlparser.stmt.TCreateTableSqlStatement;
import gudusoft.gsqlparser.stmt.TCreateViewSqlStatement;
import gudusoft.gsqlparser.stmt.TDeleteSqlStatement;
import gudusoft.gsqlparser.stmt.TInsertSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import gudusoft.gsqlparser.stmt.TStoredProcedureSqlStatement;
import gudusoft.gsqlparser.stmt.TUpdateSqlStatement;
import gudusoft.gsqlparser.stmt.mssql.TMssqlBlock;
import gudusoft.gsqlparser.stmt.mssql.TMssqlDeclare;
import gudusoft.gsqlparser.stmt.mssql.TMssqlExecute;
import gudusoft.gsqlparser.stmt.mssql.TMssqlGo;
import gudusoft.gsqlparser.stmt.mssql.TMssqlIfElse;
import gudusoft.gsqlparser.stmt.mssql.TMssqlReturn;
import gudusoft.gsqlparser.stmt.mssql.TMssqlSet;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class FormatterFactory
{
  private static volatile Map<String, AbstractStmtFormatter> a = new Hashtable();
  private static OutputConfig b;
  
  public static SelectStmtFormatter createSelectStmtFormatter(GFmtOpt paramGFmtOpt)
  {
    (SelectStmtFormatter)createFormatter(paramGFmtOpt, SelectStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<SelectStmtFormatter> create()
      {
        return new SelectStmtFormatterBuilder();
      }
    });
  }
  
  public static InsertStmtFormatter createInsertStmtFormatter(GFmtOpt paramGFmtOpt)
  {
    (InsertStmtFormatter)createFormatter(paramGFmtOpt, InsertStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<InsertStmtFormatter> create()
      {
        return new InsertStmtFormatterBuilder();
      }
    });
  }
  
  public static DeleteStmtFormatter createDeleteStmtFormatter(GFmtOpt paramGFmtOpt)
  {
    (DeleteStmtFormatter)createFormatter(paramGFmtOpt, DeleteStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<DeleteStmtFormatter> create()
      {
        return new DeleteStmtFormatterBuilder();
      }
    });
  }
  
  public static UpdateStmtFormatter createUpdateStmtFormatter(GFmtOpt paramGFmtOpt)
  {
    (UpdateStmtFormatter)createFormatter(paramGFmtOpt, UpdateStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<UpdateStmtFormatter> create()
      {
        return new UpdateStmtFormatterBuilder();
      }
    });
  }
  
  public static CreateTableStmtFormatter createCreateTableStmtFormatter(GFmtOpt paramGFmtOpt)
  {
    (CreateTableStmtFormatter)createFormatter(paramGFmtOpt, CreateTableStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<CreateTableStmtFormatter> create()
      {
        return new CreateTableStmtFormatterBuilder();
      }
    });
  }
  
  public static DeclareStmtFormatter createDeclareStmtFormatter(GFmtOpt paramGFmtOpt)
  {
    (DeclareStmtFormatter)createFormatter(paramGFmtOpt, DeclareStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<DeclareStmtFormatter> create()
      {
        return new DeclareStmtFormatterBuilder();
      }
    });
  }
  
  public static ExecuteStmtFormatter createExecuteStmtFormatter(GFmtOpt paramGFmtOpt)
  {
    (ExecuteStmtFormatter)createFormatter(paramGFmtOpt, ExecuteStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<ExecuteStmtFormatter> create()
      {
        return new ExecuteStmtFormatterBuilder();
      }
    });
  }
  
  public static SetStmtFormatter createSetStmtFormatter(GFmtOpt paramGFmtOpt)
  {
    (SetStmtFormatter)createFormatter(paramGFmtOpt, SetStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<SetStmtFormatter> create()
      {
        return new SetStmtFormatterBuilder();
      }
    });
  }
  
  public static IfStmtFormatter createIfStmtFormatter(GFmtOpt paramGFmtOpt)
  {
    (IfStmtFormatter)createFormatter(paramGFmtOpt, IfStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<IfStmtFormatter> create()
      {
        return new IfStmtFormatterBuilder();
      }
    });
  }
  
  public static CreateFunctionStmtFormatter createCreateFunctionStmtFormatter(GFmtOpt paramGFmtOpt)
  {
    (CreateFunctionStmtFormatter)createFormatter(paramGFmtOpt, CreateFunctionStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<CreateFunctionStmtFormatter> create()
      {
        return new CreateFunctionStmtFormatterBuilder();
      }
    });
  }
  
  public static GoStmtFormatter createGoStmtFormatter(GFmtOpt paramGFmtOpt)
  {
    (GoStmtFormatter)createFormatter(paramGFmtOpt, GoStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<GoStmtFormatter> create()
      {
        return new GoStmtFormatterBuilder();
      }
    });
  }
  
  public static CompactModeStmtFormatter createCompactModeStmtFormatter(GFmtOpt paramGFmtOpt)
  {
    (CompactModeStmtFormatter)createFormatter(paramGFmtOpt, CompactModeStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<CompactModeStmtFormatter> create()
      {
        return new CompactModeStmtFormatterBuilder();
      }
    });
  }
  
  public static ReturnStmtFormatter createReturnStmtFormatter(GFmtOpt paramGFmtOpt)
  {
    (ReturnStmtFormatter)createFormatter(paramGFmtOpt, ReturnStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<ReturnStmtFormatter> create()
      {
        return new ReturnStmtFormatterBuilder();
      }
    });
  }
  
  public static CreateViewStmtFormatter createCreateViewStmtFormatter(GFmtOpt paramGFmtOpt)
  {
    (CreateViewStmtFormatter)createFormatter(paramGFmtOpt, CreateViewStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<CreateViewStmtFormatter> create()
      {
        return new CreateViewStmtFormatterBuilder();
      }
    });
  }
  
  public static AlterTableStmtFormatter createAlterTableStatement(GFmtOpt paramGFmtOpt)
  {
    (AlterTableStmtFormatter)createFormatter(paramGFmtOpt, AlterTableStmtFormatter.class, new IFormatterBuilderCreator()
    {
      public final AbstractStmtFormatterBuilder<AlterTableStmtFormatter> create()
      {
        return new AlterTableStmtFormatterBuilder();
      }
    });
  }
  
  public static <E extends AbstractStmtFormatter> E createFormatter(GFmtOpt paramGFmtOpt, Class<E> paramClass, IFormatterBuilderCreator<E> paramIFormatterBuilderCreator)
  {
    paramClass = paramGFmtOpt.sessionId + paramClass.getName();
    if (!a.containsKey(paramClass)) {
      synchronized (FormatterFactory.class)
      {
        if (!a.containsKey(paramClass))
        {
          (paramIFormatterBuilderCreator = paramIFormatterBuilderCreator.create()).setOption(paramGFmtOpt);
          a.put(paramClass, paramIFormatterBuilderCreator.build());
        }
      }
    }
    return (AbstractStmtFormatter)a.get(paramClass);
  }
  
  public static void processStatement(GFmtOpt paramGFmtOpt, TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (paramGFmtOpt.compactMode == TCompactMode.Cpmugly)
    {
      createCompactModeStmtFormatter(paramGFmtOpt).format(paramTCustomSqlStatement);
      return;
    }
    if (isNotNeedFormat(paramTCustomSqlStatement)) {
      return;
    }
    if ((paramTCustomSqlStatement instanceof TSelectSqlStatement))
    {
      createSelectStmtFormatter(paramGFmtOpt).format((TSelectSqlStatement)paramTCustomSqlStatement);
      return;
    }
    if ((paramTCustomSqlStatement instanceof TInsertSqlStatement))
    {
      createInsertStmtFormatter(paramGFmtOpt).format((TInsertSqlStatement)paramTCustomSqlStatement);
      return;
    }
    if ((paramTCustomSqlStatement instanceof TDeleteSqlStatement))
    {
      createDeleteStmtFormatter(paramGFmtOpt).format((TDeleteSqlStatement)paramTCustomSqlStatement);
      return;
    }
    if ((paramTCustomSqlStatement instanceof TUpdateSqlStatement))
    {
      createUpdateStmtFormatter(paramGFmtOpt).format((TUpdateSqlStatement)paramTCustomSqlStatement);
      return;
    }
    if ((paramTCustomSqlStatement instanceof TCreateTableSqlStatement))
    {
      createCreateTableStmtFormatter(paramGFmtOpt).format((TCreateTableSqlStatement)paramTCustomSqlStatement);
      return;
    }
    if ((paramTCustomSqlStatement instanceof TMssqlDeclare))
    {
      createDeclareStmtFormatter(paramGFmtOpt).format((TMssqlDeclare)paramTCustomSqlStatement);
      return;
    }
    if ((paramTCustomSqlStatement instanceof TMssqlExecute))
    {
      createExecuteStmtFormatter(paramGFmtOpt).format((TMssqlExecute)paramTCustomSqlStatement);
      return;
    }
    if ((paramTCustomSqlStatement instanceof TStoredProcedureSqlStatement))
    {
      createCreateFunctionStmtFormatter(paramGFmtOpt).format((TStoredProcedureSqlStatement)paramTCustomSqlStatement);
      return;
    }
    if ((paramTCustomSqlStatement instanceof TMssqlSet))
    {
      createSetStmtFormatter(paramGFmtOpt).format((TMssqlSet)paramTCustomSqlStatement);
      return;
    }
    if ((paramTCustomSqlStatement instanceof TMssqlIfElse))
    {
      createIfStmtFormatter(paramGFmtOpt).format((TMssqlIfElse)paramTCustomSqlStatement);
      return;
    }
    if ((paramTCustomSqlStatement instanceof TMssqlGo))
    {
      createGoStmtFormatter(paramGFmtOpt).format((TMssqlGo)paramTCustomSqlStatement);
      return;
    }
    if ((paramTCustomSqlStatement instanceof TMssqlReturn))
    {
      createReturnStmtFormatter(paramGFmtOpt).format((TMssqlReturn)paramTCustomSqlStatement);
      return;
    }
    if ((paramTCustomSqlStatement instanceof TCreateViewSqlStatement))
    {
      createCreateViewStmtFormatter(paramGFmtOpt).format((TCreateViewSqlStatement)paramTCustomSqlStatement);
      return;
    }
    if ((paramTCustomSqlStatement instanceof TAlterTableStatement)) {
      createAlterTableStatement(paramGFmtOpt).format((TAlterTableStatement)paramTCustomSqlStatement);
    }
  }
  
  public static boolean isNotNeedFormat(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (paramTCustomSqlStatement == null) {
      return true;
    }
    if (paramTCustomSqlStatement.getStartToken() != null) {
      return isNotNeedFormat(paramTCustomSqlStatement = paramTCustomSqlStatement.getStartToken());
    }
    return false;
  }
  
  public static boolean isNotNeedFormat(TSourceToken paramTSourceToken)
  {
    if (paramTSourceToken == null) {
      return false;
    }
    if ((paramTSourceToken = paramTSourceToken.getTokensBefore()).size() > 0) {
      for (int i = 0; i < paramTSourceToken.size(); i++) {
        if (SourceTokenOperator.createNoFormatFlagToken().equals(paramTSourceToken.get(i))) {
          return true;
        }
      }
    }
    return false;
  }
  
  public static void processBlockStmt(GFmtOpt paramGFmtOpt, TMssqlBlock paramTMssqlBlock, TSourceToken paramTSourceToken)
  {
    Object localObject = paramTMssqlBlock.getStartToken();
    TSourceToken localTSourceToken = paramTMssqlBlock.getEndToken();
    if ((localObject == null) || (localTSourceToken == null)) {
      return;
    }
    int i = SourceTokenOperator.curColumnNumberVT(paramTSourceToken);
    if (paramGFmtOpt.beStyleBlockLeftBEOnNewline.booleanValue())
    {
      i += paramGFmtOpt.beStyleBlockLeftBEIndentSize.intValue();
      SourceTokenOperator.addBefore(paramGFmtOpt, (TSourceToken)localObject, SourceTokenOperator.createReturnSourceToken());
      SourceTokenOperator.addBefore(paramGFmtOpt, (TSourceToken)localObject, SourceTokenOperator.createWhitespaceSourceToken(i));
    }
    paramTSourceToken = SourceTokenOperator.curColumnNumberVT(paramTSourceToken) + (paramGFmtOpt.beStyleBlockLeftBEOnNewline.booleanValue() ? paramGFmtOpt.beStyleBlockLeftBEIndentSize : paramGFmtOpt.beStyleBlockRightBEIndentSize).intValue();
    SourceTokenOperator.addBefore(paramGFmtOpt, localTSourceToken, SourceTokenOperator.createReturnSourceToken());
    SourceTokenOperator.addBefore(paramGFmtOpt, localTSourceToken, SourceTokenOperator.createWhitespaceSourceToken(paramTSourceToken));
    if (((paramTMssqlBlock = paramTMssqlBlock.getBodyStatements()) != null) && (paramTMssqlBlock.size() > 0))
    {
      paramTSourceToken += paramGFmtOpt.beStyleBlockIndentSize.intValue();
      if ((localObject = (localObject = paramTMssqlBlock.get(0)).getStartToken()) != null)
      {
        SourceTokenOperator.addBefore(paramGFmtOpt, (TSourceToken)localObject, SourceTokenOperator.createReturnSourceToken());
        SourceTokenOperator.addBefore(paramGFmtOpt, (TSourceToken)localObject, SourceTokenOperator.createWhitespaceSourceToken(paramTSourceToken));
      }
    }
    AllStmtsFormatter.processEmptyLine(paramTMssqlBlock, paramGFmtOpt, true);
    if ((paramTMssqlBlock != null) && (paramTMssqlBlock.size() > 0)) {
      for (paramTSourceToken = 0; paramTSourceToken < paramTMssqlBlock.size(); paramTSourceToken++)
      {
        localObject = paramTMssqlBlock.get(paramTSourceToken);
        processStatement(paramGFmtOpt, (TCustomSqlStatement)localObject);
      }
    }
  }
  
  public static String pp(TGSqlParser paramTGSqlParser, GFmtOpt paramGFmtOpt)
  {
    ByteArrayOutputStream localByteArrayOutputStream;
    TextPrinter localTextPrinter = PrinterFactory.createTextPrinter(localByteArrayOutputStream = new ByteArrayOutputStream());
    createAllStmtsFormatter(paramGFmtOpt).beforeFormat(paramTGSqlParser.sqlstatements);
    for (int i = 0; i < paramTGSqlParser.sqlstatements.size(); i++)
    {
      TCustomSqlStatement localTCustomSqlStatement = paramTGSqlParser.sqlstatements.get(i);
      processStatement(paramGFmtOpt, localTCustomSqlStatement);
    }
    if ((paramTGSqlParser.sqlstatements != null) && (paramTGSqlParser.sqlstatements.size() > 0))
    {
      createAllStmtsFormatter(paramGFmtOpt).doFormat(paramTGSqlParser.sqlstatements);
      createAllStmtsFormatter(paramGFmtOpt).afterFormat(paramTGSqlParser.sqlstatements);
      if (b == null) {
        b = OutputConfigFactory.getOutputConfig(paramGFmtOpt, paramTGSqlParser.getDbVendor());
      }
      localTextPrinter.setOutputConfig(b);
      localTextPrinter.print(paramTGSqlParser.sqlstatements.get(0).getStartToken().container);
    }
    clearAllObject(paramGFmtOpt.sessionId);
    return localByteArrayOutputStream.toString();
  }
  
  public static OutputConfig getOutputConfig()
  {
    return b;
  }
  
  public static void setOutputConfig(OutputConfig paramOutputConfig)
  {
    b = paramOutputConfig;
  }
  
  public static AllStmtsFormatter createAllStmtsFormatter(GFmtOpt paramGFmtOpt)
  {
    return AllStmtsFormatterBuilder.create(paramGFmtOpt);
  }
  
  public static void clearAllObject(String paramString)
  {
    clear(paramString);
    ProcessorFactory.clear(paramString);
    MediatorFactory.clear(paramString);
  }
  
  public static void clear(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = a.keySet().iterator();
    String str;
    while (localIterator.hasNext()) {
      if ((str = (String)localIterator.next()).startsWith(paramString)) {
        localArrayList.add(str);
      }
    }
    localIterator = localArrayList.iterator();
    while (localIterator.hasNext())
    {
      str = (String)localIterator.next();
      a.remove(str);
    }
  }
  
  public static abstract interface IFormatterBuilderCreator<E extends AbstractStmtFormatter>
  {
    public abstract AbstractStmtFormatterBuilder<E> create();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\FormatterFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */