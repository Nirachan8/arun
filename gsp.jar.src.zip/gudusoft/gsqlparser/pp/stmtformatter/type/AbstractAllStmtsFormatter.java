package gudusoft.gsqlparser.pp.stmtformatter.type;

import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.GFmtOptFactory;

public class AbstractAllStmtsFormatter
{
  private String a;
  
  public GFmtOpt getOption()
  {
    return GFmtOptFactory.newInstance(this.a);
  }
  
  public void doFormat(TStatementList paramTStatementList) {}
  
  public void beforeFormat(TStatementList paramTStatementList) {}
  
  public void afterFormat(TStatementList paramTStatementList) {}
  
  public String getSessionId()
  {
    return this.a;
  }
  
  public void setSessionId(String paramString)
  {
    this.a = paramString;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\AbstractAllStmtsFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */