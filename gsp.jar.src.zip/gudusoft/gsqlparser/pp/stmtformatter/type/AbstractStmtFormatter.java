package gudusoft.gsqlparser.pp.stmtformatter.type;

import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.pp.mediator.MediatorFactory;
import gudusoft.gsqlparser.pp.mediator.type.KeywordAlignMediator;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.GFmtOptFactory;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import java.util.ArrayList;
import java.util.List;

public class AbstractStmtFormatter<E extends TCustomSqlStatement>
{
  private List<AbstractProcessor> a;
  private List<AbstractProcessor> b;
  private String c;
  
  public GFmtOpt getOption()
  {
    return GFmtOptFactory.newInstance(this.c);
  }
  
  public void format(E paramE)
  {
    beforeFormat(paramE);
    doFormat(paramE);
    afterFormat(paramE);
  }
  
  protected void beforeFormat(E paramE)
  {
    (paramE = (KeywordAlignMediator)MediatorFactory.getMediator(KeywordAlignMediator.class, this.c)).increaseLevel();
  }
  
  protected void doFormat(E paramE) {}
  
  protected void afterFormat(E paramE)
  {
    (paramE = (KeywordAlignMediator)MediatorFactory.getMediator(KeywordAlignMediator.class, this.c)).decreaseLevel();
  }
  
  protected void runProcessor(List<AbstractProcessor> paramList, TParseTreeNode paramTParseTreeNode)
  {
    if ((paramList == null) || (paramList.size() == 0)) {
      return;
    }
    for (int i = 0; i < paramList.size(); i++) {
      ((AbstractProcessor)paramList.get(i)).beforeProcess(paramTParseTreeNode);
    }
    for (i = 0; i < paramList.size(); i++) {
      ((AbstractProcessor)paramList.get(i)).process(paramTParseTreeNode);
    }
    for (i = paramList.size() - 1; i >= 0; i--) {
      ((AbstractProcessor)paramList.get(i)).afterProcess(paramTParseTreeNode);
    }
  }
  
  public void addExpressionProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.a == null) {
      this.a = new ArrayList();
    }
    this.a.add(paramAbstractProcessor);
  }
  
  public List<AbstractProcessor> getExpressionProcessors()
  {
    if (this.a == null) {
      this.a = new ArrayList();
    }
    return this.a;
  }
  
  public void addSpecialProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.b == null) {
      this.b = new ArrayList();
    }
    this.b.add(paramAbstractProcessor);
  }
  
  public List<AbstractProcessor> getSpecialProcessors()
  {
    if (this.b == null) {
      this.b = new ArrayList();
    }
    return this.b;
  }
  
  public String getSessionId()
  {
    return this.c;
  }
  
  public void setSessionId(String paramString)
  {
    this.c = paramString;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\AbstractStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */