package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.stmt.mssql.TMssqlReturn;

public class ReturnStmtFormatter
  extends AbstractStmtFormatter<TMssqlReturn>
{
  protected void doFormat(TMssqlReturn paramTMssqlReturn)
  {
    runProcessor(getSpecialProcessors(), paramTMssqlReturn);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\ReturnStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */