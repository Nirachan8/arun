package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.ColumnlistCommaProcessor;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.stmt.mssql.TMssqlExecute;
import java.util.ArrayList;
import java.util.List;

public class ExecuteStmtFormatter
  extends AbstractStmtFormatter<TMssqlExecute>
{
  private List<AbstractProcessor> a;
  
  public void addParaListProcessor(ColumnlistCommaProcessor paramColumnlistCommaProcessor)
  {
    if (this.a == null) {
      this.a = new ArrayList();
    }
    this.a.add(paramColumnlistCommaProcessor);
  }
  
  protected void doFormat(TMssqlExecute paramTMssqlExecute)
  {
    runProcessor(getSpecialProcessors(), paramTMssqlExecute);
    runProcessor(this.a, paramTMssqlExecute.getParameters());
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\ExecuteStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */