package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.nodes.TColumnDefinition;
import gudusoft.gsqlparser.nodes.TColumnDefinitionList;
import gudusoft.gsqlparser.nodes.TConstraintList;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.ExpressionProcessor;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.stmt.TCreateTableSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import java.util.ArrayList;
import java.util.List;

public class CreateTableStmtFormatter
  extends AbstractStmtFormatter<TCreateTableSqlStatement>
{
  private List<AbstractProcessor> a;
  private List<AbstractProcessor> b;
  
  public void addItemListProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.a == null) {
      this.a = new ArrayList();
    }
    this.a.add(paramAbstractProcessor);
  }
  
  public void addConstraintListProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.b == null) {
      this.b = new ArrayList();
    }
    this.b.add(paramAbstractProcessor);
  }
  
  protected void doFormat(TCreateTableSqlStatement paramTCreateTableSqlStatement)
  {
    runProcessor(getSpecialProcessors(), paramTCreateTableSqlStatement);
    TColumnDefinitionList localTColumnDefinitionList;
    if (((localTColumnDefinitionList = paramTCreateTableSqlStatement.getColumnList()) != null) && (localTColumnDefinitionList.size() > 0))
    {
      runProcessor(this.a, localTColumnDefinitionList);
      for (int i = 0; i < localTColumnDefinitionList.size(); i++)
      {
        TColumnDefinition localTColumnDefinition;
        if (((localTColumnDefinition = localTColumnDefinitionList.getColumn(i)) != null) && (localTColumnDefinition.getDatatype() != null)) {
          ExpressionProcessor.processTypeName(getOption(), localTColumnDefinition.getDatatype());
        }
      }
    }
    TConstraintList localTConstraintList;
    if (((localTConstraintList = paramTCreateTableSqlStatement.getTableConstraints()) != null) && (localTConstraintList.size() > 0)) {
      runProcessor(this.b, localTConstraintList);
    }
    if (paramTCreateTableSqlStatement.getSubQuery() != null) {
      ExpressionProcessor.processParenthesesNodeInSubQuery(getOption(), paramTCreateTableSqlStatement.getSubQuery(), paramTCreateTableSqlStatement.getSubQuery().getStartToken(), paramTCreateTableSqlStatement.getSubQuery().getEndToken());
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\CreateTableStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */