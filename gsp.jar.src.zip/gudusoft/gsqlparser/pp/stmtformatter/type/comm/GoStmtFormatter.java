package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.stmt.mssql.TMssqlGo;

public class GoStmtFormatter
  extends AbstractStmtFormatter<TMssqlGo>
{
  public void format(TMssqlGo paramTMssqlGo)
  {
    runProcessor(getSpecialProcessors(), paramTMssqlGo);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\GoStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */