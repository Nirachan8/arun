package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.ETokenType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.pp.mediator.MediatorFactory;
import gudusoft.gsqlparser.pp.mediator.type.SourceTokenTextTempMediator;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.styleenums.TCompactMode;
import gudusoft.gsqlparser.pp.para.styleenums.TEmptyLinesOption;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractAllStmtsFormatter;
import gudusoft.gsqlparser.pp.utils.SourceTokenConstant;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.db2.TDb2SetStmt;
import gudusoft.gsqlparser.stmt.mssql.TMssqlDeclare;
import gudusoft.gsqlparser.stmt.mssql.TMssqlGo;
import gudusoft.gsqlparser.stmt.mssql.TMssqlSet;
import gudusoft.gsqlparser.stmt.mysql.TMySQLSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AllStmtsFormatter
  extends AbstractAllStmtsFormatter
{
  public void doFormat(TStatementList paramTStatementList)
  {
    if ((paramTStatementList == null) || (paramTStatementList.size() == 0)) {
      return;
    }
    processEmptyLine(paramTStatementList, getOption(), false);
    a(paramTStatementList);
    d(paramTStatementList);
    e(paramTStatementList);
  }
  
  public void beforeFormat(TStatementList paramTStatementList)
  {
    if ((paramTStatementList == null) || (paramTStatementList.size() == 0)) {
      return;
    }
    b(paramTStatementList);
    c(paramTStatementList);
  }
  
  public void afterFormat(TStatementList paramTStatementList)
  {
    if ((paramTStatementList == null) || (paramTStatementList.size() == 0)) {}
  }
  
  private void a(TStatementList paramTStatementList)
  {
    Boolean localBoolean = getOption().removeComment;
    if ((paramTStatementList = paramTStatementList.get(0).getStartToken()) == null) {
      return;
    }
    paramTStatementList = paramTStatementList.container;
    SourceTokenTextTempMediator localSourceTokenTextTempMediator = (SourceTokenTextTempMediator)MediatorFactory.getMediator(SourceTokenTextTempMediator.class, getOption().sessionId);
    TSourceToken localTSourceToken1;
    TSourceToken localTSourceToken3;
    for (int j = 0; j < paramTStatementList.size(); j++) {
      if (((localTSourceToken1 = paramTStatementList.get(j)).tokentype == ETokenType.ttsimplecomment) || (localTSourceToken1.tokentype == ETokenType.ttbracketedcomment)) {
        if ((localTSourceToken1.astext != null) && ((localTSourceToken1.astext.contains("--begin_no_format")) || (localTSourceToken1.astext.contains("--end_no_format"))))
        {
          if (localTSourceToken1.astext.contains("--begin_no_format")) {
            SourceTokenOperator.addBefore(getOption(), localTSourceToken1, SourceTokenOperator.createReturnSourceToken());
          }
        }
        else
        {
          boolean bool = a(paramTStatementList, localSourceTokenTextTempMediator, j, localTSourceToken1);
          if ((localTSourceToken1.tokentype == ETokenType.ttsimplecomment) && (getOption().compactMode != TCompactMode.Cpmugly))
          {
            int m = localTSourceToken1.posinlist + 1;
            ArrayList localArrayList = new ArrayList();
            int i1;
            TSourceTokenList localTSourceTokenList;
            int i3;
            while ((m < paramTStatementList.size()) && ((localTSourceToken3 = paramTStatementList.get(m)).tokentype != ETokenType.ttreturn))
            {
              i1 = 0;
              if ((localTSourceTokenList = localTSourceToken3.getTokensBefore()) != null) {
                for (i3 = 0; i3 < localTSourceTokenList.size(); i3++) {
                  if (localTSourceTokenList.get(i3).tokentype == ETokenType.ttreturn)
                  {
                    i1 = 1;
                    break;
                  }
                }
              }
              if (i1 != 0) {
                break;
              }
              if (localTSourceToken3.getReplaceToken() != SourceTokenConstant.EMPTY) {
                localArrayList.add(localTSourceToken3);
              }
              m++;
            }
            if (!localArrayList.isEmpty())
            {
              if (bool) {
                for (m = localTSourceToken1.posinlist; (m >= 0) && ((localTSourceToken3 = paramTStatementList.get(m)).tokentype != ETokenType.ttreturn); m--)
                {
                  i1 = 0;
                  if ((localTSourceTokenList = localTSourceToken3.getTokensBefore()) != null) {
                    for (i3 = 0; i3 < localTSourceTokenList.size(); i3++) {
                      if (localTSourceTokenList.get(i3).tokentype == ETokenType.ttreturn)
                      {
                        i1 = 1;
                        break;
                      }
                    }
                  }
                  if (i1 != 0) {
                    break;
                  }
                }
              }
              m = localTSourceToken1.posinlist - 1;
              if (m > 0) {
                m = (localTSourceToken3 = SourceTokenSearcher.lastNotWhitespaceAndReturnToken(paramTStatementList, 0, m)).posinlist;
              }
              if (0 < localArrayList.size())
              {
                TSourceToken localTSourceToken4;
                if (((localTSourceToken4 = (TSourceToken)localArrayList.get(0)).tokentype == ETokenType.ttsimplecomment) || (localTSourceToken4.tokentype == ETokenType.ttbracketedcomment))
                {
                  a(paramTStatementList, localSourceTokenTextTempMediator, localTSourceToken4.posinlist, localTSourceToken4);
                  a(paramTStatementList, getOption(), localBoolean, localTSourceToken4, m + 1);
                }
                paramTStatementList.remove(localTSourceToken4.posinlist);
                for (int i2 = m + 1; i2 < localTSourceToken4.posinlist; i2++) {
                  paramTStatementList.get(i2).posinlist += 1;
                }
                paramTStatementList.add(m + 1, localTSourceToken4);
                localTSourceToken4.posinlist = (m + 1);
                j++;
              }
            }
          }
          a(paramTStatementList, getOption(), localBoolean, localTSourceToken1, j);
        }
      }
    }
    for (j = 0; j < paramTStatementList.size(); j++)
    {
      int k;
      if (((localTSourceToken1 = paramTStatementList.get(j)).tokentype == ETokenType.ttsimplecomment) && (getOption().compactMode != TCompactMode.Cpmugly) && ((k = localTSourceToken1.posinlist + 1) < paramTStatementList.size()))
      {
        TSourceToken localTSourceToken2 = paramTStatementList.get(k);
        int n = 0;
        int i;
        label797:
        while (((localTSourceToken2.getReplaceToken() == SourceTokenConstant.EMPTY) || ((localTSourceToken2.getReplaceToken() == null) && (localTSourceToken2.tokentype == ETokenType.ttwhitespace))) && (localTSourceToken2.posinlist < paramTStatementList.size() - 1)) {
          if ((localTSourceToken2 = paramTStatementList.get(localTSourceToken2.posinlist + 1)).getTokensBefore() != null) {
            for (i = 0;; i++)
            {
              if (i >= localTSourceToken2.getTokensBefore().size()) {
                break label797;
              }
              if ((localTSourceToken3 = localTSourceToken2.getTokensBefore().get(i)).tokentype == ETokenType.ttreturn)
              {
                n = 1;
                break;
              }
            }
          }
        }
        if ((n == 0) && (localTSourceToken2.getTokensBefore() != null)) {
          for (i = 0; i < localTSourceToken2.getTokensBefore().size(); i++) {
            if ((localTSourceToken3 = localTSourceToken2.getTokensBefore().get(i)).tokentype == ETokenType.ttreturn)
            {
              n = 1;
              break;
            }
          }
        }
        if ((n == 0) && (localTSourceToken2.getReplaceToken() != SourceTokenConstant.EMPTY) && (n == 0)) {
          if (localTSourceToken2.getReplaceToken() != null)
          {
            if (localTSourceToken2.getReplaceToken().astext.indexOf("\n") == -1) {
              SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createReturnSourceToken());
            }
          }
          else if (localTSourceToken2.astext.indexOf("\n") == -1) {
            SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createReturnSourceToken());
          }
        }
      }
    }
  }
  
  private boolean a(TSourceTokenList paramTSourceTokenList, SourceTokenTextTempMediator paramSourceTokenTextTempMediator, int paramInt, TSourceToken paramTSourceToken)
  {
    boolean bool = false;
    if (paramInt > 1)
    {
      paramTSourceTokenList = paramTSourceTokenList.get(paramInt - 1);
      if ((paramTSourceTokenList = b(paramTSourceTokenList = paramSourceTokenTextTempMediator.get(Integer.valueOf(paramTSourceTokenList.posinlist)))) > 0)
      {
        if (((paramTSourceTokenList = paramTSourceToken.getTokensBefore()) != null) && (paramTSourceTokenList.size() > 0)) {
          for (paramSourceTokenTextTempMediator = 0; paramSourceTokenTextTempMediator < paramTSourceTokenList.size(); paramSourceTokenTextTempMediator++) {
            if (SourceTokenSearcher.isNewLineToken(paramTSourceTokenList.get(paramSourceTokenTextTempMediator)))
            {
              bool = true;
              break;
            }
          }
        }
        if (!bool) {
          SourceTokenOperator.addBefore(getOption(), paramTSourceToken, SourceTokenOperator.createReturnSourceToken());
        }
      }
    }
    return bool;
  }
  
  private static void a(TSourceTokenList paramTSourceTokenList, GFmtOpt paramGFmtOpt, Boolean paramBoolean, TSourceToken paramTSourceToken, int paramInt)
  {
    if (paramBoolean.booleanValue())
    {
      paramTSourceToken.astext = "";
      paramTSourceToken.tokentype = ETokenType.ttwhitespace;
      if (paramTSourceToken.getTokensBefore() != null) {
        paramTSourceToken.getTokensBefore().clear();
      }
      SourceTokenOperator.removeWhitespaceAndReturnFromStart(paramGFmtOpt, paramTSourceTokenList, paramInt + 1);
    }
  }
  
  private void b(TStatementList paramTStatementList)
  {
    if ((paramTStatementList == null) || (paramTStatementList.size() == 0) || (paramTStatementList.get(0) == null)) {
      return;
    }
    if ((paramTStatementList = paramTStatementList.get(0).getStartToken()) == null) {
      return;
    }
    paramTStatementList = paramTStatementList.container;
    int i = 1;
    for (int j = 0; j < paramTStatementList.size(); j++)
    {
      TSourceToken localTSourceToken;
      if ((((localTSourceToken = paramTStatementList.get(j)).tokentype == ETokenType.ttsimplecomment) || (localTSourceToken.tokentype == ETokenType.ttbracketedcomment)) && (localTSourceToken.astext != null) && ((localTSourceToken.astext.contains("--begin_no_format")) || (localTSourceToken.astext.contains("--end_no_format"))))
      {
        if (localTSourceToken.astext.contains("--begin_no_format"))
        {
          SourceTokenOperator.addBefore(getOption(), localTSourceToken, SourceTokenOperator.createNoFormatFlagToken());
          i = 0;
        }
        else if (localTSourceToken.astext.contains("--end_no_format"))
        {
          SourceTokenOperator.addBefore(getOption(), localTSourceToken, SourceTokenOperator.createNoFormatFlagToken());
          i = 1;
        }
      }
      else if (i == 0) {
        SourceTokenOperator.addBefore(getOption(), localTSourceToken, SourceTokenOperator.createNoFormatFlagToken());
      }
    }
  }
  
  private void c(TStatementList paramTStatementList)
  {
    if ((paramTStatementList == null) || (paramTStatementList.size() == 0)) {
      return;
    }
    SourceTokenOperator.curColumnNumberVT(paramTStatementList.get(0).getStartToken());
    for (int i = 0; i < paramTStatementList.size(); i++)
    {
      TCustomSqlStatement localTCustomSqlStatement;
      TSourceToken localTSourceToken1 = (localTCustomSqlStatement = paramTStatementList.get(i)).getStartToken();
      localTCustomSqlStatement.getEndToken();
      if (localTSourceToken1 != null)
      {
        TSourceToken localTSourceToken2;
        if ((localTSourceToken1.posinlist - 1 > 0) && (SourceTokenSearcher.isNewLineToken(localTSourceToken2 = localTSourceToken1.container.get(localTSourceToken1.posinlist - 1)))) {
          if ((i > 0) && (localTSourceToken2 == paramTStatementList.get(i - 1).getEndToken()))
          {
            if ((!(localTCustomSqlStatement instanceof TMssqlGo)) && (!(localTCustomSqlStatement instanceof TMssqlSet))) {
              SourceTokenOperator.addBefore(getOption(), localTSourceToken1, SourceTokenOperator.createReturnSourceToken());
            }
          }
          else {
            localTSourceToken2.astext = a(localTSourceToken2.astext);
          }
        }
        SourceTokenOperator.curIndentLenVT(localTSourceToken1);
      }
    }
  }
  
  private static String a(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    for (int i = paramString.length() - 1; i >= 0; i--)
    {
      char c;
      if ((c = paramString.charAt(i)) != ' ') {
        localStringBuilder.insert(localStringBuilder.length(), c);
      }
    }
    return localStringBuilder.toString();
  }
  
  public static void processEmptyLine(TStatementList paramTStatementList, GFmtOpt paramGFmtOpt, boolean paramBoolean)
  {
    int i = paramTStatementList.get(0).getEndToken().posinlist;
    Object localObject1;
    int j = SourceTokenOperator.curColumnNumberVT((localObject1 = paramTStatementList.get(0)).getStartToken());
    SourceTokenTextTempMediator localSourceTokenTextTempMediator = (SourceTokenTextTempMediator)MediatorFactory.getMediator(SourceTokenTextTempMediator.class, paramGFmtOpt.sessionId);
    for (int k = 1; k < paramTStatementList.size(); k++)
    {
      TCustomSqlStatement localTCustomSqlStatement;
      TSourceToken localTSourceToken1 = (localTCustomSqlStatement = paramTStatementList.get(k)).getStartToken();
      TSourceToken localTSourceToken2 = localTCustomSqlStatement.getEndToken();
      Object localObject2 = null;
      if ((localTSourceToken1 != null) && (localTSourceToken2 != null) && (localTSourceToken1.posinlist >= 0) && (localTSourceToken1.posinlist <= localTSourceToken2.posinlist))
      {
        int m = localTSourceToken1.posinlist;
        int n = 0;
        i += 1;
        while (i < m)
        {
          TSourceToken localTSourceToken3;
          if ((SourceTokenSearcher.isNewLineToken(localTSourceToken3 = localTSourceToken1.container.get(i))) || (localSourceTokenTextTempMediator.get(Integer.valueOf(localTSourceToken3.posinlist)) != null))
          {
            String str;
            if ((str = localSourceTokenTextTempMediator.get(Integer.valueOf(localTSourceToken3.posinlist))) == null) {
              str = localTSourceToken3.astext;
            }
            int i1 = b(str);
            n += i1;
            if (SourceTokenSearcher.isNewLineToken(localTSourceToken3))
            {
              localTSourceToken3.astext = "";
              localTSourceToken3.tokentype = ETokenType.ttwhitespace;
            }
          }
          if ((SourceTokenSearcher.isSimpleComment(localTSourceToken3)) && (n > 0)) {
            localObject2 = localTSourceToken3;
          }
          i++;
        }
        SourceTokenOperator.addBefore(paramGFmtOpt, localTSourceToken1, SourceTokenOperator.createReturnSourceToken());
        if (localObject2 != null) {
          SourceTokenOperator.addBefore(paramGFmtOpt, (TSourceToken)localObject2, SourceTokenOperator.createReturnSourceToken());
        }
        if (!(localTCustomSqlStatement instanceof TMssqlGo)) {
          if ((!paramGFmtOpt.noEmptyLinesBetweenMultiSetStmts.booleanValue()) && (a((TCustomSqlStatement)localObject1)) && (a(localTCustomSqlStatement))) {
            SourceTokenOperator.addBefore(paramGFmtOpt, localObject2 == null ? localTSourceToken1 : (TSourceToken)localObject2, SourceTokenOperator.createReturnSourceToken());
          } else if ((paramBoolean) && (paramGFmtOpt.insertBlankLineInBatchSqls.booleanValue())) {
            SourceTokenOperator.addBefore(paramGFmtOpt, localObject2 == null ? localTSourceToken1 : (TSourceToken)localObject2, SourceTokenOperator.createReturnSourceToken());
          } else if (paramGFmtOpt.emptyLines != TEmptyLinesOption.EloRemove) {
            if (paramGFmtOpt.emptyLines == TEmptyLinesOption.EloMergeIntoOne)
            {
              if (n > 1) {
                SourceTokenOperator.addBefore(paramGFmtOpt, localObject2 == null ? localTSourceToken1 : (TSourceToken)localObject2, SourceTokenOperator.createReturnSourceToken());
              }
            }
            else if (paramGFmtOpt.emptyLines == TEmptyLinesOption.EloPreserve) {
              for (i = localObject2 == null ? 1 : 2; i < n; i++) {
                SourceTokenOperator.addBefore(paramGFmtOpt, localObject2 == null ? localTSourceToken1 : (TSourceToken)localObject2, SourceTokenOperator.createReturnSourceToken());
              }
            }
          }
        }
        SourceTokenOperator.addBefore(paramGFmtOpt, localTSourceToken1, SourceTokenOperator.createWhitespaceSourceToken(j));
        i = localTSourceToken2.posinlist;
        if (!(localTCustomSqlStatement instanceof TMssqlGo)) {
          localObject1 = localTCustomSqlStatement;
        }
      }
    }
  }
  
  private static int b(String paramString)
  {
    if ((paramString == null) || (paramString.length() == 0)) {
      return 0;
    }
    int i = 0;
    for (int j = 0; j < paramString.length(); j++)
    {
      int k;
      if ((k = paramString.charAt(j)) == '\n') {
        i++;
      }
    }
    return i;
  }
  
  private static boolean a(TCustomSqlStatement paramTCustomSqlStatement)
  {
    return ((paramTCustomSqlStatement instanceof TMssqlSet)) || ((paramTCustomSqlStatement instanceof TDb2SetStmt)) || ((paramTCustomSqlStatement instanceof TMySQLSet)) || ((paramTCustomSqlStatement instanceof TMssqlDeclare));
  }
  
  private void d(TStatementList paramTStatementList)
  {
    if (!getOption().useTab.booleanValue()) {
      return;
    }
    for (int i = 0; i < paramTStatementList.size(); i++)
    {
      TSourceToken localTSourceToken1 = (localObject1 = paramTStatementList.get(i)).getStartToken();
      Object localObject1 = ((TCustomSqlStatement)localObject1).getEndToken();
      if ((localTSourceToken1 != null) && (localObject1 != null) && (localTSourceToken1.posinlist >= 0) && (localTSourceToken1.posinlist < ((TSourceToken)localObject1).posinlist))
      {
        TSourceToken localTSourceToken2 = localTSourceToken1;
        for (int k = localTSourceToken1.posinlist + 1; k <= ((TSourceToken)localObject1).posinlist; k++)
        {
          TSourceToken localTSourceToken3 = localTSourceToken1.container.get(k);
          int j;
          if ((a(localTSourceToken2, localTSourceToken3)) && ((j = (j = SourceTokenOperator.curIndentLenVT(localTSourceToken3)) % getOption().tabSize.intValue()) > 0)) {
            SourceTokenOperator.addBefore(getOption(), localTSourceToken3, SourceTokenOperator.createWhitespaceSourceToken(getOption().tabSize.intValue() - j));
          }
          Object localObject2 = localTSourceToken3;
        }
      }
    }
  }
  
  private static boolean a(TSourceToken paramTSourceToken1, TSourceToken paramTSourceToken2)
  {
    if (SourceTokenSearcher.isNewLineToken(paramTSourceToken1)) {
      return true;
    }
    if ((paramTSourceToken1 = paramTSourceToken1.getTokensAfter()).size() > 0) {
      for (int i = 0; i < paramTSourceToken1.size(); i++) {
        if (SourceTokenSearcher.isNewLineToken(paramTSourceToken1.get(i))) {
          return true;
        }
      }
    }
    TSourceTokenList localTSourceTokenList;
    if ((localTSourceTokenList = paramTSourceToken2.getTokensBefore()).size() > 0) {
      for (paramTSourceToken1 = 0; paramTSourceToken1 < localTSourceTokenList.size(); paramTSourceToken1++) {
        if (SourceTokenSearcher.isNewLineToken(localTSourceTokenList.get(paramTSourceToken1))) {
          return true;
        }
      }
    }
    return false;
  }
  
  private void e(TStatementList paramTStatementList)
  {
    if (paramTStatementList.size() == 0) {
      return;
    }
    if (!(localObject = getOption()).linenumberEnabled.booleanValue()) {
      return;
    }
    paramTStatementList = paramTStatementList.get(0).getStartToken().container;
    SourceTokenVisitor local1 = new SourceTokenVisitor()
    {
      private Integer a = Integer.valueOf(0);
      
      public final TSourceToken visit(TSourceToken paramAnonymousTSourceToken)
      {
        if (SourceTokenSearcher.isNewLineToken(paramAnonymousTSourceToken))
        {
          if (paramAnonymousTSourceToken.astext.equals("\n\n")) {
            this.a = Integer.valueOf(this.a.intValue() + 1);
          }
          this.a = Integer.valueOf(this.a.intValue() + 1);
        }
        return null;
      }
      
      public final Object getObject()
      {
        return this.a;
      }
    };
    a(paramTStatementList, local1);
    final int i = String.valueOf(i = ((Integer)local1.getObject()).intValue()).length();
    SourceTokenVisitor local2 = new SourceTokenVisitor()
    {
      private Integer a = Integer.valueOf(localObject.linenumberZeroBased.booleanValue() ? 1 : 2);
      
      public final TSourceToken visit(TSourceToken paramAnonymousTSourceToken)
      {
        Object localObject1;
        Object localObject2;
        if ((paramAnonymousTSourceToken.tokentype == ETokenType.ttbracketedcomment) || (paramAnonymousTSourceToken.tokentype == ETokenType.ttsimplecomment))
        {
          localObject1 = paramAnonymousTSourceToken.astext.split("\n");
          (localObject2 = new StringBuilder()).append(localObject1[0]);
          if (localObject1.length > 1) {
            for (int i = 1; i < localObject1.length; i++)
            {
              ((StringBuilder)localObject2).append("\n");
              ((StringBuilder)localObject2).append(AllStmtsFormatter.a(AllStmtsFormatter.this, this.a.intValue(), i, localObject.linenumberLeftMargin.intValue(), localObject.linenumberRightMargin.intValue()));
              this.a = Integer.valueOf(this.a.intValue() + 1);
              ((StringBuilder)localObject2).append(localObject1[i]);
            }
          }
          paramAnonymousTSourceToken.astext = ((StringBuilder)localObject2).toString();
        }
        if (SourceTokenSearcher.isNewLineToken(paramAnonymousTSourceToken)) {
          if (paramAnonymousTSourceToken.astext.equals("\n\n"))
          {
            localObject2 = this.a;
            this.a = Integer.valueOf(this.a.intValue() + 1);
            localObject1 = AllStmtsFormatter.a(AllStmtsFormatter.this, ((Integer)localObject2).intValue(), i, localObject.linenumberLeftMargin.intValue(), localObject.linenumberRightMargin.intValue());
            Integer localInteger = this.a;
            this.a = Integer.valueOf(this.a.intValue() + 1);
            localObject2 = AllStmtsFormatter.a(AllStmtsFormatter.this, localInteger.intValue(), i, localObject.linenumberLeftMargin.intValue(), localObject.linenumberRightMargin.intValue());
            paramAnonymousTSourceToken.astext = ("\n" + (String)localObject1 + "\n" + (String)localObject2);
          }
          else
          {
            localObject1 = new TSourceToken(AllStmtsFormatter.a(AllStmtsFormatter.this, this.a.intValue(), i, localObject.linenumberLeftMargin.intValue(), localObject.linenumberRightMargin.intValue()));
            this.a = Integer.valueOf(this.a.intValue() + 1);
            return (TSourceToken)localObject1;
          }
        }
        return null;
      }
      
      public final Object getObject()
      {
        return null;
      }
    };
    a(paramTStatementList, local2);
    final Object localObject = new TSourceToken(a(((GFmtOpt)localObject).linenumberZeroBased.booleanValue() ? 0 : 1, i, ((GFmtOpt)localObject).linenumberLeftMargin.intValue(), ((GFmtOpt)localObject).linenumberRightMargin.intValue()));
    SourceTokenOperator.addBefore(getOption(), paramTStatementList.get(0), (TSourceToken)localObject);
  }
  
  private static String a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if (paramInt3 > 0)
    {
      Arrays.fill(paramInt3 = new char[paramInt3], ' ');
      localStringBuilder.append(paramInt3);
    }
    if ((paramInt3 = paramInt2 - String.valueOf(paramInt1).length()) > 0)
    {
      Arrays.fill(paramInt2 = new char[paramInt3], '0');
      String.valueOf(paramInt2);
      localStringBuilder.append(paramInt2);
    }
    localStringBuilder.append(paramInt1);
    if (paramInt4 > 0)
    {
      Arrays.fill(paramInt2 = new char[paramInt4], ' ');
      localStringBuilder.append(paramInt2);
    }
    return localStringBuilder.toString();
  }
  
  private static void a(TSourceTokenList paramTSourceTokenList, SourceTokenVisitor paramSourceTokenVisitor)
  {
    for (int i = 0; i < paramTSourceTokenList.size(); i++)
    {
      TSourceToken localTSourceToken1;
      Object localObject1;
      for (int j = (localObject1 = (localTSourceToken1 = paramTSourceTokenList.get(i)).getTokensBefore()).size() - 1; j >= 0; j--)
      {
        localObject2 = ((TSourceTokenList)localObject1).get(j);
        TSourceToken localTSourceToken3;
        if ((localTSourceToken3 = paramSourceTokenVisitor.visit((TSourceToken)localObject2)) != null) {
          ((TSourceToken)localObject2).getTokensAfter().add(localTSourceToken3);
        }
      }
      TSourceToken localTSourceToken2 = paramSourceTokenVisitor.visit(localTSourceToken1);
      Object localObject2 = localTSourceToken1.getTokensAfter();
      for (int k = 0; k < ((TSourceTokenList)localObject2).size(); k++)
      {
        localObject1 = ((TSourceTokenList)localObject2).get(k);
        TSourceToken localTSourceToken4;
        if ((localTSourceToken4 = paramSourceTokenVisitor.visit((TSourceToken)localObject1)) != null) {
          ((TSourceToken)localObject1).getTokensAfter().add(localTSourceToken4);
        }
      }
      if (localTSourceToken2 != null) {
        localTSourceToken1.getTokensAfter().add(localTSourceToken2);
      }
    }
  }
  
  public static abstract interface SourceTokenVisitor
  {
    public abstract Object getObject();
    
    public abstract TSourceToken visit(TSourceToken paramTSourceToken);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\AllStmtsFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */