package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.nodes.TExpression;
import gudusoft.gsqlparser.nodes.TResultColumn;
import gudusoft.gsqlparser.nodes.TResultColumnList;
import gudusoft.gsqlparser.nodes.TWhereClause;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.ExpressionProcessor;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import gudusoft.gsqlparser.stmt.TUpdateSqlStatement;
import java.util.ArrayList;
import java.util.List;

public class UpdateStmtFormatter
  extends AbstractStmtFormatter<TUpdateSqlStatement>
{
  private List<AbstractProcessor> a;
  private List<AbstractProcessor> b;
  
  public void addSetClauseProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.a == null) {
      this.a = new ArrayList();
    }
    this.a.add(paramAbstractProcessor);
  }
  
  public void addWhereClauseProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.b == null) {
      this.b = new ArrayList();
    }
    this.b.add(paramAbstractProcessor);
  }
  
  protected void doFormat(TUpdateSqlStatement paramTUpdateSqlStatement)
  {
    runProcessor(getSpecialProcessors(), paramTUpdateSqlStatement);
    if ((paramTUpdateSqlStatement.getResultColumnList() != null) && (paramTUpdateSqlStatement.getResultColumnList().size() > 0))
    {
      runProcessor(this.a, paramTUpdateSqlStatement.getResultColumnList());
      for (int i = 0; i < paramTUpdateSqlStatement.getResultColumnList().size(); i++)
      {
        TResultColumn localTResultColumn;
        if (((localTResultColumn = paramTUpdateSqlStatement.getResultColumnList().getResultColumn(i)).getExpr() != null) && (localTResultColumn.getExpr().getRightOperand() != null) && (localTResultColumn.getExpr().getRightOperand().getSubQuery() != null)) {
          ExpressionProcessor.processParenthesesNodeInSubQuery(getOption(), localTResultColumn.getExpr().getRightOperand().getSubQuery(), localTResultColumn.getExpr().getRightOperand().getSubQuery().getStartToken(), localTResultColumn.getExpr().getRightOperand().getSubQuery().getEndToken());
        }
      }
    }
    if (paramTUpdateSqlStatement.getWhereClause() != null)
    {
      runProcessor(this.b, paramTUpdateSqlStatement.getWhereClause().getCondition());
      runProcessor(getExpressionProcessors(), paramTUpdateSqlStatement.getWhereClause().getCondition());
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\UpdateStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */