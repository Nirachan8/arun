package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.nodes.TDeclareVariableList;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.ExpressionProcessor;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import gudusoft.gsqlparser.stmt.mssql.TMssqlDeclare;
import java.util.ArrayList;
import java.util.List;

public class DeclareStmtFormatter
  extends AbstractStmtFormatter<TMssqlDeclare>
{
  private List<AbstractProcessor> a;
  
  public void addVarProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.a == null) {
      this.a = new ArrayList();
    }
    this.a.add(paramAbstractProcessor);
  }
  
  protected void doFormat(TMssqlDeclare paramTMssqlDeclare)
  {
    runProcessor(getSpecialProcessors(), paramTMssqlDeclare);
    TDeclareVariableList localTDeclareVariableList;
    if (((localTDeclareVariableList = paramTMssqlDeclare.getVariables()) != null) && (localTDeclareVariableList.size() > 0)) {
      runProcessor(this.a, localTDeclareVariableList);
    }
    if (paramTMssqlDeclare.getSubquery() != null)
    {
      paramTMssqlDeclare = paramTMssqlDeclare.getSubquery();
      ExpressionProcessor.processParenthesesNodeInSubQuery(getOption(), paramTMssqlDeclare, paramTMssqlDeclare.getStartToken(), paramTMssqlDeclare.getEndToken());
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\DeclareStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */