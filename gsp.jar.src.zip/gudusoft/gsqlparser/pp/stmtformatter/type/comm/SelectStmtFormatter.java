package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TGroupBy;
import gudusoft.gsqlparser.nodes.TGroupByItemList;
import gudusoft.gsqlparser.nodes.TOrderBy;
import gudusoft.gsqlparser.nodes.TOrderByItemList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.nodes.TResultColumn;
import gudusoft.gsqlparser.nodes.TResultColumnList;
import gudusoft.gsqlparser.nodes.TTableList;
import gudusoft.gsqlparser.nodes.TWhereClause;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.processor.type.select.UnionProcessor;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import java.util.ArrayList;
import java.util.List;

public class SelectStmtFormatter
  extends AbstractStmtFormatter<TSelectSqlStatement>
{
  private List<AbstractProcessor> a;
  private List<AbstractProcessor> b;
  private List<AbstractProcessor> c;
  private List<AbstractProcessor> d;
  private List<AbstractProcessor> e;
  private List<AbstractProcessor> f;
  private List<AbstractProcessor> g;
  private List<AbstractProcessor> h;
  private List<AbstractProcessor> i;
  private UnionProcessor j;
  
  public void addItemListProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.a == null) {
      this.a = new ArrayList();
    }
    this.a.add(paramAbstractProcessor);
  }
  
  public void addItemListAlignProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.b == null) {
      this.b = new ArrayList();
    }
    this.b.add(paramAbstractProcessor);
  }
  
  public void addTableClauseProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.c == null) {
      this.c = new ArrayList();
    }
    this.c.add(paramAbstractProcessor);
  }
  
  public void addFromJoinClauseProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.d == null) {
      this.d = new ArrayList();
    }
    this.d.add(paramAbstractProcessor);
  }
  
  public void addGroupByClauseProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.e == null) {
      this.e = new ArrayList();
    }
    this.e.add(paramAbstractProcessor);
  }
  
  public void addOrderByClauseProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.f == null) {
      this.f = new ArrayList();
    }
    this.f.add(paramAbstractProcessor);
  }
  
  public void addWhereClauseProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.g == null) {
      this.g = new ArrayList();
    }
    this.g.add(paramAbstractProcessor);
  }
  
  public void addWhereExpProcessors(AbstractProcessor paramAbstractProcessor)
  {
    if (this.h == null) {
      this.h = new ArrayList();
    }
    this.h.add(paramAbstractProcessor);
  }
  
  public void addHavingClauseProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.i == null) {
      this.i = new ArrayList();
    }
    this.i.add(paramAbstractProcessor);
  }
  
  protected void doFormat(TSelectSqlStatement paramTSelectSqlStatement)
  {
    int k = 0;
    if ((paramTSelectSqlStatement.getLeftStmt() != null) || (paramTSelectSqlStatement.getRightStmt() != null)) {
      k = 1;
    }
    if (k != 0)
    {
      Object localObject;
      if ((localObject = paramTSelectSqlStatement.getLeftStmt()) != null) {
        format((TCustomSqlStatement)localObject);
      }
      if (this.j != null)
      {
        (localObject = new ArrayList()).add(this.j);
        runProcessor((List)localObject, paramTSelectSqlStatement);
      }
      if ((localObject = paramTSelectSqlStatement.getRightStmt()) != null) {
        format((TCustomSqlStatement)localObject);
      }
      return;
    }
    a(paramTSelectSqlStatement);
  }
  
  private void a(TSelectSqlStatement paramTSelectSqlStatement)
  {
    runProcessor(getSpecialProcessors(), paramTSelectSqlStatement);
    Object localObject1 = paramTSelectSqlStatement.getResultColumnList();
    runProcessor(this.a, (TParseTreeNode)localObject1);
    Object localObject2;
    if (localObject1 != null) {
      for (int k = 0; k < ((TResultColumnList)localObject1).size(); k++) {
        if ((localObject2 = ((TResultColumnList)localObject1).getResultColumn(k)).getExpr() != null) {
          runProcessor(getExpressionProcessors(), ((TResultColumn)localObject2).getExpr());
        }
      }
    }
    runProcessor(this.b, (TParseTreeNode)localObject1);
    TTableList localTTableList = paramTSelectSqlStatement.tables;
    runProcessor(this.c, localTTableList);
    runProcessor(this.d, paramTSelectSqlStatement);
    if (paramTSelectSqlStatement.getWhereClause() != null)
    {
      runProcessor(this.g, paramTSelectSqlStatement.getWhereClause().getCondition());
      runProcessor(this.h, paramTSelectSqlStatement.getWhereClause().getCondition());
    }
    if (paramTSelectSqlStatement.getGroupByClause() != null)
    {
      if ((localObject2 = paramTSelectSqlStatement.getGroupByClause().getItems()).size() > 0) {
        runProcessor(this.e, (TParseTreeNode)localObject2);
      }
      if ((localObject1 = paramTSelectSqlStatement.getGroupByClause().getHavingClause()) != null)
      {
        runProcessor(this.i, (TParseTreeNode)localObject1);
        runProcessor(getExpressionProcessors(), (TParseTreeNode)localObject1);
      }
    }
    if ((paramTSelectSqlStatement.getOrderbyClause() != null) && ((localObject2 = paramTSelectSqlStatement.getOrderbyClause().getItems()).size() > 0)) {
      runProcessor(this.f, (TParseTreeNode)localObject2);
    }
  }
  
  public UnionProcessor getUnionProcessor()
  {
    return this.j;
  }
  
  public void setUnionProcessor(UnionProcessor paramUnionProcessor)
  {
    this.j = paramUnionProcessor;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\SelectStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */