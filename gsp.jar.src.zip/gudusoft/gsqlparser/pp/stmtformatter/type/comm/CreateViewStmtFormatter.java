package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.nodes.TViewAliasClause;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.stmt.TCreateViewSqlStatement;
import java.util.ArrayList;
import java.util.List;

public class CreateViewStmtFormatter
  extends AbstractStmtFormatter<TCreateViewSqlStatement>
{
  private List<AbstractProcessor> a;
  
  public void addParameterProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.a == null) {
      this.a = new ArrayList();
    }
    this.a.add(paramAbstractProcessor);
  }
  
  protected void doFormat(TCreateViewSqlStatement paramTCreateViewSqlStatement)
  {
    runProcessor(getSpecialProcessors(), paramTCreateViewSqlStatement);
    if ((paramTCreateViewSqlStatement.getViewAliasClause() != null) && (paramTCreateViewSqlStatement.getViewAliasClause().getViewAliasItemList() != null)) {
      runProcessor(this.a, paramTCreateViewSqlStatement.getViewAliasClause().getViewAliasItemList());
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\CreateViewStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */