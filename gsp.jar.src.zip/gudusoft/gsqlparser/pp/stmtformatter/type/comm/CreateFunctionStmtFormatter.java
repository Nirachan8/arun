package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.stmt.TStoredProcedureSqlStatement;
import java.util.ArrayList;
import java.util.List;

public class CreateFunctionStmtFormatter
  extends AbstractStmtFormatter<TStoredProcedureSqlStatement>
{
  private List<AbstractProcessor> a;
  
  public void addParameterProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.a == null) {
      this.a = new ArrayList();
    }
    this.a.add(paramAbstractProcessor);
  }
  
  protected void doFormat(TStoredProcedureSqlStatement paramTStoredProcedureSqlStatement)
  {
    runProcessor(getSpecialProcessors(), paramTStoredProcedureSqlStatement);
    if (paramTStoredProcedureSqlStatement.getParameterDeclarations() != null) {
      runProcessor(this.a, paramTStoredProcedureSqlStatement.getParameterDeclarations());
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\CreateFunctionStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */