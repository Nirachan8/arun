package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.stmt.mssql.TMssqlIfElse;

public class IfStmtFormatter
  extends AbstractStmtFormatter<TMssqlIfElse>
{
  public void format(TMssqlIfElse paramTMssqlIfElse)
  {
    runProcessor(getSpecialProcessors(), paramTMssqlIfElse);
    runProcessor(getExpressionProcessors(), paramTMssqlIfElse.getCondition());
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\IfStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */