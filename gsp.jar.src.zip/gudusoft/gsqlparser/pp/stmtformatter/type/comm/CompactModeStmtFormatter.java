package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.ETokenType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;

public class CompactModeStmtFormatter
  extends AbstractStmtFormatter<TCustomSqlStatement>
{
  public void format(TCustomSqlStatement paramTCustomSqlStatement)
  {
    runProcessor(getSpecialProcessors(), paramTCustomSqlStatement);
    a(paramTCustomSqlStatement);
  }
  
  private void a(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (paramTCustomSqlStatement == null) {
      return;
    }
    TSourceToken localTSourceToken1 = paramTCustomSqlStatement.getStartToken();
    paramTCustomSqlStatement = paramTCustomSqlStatement.getEndToken();
    if ((localTSourceToken1 == null) || (paramTCustomSqlStatement == null)) {
      return;
    }
    int i = getOption().lineWidth.intValue();
    int j = 0;
    for (int k = localTSourceToken1.posinlist; k <= paramTCustomSqlStatement.posinlist; k++)
    {
      TSourceToken localTSourceToken2 = localTSourceToken1.container.get(k);
      SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createNoFormatFlagToken());
      if (localTSourceToken2.astext != null)
      {
        if (localTSourceToken2.tokentype == ETokenType.ttsimplecomment) {
          localTSourceToken2.astext = ("/* " + localTSourceToken2.astext + "*/");
        }
        if (localTSourceToken2.astext.length() >= i)
        {
          localTSourceToken2.astext = ("\n" + localTSourceToken2.astext + "\n");
          j = 0;
        }
        else if (j += localTSourceToken2.astext.length() > i)
        {
          localTSourceToken2.astext = ("\n" + localTSourceToken2.astext);
          j = localTSourceToken2.astext.length();
        }
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\CompactModeStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */