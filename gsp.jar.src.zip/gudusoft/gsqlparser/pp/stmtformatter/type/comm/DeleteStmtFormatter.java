package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.nodes.TWhereClause;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.stmt.TDeleteSqlStatement;
import java.util.ArrayList;
import java.util.List;

public class DeleteStmtFormatter
  extends AbstractStmtFormatter<TDeleteSqlStatement>
{
  private List<AbstractProcessor> a;
  
  public void addWhereClauseProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.a == null) {
      this.a = new ArrayList();
    }
    this.a.add(paramAbstractProcessor);
  }
  
  protected void doFormat(TDeleteSqlStatement paramTDeleteSqlStatement)
  {
    runProcessor(getSpecialProcessors(), paramTDeleteSqlStatement);
    if (paramTDeleteSqlStatement.getWhereClause() != null)
    {
      runProcessor(this.a, paramTDeleteSqlStatement.getWhereClause().getCondition());
      runProcessor(getExpressionProcessors(), paramTDeleteSqlStatement.getWhereClause().getCondition());
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\DeleteStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */