package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.stmt.TAlterTableStatement;
import java.util.ArrayList;
import java.util.List;

public class AlterTableStmtFormatter
  extends AbstractStmtFormatter<TAlterTableStatement>
{
  private List<AbstractProcessor> a;
  
  protected AlterTableStmtFormatter newInstanceFormatter()
  {
    return new AlterTableStmtFormatter();
  }
  
  protected void doFormat(TAlterTableStatement paramTAlterTableStatement)
  {
    runProcessor(getSpecialProcessors(), paramTAlterTableStatement);
    paramTAlterTableStatement = paramTAlterTableStatement.getAlterTableOptionList();
    runProcessor(this.a, paramTAlterTableStatement);
  }
  
  public void addItemListProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.a == null) {
      this.a = new ArrayList();
    }
    this.a.add(paramAbstractProcessor);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\AlterTableStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */