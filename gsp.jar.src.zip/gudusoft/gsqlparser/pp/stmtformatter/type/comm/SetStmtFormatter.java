package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.stmt.mssql.TMssqlSet;

public class SetStmtFormatter
  extends AbstractStmtFormatter<TMssqlSet>
{
  protected void doFormat(TMssqlSet paramTMssqlSet)
  {
    runProcessor(getSpecialProcessors(), paramTMssqlSet);
    runProcessor(getExpressionProcessors(), paramTMssqlSet.getVarExpr());
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\SetStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */