package gudusoft.gsqlparser.pp.stmtformatter.type.comm;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TInsertIntoValue;
import gudusoft.gsqlparser.nodes.TMultiTarget;
import gudusoft.gsqlparser.nodes.TMultiTargetList;
import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.nodes.TResultColumn;
import gudusoft.gsqlparser.nodes.TResultColumnList;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.ExpressionProcessor;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.stmt.TInsertSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import java.util.ArrayList;
import java.util.List;

public class InsertStmtFormatter
  extends AbstractStmtFormatter<TInsertSqlStatement>
{
  private List<AbstractProcessor> a;
  private List<AbstractProcessor> b;
  
  public void addItemListProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.a == null) {
      this.a = new ArrayList();
    }
    this.a.add(paramAbstractProcessor);
  }
  
  public void addValueListProcessor(AbstractProcessor paramAbstractProcessor)
  {
    if (this.b == null) {
      this.b = new ArrayList();
    }
    this.b.add(paramAbstractProcessor);
  }
  
  protected void doFormat(TInsertSqlStatement paramTInsertSqlStatement)
  {
    runProcessor(getSpecialProcessors(), paramTInsertSqlStatement);
    Object localObject = paramTInsertSqlStatement.getColumnList();
    runProcessor(this.a, (TParseTreeNode)localObject);
    localObject = paramTInsertSqlStatement.getValues();
    a((TMultiTargetList)localObject);
    if ((paramTInsertSqlStatement.getInsertIntoValues() != null) && (paramTInsertSqlStatement.getInsertIntoValues().size() > 0)) {
      for (int i = 0; i < paramTInsertSqlStatement.getInsertIntoValues().size(); i++)
      {
        TInsertIntoValue localTInsertIntoValue = (TInsertIntoValue)paramTInsertSqlStatement.getInsertIntoValues().getElement(i);
        runProcessor(this.a, localTInsertIntoValue.getColumnList());
        a(localTInsertIntoValue.getTargetList());
      }
    }
    if (paramTInsertSqlStatement.getSubQuery() != null)
    {
      TSourceToken localTSourceToken;
      int j = SourceTokenOperator.curIndentLenVT(localTSourceToken = paramTInsertSqlStatement.getStartToken());
      if ((paramTInsertSqlStatement.getInsertIntoValues() != null) && (paramTInsertSqlStatement.getInsertIntoValues().size() > 0))
      {
        SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), paramTInsertSqlStatement.getSubQuery().getStartToken());
        SourceTokenOperator.addBefore(getOption(), paramTInsertSqlStatement.getSubQuery().getStartToken(), SourceTokenOperator.createReturnSourceToken());
        SourceTokenOperator.addBefore(getOption(), paramTInsertSqlStatement.getSubQuery().getStartToken(), SourceTokenOperator.createWhitespaceSourceToken(j));
      }
      ExpressionProcessor.processParenthesesNodeInSubQuery(getOption(), paramTInsertSqlStatement.getSubQuery(), paramTInsertSqlStatement.getSubQuery().getStartToken(), paramTInsertSqlStatement.getSubQuery().getEndToken());
    }
  }
  
  private void a(TMultiTargetList paramTMultiTargetList)
  {
    if (paramTMultiTargetList != null) {
      for (int i = 0; i < paramTMultiTargetList.size(); i++)
      {
        TMultiTarget localTMultiTarget;
        if (((localTMultiTarget = paramTMultiTargetList.getMultiTarget(i)).getColumnList() != null) && (localTMultiTarget.getColumnList().size() > 0))
        {
          runProcessor(this.b, localTMultiTarget.getColumnList());
          for (int j = 0; j < localTMultiTarget.getColumnList().size(); j++)
          {
            TResultColumn localTResultColumn;
            if ((localTResultColumn = localTMultiTarget.getColumnList().getResultColumn(j)).getExpr() != null) {
              runProcessor(getExpressionProcessors(), localTResultColumn.getExpr());
            }
          }
        }
        if (localTMultiTarget.getSubQuery() != null) {
          ExpressionProcessor.processParenthesesNodeInSubQuery(getOption(), localTMultiTarget.getSubQuery(), localTMultiTarget.getSubQuery().getStartToken(), localTMultiTarget.getSubQuery().getEndToken());
        }
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\type\comm\InsertStmtFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */