package gudusoft.gsqlparser.pp.stmtformatter;

import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TGSqlParser;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.pp.output.OutputConfigFactory;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.print.IPrinter;
import gudusoft.gsqlparser.pp.print.PrinterFactory;
import gudusoft.gsqlparser.pp.print.TextPrinter;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.AllStmtsFormatter;
import java.io.ByteArrayOutputStream;

public class SqlFormatter
{
  public String format(TGSqlParser paramTGSqlParser, GFmtOpt paramGFmtOpt)
  {
    ByteArrayOutputStream localByteArrayOutputStream;
    TextPrinter localTextPrinter = PrinterFactory.createTextPrinter(localByteArrayOutputStream = new ByteArrayOutputStream());
    FormatterFactory.createAllStmtsFormatter(paramGFmtOpt).beforeFormat(paramTGSqlParser.sqlstatements);
    for (int i = 0; i < paramTGSqlParser.sqlstatements.size(); i++)
    {
      TCustomSqlStatement localTCustomSqlStatement = paramTGSqlParser.sqlstatements.get(i);
      FormatterFactory.processStatement(paramGFmtOpt, localTCustomSqlStatement);
    }
    if ((paramTGSqlParser.sqlstatements != null) && (paramTGSqlParser.sqlstatements.size() > 0))
    {
      FormatterFactory.createAllStmtsFormatter(paramGFmtOpt).doFormat(paramTGSqlParser.sqlstatements);
      FormatterFactory.createAllStmtsFormatter(paramGFmtOpt).afterFormat(paramTGSqlParser.sqlstatements);
      if (FormatterFactory.getOutputConfig() == null) {
        localTextPrinter.setOutputConfig(OutputConfigFactory.getOutputConfig(paramGFmtOpt, paramTGSqlParser.getDbVendor()));
      } else {
        localTextPrinter.setOutputConfig(FormatterFactory.getOutputConfig());
      }
      localTextPrinter.print(paramTGSqlParser.sqlstatements.get(0).getStartToken().container);
    }
    FormatterFactory.clearAllObject(paramGFmtOpt.sessionId);
    return localByteArrayOutputStream.toString();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\SqlFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */