package gudusoft.gsqlparser.pp.stmtformatter.builder.comm;

import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.ProcessorFactory;
import gudusoft.gsqlparser.pp.stmtformatter.builder.AbstractStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.InsertStmtFormatter;

public class InsertStmtFormatterBuilder
  extends AbstractStmtFormatterBuilder<InsertStmtFormatter>
{
  protected void initSpecialProcessorForFormatter(InsertStmtFormatter paramInsertStmtFormatter)
  {
    paramInsertStmtFormatter.addSpecialProcessor(ProcessorFactory.createCapitalisationProcessor(getOption()));
    paramInsertStmtFormatter.addSpecialProcessor(ProcessorFactory.createCombineWhitespaceAndClearReturnProcessor(getOption()));
    paramInsertStmtFormatter.addSpecialProcessor(ProcessorFactory.createCTEProcessor(getOption(), getOption().cteNewlineBeforeAs));
    paramInsertStmtFormatter.addSpecialProcessor(ProcessorFactory.createInsertKeyWordAlignProcessor(getOption()));
    paramInsertStmtFormatter.addSpecialProcessor(ProcessorFactory.createAppendLineAfterInsertTableNameProcessor(getOption()));
    paramInsertStmtFormatter.addSpecialProcessor(ProcessorFactory.createInsertValuesParenthsesAdjustProcessor(getOption()));
    paramInsertStmtFormatter.addSpecialProcessor(ProcessorFactory.createInsertOutputClauseProcessor(getOption()));
    paramInsertStmtFormatter.addItemListProcessor(ProcessorFactory.createColumnlistCommaProcessor(getOption(), getOption().defaultCommaOption, getOption().insertColumnlistStyle));
    paramInsertStmtFormatter.addValueListProcessor(ProcessorFactory.createAppendNewLineBeforeReverseKeyWordProcessor(getOption(), true, "values"));
    paramInsertStmtFormatter.addValueListProcessor(ProcessorFactory.createColumnlistCommaProcessor(getOption(), getOption().defaultCommaOption, getOption().insertValuelistStyle));
  }
  
  protected InsertStmtFormatter newInstanceFormatter()
  {
    return new InsertStmtFormatter();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\comm\InsertStmtFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */