package gudusoft.gsqlparser.pp.stmtformatter.builder.comm;

import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.ProcessorFactory;
import gudusoft.gsqlparser.pp.stmtformatter.builder.AbstractStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.UpdateStmtFormatter;

public class UpdateStmtFormatterBuilder
  extends AbstractStmtFormatterBuilder<UpdateStmtFormatter>
{
  protected void initSpecialProcessorForFormatter(UpdateStmtFormatter paramUpdateStmtFormatter)
  {
    paramUpdateStmtFormatter.addSpecialProcessor(ProcessorFactory.createCapitalisationProcessor(getOption()));
    paramUpdateStmtFormatter.addSpecialProcessor(ProcessorFactory.createCombineWhitespaceAndClearReturnProcessor(getOption()));
    paramUpdateStmtFormatter.addSpecialProcessor(ProcessorFactory.createUpdateKeyWordAlignProcessor(getOption()));
    paramUpdateStmtFormatter.addSetClauseProcessor(ProcessorFactory.createAppendNewLineBeforeReverseKeyWordProcessor(getOption(), true, "set"));
    paramUpdateStmtFormatter.addSetClauseProcessor(ProcessorFactory.createColumnlistCommaProcessor(getOption(), getOption().defaultCommaOption, getOption().defaultAligntype));
    paramUpdateStmtFormatter.addWhereClauseProcessor(ProcessorFactory.createAppendNewLineBeforeReverseKeyWordProcessor(getOption(), true, "where"));
  }
  
  protected UpdateStmtFormatter newInstanceFormatter()
  {
    return new UpdateStmtFormatter();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\comm\UpdateStmtFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */