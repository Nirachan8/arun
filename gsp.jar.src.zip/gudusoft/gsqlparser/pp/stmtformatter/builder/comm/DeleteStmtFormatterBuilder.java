package gudusoft.gsqlparser.pp.stmtformatter.builder.comm;

import gudusoft.gsqlparser.pp.processor.ProcessorFactory;
import gudusoft.gsqlparser.pp.stmtformatter.builder.AbstractStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.DeleteStmtFormatter;

public class DeleteStmtFormatterBuilder
  extends AbstractStmtFormatterBuilder<DeleteStmtFormatter>
{
  protected void initSpecialProcessorForFormatter(DeleteStmtFormatter paramDeleteStmtFormatter)
  {
    paramDeleteStmtFormatter.addSpecialProcessor(ProcessorFactory.createCapitalisationProcessor(getOption()));
    paramDeleteStmtFormatter.addSpecialProcessor(ProcessorFactory.createCombineWhitespaceAndClearReturnProcessor(getOption()));
    paramDeleteStmtFormatter.addSpecialProcessor(ProcessorFactory.createDeleteKeyWordAlignProcessor(getOption()));
    paramDeleteStmtFormatter.addWhereClauseProcessor(ProcessorFactory.createAppendNewLineBeforeReverseKeyWordProcessor(getOption(), true, "where"));
  }
  
  protected DeleteStmtFormatter newInstanceFormatter()
  {
    return new DeleteStmtFormatter();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\comm\DeleteStmtFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */