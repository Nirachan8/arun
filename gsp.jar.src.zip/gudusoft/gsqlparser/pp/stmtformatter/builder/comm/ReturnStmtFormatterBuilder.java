package gudusoft.gsqlparser.pp.stmtformatter.builder.comm;

import gudusoft.gsqlparser.pp.processor.ProcessorFactory;
import gudusoft.gsqlparser.pp.stmtformatter.builder.AbstractStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.ReturnStmtFormatter;

public class ReturnStmtFormatterBuilder
  extends AbstractStmtFormatterBuilder<ReturnStmtFormatter>
{
  protected void initSpecialProcessorForFormatter(ReturnStmtFormatter paramReturnStmtFormatter)
  {
    paramReturnStmtFormatter.addSpecialProcessor(ProcessorFactory.createCapitalisationProcessor(getOption()));
    paramReturnStmtFormatter.addSpecialProcessor(ProcessorFactory.createCombineWhitespaceAndClearReturnProcessor(getOption()));
    paramReturnStmtFormatter.addSpecialProcessor(ProcessorFactory.createReturnStmtProcessor(getOption()));
  }
  
  protected ReturnStmtFormatter newInstanceFormatter()
  {
    return new ReturnStmtFormatter();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\comm\ReturnStmtFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */