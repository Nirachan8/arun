package gudusoft.gsqlparser.pp.stmtformatter.builder.comm;

import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.styleenums.TAlignStyle;
import gudusoft.gsqlparser.pp.para.styleenums.TLinefeedsCommaOption;
import gudusoft.gsqlparser.pp.processor.ProcessorFactory;
import gudusoft.gsqlparser.pp.stmtformatter.builder.AbstractStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.DeclareStmtFormatter;

public class DeclareStmtFormatterBuilder
  extends AbstractStmtFormatterBuilder<DeclareStmtFormatter>
{
  protected void initSpecialProcessorForFormatter(DeclareStmtFormatter paramDeclareStmtFormatter)
  {
    paramDeclareStmtFormatter.addSpecialProcessor(ProcessorFactory.createCapitalisationProcessor(getOption()));
    paramDeclareStmtFormatter.addSpecialProcessor(ProcessorFactory.createCombineWhitespaceAndClearReturnProcessor(getOption()));
    paramDeclareStmtFormatter.addVarProcessor(ProcessorFactory.createDeclareVarItemAlignProcessor(getOption()));
    paramDeclareStmtFormatter.addVarProcessor(ProcessorFactory.appendNewLineAfterReverseKeyWordProcessor(getOption(), getOption().linebreakAfterDeclare.booleanValue(), "declare"));
    paramDeclareStmtFormatter.addVarProcessor(ProcessorFactory.createColumnlistCommaProcessor(getOption(), TLinefeedsCommaOption.LfAfterComma, TAlignStyle.AsStacked));
  }
  
  protected DeclareStmtFormatter newInstanceFormatter()
  {
    return new DeclareStmtFormatter();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\comm\DeclareStmtFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */