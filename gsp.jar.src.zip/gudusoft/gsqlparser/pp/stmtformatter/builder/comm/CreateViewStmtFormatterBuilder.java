package gudusoft.gsqlparser.pp.stmtformatter.builder.comm;

import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.ProcessorFactory;
import gudusoft.gsqlparser.pp.stmtformatter.builder.AbstractStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.CreateViewStmtFormatter;

public class CreateViewStmtFormatterBuilder
  extends AbstractStmtFormatterBuilder<CreateViewStmtFormatter>
{
  protected void initSpecialProcessorForFormatter(CreateViewStmtFormatter paramCreateViewStmtFormatter)
  {
    paramCreateViewStmtFormatter.addSpecialProcessor(ProcessorFactory.createCapitalisationProcessor(getOption()));
    paramCreateViewStmtFormatter.addSpecialProcessor(ProcessorFactory.createCombineWhitespaceAndClearReturnProcessor(getOption()));
    paramCreateViewStmtFormatter.addSpecialProcessor(ProcessorFactory.createCreateViewReturnProcessor(getOption()));
    paramCreateViewStmtFormatter.addParameterProcessor(ProcessorFactory.createColumnlistCommaProcessor(getOption(), getOption().parametersComma, getOption().parametersStyle));
    paramCreateViewStmtFormatter.addParameterProcessor(ProcessorFactory.createAlignAliasProcessor(getOption(), true, getOption().parametersStyle));
  }
  
  protected CreateViewStmtFormatter newInstanceFormatter()
  {
    return new CreateViewStmtFormatter();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\comm\CreateViewStmtFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */