package gudusoft.gsqlparser.pp.stmtformatter.builder.comm;

import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.ProcessorFactory;
import gudusoft.gsqlparser.pp.stmtformatter.builder.AbstractStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.CreateTableStmtFormatter;

public class CreateTableStmtFormatterBuilder
  extends AbstractStmtFormatterBuilder<CreateTableStmtFormatter>
{
  protected void initSpecialProcessorForFormatter(CreateTableStmtFormatter paramCreateTableStmtFormatter)
  {
    paramCreateTableStmtFormatter.addSpecialProcessor(ProcessorFactory.createCapitalisationProcessor(getOption()));
    paramCreateTableStmtFormatter.addSpecialProcessor(ProcessorFactory.createCombineWhitespaceAndClearReturnProcessor(getOption()));
    paramCreateTableStmtFormatter.addSpecialProcessor(ProcessorFactory.createCreateTableBEInNewLineProcessor(getOption(), Boolean.valueOf(getOption().beStyleCreatetableLeftBEOnNewline), Boolean.valueOf(getOption().beStyleCreatetableRightBEOnNewline), Boolean.valueOf(getOption().createtableListitemInNewLine)));
    paramCreateTableStmtFormatter.addSpecialProcessor(ProcessorFactory.createCreateTableConstraintAlignProcessor(getOption()));
    paramCreateTableStmtFormatter.addItemListProcessor(ProcessorFactory.createColumnlistCommaProcessor(getOption(), getOption().defaultCommaOption, getOption().defaultAligntype));
    paramCreateTableStmtFormatter.addItemListProcessor(ProcessorFactory.createCreateTableItemAlignProcessor(getOption(), getOption().createtableFieldlistAlignOption));
    paramCreateTableStmtFormatter.addConstraintListProcessor(ProcessorFactory.createColumnlistCommaProcessor(getOption(), getOption().defaultCommaOption, getOption().defaultAligntype));
  }
  
  protected CreateTableStmtFormatter newInstanceFormatter()
  {
    return new CreateTableStmtFormatter();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\comm\CreateTableStmtFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */