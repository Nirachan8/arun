package gudusoft.gsqlparser.pp.stmtformatter.builder.comm;

import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.ProcessorFactory;
import gudusoft.gsqlparser.pp.stmtformatter.builder.AbstractStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.SelectStmtFormatter;

public class SelectStmtFormatterBuilder
  extends AbstractStmtFormatterBuilder<SelectStmtFormatter>
{
  protected SelectStmtFormatter newInstanceFormatter()
  {
    return new SelectStmtFormatter();
  }
  
  protected void initSpecialProcessorForFormatter(SelectStmtFormatter paramSelectStmtFormatter)
  {
    paramSelectStmtFormatter.addSpecialProcessor(ProcessorFactory.createCapitalisationProcessor(getOption()));
    paramSelectStmtFormatter.addSpecialProcessor(ProcessorFactory.createCombineWhitespaceAndClearReturnProcessor(getOption()));
    paramSelectStmtFormatter.addSpecialProcessor(ProcessorFactory.createSelectKeyWordAlignProcessor(getOption()));
    paramSelectStmtFormatter.addSpecialProcessor(ProcessorFactory.createCTEProcessor(getOption(), getOption().cteNewlineBeforeAs));
    paramSelectStmtFormatter.addSpecialProcessor(ProcessorFactory.createDistinctKeyWordProcessor(getOption(), getOption().treatDistinctAsVirtualColumn));
    paramSelectStmtFormatter.addItemListProcessor(ProcessorFactory.appendNewLineAfterReverseKeyWordProcessor(getOption(), getOption().selectItemInNewLine, "select"));
    paramSelectStmtFormatter.addItemListProcessor(ProcessorFactory.createColumnlistCommaProcessor(getOption(), getOption().selectColumnlistComma, getOption().selectColumnlistStyle));
    paramSelectStmtFormatter.addItemListAlignProcessor(ProcessorFactory.createAlignAliasProcessor(getOption(), getOption().alignAliasInSelectList, getOption().selectColumnlistStyle));
    paramSelectStmtFormatter.addTableClauseProcessor(ProcessorFactory.appendNewLineAfterAndBeforeReverseKeyWordProcessor(getOption(), getOption().fromClauseInNewLine, "from", null));
    paramSelectStmtFormatter.addTableClauseProcessor(ProcessorFactory.createColumnlistCommaProcessor(getOption(), getOption().selectFromclauseComma, getOption().selectFromclauseStyle));
    paramSelectStmtFormatter.addFromJoinClauseProcessor(ProcessorFactory.createJoinOnProcessor(getOption(), getOption().selectFromclauseJoinOnInNewline, getOption().alignJoinWithFromKeyword));
    paramSelectStmtFormatter.addGroupByClauseProcessor(ProcessorFactory.appendNewLineAfterAndBeforeReverseKeyWordProcessor(getOption(), getOption().selectItemInNewLine, "group", "by"));
    paramSelectStmtFormatter.addGroupByClauseProcessor(ProcessorFactory.createColumnlistCommaProcessor(getOption(), getOption().selectColumnlistComma, getOption().selectColumnlistStyle));
    paramSelectStmtFormatter.addHavingClauseProcessor(ProcessorFactory.appendNewLineAfterReverseKeyWordProcessor(getOption(), false, "having"));
    paramSelectStmtFormatter.addOrderByClauseProcessor(ProcessorFactory.appendNewLineAfterAndBeforeReverseKeyWordProcessor(getOption(), getOption().selectItemInNewLine, "order", "by"));
    paramSelectStmtFormatter.addOrderByClauseProcessor(ProcessorFactory.createColumnlistCommaProcessor(getOption(), getOption().selectColumnlistComma, getOption().selectColumnlistStyle));
    paramSelectStmtFormatter.addWhereClauseProcessor(ProcessorFactory.createAppendNewLineBeforeReverseKeyWordProcessor(getOption(), true, "where"));
    paramSelectStmtFormatter.addWhereExpProcessors(ProcessorFactory.createExpressionProcessor(getOption(), Boolean.valueOf(getOption().andOrUnderWhere)));
    paramSelectStmtFormatter.setUnionProcessor(ProcessorFactory.createUnionProcessor(getOption()));
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\comm\SelectStmtFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */