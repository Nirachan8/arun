package gudusoft.gsqlparser.pp.stmtformatter.builder.comm;

import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.styleenums.TAlignStyle;
import gudusoft.gsqlparser.pp.para.styleenums.TLinefeedsCommaOption;
import gudusoft.gsqlparser.pp.processor.ProcessorFactory;
import gudusoft.gsqlparser.pp.stmtformatter.builder.AbstractStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.ExecuteStmtFormatter;

public class ExecuteStmtFormatterBuilder
  extends AbstractStmtFormatterBuilder<ExecuteStmtFormatter>
{
  protected void initSpecialProcessorForFormatter(ExecuteStmtFormatter paramExecuteStmtFormatter)
  {
    paramExecuteStmtFormatter.addSpecialProcessor(ProcessorFactory.createCapitalisationProcessor(getOption()));
    paramExecuteStmtFormatter.addSpecialProcessor(ProcessorFactory.createCombineWhitespaceAndClearReturnProcessor(getOption()));
    paramExecuteStmtFormatter.addSpecialProcessor(ProcessorFactory.createExecParaNewLineProcessor(getOption(), getOption().linebreakBeforeParamInExec));
    paramExecuteStmtFormatter.addParaListProcessor(ProcessorFactory.createColumnlistCommaProcessor(getOption(), TLinefeedsCommaOption.LfAfterComma, getOption().linebreakBeforeParamInExec.booleanValue() ? TAlignStyle.AsStacked : TAlignStyle.AsWrapped));
  }
  
  protected ExecuteStmtFormatter newInstanceFormatter()
  {
    return new ExecuteStmtFormatter();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\comm\ExecuteStmtFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */