package gudusoft.gsqlparser.pp.stmtformatter.builder.comm;

import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.AllStmtsFormatter;

public class AllStmtsFormatterBuilder
{
  public static AllStmtsFormatter create(GFmtOpt paramGFmtOpt)
  {
    AllStmtsFormatter localAllStmtsFormatter;
    (localAllStmtsFormatter = new AllStmtsFormatter()).setSessionId(paramGFmtOpt.sessionId);
    return localAllStmtsFormatter;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\comm\AllStmtsFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */