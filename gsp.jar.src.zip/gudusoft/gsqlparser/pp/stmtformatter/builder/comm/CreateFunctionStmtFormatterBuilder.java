package gudusoft.gsqlparser.pp.stmtformatter.builder.comm;

import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.ProcessorFactory;
import gudusoft.gsqlparser.pp.stmtformatter.builder.AbstractStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.CreateFunctionStmtFormatter;

public class CreateFunctionStmtFormatterBuilder
  extends AbstractStmtFormatterBuilder<CreateFunctionStmtFormatter>
{
  protected void initSpecialProcessorForFormatter(CreateFunctionStmtFormatter paramCreateFunctionStmtFormatter)
  {
    paramCreateFunctionStmtFormatter.addSpecialProcessor(ProcessorFactory.createCapitalisationProcessor(getOption()));
    paramCreateFunctionStmtFormatter.addSpecialProcessor(ProcessorFactory.createCombineWhitespaceAndClearReturnProcessor(getOption()));
    paramCreateFunctionStmtFormatter.addSpecialProcessor(ProcessorFactory.createCreateFuncLeftBEProcessor(getOption(), getOption().beStyleFunctionLeftBEOnNewline, getOption().beStyleFunctionLeftBEIndentSize));
    paramCreateFunctionStmtFormatter.addSpecialProcessor(ProcessorFactory.createCreateFuncRightBEProcessor(getOption(), getOption().beStyleFunctionRightBEOnNewline, getOption().beStyleFunctionRightBEIndentSize));
    paramCreateFunctionStmtFormatter.addSpecialProcessor(ProcessorFactory.createCreateFuncFirstParamInNewlineProcessor(getOption(), getOption().beStyleFunctionFirstParamInNewline));
    paramCreateFunctionStmtFormatter.addSpecialProcessor(ProcessorFactory.createCreateFuncReturnsTableProcessor(getOption()));
    paramCreateFunctionStmtFormatter.addSpecialProcessor(ProcessorFactory.createCreateFuncWSPaddingParenthesesProcessor(getOption()));
    paramCreateFunctionStmtFormatter.addParameterProcessor(ProcessorFactory.createColumnlistCommaProcessor(getOption(), getOption().parametersComma, getOption().parametersStyle));
    paramCreateFunctionStmtFormatter.addParameterProcessor(ProcessorFactory.createAlignAliasProcessor(getOption(), true, getOption().parametersStyle));
  }
  
  protected CreateFunctionStmtFormatter newInstanceFormatter()
  {
    return new CreateFunctionStmtFormatter();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\comm\CreateFunctionStmtFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */