package gudusoft.gsqlparser.pp.stmtformatter.builder.comm;

import gudusoft.gsqlparser.pp.processor.ProcessorFactory;
import gudusoft.gsqlparser.pp.stmtformatter.builder.AbstractStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.CompactModeStmtFormatter;

public class CompactModeStmtFormatterBuilder
  extends AbstractStmtFormatterBuilder<CompactModeStmtFormatter>
{
  protected void initSpecialProcessorForFormatter(CompactModeStmtFormatter paramCompactModeStmtFormatter)
  {
    paramCompactModeStmtFormatter.addSpecialProcessor(ProcessorFactory.createCapitalisationProcessor(getOption()));
    paramCompactModeStmtFormatter.addSpecialProcessor(ProcessorFactory.createCombineWhitespaceAndClearReturnProcessor(getOption()));
  }
  
  protected CompactModeStmtFormatter newInstanceFormatter()
  {
    return new CompactModeStmtFormatter();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\comm\CompactModeStmtFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */