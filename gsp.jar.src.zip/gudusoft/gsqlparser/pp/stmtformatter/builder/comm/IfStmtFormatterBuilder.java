package gudusoft.gsqlparser.pp.stmtformatter.builder.comm;

import gudusoft.gsqlparser.pp.processor.ProcessorFactory;
import gudusoft.gsqlparser.pp.stmtformatter.builder.AbstractStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.IfStmtFormatter;

public class IfStmtFormatterBuilder
  extends AbstractStmtFormatterBuilder<IfStmtFormatter>
{
  protected void initSpecialProcessorForFormatter(IfStmtFormatter paramIfStmtFormatter)
  {
    paramIfStmtFormatter.addSpecialProcessor(ProcessorFactory.createCapitalisationProcessor(getOption()));
    paramIfStmtFormatter.addSpecialProcessor(ProcessorFactory.createCombineWhitespaceAndClearReturnProcessor(getOption()));
    paramIfStmtFormatter.addSpecialProcessor(ProcessorFactory.createIfStmtBEProcessor(getOption()));
  }
  
  protected IfStmtFormatter newInstanceFormatter()
  {
    return new IfStmtFormatter();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\comm\IfStmtFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */