package gudusoft.gsqlparser.pp.stmtformatter.builder.comm;

import gudusoft.gsqlparser.pp.stmtformatter.builder.AbstractStmtFormatterBuilder;
import gudusoft.gsqlparser.pp.stmtformatter.type.comm.GoStmtFormatter;

public class GoStmtFormatterBuilder
  extends AbstractStmtFormatterBuilder<GoStmtFormatter>
{
  protected void initSpecialProcessorForFormatter(GoStmtFormatter paramGoStmtFormatter) {}
  
  protected GoStmtFormatter newInstanceFormatter()
  {
    return new GoStmtFormatter();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\comm\GoStmtFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */