package gudusoft.gsqlparser.pp.stmtformatter.builder;

import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.ProcessorFactory;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;

public class AbstractStmtFormatterBuilder<E extends AbstractStmtFormatter>
{
  private GFmtOpt a;
  
  public E build()
  {
    AbstractStmtFormatter localAbstractStmtFormatter;
    (localAbstractStmtFormatter = newInstanceFormatter()).setSessionId(getOption().sessionId);
    initCommonProcessorsForFormatter(localAbstractStmtFormatter);
    initSpecialProcessorForFormatter(localAbstractStmtFormatter);
    return localAbstractStmtFormatter;
  }
  
  protected void initCommonProcessorsForFormatter(E paramE)
  {
    paramE.addExpressionProcessor(ProcessorFactory.createExpressionProcessor(getOption()));
  }
  
  protected void initSpecialProcessorForFormatter(E paramE) {}
  
  protected E newInstanceFormatter()
  {
    return null;
  }
  
  public GFmtOpt getOption()
  {
    return this.a;
  }
  
  public void setOption(GFmtOpt paramGFmtOpt)
  {
    this.a = paramGFmtOpt;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\stmtformatter\builder\AbstractStmtFormatterBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */