package gudusoft.gsqlparser.pp.mediator;

import gudusoft.gsqlparser.pp.logger.PPLogger;
import gudusoft.gsqlparser.pp.mediator.type.AbstractMediator;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MediatorFactory
{
  private static volatile Map<String, AbstractMediator> a = new Hashtable();
  
  public static <E extends AbstractMediator> E getMediator(Class<E> paramClass, String paramString)
  {
    paramString = paramString + paramClass.getName();
    if (!a.containsKey(paramString)) {
      synchronized (MediatorFactory.class)
      {
        if (!a.containsKey(paramString))
        {
          paramClass = newInstance(paramClass);
          a.put(paramString, paramClass);
        }
      }
    }
    return (AbstractMediator)a.get(paramString);
  }
  
  public static <E extends AbstractMediator> E newInstance(Class<E> paramClass)
  {
    try
    {
      return (AbstractMediator)paramClass.newInstance();
    }
    catch (InstantiationException localInstantiationException)
    {
      PPLogger.error(paramClass = localInstantiationException);
      return null;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      PPLogger.error(paramClass = localIllegalAccessException);
    }
    return null;
  }
  
  public static void clear(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = a.keySet().iterator();
    String str;
    while (localIterator.hasNext()) {
      if ((str = (String)localIterator.next()).startsWith(paramString)) {
        localArrayList.add(str);
      }
    }
    localIterator = localArrayList.iterator();
    while (localIterator.hasNext())
    {
      str = (String)localIterator.next();
      a.remove(str);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\mediator\MediatorFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */