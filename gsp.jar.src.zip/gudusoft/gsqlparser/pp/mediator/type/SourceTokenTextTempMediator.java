package gudusoft.gsqlparser.pp.mediator.type;

import java.util.HashMap;
import java.util.Map;

public class SourceTokenTextTempMediator
  extends AbstractMediator
{
  private Map<Integer, String> a = new HashMap();
  
  public String get(Integer paramInteger)
  {
    return (String)this.a.get(paramInteger);
  }
  
  public void set(Integer paramInteger, String paramString)
  {
    if (this.a.containsKey(paramInteger)) {
      return;
    }
    this.a.put(paramInteger, paramString);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\mediator\type\SourceTokenTextTempMediator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */