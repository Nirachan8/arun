package gudusoft.gsqlparser.pp.mediator.type;

public class AbstractMediator {}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\mediator\type\AbstractMediator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */