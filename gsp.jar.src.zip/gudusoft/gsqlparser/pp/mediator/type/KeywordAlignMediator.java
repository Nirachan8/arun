package gudusoft.gsqlparser.pp.mediator.type;

import gudusoft.gsqlparser.TSourceToken;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class KeywordAlignMediator
  extends AbstractMediator
{
  private int a = 0;
  private Map<Integer, List<IndentLevelItem>> b = new HashMap();
  
  public void addIndentLevelItem(TSourceToken paramTSourceToken, int paramInt)
  {
    if (!this.b.containsKey(Integer.valueOf(this.a))) {
      this.b.put(Integer.valueOf(this.a), new ArrayList());
    }
    List localList;
    (localList = (List)this.b.get(Integer.valueOf(this.a))).add(new IndentLevelItem(this.a, paramInt, paramTSourceToken));
  }
  
  public int getCurLevelIndentLen()
  {
    if (this.b.containsKey(Integer.valueOf(this.a)))
    {
      Object localObject = (List)this.b.get(Integer.valueOf(this.a));
      int i = 0;
      localObject = ((List)localObject).iterator();
      while (((Iterator)localObject).hasNext())
      {
        IndentLevelItem localIndentLevelItem;
        if ((localIndentLevelItem = (IndentLevelItem)((Iterator)localObject).next()).getIndentLen() > i) {
          i = localIndentLevelItem.getIndentLen();
        }
      }
      return i;
    }
    return 0;
  }
  
  public int getLevelIndentLen(int paramInt)
  {
    if (this.b.containsKey(Integer.valueOf(paramInt)))
    {
      paramInt = (List)this.b.get(Integer.valueOf(paramInt));
      int i = 0;
      paramInt = paramInt.iterator();
      while (paramInt.hasNext())
      {
        IndentLevelItem localIndentLevelItem;
        if ((localIndentLevelItem = (IndentLevelItem)paramInt.next()).getIndentLen() > i) {
          i = localIndentLevelItem.getIndentLen();
        }
      }
      return i;
    }
    return 0;
  }
  
  public int getCurrentIndentLevel()
  {
    return this.a;
  }
  
  public void increaseLevel()
  {
    this.a += 1;
  }
  
  public void decreaseLevel()
  {
    if (this.b.get(Integer.valueOf(this.a)) != null) {
      ((List)this.b.get(Integer.valueOf(this.a))).clear();
    }
    this.a -= 1;
  }
  
  public static class IndentLevelItem
  {
    private int a;
    private int b;
    private TSourceToken c;
    
    public IndentLevelItem() {}
    
    public IndentLevelItem(int paramInt1, int paramInt2, TSourceToken paramTSourceToken)
    {
      this.a = paramInt1;
      this.b = paramInt2;
      this.c = paramTSourceToken;
    }
    
    public int getLevel()
    {
      return this.a;
    }
    
    public void setLevel(int paramInt)
    {
      this.a = paramInt;
    }
    
    public int getIndentLen()
    {
      return this.b;
    }
    
    public void setIndentLen(int paramInt)
    {
      this.b = paramInt;
    }
    
    public TSourceToken getToken()
    {
      return this.c;
    }
    
    public void setToken(TSourceToken paramTSourceToken)
    {
      this.c = paramTSourceToken;
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\mediator\type\KeywordAlignMediator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */