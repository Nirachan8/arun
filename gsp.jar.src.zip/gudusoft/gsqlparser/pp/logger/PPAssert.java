package gudusoft.gsqlparser.pp.logger;

import gudusoft.gsqlparser.pp.utils.PPBusinessException;

public class PPAssert
{
  public static void assertTrue(boolean paramBoolean, String paramString)
  {
    if (!paramBoolean) {
      throw new PPBusinessException(paramString);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\logger\PPAssert.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */