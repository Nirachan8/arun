package gudusoft.gsqlparser.pp.logger;

import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PPLogger
{
  public static final int OFF = 0;
  public static final int INFO = 300;
  public static final int ERROR = 100;
  public static int currLogLevel = 0;
  private static PPLogger a = new PPLogger();
  
  public static void error(Throwable paramThrowable)
  {
    a(new PPLoggerRecord(100, null, paramThrowable));
  }
  
  public static void info(Throwable paramThrowable)
  {
    info(null, paramThrowable);
  }
  
  public static void info(String paramString)
  {
    info(paramString, null);
  }
  
  public static void info(String paramString, Throwable paramThrowable)
  {
    info(0, paramString, null);
  }
  
  public static void info(int paramInt, String paramString, Throwable paramThrowable)
  {
    a(new PPLoggerRecord(300, paramInt, paramString, paramThrowable));
  }
  
  private static void a(PPLoggerRecord paramPPLoggerRecord)
  {
    if (currLogLevel == 0) {
      return;
    }
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    if (currLogLevel >= paramPPLoggerRecord.getLogLevel())
    {
      StringBuilder localStringBuilder;
      (localStringBuilder = new StringBuilder()).append(localSimpleDateFormat.format(new Date()));
      switch (paramPPLoggerRecord.getLogLevel())
      {
      case 100: 
        localStringBuilder.append(" ERROR: ");
        break;
      case 300: 
        localStringBuilder.append(" INFO: ");
      }
      localStringBuilder.append(paramPPLoggerRecord.getClassName()).append(".").append(paramPPLoggerRecord.getMethodName()).append("(").append(paramPPLoggerRecord.getFileName()).append(":").append(paramPPLoggerRecord.getLineNum()).append(")");
      if (paramPPLoggerRecord.getMsg() != null) {
        localStringBuilder.append("\n").append(paramPPLoggerRecord.getMsg());
      }
      System.err.println(localStringBuilder);
      if (paramPPLoggerRecord.getE() != null) {
        paramPPLoggerRecord.getE().printStackTrace();
      }
      System.err.print("\n");
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\logger\PPLogger.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */