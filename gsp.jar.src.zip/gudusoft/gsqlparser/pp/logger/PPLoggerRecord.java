package gudusoft.gsqlparser.pp.logger;

public class PPLoggerRecord
{
  private String a;
  private String b;
  private String c;
  private Throwable d;
  private int e;
  private int f;
  private int g;
  private String h;
  
  public PPLoggerRecord(int paramInt, String paramString, Throwable paramThrowable)
  {
    this(paramInt, 0, paramString, paramThrowable);
  }
  
  public PPLoggerRecord(int paramInt1, int paramInt2, String paramString, Throwable paramThrowable)
  {
    this.e = paramInt1;
    this.f = paramInt2;
    this.h = paramString;
    this.d = paramThrowable;
    a();
  }
  
  private void a()
  {
    StackTraceElement[] arrayOfStackTraceElement = new Throwable().getStackTrace();
    StackTraceElement localStackTraceElement;
    String str;
    for (int i = 0; (i < arrayOfStackTraceElement.length) && (!(str = (localStackTraceElement = arrayOfStackTraceElement[i]).getClassName()).equals(PPLogger.class.getName())); i++) {}
    i += this.f;
    while (i < arrayOfStackTraceElement.length)
    {
      if (!(str = (localStackTraceElement = arrayOfStackTraceElement[i]).getClassName()).equals(PPLogger.class.getName()))
      {
        this.a = str;
        this.b = localStackTraceElement.getMethodName();
        this.g = localStackTraceElement.getLineNumber();
        this.c = localStackTraceElement.getFileName();
        return;
      }
      i++;
    }
  }
  
  public String getClassName()
  {
    return this.a;
  }
  
  public String getMethodName()
  {
    return this.b;
  }
  
  public int getStackLevel()
  {
    return this.f;
  }
  
  public String getMsg()
  {
    return this.h;
  }
  
  public int getLogLevel()
  {
    return this.e;
  }
  
  public Throwable getE()
  {
    return this.d;
  }
  
  public int getLineNum()
  {
    return this.g;
  }
  
  public String getFileName()
  {
    return this.c;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\logger\PPLoggerRecord.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */