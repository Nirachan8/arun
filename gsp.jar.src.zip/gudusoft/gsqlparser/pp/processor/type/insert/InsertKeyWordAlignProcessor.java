package gudusoft.gsqlparser.pp.processor.type.insert;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TInsertIntoValue;
import gudusoft.gsqlparser.nodes.TMultiTargetList;
import gudusoft.gsqlparser.nodes.TOutputClause;
import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TWhereClause;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractKeyWordAlignProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TInsertSqlStatement;
import java.util.ArrayList;
import java.util.List;

public class InsertKeyWordAlignProcessor
  extends AbstractKeyWordAlignProcessor<TInsertSqlStatement>
{
  protected List<TSourceToken[]> getTSourceToken(TInsertSqlStatement paramTInsertSqlStatement)
  {
    ArrayList localArrayList = new ArrayList();
    Object localObject;
    TSourceToken localTSourceToken1 = SourceTokenSearcher.forwardSearch(localObject = paramTInsertSqlStatement.getInsertToken(), 3, "all");
    TSourceToken localTSourceToken3 = SourceTokenSearcher.forwardSearch((TSourceToken)localObject, 3, "first");
    if ((localTSourceToken1 != null) || (localTSourceToken3 != null))
    {
      if (localTSourceToken1 != null) {
        localArrayList.add(new TSourceToken[] { localObject, localTSourceToken1 });
      }
      if (localTSourceToken3 != null) {
        localArrayList.add(new TSourceToken[] { localObject, localTSourceToken3 });
      }
      if (paramTInsertSqlStatement.getInsertIntoValues() != null) {
        for (int i = 0; i < paramTInsertSqlStatement.getInsertIntoValues().size(); i++) {
          if (((localObject = (TInsertIntoValue)paramTInsertSqlStatement.getInsertIntoValues().getElement(i)).getTargetList() != null) && ((localObject = SourceTokenSearcher.backforwardSearch(((TInsertIntoValue)localObject).getTargetList().getStartToken(), 3, "values")) != null)) {
            localArrayList.add(new TSourceToken[] { localObject });
          }
        }
      }
    }
    else
    {
      TSourceToken localTSourceToken2;
      if ((localTSourceToken2 = SourceTokenSearcher.forwardSearch((TSourceToken)localObject, 3, "into")) != null) {
        localArrayList.add(new TSourceToken[] { localObject, localTSourceToken2 });
      } else {
        localArrayList.add(new TSourceToken[] { localObject });
      }
      if (paramTInsertSqlStatement.getOutputClause() != null)
      {
        localObject = paramTInsertSqlStatement.getOutputClause().getStartToken();
        localArrayList.add(new TSourceToken[] { localObject });
      }
      if (paramTInsertSqlStatement.getWhereClause() != null)
      {
        localObject = paramTInsertSqlStatement.getWhereClause().getStartToken();
        localArrayList.add(new TSourceToken[] { localObject });
      }
      if ((paramTInsertSqlStatement.getValues() != null) && ((localObject = SourceTokenSearcher.backforwardSearch(paramTInsertSqlStatement.getValues().getStartToken(), 3, "values")) != null)) {
        localArrayList.add(new TSourceToken[] { localObject });
      }
    }
    return localArrayList;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\insert\InsertKeyWordAlignProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */