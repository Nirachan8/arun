package gudusoft.gsqlparser.pp.processor.type.insert;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TInsertIntoValue;
import gudusoft.gsqlparser.nodes.TObjectNameList;
import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TTable;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TInsertSqlStatement;

public class AppendLineAfterInsertTableNameProcessor
  extends AbstractProcessor<TInsertSqlStatement>
{
  public void process(TInsertSqlStatement paramTInsertSqlStatement)
  {
    TObjectNameList localTObjectNameList = paramTInsertSqlStatement.getColumnList();
    a(paramTInsertSqlStatement.getTargetTable(), localTObjectNameList);
    if ((paramTInsertSqlStatement.getInsertIntoValues() != null) && (paramTInsertSqlStatement.getInsertIntoValues().size() > 0)) {
      for (int i = 0; i < paramTInsertSqlStatement.getInsertIntoValues().size(); i++)
      {
        TInsertIntoValue localTInsertIntoValue = (TInsertIntoValue)paramTInsertSqlStatement.getInsertIntoValues().getElement(i);
        TSourceToken localTSourceToken;
        int j = SourceTokenOperator.curIndentLenVT(localTSourceToken = paramTInsertSqlStatement.getStartToken());
        SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), localTInsertIntoValue.getStartToken());
        SourceTokenOperator.addBefore(getOption(), localTInsertIntoValue.getStartToken(), SourceTokenOperator.createReturnSourceToken());
        SourceTokenOperator.addBefore(getOption(), localTInsertIntoValue.getStartToken(), SourceTokenOperator.createWhitespaceSourceToken(j));
        a(localTInsertIntoValue.getTable(), localTInsertIntoValue.getColumnList());
      }
    }
  }
  
  private void a(TTable paramTTable, TObjectNameList paramTObjectNameList)
  {
    if ((paramTObjectNameList != null) && (paramTObjectNameList.size() > 0))
    {
      paramTObjectNameList = SourceTokenSearcher.backforwardSearch(paramTObjectNameList.getStartToken(), 3, "(");
      paramTTable = SourceTokenOperator.curColumnNumberVT(paramTTable = paramTTable.getStartToken());
      SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), paramTObjectNameList);
      SourceTokenOperator.addBefore(getOption(), paramTObjectNameList, SourceTokenOperator.createReturnSourceToken());
      SourceTokenOperator.addBefore(getOption(), paramTObjectNameList, SourceTokenOperator.createWhitespaceSourceToken(paramTTable));
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\insert\AppendLineAfterInsertTableNameProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */