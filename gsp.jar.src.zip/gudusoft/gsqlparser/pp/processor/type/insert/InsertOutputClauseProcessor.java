package gudusoft.gsqlparser.pp.processor.type.insert;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TOutputClause;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.stmt.TInsertSqlStatement;

public class InsertOutputClauseProcessor
  extends AbstractProcessor<TInsertSqlStatement>
{
  public void process(TInsertSqlStatement paramTInsertSqlStatement)
  {
    if (paramTInsertSqlStatement.getOutputClause() == null) {
      return;
    }
    TSourceToken localTSourceToken;
    int i = SourceTokenOperator.curColumnNumberVT(localTSourceToken = paramTInsertSqlStatement.getInsertToken());
    paramTInsertSqlStatement = paramTInsertSqlStatement.getOutputClause().getStartToken();
    SourceTokenOperator.addBefore(getOption(), paramTInsertSqlStatement, SourceTokenOperator.createReturnSourceToken());
    SourceTokenOperator.addBefore(getOption(), paramTInsertSqlStatement, SourceTokenOperator.createWhitespaceSourceToken(i));
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\insert\InsertOutputClauseProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */