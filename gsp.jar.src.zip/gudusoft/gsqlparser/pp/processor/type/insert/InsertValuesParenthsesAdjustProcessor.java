package gudusoft.gsqlparser.pp.processor.type.insert;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TInsertIntoValue;
import gudusoft.gsqlparser.nodes.TMultiTarget;
import gudusoft.gsqlparser.nodes.TMultiTargetList;
import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TResultColumnList;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.stmt.TInsertSqlStatement;

public class InsertValuesParenthsesAdjustProcessor
  extends AbstractProcessor<TInsertSqlStatement>
{
  public void process(TInsertSqlStatement paramTInsertSqlStatement)
  {
    TMultiTargetList localTMultiTargetList = paramTInsertSqlStatement.getValues();
    a(localTMultiTargetList);
    if ((paramTInsertSqlStatement.getInsertIntoValues() != null) && (paramTInsertSqlStatement.getInsertIntoValues().size() > 0)) {
      for (int i = 0; i < paramTInsertSqlStatement.getInsertIntoValues().size(); i++)
      {
        TInsertIntoValue localTInsertIntoValue = (TInsertIntoValue)paramTInsertSqlStatement.getInsertIntoValues().getElement(i);
        a(localTInsertIntoValue.getTargetList());
      }
    }
  }
  
  private void a(TMultiTargetList paramTMultiTargetList)
  {
    if (paramTMultiTargetList != null) {
      for (int i = 0; i < paramTMultiTargetList.size(); i++)
      {
        TMultiTarget localTMultiTarget;
        if (((localTMultiTarget = paramTMultiTargetList.getMultiTarget(i)).getColumnList() != null) && (localTMultiTarget.getColumnList().size() > 0) && (paramTMultiTargetList.getStartToken().astext.equals("(")))
        {
          SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), paramTMultiTargetList.getStartToken());
          SourceTokenOperator.addBefore(getOption(), paramTMultiTargetList.getStartToken(), SourceTokenOperator.createWhitespaceSourceToken(1));
        }
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\insert\InsertValuesParenthsesAdjustProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */