package gudusoft.gsqlparser.pp.processor.type.declare;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TDeclareVariable;
import gudusoft.gsqlparser.nodes.TDeclareVariableList;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import java.util.Arrays;

public class DeclareVarItemAlignProcessor
  extends AbstractProcessor<TDeclareVariableList>
{
  public void process(TDeclareVariableList paramTDeclareVariableList)
  {
    if ((paramTDeclareVariableList == null) || (paramTDeclareVariableList.size() == 0)) {
      return;
    }
    int i = 0;
    for (int j = 0; j < paramTDeclareVariableList.size(); j++)
    {
      TDeclareVariable localTDeclareVariable;
      int k;
      if ((k = (localTDeclareVariable = paramTDeclareVariableList.getDeclareVariable(j)).getVariableName().getStartToken().astext.length()) > i) {
        i = k;
      }
    }
    for (j = 0; j < paramTDeclareVariableList.size(); j++)
    {
      Object localObject;
      int m = (localObject = (localObject = paramTDeclareVariableList.getDeclareVariable(j)).getVariableName().getStartToken()).astext.length();
      if ((m = i - m) > 0)
      {
        String str = a(m);
        ((TSourceToken)localObject).astext += str;
      }
    }
  }
  
  private static String a(int paramInt)
  {
    Arrays.fill(paramInt = new char[paramInt], 0, paramInt.length, ' ');
    return String.copyValueOf(paramInt);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\declare\DeclareVarItemAlignProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */