package gudusoft.gsqlparser.pp.processor.type.comm;

import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.pp.para.GFmtOpt;

public class AbstractProcessor<NodeType extends TParseTreeNode>
{
  private Object[] a;
  private GFmtOpt b;
  
  public void init(GFmtOpt paramGFmtOpt, Object... paramVarArgs)
  {
    this.b = paramGFmtOpt;
    this.a = paramVarArgs;
  }
  
  protected <E> E getParameter(Class<E> paramClass)
  {
    return (E)getParameter(paramClass, 0);
  }
  
  protected <E> E getParameter(Class<E> paramClass, int paramInt)
  {
    if ((this.a == null) || (paramInt >= this.a.length) || (this.a[paramInt] == null)) {
      return null;
    }
    if (!paramClass.isAssignableFrom(this.a[paramInt].getClass())) {
      return null;
    }
    return (E)this.a[paramInt];
  }
  
  public void beforeProcess(NodeType paramNodeType) {}
  
  public void afterProcess(NodeType paramNodeType) {}
  
  public void process(NodeType paramNodeType) {}
  
  public GFmtOpt getOption()
  {
    return this.b;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\comm\AbstractProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */