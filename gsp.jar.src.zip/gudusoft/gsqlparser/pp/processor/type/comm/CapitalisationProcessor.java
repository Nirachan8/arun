package gudusoft.gsqlparser.pp.processor.type.comm;

import gudusoft.gsqlparser.ETokenType;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.styleenums.TCaseOption;

public class CapitalisationProcessor
  extends AbstractProcessor<TParseTreeNode>
{
  public void beforeProcess(TParseTreeNode paramTParseTreeNode)
  {
    TSourceTokenList localTSourceTokenList = paramTParseTreeNode.getStartToken().container;
    for (int i = paramTParseTreeNode.getStartToken().posinlist; (i < paramTParseTreeNode.getEndToken().posinlist + 1) && (i < localTSourceTokenList.size()); i++)
    {
      TSourceToken localTSourceToken;
      if ((localTSourceToken = localTSourceTokenList.get(i)).tokentype == ETokenType.ttkeyword)
      {
        if (localTSourceToken.getDbObjType() == 30) {
          a(localTSourceToken, getOption().caseDatatype);
        } else if (localTSourceToken.getDbObjType() == 13) {
          a(localTSourceToken, getOption().caseFuncname);
        } else {
          a(localTSourceToken, getOption().caseKeywords);
        }
      }
      else if (localTSourceToken.tokentype == ETokenType.ttidentifier)
      {
        if (localTSourceToken.getDbObjType() == 30) {
          a(localTSourceToken, getOption().caseDatatype);
        } else if (localTSourceToken.getDbObjType() == 13) {
          a(localTSourceToken, getOption().caseFuncname);
        } else {
          a(localTSourceToken, getOption().caseIdentifier);
        }
      }
      else if (localTSourceToken.tokentype == ETokenType.ttdqstring) {
        a(localTSourceToken, getOption().caseQuotedIdentifier);
      }
    }
  }
  
  private static void a(TSourceToken paramTSourceToken, TCaseOption paramTCaseOption)
  {
    if ((paramTSourceToken == null) || (paramTSourceToken.astext == null)) {
      return;
    }
    if (paramTCaseOption == TCaseOption.CoUppercase)
    {
      paramTSourceToken.astext = paramTSourceToken.astext.toUpperCase();
      return;
    }
    if (paramTCaseOption == TCaseOption.CoLowercase)
    {
      paramTSourceToken.astext = paramTSourceToken.astext.toLowerCase();
      return;
    }
    if (paramTCaseOption == TCaseOption.CoInitCap)
    {
      paramTCaseOption = new StringBuffer();
      char[] arrayOfChar = paramTSourceToken.astext.toCharArray();
      int i = 32;
      int j = (arrayOfChar = arrayOfChar).length;
      for (int k = 0; k < j; k++)
      {
        char c;
        if (((c = arrayOfChar[k]) != ' ') && (i == 32)) {
          paramTCaseOption.append(Character.toUpperCase(c));
        } else {
          paramTCaseOption.append(Character.toLowerCase(c));
        }
        i = c;
      }
      paramTSourceToken.astext = paramTCaseOption.toString();
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\comm\CapitalisationProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */