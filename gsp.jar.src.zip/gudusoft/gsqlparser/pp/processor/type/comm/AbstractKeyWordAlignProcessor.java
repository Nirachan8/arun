package gudusoft.gsqlparser.pp.processor.type.comm;

import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.styleenums.TAlignOption;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public abstract class AbstractKeyWordAlignProcessor<E extends TCustomSqlStatement>
  extends AbstractProcessor<E>
{
  protected abstract List<TSourceToken[]> getTSourceToken(E paramE);
  
  public void beforeProcess(E paramE)
  {
    paramE = getTSourceToken(paramE);
    int i = 0;
    Iterator localIterator = paramE.iterator();
    TSourceToken[] arrayOfTSourceToken;
    while (localIterator.hasNext())
    {
      arrayOfTSourceToken = (TSourceToken[])localIterator.next();
      if (a(arrayOfTSourceToken) > i) {
        i = a(arrayOfTSourceToken);
      }
    }
    localIterator = paramE.iterator();
    while (localIterator.hasNext())
    {
      arrayOfTSourceToken = (TSourceToken[])localIterator.next();
      a(arrayOfTSourceToken, i);
    }
  }
  
  private int a(TSourceToken[] paramArrayOfTSourceToken)
  {
    if (paramArrayOfTSourceToken.length == 1) {
      return a(paramArrayOfTSourceToken[0]);
    }
    TSourceToken localTSourceToken1 = paramArrayOfTSourceToken[0];
    paramArrayOfTSourceToken = paramArrayOfTSourceToken[1];
    int i = 0;
    for (int j = localTSourceToken1.posinlist; j <= paramArrayOfTSourceToken.posinlist; j++)
    {
      TSourceToken localTSourceToken2;
      if ((localTSourceToken2 = localTSourceToken1.container.get(j)).astext != null) {
        i += localTSourceToken2.astext.length();
      }
    }
    return i;
  }
  
  private static int a(TSourceToken paramTSourceToken)
  {
    if ((paramTSourceToken != null) && (paramTSourceToken.astext != null)) {
      return paramTSourceToken.astext.length();
    }
    return 0;
  }
  
  private static String b(TSourceToken paramTSourceToken)
  {
    if ((paramTSourceToken != null) && (paramTSourceToken.astext != null)) {
      return paramTSourceToken.astext;
    }
    return "";
  }
  
  private void a(TSourceToken[] paramArrayOfTSourceToken, int paramInt)
  {
    if (paramArrayOfTSourceToken.length == 1)
    {
      a(paramArrayOfTSourceToken[0], paramInt);
      return;
    }
    int i = a(paramArrayOfTSourceToken);
    paramInt = a(paramInt - i);
    if (getOption().selectKeywordsAlignOption == TAlignOption.AloLeft)
    {
      paramArrayOfTSourceToken[1].astext += paramInt;
      return;
    }
    paramArrayOfTSourceToken[0].astext = (paramInt + paramArrayOfTSourceToken[0]);
  }
  
  private void a(TSourceToken paramTSourceToken, int paramInt)
  {
    int i = a(paramTSourceToken);
    paramInt = a(paramInt - i);
    if (getOption().selectKeywordsAlignOption == TAlignOption.AloLeft)
    {
      paramTSourceToken.astext = (b(paramTSourceToken) + paramInt);
      return;
    }
    paramTSourceToken.astext = (paramInt + b(paramTSourceToken));
  }
  
  private static String a(int paramInt)
  {
    Arrays.fill(paramInt = new char[paramInt], 0, paramInt.length, ' ');
    return String.copyValueOf(paramInt);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\comm\AbstractKeyWordAlignProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */