package gudusoft.gsqlparser.pp.processor.type.comm;

import gudusoft.gsqlparser.ETokenType;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.pp.mediator.MediatorFactory;
import gudusoft.gsqlparser.pp.mediator.type.SourceTokenTextTempMediator;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.stmtformatter.FormatterFactory;

public class CombineWhitespaceAndClearReturnProcessor
  extends AbstractProcessor<TParseTreeNode>
{
  public void beforeProcess(TParseTreeNode paramTParseTreeNode)
  {
    TSourceTokenList localTSourceTokenList = paramTParseTreeNode.getStartToken().container;
    for (int i = paramTParseTreeNode.getStartToken().posinlist; (i < paramTParseTreeNode.getEndToken().posinlist + 1) && (i < localTSourceTokenList.size()); i++)
    {
      TSourceToken localTSourceToken;
      if (!FormatterFactory.isNotNeedFormat(localTSourceToken = localTSourceTokenList.get(i))) {
        if (localTSourceToken.tokentype == ETokenType.ttwhitespace)
        {
          localTSourceToken.astext = " ";
        }
        else if ((localTSourceToken.tokentype == ETokenType.ttreturn) && (localTSourceToken.posinlist > 0))
        {
          Object localObject;
          (localObject = (SourceTokenTextTempMediator)MediatorFactory.getMediator(SourceTokenTextTempMediator.class, getOption().sessionId)).set(Integer.valueOf(localTSourceToken.posinlist), localTSourceToken.astext);
          if (localTSourceToken.container.get(localTSourceToken.posinlist - 1).tokentype == ETokenType.ttwhitespace) {
            localTSourceToken.astext = "";
          } else if (localTSourceToken.posinlist < localTSourceToken.container.size() - 1)
          {
            if ((localObject = localTSourceToken.container.get(localTSourceToken.posinlist + 1)).tokentype == ETokenType.ttwhitespace) {
              localTSourceToken.astext = "";
            } else {
              localTSourceToken.astext = " ";
            }
          }
          else {
            localTSourceToken.astext = " ";
          }
          localTSourceToken.tokentype = ETokenType.ttwhitespace;
        }
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\comm\CombineWhitespaceAndClearReturnProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */