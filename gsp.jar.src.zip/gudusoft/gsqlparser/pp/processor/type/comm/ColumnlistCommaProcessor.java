package gudusoft.gsqlparser.pp.processor.type.comm;

import gudusoft.gsqlparser.ETokenType;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.nodes.TParseTreeNodeList;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.styleenums.TAlignStyle;
import gudusoft.gsqlparser.pp.para.styleenums.TLinefeedsCommaOption;
import gudusoft.gsqlparser.pp.utils.SourceTokenConstant;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;

public class ColumnlistCommaProcessor
  extends AbstractProcessor<TParseTreeNodeList>
{
  public static Object[] getNextNotEmptyNode(TParseTreeNodeList paramTParseTreeNodeList, int paramInt)
  {
    for (paramInt = paramInt;; paramInt++)
    {
      if (paramInt >= paramTParseTreeNodeList.size()) {
        return new Object[] { null, Integer.valueOf(-1) };
      }
      TParseTreeNode localTParseTreeNode;
      if ((localTParseTreeNode = paramTParseTreeNodeList.getElement(paramInt)).getStartToken() != null) {
        return new Object[] { localTParseTreeNode, Integer.valueOf(paramInt) };
      }
    }
  }
  
  public static void processColumns(GFmtOpt paramGFmtOpt, TLinefeedsCommaOption paramTLinefeedsCommaOption, TAlignStyle paramTAlignStyle, TParseTreeNodeList paramTParseTreeNodeList)
  {
    if ((paramTParseTreeNodeList == null) || (paramTParseTreeNodeList.size() == 0)) {
      return;
    }
    Object[] arrayOfObject1;
    TParseTreeNode localTParseTreeNode = (TParseTreeNode)(arrayOfObject1 = getNextNotEmptyNode(paramTParseTreeNodeList, 0))[0];
    int i = ((Integer)arrayOfObject1[1]).intValue();
    TSourceToken localTSourceToken = null;
    if ((localTParseTreeNode != null) && (localTParseTreeNode.getStartToken() != null)) {
      localTSourceToken = localTParseTreeNode.getStartToken();
    }
    int j = SourceTokenOperator.curColumnNumberVT(localTSourceToken);
    int k = i;
    localTParseTreeNode = localTParseTreeNode;
    for (;;)
    {
      Object localObject = localTParseTreeNode;
      Object[] arrayOfObject2;
      localTParseTreeNode = (TParseTreeNode)(arrayOfObject2 = getNextNotEmptyNode(paramTParseTreeNodeList, k + 1))[0];
      int m = ((Integer)arrayOfObject2[1]).intValue();
      if (localTParseTreeNode == null) {
        break;
      }
      if ((((TParseTreeNode)localObject).getStartToken() != null) && (((TParseTreeNode)localObject).getEndToken() != null) && (localTParseTreeNode.getStartToken() != null) && (localTParseTreeNode.getEndToken() != null))
      {
        TSourceTokenList localTSourceTokenList = ((TParseTreeNode)localObject).getStartToken().container;
        if (paramTAlignStyle == TAlignStyle.AsWrapped)
        {
          if (paramTLinefeedsCommaOption == TLinefeedsCommaOption.LfbeforeCommaWithSpace) {
            SourceTokenOperator.addBefore(paramGFmtOpt, localTParseTreeNode.getStartToken(), SourceTokenConstant.WHITESPACE);
          }
        }
        else if (paramTLinefeedsCommaOption == TLinefeedsCommaOption.LfAfterComma)
        {
          if ((localObject = SourceTokenSearcher.lastNotWhitespaceAndReturnToken(localTSourceTokenList, ((TParseTreeNode)localObject).getEndToken().posinlist, localTParseTreeNode.getStartToken().posinlist)).tokentype == ETokenType.ttcomma)
          {
            SourceTokenOperator.removeWhitespaceAndReturnFromEnd(paramGFmtOpt, localTSourceTokenList, ((TSourceToken)localObject).posinlist);
            SourceTokenOperator.removeWhitespaceAndReturnFromStart(paramGFmtOpt, localTSourceTokenList, ((TSourceToken)localObject).posinlist + 1);
          }
          SourceTokenOperator.addBefore(paramGFmtOpt, localTParseTreeNode.getStartToken(), SourceTokenOperator.createReturnSourceToken());
          SourceTokenOperator.addBefore(paramGFmtOpt, localTParseTreeNode.getStartToken(), SourceTokenOperator.createWhitespaceSourceToken(j));
        }
        else if ((paramTLinefeedsCommaOption == TLinefeedsCommaOption.LfbeforeCommaWithSpace) || (paramTLinefeedsCommaOption == TLinefeedsCommaOption.LfBeforeComma))
        {
          if ((localObject = SourceTokenSearcher.lastNotWhitespaceAndReturnToken(localTSourceTokenList, ((TParseTreeNode)localObject).getEndToken().posinlist, localTParseTreeNode.getStartToken().posinlist)).tokentype == ETokenType.ttcomma)
          {
            SourceTokenOperator.removeWhitespaceAndReturnFromEnd(paramGFmtOpt, localTSourceTokenList, ((TSourceToken)localObject).posinlist);
            SourceTokenOperator.removeWhitespaceAndReturnFromStart(paramGFmtOpt, localTSourceTokenList, ((TSourceToken)localObject).posinlist + 1);
            SourceTokenOperator.addBefore(paramGFmtOpt, (TSourceToken)localObject, SourceTokenOperator.createReturnSourceToken());
            SourceTokenOperator.addBefore(paramGFmtOpt, (TSourceToken)localObject, SourceTokenOperator.createWhitespaceSourceToken(j));
            if (paramTLinefeedsCommaOption == TLinefeedsCommaOption.LfbeforeCommaWithSpace) {
              SourceTokenOperator.addAfter(paramGFmtOpt, (TSourceToken)localObject, SourceTokenConstant.WHITESPACE);
            }
          }
          else if ((((TSourceToken)localObject).astext != null) && (((TSourceToken)localObject).astext.equalsIgnoreCase("distinct")))
          {
            SourceTokenOperator.removeWhitespaceAndReturnFromStart(paramGFmtOpt, localTSourceTokenList, ((TSourceToken)localObject).posinlist + 1);
            SourceTokenOperator.addAfter(paramGFmtOpt, (TSourceToken)localObject, SourceTokenOperator.createReturnSourceToken());
          }
        }
      }
    }
  }
  
  public void process(TParseTreeNodeList paramTParseTreeNodeList)
  {
    TLinefeedsCommaOption localTLinefeedsCommaOption = (TLinefeedsCommaOption)getParameter(TLinefeedsCommaOption.class, 0);
    TAlignStyle localTAlignStyle = (TAlignStyle)getParameter(TAlignStyle.class, 1);
    processColumns(getOption(), localTLinefeedsCommaOption, localTAlignStyle, paramTParseTreeNodeList);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\comm\ColumnlistCommaProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */