package gudusoft.gsqlparser.pp.processor.type.comm;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.pp.mediator.MediatorFactory;
import gudusoft.gsqlparser.pp.mediator.type.KeywordAlignMediator;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.utils.SourceTokenConstant;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;

public class AppendNewLineAfterAndBeforeReverseKeyWordProcessor
  extends AbstractProcessor<TParseTreeNode>
{
  public void process(TParseTreeNode paramTParseTreeNode)
  {
    boolean bool = ((Boolean)getParameter(Boolean.class)).booleanValue();
    Object localObject1 = (String)getParameter(String.class, 1);
    String str = (String)getParameter(String.class, 2);
    getParameter(TSourceToken.class, 3);
    Object localObject2 = null;
    TSourceToken localTSourceToken = null;
    if (str != null)
    {
      if ((localObject2 = SourceTokenSearcher.lastSelectedNotWhitespaceAndReturnToken(paramTParseTreeNode.getStartToken(), str)) != null) {
        localTSourceToken = SourceTokenSearcher.backforwardSearchNotWhitespaceAndReturnToken((TSourceToken)localObject2, 3, (String)localObject1);
      }
    }
    else {
      localTSourceToken = SourceTokenSearcher.lastSelectedNotWhitespaceAndReturnToken(paramTParseTreeNode.getStartToken(), (String)localObject1);
    }
    if (localTSourceToken != null)
    {
      paramTParseTreeNode = 0;
      if ((localObject1 = (KeywordAlignMediator)MediatorFactory.getMediator(KeywordAlignMediator.class, getOption().sessionId)).getCurLevelIndentLen() > 0) {
        paramTParseTreeNode = ((KeywordAlignMediator)localObject1).getCurLevelIndentLen();
      }
      ((KeywordAlignMediator)localObject1).addIndentLevelItem(localTSourceToken, paramTParseTreeNode);
      SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), localTSourceToken.container, localTSourceToken.posinlist);
      SourceTokenOperator.addBefore(getOption(), localTSourceToken, SourceTokenOperator.createReturnSourceToken());
      SourceTokenOperator.addBefore(getOption(), localTSourceToken, SourceTokenOperator.createWhitespaceSourceToken(paramTParseTreeNode));
      if (str == null) {
        localObject2 = localTSourceToken;
      }
      SourceTokenOperator.removeWhitespaceAndReturnFromStart(getOption(), ((TSourceToken)localObject2).container, ((TSourceToken)localObject2).posinlist + 1);
      if (bool)
      {
        SourceTokenOperator.addAfter(getOption(), (TSourceToken)localObject2, SourceTokenOperator.createReturnSourceToken());
        SourceTokenOperator.addAfter(getOption(), (TSourceToken)localObject2, SourceTokenOperator.createWhitespaceSourceToken(paramTParseTreeNode + getOption().indentLen.intValue()));
        return;
      }
      SourceTokenOperator.addAfter(getOption(), (TSourceToken)localObject2, SourceTokenConstant.WHITESPACE);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\comm\AppendNewLineAfterAndBeforeReverseKeyWordProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */