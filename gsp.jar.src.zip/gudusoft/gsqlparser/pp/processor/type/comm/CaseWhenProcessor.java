package gudusoft.gsqlparser.pp.processor.type.comm;

import gudusoft.gsqlparser.nodes.TParseTreeNodeList;

public class CaseWhenProcessor
  extends AbstractProcessor<TParseTreeNodeList>
{
  public void process(TParseTreeNodeList paramTParseTreeNodeList)
  {
    getParameter(Boolean.class);
    getParameter(Integer.class);
    if ((paramTParseTreeNodeList == null) || (paramTParseTreeNodeList.size() == 0)) {}
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\comm\CaseWhenProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */