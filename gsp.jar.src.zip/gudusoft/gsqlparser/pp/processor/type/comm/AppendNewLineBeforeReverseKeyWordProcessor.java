package gudusoft.gsqlparser.pp.processor.type.comm;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.pp.mediator.MediatorFactory;
import gudusoft.gsqlparser.pp.mediator.type.KeywordAlignMediator;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.utils.SourceTokenConstant;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;

public class AppendNewLineBeforeReverseKeyWordProcessor
  extends AbstractProcessor<TParseTreeNode>
{
  public void process(TParseTreeNode paramTParseTreeNode)
  {
    boolean bool = ((Boolean)getParameter(Boolean.class)).booleanValue();
    String str = (String)getParameter(String.class, 1);
    if ((paramTParseTreeNode = SourceTokenSearcher.backforwardSearch(paramTParseTreeNode.getStartToken(), 5, str)) != null)
    {
      int i = 0;
      KeywordAlignMediator localKeywordAlignMediator;
      if ((localKeywordAlignMediator = (KeywordAlignMediator)MediatorFactory.getMediator(KeywordAlignMediator.class, getOption().sessionId)).getCurLevelIndentLen() > 0) {
        i = localKeywordAlignMediator.getCurLevelIndentLen();
      }
      localKeywordAlignMediator.addIndentLevelItem(paramTParseTreeNode, i);
      SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), paramTParseTreeNode.container, paramTParseTreeNode.posinlist);
      if (bool)
      {
        SourceTokenOperator.addBefore(getOption(), paramTParseTreeNode, SourceTokenOperator.createReturnSourceToken());
        SourceTokenOperator.addBefore(getOption(), paramTParseTreeNode, SourceTokenOperator.createWhitespaceSourceToken(i));
        return;
      }
      SourceTokenOperator.addBefore(getOption(), paramTParseTreeNode, SourceTokenConstant.WHITESPACE);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\comm\AppendNewLineBeforeReverseKeyWordProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */