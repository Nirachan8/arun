package gudusoft.gsqlparser.pp.processor.type.comm;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.nodes.TAliasClause;
import gudusoft.gsqlparser.nodes.TParameterDeclaration;
import gudusoft.gsqlparser.nodes.TParameterDeclarationList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.nodes.TParseTreeNodeList;
import gudusoft.gsqlparser.nodes.TResultColumn;
import gudusoft.gsqlparser.nodes.TResultColumnList;
import gudusoft.gsqlparser.pp.para.styleenums.TAlignStyle;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import java.util.HashMap;
import java.util.Map;

public class AlignAliasProcessor
  extends AbstractProcessor<TParseTreeNode>
{
  public void afterProcess(TParseTreeNode paramTParseTreeNode)
  {
    if ((!(paramTParseTreeNode instanceof TResultColumnList)) && (!(paramTParseTreeNode instanceof TParameterDeclarationList))) {
      return;
    }
    boolean bool = ((Boolean)getParameter(Boolean.class)).booleanValue();
    Object localObject = (TAlignStyle)getParameter(TAlignStyle.class, 1);
    if ((!bool) || (localObject == TAlignStyle.AsWrapped)) {
      return;
    }
    paramTParseTreeNode = (TParseTreeNodeList)paramTParseTreeNode;
    int i = -1;
    localObject = new HashMap();
    TParseTreeNode localTParseTreeNode;
    int k;
    int m;
    int n;
    for (int j = 0; j < paramTParseTreeNode.size(); j++)
    {
      k = (localTParseTreeNode = paramTParseTreeNode.getElement(j)).getStartToken().posinlist;
      m = -1;
      if ((localTParseTreeNode instanceof TResultColumn) ? (m = a((TResultColumn)localTParseTreeNode)) == -1 : (!(localTParseTreeNode instanceof TParameterDeclaration)) || ((m = a((TParameterDeclaration)localTParseTreeNode)) != -1))
      {
        n = SourceTokenOperator.curColumnNumberVT(localTParseTreeNode.getStartToken().container, m);
        ((Map)localObject).put(k + "_" + m, Integer.valueOf(n));
        if (n >= i) {
          i = n;
        }
      }
    }
    for (j = 0; j < paramTParseTreeNode.size(); j++)
    {
      k = (localTParseTreeNode = paramTParseTreeNode.getElement(j)).getStartToken().posinlist;
      m = -1;
      if ((localTParseTreeNode instanceof TResultColumn) ? (m = a((TResultColumn)localTParseTreeNode)) == -1 : (!(localTParseTreeNode instanceof TParameterDeclaration)) || ((m = a((TParameterDeclaration)localTParseTreeNode)) != -1))
      {
        n = ((Integer)((Map)localObject).get(k + "_" + m)).intValue();
        if ((k = i - n) != 0)
        {
          TSourceToken localTSourceToken = SourceTokenOperator.createWhitespaceSourceToken(k);
          SourceTokenOperator.addBefore(getOption(), localTParseTreeNode.getStartToken().container.get(m), localTSourceToken);
        }
      }
    }
  }
  
  private static int a(TResultColumn paramTResultColumn)
  {
    if (paramTResultColumn.getAliasClause() == null) {
      return -1;
    }
    int i;
    if ((i = SourceTokenSearcher.lastIndexOf(paramTResultColumn.getStartToken().container, paramTResultColumn.getStartToken().posinlist, paramTResultColumn.getAliasClause().getStartToken().posinlist, "as")) == -1) {
      i = paramTResultColumn.getAliasClause().getStartToken().posinlist;
    }
    return i;
  }
  
  private static int a(TParameterDeclaration paramTParameterDeclaration)
  {
    int i;
    if ((i = SourceTokenSearcher.lastIndexOf(paramTParameterDeclaration.getStartToken().container, paramTParameterDeclaration.getStartToken().posinlist, paramTParameterDeclaration.getEndToken().posinlist, "as")) == -1) {
      i = paramTParameterDeclaration.getEndToken().posinlist;
    }
    return i;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\comm\AlignAliasProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */