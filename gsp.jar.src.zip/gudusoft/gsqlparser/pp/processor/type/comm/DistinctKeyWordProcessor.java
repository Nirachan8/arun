package gudusoft.gsqlparser.pp.processor.type.comm;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.nodes.TExpression;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TResultColumn;
import gudusoft.gsqlparser.nodes.TResultColumnList;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class DistinctKeyWordProcessor
  extends AbstractProcessor<TSelectSqlStatement>
{
  public void process(TSelectSqlStatement paramTSelectSqlStatement)
  {
    boolean bool = ((Boolean)getParameter(Boolean.class)).booleanValue();
    paramTSelectSqlStatement = paramTSelectSqlStatement;
    if (bool)
    {
      Object localObject = paramTSelectSqlStatement.getStartToken();
      TSourceToken localTSourceToken = paramTSelectSqlStatement.getResultColumnList().getResultColumn(0).getStartToken();
      int i;
      if ((i = SourceTokenSearcher.indexOf(((TSourceToken)localObject).container, ((TSourceToken)localObject).posinlist, localTSourceToken.posinlist, "distinct")) > 0)
      {
        TResultColumn localTResultColumn = new TResultColumn();
        TExpression localTExpression = new TExpression();
        TObjectName localTObjectName;
        (localTObjectName = new TObjectName()).init(((TSourceToken)localObject).container.get(i));
        localTExpression.setObjectOperand(localTObjectName);
        localTResultColumn.init(localTExpression);
        localTResultColumn.setStartToken(((TSourceToken)localObject).container.get(i));
        localTResultColumn.setEndToken(((TSourceToken)localObject).container.get(i));
        (localObject = new TResultColumnList()).addResultColumn(localTResultColumn);
        for (i = 0; i < paramTSelectSqlStatement.getResultColumnList().size(); i++) {
          ((TResultColumnList)localObject).addElement(paramTSelectSqlStatement.getResultColumnList().getResultColumn(i));
        }
        paramTSelectSqlStatement.setResultColumnList((TResultColumnList)localObject);
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\comm\DistinctKeyWordProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */