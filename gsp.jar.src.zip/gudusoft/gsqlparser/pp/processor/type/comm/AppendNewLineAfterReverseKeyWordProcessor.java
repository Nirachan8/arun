package gudusoft.gsqlparser.pp.processor.type.comm;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.pp.mediator.MediatorFactory;
import gudusoft.gsqlparser.pp.mediator.type.KeywordAlignMediator;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.utils.SourceTokenConstant;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;

public class AppendNewLineAfterReverseKeyWordProcessor
  extends AbstractProcessor<TParseTreeNode>
{
  public void process(TParseTreeNode paramTParseTreeNode)
  {
    if (paramTParseTreeNode == null) {
      return;
    }
    boolean bool = ((Boolean)getParameter(Boolean.class)).booleanValue();
    Object localObject = (String)getParameter(String.class, 1);
    if ((localObject = SourceTokenSearcher.backforwardSearch(paramTParseTreeNode = paramTParseTreeNode.getStartToken(), 10, (String)localObject)) != null)
    {
      int i = SourceTokenOperator.curColumnNumberVT((TSourceToken)localObject);
      KeywordAlignMediator localKeywordAlignMediator;
      (localKeywordAlignMediator = (KeywordAlignMediator)MediatorFactory.getMediator(KeywordAlignMediator.class, getOption().sessionId)).addIndentLevelItem((TSourceToken)localObject, i);
      SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), paramTParseTreeNode);
      if (bool)
      {
        SourceTokenOperator.addBefore(getOption(), paramTParseTreeNode, SourceTokenOperator.createReturnSourceToken());
        SourceTokenOperator.addBefore(getOption(), paramTParseTreeNode, SourceTokenOperator.createWhitespaceSourceToken(i + getOption().indentLen.intValue()));
        return;
      }
      SourceTokenOperator.addBefore(getOption(), paramTParseTreeNode, SourceTokenConstant.WHITESPACE);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\comm\AppendNewLineAfterReverseKeyWordProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */