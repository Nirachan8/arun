package gudusoft.gsqlparser.pp.processor.type.comm;

import gudusoft.gsqlparser.EExpressionType;
import gudusoft.gsqlparser.ETokenType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TCaseExpression;
import gudusoft.gsqlparser.nodes.TExpression;
import gudusoft.gsqlparser.nodes.TExpressionList;
import gudusoft.gsqlparser.nodes.TFunctionCall;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TTypeName;
import gudusoft.gsqlparser.nodes.TWhenClauseItem;
import gudusoft.gsqlparser.nodes.TWhenClauseItemList;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.styleenums.TAlignStyle;
import gudusoft.gsqlparser.pp.para.styleenums.TLinefeedsCommaOption;
import gudusoft.gsqlparser.pp.stmtformatter.FormatterFactory;
import gudusoft.gsqlparser.pp.stmtformatter.type.AbstractStmtFormatter;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TDeleteSqlStatement;
import gudusoft.gsqlparser.stmt.TInsertSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import gudusoft.gsqlparser.stmt.TUpdateSqlStatement;

public class ExpressionProcessor
  extends AbstractProcessor<TExpression>
{
  public void process(TExpression paramTExpression)
  {
    Boolean localBoolean;
    if ((localBoolean = (Boolean)getParameter(Boolean.class)) == null) {
      localBoolean = Boolean.valueOf(false);
    }
    if (paramTExpression != null)
    {
      if ((paramTExpression.getLeftOperand() != null) && (paramTExpression.getRightOperand() != null))
      {
        process(paramTExpression.getLeftOperand());
        a(paramTExpression.getLeftOperand(), paramTExpression.getRightOperand(), localBoolean);
        process(paramTExpression.getRightOperand());
        return;
      }
      if ((paramTExpression.getLeftOperand() != null) && (paramTExpression.getExpressionType() != EExpressionType.in_t) && (paramTExpression.getExpressionType() != EExpressionType.unary_minus_t) && (paramTExpression.getExpressionType() != EExpressionType.unary_plus_t))
      {
        a(paramTExpression.getLeftOperand(), paramTExpression.getStartToken(), paramTExpression.getEndToken());
        return;
      }
      if ((paramTExpression.getRightOperand() != null) && (paramTExpression.getExpressionType() != EExpressionType.in_t) && (paramTExpression.getExpressionType() != EExpressionType.unary_minus_t) && (paramTExpression.getExpressionType() != EExpressionType.unary_plus_t))
      {
        a(paramTExpression.getRightOperand(), paramTExpression.getStartToken(), paramTExpression.getEndToken());
        return;
      }
      if (paramTExpression.getFunctionCall() != null)
      {
        a(paramTExpression.getFunctionCall());
        return;
      }
      a(paramTExpression);
    }
  }
  
  private void a(TFunctionCall paramTFunctionCall)
  {
    TSourceToken localTSourceToken1 = SourceTokenSearcher.forwardSearch(paramTFunctionCall.getStartToken(), 5, "(");
    TSourceToken localTSourceToken2 = paramTFunctionCall.getEndToken();
    if ((localTSourceToken1 != null) && (localTSourceToken2 != null))
    {
      SourceTokenOperator.removeWhitespaceAndReturnFromStart(getOption(), localTSourceToken1.container, localTSourceToken1.posinlist + 1);
      if (getOption().wsPaddingParenthesesInFunctionCall.booleanValue()) {
        SourceTokenOperator.addAfter(getOption(), localTSourceToken1, SourceTokenOperator.createWhitespaceSourceToken(1));
      }
      SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), localTSourceToken2);
      if (getOption().wsPaddingParenthesesInFunctionCall.booleanValue()) {
        SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createWhitespaceSourceToken(1));
      }
      a(paramTFunctionCall.getArgs());
    }
  }
  
  private void a(TExpressionList paramTExpressionList)
  {
    if ((paramTExpressionList == null) || (paramTExpressionList.size() == 0)) {
      return;
    }
    TAlignStyle localTAlignStyle = getOption().functionCallParametersStyle;
    TLinefeedsCommaOption localTLinefeedsCommaOption = getOption().functionCallParametersComma;
    ColumnlistCommaProcessor.processColumns(getOption(), localTLinefeedsCommaOption, localTAlignStyle, paramTExpressionList);
  }
  
  private void a(TExpression paramTExpression)
  {
    if (paramTExpression.getExpressionType() == EExpressionType.in_t)
    {
      if (paramTExpression.getSubQuery() != null) {
        processParenthesesNodeInSubQuery(getOption(), paramTExpression.getSubQuery(), paramTExpression.getStartToken(), paramTExpression.getEndToken());
      }
    }
    else
    {
      if (paramTExpression.getCaseExpression() != null)
      {
        a(paramTExpression.getCaseExpression());
        return;
      }
      if (paramTExpression.getSubQuery() != null)
      {
        processParenthesesNodeInSubQuery(getOption(), paramTExpression.getSubQuery(), paramTExpression.getStartToken(), paramTExpression.getEndToken());
        return;
      }
      if (paramTExpression.getFunctionCall() != null)
      {
        a(getOption(), paramTExpression.getFunctionCall());
        return;
      }
      if ((paramTExpression.getExpressionType() == EExpressionType.unary_minus_t) || (paramTExpression.getExpressionType() == EExpressionType.unary_plus_t)) {
        b(paramTExpression);
      }
    }
  }
  
  private void b(TExpression paramTExpression)
  {
    SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), paramTExpression.getStartToken());
  }
  
  private void a(GFmtOpt paramGFmtOpt, TFunctionCall paramTFunctionCall)
  {
    TSourceToken localTSourceToken = SourceTokenSearcher.forwardSearch(paramTFunctionCall.getFunctionName().getStartToken(), 5, "(");
    paramTFunctionCall = paramTFunctionCall.getEndToken();
    SourceTokenOperator.removeWhitespaceAndReturnFormBeforeAndAfter(getOption(), localTSourceToken);
    SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), paramTFunctionCall);
    if ((paramGFmtOpt.wsPaddingParenthesesInFunctionCall.booleanValue()) && (paramTFunctionCall.posinlist - localTSourceToken.posinlist > 1))
    {
      SourceTokenOperator.addAfter(getOption(), localTSourceToken, SourceTokenOperator.createWhitespaceSourceToken(1));
      SourceTokenOperator.addBefore(getOption(), paramTFunctionCall, SourceTokenOperator.createWhitespaceSourceToken(1));
    }
  }
  
  public static void processParenthesesNodeInSubQuery(GFmtOpt paramGFmtOpt, TCustomSqlStatement paramTCustomSqlStatement, TSourceToken paramTSourceToken1, TSourceToken paramTSourceToken2)
  {
    Object localObject = null;
    if ((paramTCustomSqlStatement instanceof TSelectSqlStatement)) {
      localObject = FormatterFactory.createSelectStmtFormatter(paramGFmtOpt);
    } else if ((paramTCustomSqlStatement instanceof TUpdateSqlStatement)) {
      localObject = FormatterFactory.createUpdateStmtFormatter(paramGFmtOpt);
    } else if ((paramTCustomSqlStatement instanceof TInsertSqlStatement)) {
      localObject = FormatterFactory.createInsertStmtFormatter(paramGFmtOpt);
    } else if ((paramTCustomSqlStatement instanceof TDeleteSqlStatement)) {
      localObject = FormatterFactory.createDeleteStmtFormatter(paramGFmtOpt);
    }
    if (localObject == null) {
      return;
    }
    if ((!"(".equals(paramTSourceToken1.astext)) || (!")".equals(paramTSourceToken2.astext)))
    {
      ((AbstractStmtFormatter)localObject).format(paramTCustomSqlStatement);
      return;
    }
    SourceTokenOperator.removeWhitespaceAndReturnFromStart(paramGFmtOpt, paramTSourceToken1.container, paramTSourceToken1.posinlist + 1);
    if (paramGFmtOpt.wsPaddingParenthesesOfSubQuery.booleanValue()) {
      SourceTokenOperator.addAfter(paramGFmtOpt, paramTSourceToken1, SourceTokenOperator.createWhitespaceSourceToken(1));
    }
    ((AbstractStmtFormatter)localObject).format(paramTCustomSqlStatement);
    SourceTokenOperator.removeWhitespaceAndReturnFromEnd(paramGFmtOpt, paramTSourceToken2.container, paramTSourceToken2.posinlist);
    if (paramGFmtOpt.wsPaddingParenthesesOfSubQuery.booleanValue()) {
      SourceTokenOperator.addBefore(paramGFmtOpt, paramTSourceToken2, SourceTokenOperator.createWhitespaceSourceToken(1));
    }
  }
  
  private void a(TExpression paramTExpression, TSourceToken paramTSourceToken1, TSourceToken paramTSourceToken2)
  {
    SourceTokenOperator.removeWhitespaceAndReturnFromStart(getOption(), paramTSourceToken1.container, paramTSourceToken1.posinlist + 1);
    if (getOption().wsPaddingParenthesesInExpression.booleanValue()) {
      SourceTokenOperator.addAfter(getOption(), paramTSourceToken1, SourceTokenOperator.createWhitespaceSourceToken(1));
    }
    process(paramTExpression);
    SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), paramTSourceToken2.container, paramTSourceToken2.posinlist);
    if (getOption().wsPaddingParenthesesInExpression.booleanValue()) {
      SourceTokenOperator.addBefore(getOption(), paramTSourceToken2, SourceTokenOperator.createWhitespaceSourceToken(1));
    }
  }
  
  private void a(TCaseExpression paramTCaseExpression)
  {
    TSourceToken localTSourceToken1;
    int i = SourceTokenOperator.curColumnNumberVT(localTSourceToken1 = paramTCaseExpression.getStartToken());
    TWhenClauseItemList localTWhenClauseItemList;
    if (((localTWhenClauseItemList = paramTCaseExpression.getWhenClauseItemList()) != null) && (localTWhenClauseItemList.size() > 0)) {
      for (int j = 0; j < localTWhenClauseItemList.size(); j++)
      {
        TWhenClauseItem localTWhenClauseItem;
        TSourceToken localTSourceToken3 = (localTWhenClauseItem = localTWhenClauseItemList.getWhenClauseItem(j)).getStartToken();
        SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), localTSourceToken3);
        SourceTokenOperator.addBefore(getOption(), localTSourceToken3, SourceTokenOperator.createReturnSourceToken());
        SourceTokenOperator.addBefore(getOption(), localTSourceToken3, SourceTokenOperator.createWhitespaceSourceToken(i + getOption().indentCaseFromSwitch.intValue()));
        if ((localTSourceToken3 = SourceTokenSearcher.lastNotWhitespaceAndReturnToken(localTWhenClauseItem.getReturn_expr().getStartToken().container, localTWhenClauseItem.getReturn_expr().getStartToken().posinlist - 1)).astext.equalsIgnoreCase("then"))
        {
          SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), localTSourceToken3);
          if (getOption().caseWhenThenInSameLine.booleanValue())
          {
            SourceTokenOperator.addBefore(getOption(), localTSourceToken3, SourceTokenOperator.createWhitespaceSourceToken(1));
          }
          else
          {
            SourceTokenOperator.addBefore(getOption(), localTSourceToken3, SourceTokenOperator.createReturnSourceToken());
            SourceTokenOperator.addBefore(getOption(), localTSourceToken3, SourceTokenOperator.createWhitespaceSourceToken(i + getOption().indentCaseFromSwitch.intValue() + getOption().indentCaseThen.intValue()));
          }
        }
        process(localTWhenClauseItem.getComparison_expr());
        process(localTWhenClauseItem.getReturn_expr());
      }
    }
    if ((paramTCaseExpression.getElse_expr() != null) && ((localTSourceToken2 = SourceTokenSearcher.lastNotWhitespaceAndReturnToken(paramTCaseExpression.getElse_expr().getStartToken().container, paramTCaseExpression.getElse_expr().getStartToken().posinlist - 1)).astext.equalsIgnoreCase("else")))
    {
      SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), localTSourceToken2);
      SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createReturnSourceToken());
      SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createWhitespaceSourceToken(i + getOption().indentCaseFromSwitch.intValue()));
    }
    TSourceToken localTSourceToken2 = paramTCaseExpression.getEndToken();
    SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), localTSourceToken2);
    SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createReturnSourceToken());
    SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createWhitespaceSourceToken(i));
  }
  
  private void a(TExpression paramTExpression1, TExpression paramTExpression2, Boolean paramBoolean)
  {
    int i = SourceTokenOperator.curColumnNumberVT(paramTExpression1.getStartToken());
    paramTExpression1 = SourceTokenSearcher.firstNotWhitespaceAndReturnToken(paramTExpression1.getEndToken().container, paramTExpression1.getEndToken().posinlist + 1, paramTExpression2.getStartToken().posinlist);
    if (ETokenType.ttconcatenationop.equals(paramTExpression1.tokentype))
    {
      SourceTokenOperator.addBefore(getOption(), paramTExpression1, SourceTokenOperator.createReturnSourceToken());
      SourceTokenOperator.addBefore(getOption(), paramTExpression1, SourceTokenOperator.createWhitespaceSourceToken(i + getOption().indentLen.intValue()));
      return;
    }
    if (("and".equalsIgnoreCase(paramTExpression1.astext)) || ("or".equalsIgnoreCase(paramTExpression1.astext)))
    {
      SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), paramTExpression1);
      SourceTokenOperator.addBefore(getOption(), paramTExpression1, SourceTokenOperator.createReturnSourceToken());
      if (paramBoolean.booleanValue()) {
        i -= paramTExpression1.astext.length() + 1;
      }
      SourceTokenOperator.addBefore(getOption(), paramTExpression1, SourceTokenOperator.createWhitespaceSourceToken(i));
      SourceTokenOperator.removeWhitespaceAndReturnFromStart(getOption(), paramTExpression1.container, paramTExpression1.posinlist + 1);
      SourceTokenOperator.addAfter(getOption(), paramTExpression1, SourceTokenOperator.createWhitespaceSourceToken(1));
      return;
    }
    if ((paramTExpression1.astext.trim().equals("+")) || (paramTExpression1.astext.trim().equals("-")) || (paramTExpression1.astext.trim().equals("*")) || (paramTExpression1.astext.trim().equals("/")) || (paramTExpression1.astext.trim().equals(">")) || (paramTExpression1.astext.trim().equals(">=")) || (paramTExpression1.astext.trim().equals("<")) || (paramTExpression1.astext.trim().equals("<=")) || (paramTExpression1.astext.trim().equals("==")) || (paramTExpression1.astext.trim().equals("!=")) || (paramTExpression1.astext.trim().equals("<>")) || (paramTExpression1.astext.trim().equals("=")) || (paramTExpression1.astext.trim().equals("^=")))
    {
      SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), paramTExpression1.container, paramTExpression1.posinlist);
      SourceTokenOperator.removeWhitespaceAndReturnFromStart(getOption(), paramTExpression1.container, paramTExpression1.posinlist + 1);
      if (getOption().wsPaddingOperatorArithmetic.booleanValue())
      {
        SourceTokenOperator.addBefore(getOption(), paramTExpression1, SourceTokenOperator.createWhitespaceSourceToken(1));
        SourceTokenOperator.addAfter(getOption(), paramTExpression1, SourceTokenOperator.createWhitespaceSourceToken(1));
      }
    }
  }
  
  public static void processTypeName(GFmtOpt paramGFmtOpt, TTypeName paramTTypeName)
  {
    TSourceToken localTSourceToken = SourceTokenSearcher.forwardSearch(paramTTypeName.getStartToken(), 5, "(");
    paramTTypeName = paramTTypeName.getEndToken();
    if ((localTSourceToken != null) && (paramTTypeName != null))
    {
      SourceTokenOperator.removeWhitespaceAndReturnFromStart(paramGFmtOpt, localTSourceToken.container, localTSourceToken.posinlist + 1);
      if (paramGFmtOpt.wsPaddingParenthesesOfTypename.booleanValue()) {
        SourceTokenOperator.addAfter(paramGFmtOpt, localTSourceToken, SourceTokenOperator.createWhitespaceSourceToken(1));
      }
      SourceTokenOperator.removeWhitespaceAndReturnFromEnd(paramGFmtOpt, paramTTypeName);
      if (paramGFmtOpt.wsPaddingParenthesesOfTypename.booleanValue()) {
        SourceTokenOperator.addBefore(paramGFmtOpt, paramTTypeName, SourceTokenOperator.createWhitespaceSourceToken(1));
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\comm\ExpressionProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */