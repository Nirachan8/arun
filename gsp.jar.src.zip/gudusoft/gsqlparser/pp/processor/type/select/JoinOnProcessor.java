package gudusoft.gsqlparser.pp.processor.type.select;

import gudusoft.gsqlparser.EJoinType;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TExpression;
import gudusoft.gsqlparser.nodes.TJoin;
import gudusoft.gsqlparser.nodes.TJoinItem;
import gudusoft.gsqlparser.nodes.TJoinItemList;
import gudusoft.gsqlparser.nodes.TJoinList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.nodes.TTable;
import gudusoft.gsqlparser.nodes.TTableList;
import gudusoft.gsqlparser.pp.mediator.MediatorFactory;
import gudusoft.gsqlparser.pp.mediator.type.KeywordAlignMediator;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.ExpressionProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class JoinOnProcessor
  extends AbstractProcessor<TSelectSqlStatement>
{
  public void process(TSelectSqlStatement paramTSelectSqlStatement)
  {
    boolean bool1 = ((Boolean)getParameter(Boolean.class)).booleanValue();
    boolean bool2 = ((Boolean)getParameter(Boolean.class, 1)).booleanValue();
    TTableList localTTableList = (paramTSelectSqlStatement = paramTSelectSqlStatement).tables;
    paramTSelectSqlStatement = paramTSelectSqlStatement.joins;
    if (localTTableList.size() == 0) {
      return;
    }
    int i = SourceTokenOperator.curColumnNumberVT(localTTableList.getElement(0).getStartToken());
    for (int j = 0; j < paramTSelectSqlStatement.size(); j++)
    {
      TJoin localTJoin = paramTSelectSqlStatement.getJoin(j);
      for (int k = 0; k < localTJoin.getJoinItems().size(); k++)
      {
        TJoinItem localTJoinItem;
        if ((localTJoinItem = localTJoin.getJoinItems().getJoinItem(k)) != null)
        {
          TSourceToken localTSourceToken = localTJoinItem.getStartToken();
          SourceTokenOperator.removeAllBeforeTokenVT(getOption(), localTSourceToken);
          Object localObject;
          if ((localTSourceToken = getBeginJoinToken(localTJoinItem)) != null)
          {
            SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), localTSourceToken);
            SourceTokenOperator.addBefore(getOption(), localTSourceToken, SourceTokenOperator.createReturnSourceToken());
            if (bool2)
            {
              localObject = (KeywordAlignMediator)MediatorFactory.getMediator(KeywordAlignMediator.class, getOption().sessionId);
              SourceTokenOperator.addBefore(getOption(), localTSourceToken, SourceTokenOperator.createWhitespaceSourceToken(((KeywordAlignMediator)localObject).getCurLevelIndentLen()));
            }
            else
            {
              SourceTokenOperator.addBefore(getOption(), localTSourceToken, SourceTokenOperator.createWhitespaceSourceToken(i));
            }
          }
          if ((localTJoinItem.getOnCondition() != null) && ((localObject = SourceTokenSearcher.lastSelectedNotWhitespaceAndReturnToken(localTJoinItem.getOnCondition().getStartToken(), "on")) != null) && (bool1))
          {
            SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), (TSourceToken)localObject);
            SourceTokenOperator.addBefore(getOption(), (TSourceToken)localObject, SourceTokenOperator.createReturnSourceToken());
            SourceTokenOperator.addBefore(getOption(), (TSourceToken)localObject, SourceTokenOperator.createWhitespaceSourceToken(i));
          }
        }
      }
      if ((localTJoin.getTable() != null) && (localTJoin.getTable().getSubquery() != null)) {
        ExpressionProcessor.processParenthesesNodeInSubQuery(getOption(), localTJoin.getTable().getSubquery(), localTJoin.getTable().getSubquery().getStartToken(), localTJoin.getTable().getSubquery().getEndToken());
      }
    }
  }
  
  public static TSourceToken getBeginJoinToken(TJoinItem paramTJoinItem)
  {
    TSourceToken localTSourceToken1 = paramTJoinItem.getStartToken();
    TSourceToken localTSourceToken2 = null;
    if ((paramTJoinItem.getJoinType() == EJoinType.cross) || (paramTJoinItem.getJoinType() == EJoinType.crossapply)) {
      localTSourceToken2 = SourceTokenSearcher.backforwardSearch(localTSourceToken1, 5, "cross");
    } else if ((paramTJoinItem.getJoinType() == EJoinType.full) || (paramTJoinItem.getJoinType() == EJoinType.fullouter)) {
      localTSourceToken2 = SourceTokenSearcher.backforwardSearch(localTSourceToken1, 10, "full");
    } else if (paramTJoinItem.getJoinType() == EJoinType.inner)
    {
      if ((localTSourceToken2 = SourceTokenSearcher.backforwardSearch(localTSourceToken1, 5, "inner")) == null) {
        localTSourceToken2 = SourceTokenSearcher.backforwardSearch(localTSourceToken1, 5, "join");
      }
    }
    else if ((paramTJoinItem.getJoinType() == EJoinType.left) || (paramTJoinItem.getJoinType() == EJoinType.leftouter)) {
      localTSourceToken2 = SourceTokenSearcher.backforwardSearch(localTSourceToken1, 10, "left");
    } else if (paramTJoinItem.getJoinType() == EJoinType.natural) {
      localTSourceToken2 = SourceTokenSearcher.backforwardSearch(localTSourceToken1, 5, "natural");
    } else if (paramTJoinItem.getJoinType() == EJoinType.nested) {
      localTSourceToken2 = SourceTokenSearcher.backforwardSearch(localTSourceToken1, 5, "nested");
    } else if ((paramTJoinItem.getJoinType() == EJoinType.right) || (paramTJoinItem.getJoinType() == EJoinType.rightouter)) {
      localTSourceToken2 = SourceTokenSearcher.backforwardSearch(localTSourceToken1, 10, "right");
    } else if (paramTJoinItem.getJoinType() == EJoinType.outerapply) {
      localTSourceToken2 = SourceTokenSearcher.backforwardSearch(localTSourceToken1, 5, "outer");
    }
    return localTSourceToken2;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\select\JoinOnProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */