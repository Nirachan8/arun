package gudusoft.gsqlparser.pp.processor.type.select;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.pp.mediator.MediatorFactory;
import gudusoft.gsqlparser.pp.mediator.type.KeywordAlignMediator;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class UnionProcessor
  extends AbstractProcessor<TSelectSqlStatement>
{
  public void process(TSelectSqlStatement paramTSelectSqlStatement)
  {
    TSourceToken localTSourceToken1;
    if ((paramTSelectSqlStatement.getRightStmt() != null) && (paramTSelectSqlStatement.getLeftStmt() != null) && ((localTSourceToken1 = SourceTokenSearcher.backforwardSearch(paramTSelectSqlStatement.getRightStmt().getStartToken(), 5, "union")) != null))
    {
      TSourceToken localTSourceToken2 = null;
      for (Object localObject = paramTSelectSqlStatement; (localObject != null) && (localTSourceToken2 == null); localObject = ((TSelectSqlStatement)localObject).getLeftStmt()) {
        localTSourceToken2 = ((TSelectSqlStatement)localObject).getSelectToken();
      }
      if (localTSourceToken2 == null) {
        return;
      }
      int i = SourceTokenOperator.curColumnNumberVT(localTSourceToken2);
      if ((localObject = (KeywordAlignMediator)MediatorFactory.getMediator(KeywordAlignMediator.class, getOption().sessionId)).getLevelIndentLen(((KeywordAlignMediator)localObject).getCurrentIndentLevel() + 1) > i) {
        i = ((KeywordAlignMediator)localObject).getLevelIndentLen(((KeywordAlignMediator)localObject).getCurrentIndentLevel() + 1);
      }
      ((KeywordAlignMediator)localObject).addIndentLevelItem(localTSourceToken1, i);
      SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), localTSourceToken1);
      SourceTokenOperator.addBefore(getOption(), localTSourceToken1, SourceTokenOperator.createReturnSourceToken());
      SourceTokenOperator.addBefore(getOption(), localTSourceToken1, SourceTokenOperator.createWhitespaceSourceToken(i));
      SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), paramTSelectSqlStatement.getRightStmt().getStartToken());
      SourceTokenOperator.addBefore(getOption(), paramTSelectSqlStatement.getRightStmt().getStartToken(), SourceTokenOperator.createReturnSourceToken());
      SourceTokenOperator.addBefore(getOption(), paramTSelectSqlStatement.getRightStmt().getStartToken(), SourceTokenOperator.createWhitespaceSourceToken(i));
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\select\UnionProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */