package gudusoft.gsqlparser.pp.processor.type.select;

import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TCTE;
import gudusoft.gsqlparser.nodes.TCTEList;
import gudusoft.gsqlparser.pp.mediator.MediatorFactory;
import gudusoft.gsqlparser.pp.mediator.type.KeywordAlignMediator;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.ExpressionProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TInsertSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class CTEProcessor
  extends AbstractProcessor<TCustomSqlStatement>
{
  public void process(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if ((paramTCustomSqlStatement.getCteList() == null) || (paramTCustomSqlStatement.getCteList().size() == 0)) {
      return;
    }
    boolean bool = ((Boolean)getParameter(Boolean.class)).booleanValue();
    KeywordAlignMediator localKeywordAlignMediator = (KeywordAlignMediator)MediatorFactory.newInstance(KeywordAlignMediator.class);
    TSourceToken localTSourceToken2 = SourceTokenSearcher.backforwardSearch(paramTCustomSqlStatement.getCteList().getStartToken(), 5, "with");
    SourceTokenOperator.removeWhitespaceAndReturnFromStart(getOption(), localTSourceToken2.container, localTSourceToken2.posinlist + 1);
    SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createWhitespaceSourceToken(localKeywordAlignMediator.getCurLevelIndentLen()));
    SourceTokenOperator.addAfter(getOption(), localTSourceToken2, SourceTokenOperator.createWhitespaceSourceToken(1));
    for (int i = 0; i < paramTCustomSqlStatement.getCteList().size(); i++)
    {
      TCTE localTCTE;
      TSourceToken localTSourceToken3 = SourceTokenSearcher.backforwardSearch((localTCTE = paramTCustomSqlStatement.getCteList().getCTE(i)).getPreparableStmt().getStartToken(), 5, "as");
      SourceTokenOperator.removeWhitespaceAndReturnFormBeforeAndAfter(getOption(), localTSourceToken3);
      if (bool)
      {
        SourceTokenOperator.addBefore(getOption(), localTSourceToken3, SourceTokenOperator.createReturnSourceToken());
        SourceTokenOperator.addBefore(getOption(), localTSourceToken3, SourceTokenOperator.createWhitespaceSourceToken(SourceTokenOperator.curColumnNumberVT(localTSourceToken2) + "with".length() + 1));
      }
      else
      {
        SourceTokenOperator.addBefore(getOption(), localTSourceToken3, SourceTokenOperator.createWhitespaceSourceToken(1));
      }
      SourceTokenOperator.addAfter(getOption(), localTSourceToken3, SourceTokenOperator.createWhitespaceSourceToken(1));
      ExpressionProcessor.processParenthesesNodeInSubQuery(getOption(), localTCTE.getPreparableStmt(), localTCTE.getPreparableStmt().getStartToken(), localTCTE.getPreparableStmt().getEndToken());
    }
    TSourceToken localTSourceToken1;
    if ((paramTCustomSqlStatement instanceof TSelectSqlStatement)) {
      localTSourceToken1 = ((TSelectSqlStatement)paramTCustomSqlStatement).getSelectToken();
    } else if ((paramTCustomSqlStatement instanceof TInsertSqlStatement)) {
      localTSourceToken1 = ((TInsertSqlStatement)paramTCustomSqlStatement).getInsertToken();
    } else {
      return;
    }
    SourceTokenOperator.addBefore(getOption(), localTSourceToken1, SourceTokenOperator.createReturnSourceToken());
    SourceTokenOperator.addBefore(getOption(), localTSourceToken1, SourceTokenOperator.createWhitespaceSourceToken(SourceTokenOperator.curColumnNumberVT(localTSourceToken2)));
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\select\CTEProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */