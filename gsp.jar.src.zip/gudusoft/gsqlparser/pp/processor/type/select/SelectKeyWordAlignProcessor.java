package gudusoft.gsqlparser.pp.processor.type.select;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TGroupBy;
import gudusoft.gsqlparser.nodes.TJoin;
import gudusoft.gsqlparser.nodes.TJoinItem;
import gudusoft.gsqlparser.nodes.TJoinItemList;
import gudusoft.gsqlparser.nodes.TJoinList;
import gudusoft.gsqlparser.nodes.TOrderBy;
import gudusoft.gsqlparser.nodes.TWhereClause;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractKeyWordAlignProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import java.util.ArrayList;
import java.util.List;

public class SelectKeyWordAlignProcessor
  extends AbstractKeyWordAlignProcessor<TSelectSqlStatement>
{
  protected List<TSourceToken[]> getTSourceToken(TSelectSqlStatement paramTSelectSqlStatement)
  {
    ArrayList localArrayList = new ArrayList();
    TSourceToken localTSourceToken1;
    if ((localTSourceToken1 = paramTSelectSqlStatement.getSelectToken()) != null) {
      localArrayList.add(new TSourceToken[] { localTSourceToken1 });
    }
    if (paramTSelectSqlStatement.joins.size() > 0)
    {
      localTSourceToken1 = SourceTokenSearcher.backforwardSearch(paramTSelectSqlStatement.joins.getStartToken(), 5, "from");
      localArrayList.add(new TSourceToken[] { localTSourceToken1 });
    }
    Object localObject1;
    if (paramTSelectSqlStatement.getGroupByClause() != null)
    {
      localTSourceToken1 = paramTSelectSqlStatement.getGroupByClause().getStartToken();
      localObject1 = SourceTokenSearcher.forwardSearch(paramTSelectSqlStatement.getGroupByClause().getStartToken(), 5, "by");
      localArrayList.add(new TSourceToken[] { localTSourceToken1, localObject1 });
    }
    if (paramTSelectSqlStatement.getOrderbyClause() != null)
    {
      localTSourceToken1 = paramTSelectSqlStatement.getOrderbyClause().getStartToken();
      localObject1 = SourceTokenSearcher.forwardSearch(paramTSelectSqlStatement.getOrderbyClause().getStartToken(), 5, "by");
      localArrayList.add(new TSourceToken[] { localTSourceToken1, localObject1 });
    }
    if (paramTSelectSqlStatement.getWhereClause() != null)
    {
      localTSourceToken1 = paramTSelectSqlStatement.getWhereClause().getStartToken();
      localArrayList.add(new TSourceToken[] { localTSourceToken1 });
    }
    if ((paramTSelectSqlStatement.joins != null) && (getOption().alignJoinWithFromKeyword)) {
      for (int i = 0; i < paramTSelectSqlStatement.joins.size(); i++)
      {
        localObject1 = paramTSelectSqlStatement.joins.getJoin(i);
        for (int j = 0; j < ((TJoin)localObject1).getJoinItems().size(); j++)
        {
          Object localObject2;
          if ((localObject2 = ((TJoin)localObject1).getJoinItems().getJoinItem(j)) != null) {
            if ((localObject2 = JoinOnProcessor.getBeginJoinToken((TJoinItem)localObject2)).astext.trim().equalsIgnoreCase("join"))
            {
              localArrayList.add(new TSourceToken[] { localObject2 });
            }
            else
            {
              TSourceToken localTSourceToken2 = SourceTokenSearcher.forwardSearch((TSourceToken)localObject2, 5, "join");
              localArrayList.add(new TSourceToken[] { localObject2, localTSourceToken2 });
            }
          }
        }
      }
    }
    return localArrayList;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\select\SelectKeyWordAlignProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */