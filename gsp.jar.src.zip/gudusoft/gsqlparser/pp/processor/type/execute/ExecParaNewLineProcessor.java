package gudusoft.gsqlparser.pp.processor.type.execute;

import gudusoft.gsqlparser.nodes.TExecParameter;
import gudusoft.gsqlparser.nodes.TExecParameterList;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.stmt.mssql.TMssqlExecute;

public class ExecParaNewLineProcessor
  extends AbstractProcessor<TMssqlExecute>
{
  public void process(TMssqlExecute paramTMssqlExecute)
  {
    if ((paramTMssqlExecute.getParameters() == null) || (paramTMssqlExecute.getParameters().size() == 0)) {
      return;
    }
    Object localObject;
    if ((localObject = (Boolean)getParameter(Boolean.class)).booleanValue())
    {
      int i = SourceTokenOperator.curIndentLenVT(localObject = paramTMssqlExecute.getStartToken()) + getOption().indentLen.intValue();
      paramTMssqlExecute = paramTMssqlExecute.getParameters().getExecParameter(0).getStartToken();
      SourceTokenOperator.addBefore(getOption(), paramTMssqlExecute, SourceTokenOperator.createReturnSourceToken());
      SourceTokenOperator.addBefore(getOption(), paramTMssqlExecute, SourceTokenOperator.createWhitespaceSourceToken(i));
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\execute\ExecParaNewLineProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */