package gudusoft.gsqlparser.pp.processor.type.update;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TResultColumnList;
import gudusoft.gsqlparser.nodes.TWhereClause;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractKeyWordAlignProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TUpdateSqlStatement;
import java.util.ArrayList;
import java.util.List;

public class UpdateKeyWordAlignProcessor
  extends AbstractKeyWordAlignProcessor<TUpdateSqlStatement>
{
  protected List<TSourceToken[]> getTSourceToken(TUpdateSqlStatement paramTUpdateSqlStatement)
  {
    ArrayList localArrayList = new ArrayList();
    TSourceToken localTSourceToken;
    if ((localTSourceToken = paramTUpdateSqlStatement.getUpdateToken()) != null) {
      localArrayList.add(new TSourceToken[] { localTSourceToken });
    }
    if ((localTSourceToken = SourceTokenSearcher.backforwardSearch(paramTUpdateSqlStatement.getResultColumnList().getStartToken(), 5, "set")) != null) {
      localArrayList.add(new TSourceToken[] { localTSourceToken });
    }
    if ((paramTUpdateSqlStatement.getWhereClause() != null) && (paramTUpdateSqlStatement.getWhereClause().getStartToken() != null)) {
      localArrayList.add(new TSourceToken[] { paramTUpdateSqlStatement.getWhereClause().getStartToken() });
    }
    return localArrayList;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\update\UpdateKeyWordAlignProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */