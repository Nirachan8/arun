package gudusoft.gsqlparser.pp.processor.type.createview;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.stmtformatter.FormatterFactory;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TCreateViewSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class CreateViewReturnProcessor
  extends AbstractProcessor<TCreateViewSqlStatement>
{
  public void process(TCreateViewSqlStatement paramTCreateViewSqlStatement)
  {
    TSourceToken localTSourceToken1;
    if ((localTSourceToken1 = paramTCreateViewSqlStatement.getStartToken()) == null) {
      return;
    }
    int i = SourceTokenOperator.curColumnNumberVT(localTSourceToken1);
    if ((paramTCreateViewSqlStatement = paramTCreateViewSqlStatement.getSubquery()) == null) {
      return;
    }
    TSourceToken localTSourceToken2;
    if ((localTSourceToken2 = SourceTokenSearcher.backforwardSearch(paramTCreateViewSqlStatement.getStartToken(), 5, "as")) == null) {
      return;
    }
    SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createReturnSourceToken());
    SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createWhitespaceSourceToken(i));
    if ((localTSourceToken2 = paramTCreateViewSqlStatement.getStartToken()) == null) {
      return;
    }
    SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createReturnSourceToken());
    SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createWhitespaceSourceToken(i + getOption().beStyleBlockIndentSize.intValue()));
    FormatterFactory.processStatement(getOption(), paramTCreateViewSqlStatement);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\createview\CreateViewReturnProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */