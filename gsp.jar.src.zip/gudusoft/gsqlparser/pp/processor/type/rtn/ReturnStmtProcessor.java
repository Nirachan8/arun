package gudusoft.gsqlparser.pp.processor.type.rtn;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.ExpressionProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import gudusoft.gsqlparser.stmt.mssql.TMssqlReturn;

public class ReturnStmtProcessor
  extends AbstractProcessor<TMssqlReturn>
{
  public void process(TMssqlReturn paramTMssqlReturn)
  {
    TSourceToken localTSourceToken1;
    if ((localTSourceToken1 = paramTMssqlReturn.getStartToken()) == null) {
      return;
    }
    int i;
    int j = (i = SourceTokenOperator.curColumnNumberVT(localTSourceToken1)) + getOption().beStyleBlockIndentSize.intValue();
    Object localObject;
    if (paramTMssqlReturn.getSubquery() != null)
    {
      if ((localObject = paramTMssqlReturn.getSubquery().getStartToken()) == null) {
        return;
      }
      SourceTokenOperator.addBefore(getOption(), (TSourceToken)localObject, SourceTokenOperator.createReturnSourceToken());
      SourceTokenOperator.addBefore(getOption(), (TSourceToken)localObject, SourceTokenOperator.createWhitespaceSourceToken(j));
      ExpressionProcessor.processParenthesesNodeInSubQuery(getOption(), paramTMssqlReturn.getSubquery(), paramTMssqlReturn.getSubquery().getStartToken(), paramTMssqlReturn.getSubquery().getEndToken());
      return;
    }
    if ((paramTMssqlReturn.getStatements() != null) && (paramTMssqlReturn.getStatements().size() > 0) && (((localObject = paramTMssqlReturn.getStatements()).get(0) instanceof TSelectSqlStatement)))
    {
      localObject = (paramTMssqlReturn = (TSelectSqlStatement)((TStatementList)localObject).get(0)).getStartToken();
      TSourceToken localTSourceToken2 = paramTMssqlReturn.getEndToken();
      if ((localObject != null) && (((TSourceToken)localObject).astext.equals("(")) && (localTSourceToken2 != null) && (localTSourceToken2.astext.equals(")")))
      {
        SourceTokenOperator.addBefore(getOption(), (TSourceToken)localObject, SourceTokenOperator.createReturnSourceToken());
        SourceTokenOperator.addBefore(getOption(), (TSourceToken)localObject, SourceTokenOperator.createWhitespaceSourceToken(i));
        SourceTokenOperator.addAfter(getOption(), (TSourceToken)localObject, SourceTokenOperator.createReturnSourceToken());
        SourceTokenOperator.addAfter(getOption(), (TSourceToken)localObject, SourceTokenOperator.createWhitespaceSourceToken(j));
        SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createReturnSourceToken());
        SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createWhitespaceSourceToken(i));
      }
      ExpressionProcessor.processParenthesesNodeInSubQuery(getOption(), paramTMssqlReturn, paramTMssqlReturn.getStartToken(), paramTMssqlReturn.getEndToken());
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\rtn\ReturnStmtProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */