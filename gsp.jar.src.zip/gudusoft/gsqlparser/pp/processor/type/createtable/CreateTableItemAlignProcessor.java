package gudusoft.gsqlparser.pp.processor.type.createtable;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TColumnDefinition;
import gudusoft.gsqlparser.nodes.TColumnDefinitionList;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.styleenums.TAlignOption;
import gudusoft.gsqlparser.pp.para.styleenums.TAlignStyle;
import gudusoft.gsqlparser.pp.para.styleenums.TLinefeedsCommaOption;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import java.util.Arrays;

public class CreateTableItemAlignProcessor
  extends AbstractProcessor<TColumnDefinitionList>
{
  public void process(TColumnDefinitionList paramTColumnDefinitionList)
  {
    TAlignOption localTAlignOption = (TAlignOption)getParameter(TAlignOption.class);
    if ((paramTColumnDefinitionList == null) || (paramTColumnDefinitionList.size() == 0)) {
      return;
    }
    if (getOption().defaultAligntype != TAlignStyle.AsStacked) {
      return;
    }
    int i = 0;
    if (getOption().defaultCommaOption == TLinefeedsCommaOption.LfbeforeCommaWithSpace) {
      i = 2;
    }
    int j = 0;
    for (int k = 0; k < paramTColumnDefinitionList.size(); k++)
    {
      TColumnDefinition localTColumnDefinition;
      int m;
      if ((m = (localTColumnDefinition = paramTColumnDefinitionList.getColumn(k)).getColumnName().getStartToken().astext.length() + (k != 0 ? i : 0)) > j) {
        j = m;
      }
    }
    for (k = 0; k < paramTColumnDefinitionList.size(); k++)
    {
      Object localObject;
      int n = (localObject = (localObject = paramTColumnDefinitionList.getColumn(k)).getColumnName().getStartToken()).astext.length() + (k != 0 ? i : 0);
      if ((n = j - n) > 0)
      {
        String str = a(n);
        if (localTAlignOption == TAlignOption.AloLeft) {
          ((TSourceToken)localObject).astext += str;
        } else if (localTAlignOption == TAlignOption.AloRight) {
          ((TSourceToken)localObject).astext = (str + ((TSourceToken)localObject).astext);
        }
      }
    }
  }
  
  private static String a(int paramInt)
  {
    Arrays.fill(paramInt = new char[paramInt], 0, paramInt.length, ' ');
    return String.copyValueOf(paramInt);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\createtable\CreateTableItemAlignProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */