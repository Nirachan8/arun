package gudusoft.gsqlparser.pp.processor.type.createtable;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.nodes.TColumnDefinitionList;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TCreateTableSqlStatement;

public class CreateTableBEInNewLineProcessor
  extends AbstractProcessor<TCreateTableSqlStatement>
{
  public void process(TCreateTableSqlStatement paramTCreateTableSqlStatement)
  {
    Boolean localBoolean1 = (Boolean)getParameter(Boolean.class);
    Boolean localBoolean2 = (Boolean)getParameter(Boolean.class, 1);
    Object localObject = (Boolean)getParameter(Boolean.class, 2);
    TColumnDefinitionList localTColumnDefinitionList;
    if (((localTColumnDefinitionList = paramTCreateTableSqlStatement.getColumnList()) != null) && (localTColumnDefinitionList.size() > 0))
    {
      paramTCreateTableSqlStatement = SourceTokenOperator.curIndentLenVT(paramTCreateTableSqlStatement.getStartToken());
      TSourceToken localTSourceToken;
      if ((localTSourceToken = SourceTokenSearcher.backforwardSearch(localTColumnDefinitionList.getStartToken(), 3, "(")) != null)
      {
        SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), localTSourceToken);
        SourceTokenOperator.removeWhitespaceAndReturnFromStart(getOption(), localTSourceToken.container, localTSourceToken.posinlist + 1);
        if ((localObject != null) && (((Boolean)localObject).booleanValue() == true)) {
          SourceTokenOperator.addAfter(getOption(), localTSourceToken, SourceTokenOperator.createReturnSourceToken());
        }
        if ((localBoolean1 != null) && (localBoolean1.booleanValue() == true))
        {
          SourceTokenOperator.addBefore(getOption(), localTSourceToken, SourceTokenOperator.createReturnSourceToken());
          SourceTokenOperator.addBefore(getOption(), localTSourceToken, SourceTokenOperator.createWhitespaceSourceToken(paramTCreateTableSqlStatement + getOption().indentLen.intValue()));
          if ((localObject != null) && (((Boolean)localObject).booleanValue() == true)) {
            SourceTokenOperator.addAfter(getOption(), localTSourceToken, SourceTokenOperator.createWhitespaceSourceToken(paramTCreateTableSqlStatement + (getOption().indentLen.intValue() << 1)));
          }
        }
        else if ((localObject != null) && (((Boolean)localObject).booleanValue() == true))
        {
          SourceTokenOperator.addAfter(getOption(), localTSourceToken, SourceTokenOperator.createWhitespaceSourceToken(paramTCreateTableSqlStatement + getOption().indentLen.intValue()));
        }
      }
      if ((localObject = SourceTokenSearcher.forwardSearch(localTColumnDefinitionList.getEndToken().container.get(localTColumnDefinitionList.getEndToken().posinlist + 1), 3, ")")) != null)
      {
        SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), (TSourceToken)localObject);
        SourceTokenOperator.removeWhitespaceAndReturnFromStart(getOption(), ((TSourceToken)localObject).container, ((TSourceToken)localObject).posinlist + 1);
        if ((localBoolean2 != null) && (localBoolean2.booleanValue() == true))
        {
          SourceTokenOperator.addBefore(getOption(), (TSourceToken)localObject, SourceTokenOperator.createReturnSourceToken());
          SourceTokenOperator.addBefore(getOption(), (TSourceToken)localObject, SourceTokenOperator.createWhitespaceSourceToken(paramTCreateTableSqlStatement + (localBoolean1.booleanValue() ? getOption().indentLen.intValue() : 0)));
        }
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\createtable\CreateTableBEInNewLineProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */