package gudusoft.gsqlparser.pp.processor.type.createtable;

import gudusoft.gsqlparser.nodes.TConstraint;
import gudusoft.gsqlparser.nodes.TConstraintList;
import gudusoft.gsqlparser.nodes.TTable;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TCreateTableSqlStatement;

public class CreateTableConstraintAlignProcessor
  extends AbstractProcessor<TCreateTableSqlStatement>
{
  public void process(TCreateTableSqlStatement paramTCreateTableSqlStatement)
  {
    if (((localObject = paramTCreateTableSqlStatement.getTableConstraints()) == null) || (((TConstraintList)localObject).size() == 0)) {
      return;
    }
    paramTCreateTableSqlStatement = SourceTokenOperator.curColumnNumberVT(paramTCreateTableSqlStatement = SourceTokenSearcher.forwardSearch(paramTCreateTableSqlStatement.getTargetTable().getEndToken(), 5, "("));
    Object localObject = ((TConstraintList)localObject).getConstraint(0);
    SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), ((TConstraint)localObject).getStartToken());
    SourceTokenOperator.addBefore(getOption(), ((TConstraint)localObject).getStartToken(), SourceTokenOperator.createReturnSourceToken());
    SourceTokenOperator.addBefore(getOption(), ((TConstraint)localObject).getStartToken(), SourceTokenOperator.createWhitespaceSourceToken(paramTCreateTableSqlStatement + 1));
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\createtable\CreateTableConstraintAlignProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */