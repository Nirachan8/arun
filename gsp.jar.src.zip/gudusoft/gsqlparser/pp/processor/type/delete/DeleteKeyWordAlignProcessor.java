package gudusoft.gsqlparser.pp.processor.type.delete;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TWhereClause;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractKeyWordAlignProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TDeleteSqlStatement;
import java.util.ArrayList;
import java.util.List;

public class DeleteKeyWordAlignProcessor
  extends AbstractKeyWordAlignProcessor<TDeleteSqlStatement>
{
  protected List<TSourceToken[]> getTSourceToken(TDeleteSqlStatement paramTDeleteSqlStatement)
  {
    ArrayList localArrayList = new ArrayList();
    TSourceToken localTSourceToken1;
    TSourceToken localTSourceToken2 = SourceTokenSearcher.forwardSearch(localTSourceToken1 = paramTDeleteSqlStatement.getDeleteToken(), 5, "from");
    if ((localTSourceToken1 != null) && (localTSourceToken2 != null)) {
      localArrayList.add(new TSourceToken[] { localTSourceToken1, localTSourceToken2 });
    }
    if ((paramTDeleteSqlStatement.getWhereClause() != null) && (paramTDeleteSqlStatement.getWhereClause().getStartToken() != null)) {
      localArrayList.add(new TSourceToken[] { paramTDeleteSqlStatement.getWhereClause().getStartToken() });
    }
    return localArrayList;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\delete\DeleteKeyWordAlignProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */