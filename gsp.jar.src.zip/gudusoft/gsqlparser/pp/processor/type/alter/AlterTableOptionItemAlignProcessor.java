package gudusoft.gsqlparser.pp.processor.type.alter;

import gudusoft.gsqlparser.nodes.TAlterTableOption;
import gudusoft.gsqlparser.nodes.TAlterTableOptionList;
import gudusoft.gsqlparser.pp.mediator.MediatorFactory;
import gudusoft.gsqlparser.pp.mediator.type.KeywordAlignMediator;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenConstant;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;

public class AlterTableOptionItemAlignProcessor
  extends AbstractProcessor<TAlterTableOptionList>
{
  public void process(TAlterTableOptionList paramTAlterTableOptionList)
  {
    boolean bool = ((Boolean)getParameter(Boolean.class)).booleanValue();
    if ((paramTAlterTableOptionList == null) || (paramTAlterTableOptionList.size() == 0)) {
      return;
    }
    TAlterTableOption localTAlterTableOption;
    for (int i = 0; i < paramTAlterTableOptionList.size(); i++) {
      (localTAlterTableOption = paramTAlterTableOptionList.getAlterTableOption(i)).toString().length();
    }
    for (i = 0; i < paramTAlterTableOptionList.size(); i++)
    {
      localTAlterTableOption = paramTAlterTableOptionList.getAlterTableOption(i);
      int j = 0;
      KeywordAlignMediator localKeywordAlignMediator;
      if ((localKeywordAlignMediator = (KeywordAlignMediator)MediatorFactory.getMediator(KeywordAlignMediator.class, getOption().sessionId)).getCurLevelIndentLen() > 0) {
        j = localKeywordAlignMediator.getCurLevelIndentLen();
      }
      localKeywordAlignMediator.addIndentLevelItem(localTAlterTableOption.getStartToken(), j);
      if (bool)
      {
        SourceTokenOperator.addBefore(getOption(), localTAlterTableOption.getStartToken(), SourceTokenOperator.createReturnSourceToken());
        SourceTokenOperator.addBefore(getOption(), localTAlterTableOption.getStartToken(), SourceTokenOperator.createWhitespaceSourceToken(j + getOption().indentLen.intValue()));
      }
      else
      {
        SourceTokenOperator.addBefore(getOption(), localTAlterTableOption.getStartToken(), SourceTokenConstant.WHITESPACE);
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\alter\AlterTableOptionItemAlignProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */