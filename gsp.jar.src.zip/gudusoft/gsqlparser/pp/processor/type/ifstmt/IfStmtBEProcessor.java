package gudusoft.gsqlparser.pp.processor.type.ifstmt;

import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.stmtformatter.FormatterFactory;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.mssql.TMssqlBlock;
import gudusoft.gsqlparser.stmt.mssql.TMssqlIfElse;

public class IfStmtBEProcessor
  extends AbstractProcessor<TMssqlIfElse>
{
  public void process(TMssqlIfElse paramTMssqlIfElse)
  {
    GFmtOpt localGFmtOpt = getOption();
    if ((paramTMssqlIfElse.getStmt() instanceof TMssqlBlock))
    {
      Object localObject = (TMssqlBlock)paramTMssqlIfElse.getStmt();
      TSourceToken localTSourceToken = paramTMssqlIfElse.getStartToken();
      FormatterFactory.processBlockStmt(localGFmtOpt, (TMssqlBlock)localObject, localTSourceToken);
      if ((paramTMssqlIfElse = paramTMssqlIfElse.getElseStmt()) == null) {
        return;
      }
      if ((localObject = paramTMssqlIfElse.getStartToken()) == null) {
        return;
      }
      if ((paramTMssqlIfElse = SourceTokenSearcher.backforwardSearch(paramTMssqlIfElse.getStartToken(), 5, "else")) == null) {
        return;
      }
      int i = SourceTokenOperator.curColumnNumberVT(localTSourceToken);
      SourceTokenOperator.addBefore(localGFmtOpt, paramTMssqlIfElse, SourceTokenOperator.createReturnSourceToken());
      SourceTokenOperator.addBefore(localGFmtOpt, paramTMssqlIfElse, SourceTokenOperator.createWhitespaceSourceToken(i));
      paramTMssqlIfElse = i + localGFmtOpt.beStyleIfElseSingleStmtIndentSize.intValue();
      SourceTokenOperator.addBefore(localGFmtOpt, (TSourceToken)localObject, SourceTokenOperator.createReturnSourceToken());
      SourceTokenOperator.addBefore(localGFmtOpt, (TSourceToken)localObject, SourceTokenOperator.createWhitespaceSourceToken(paramTMssqlIfElse));
      return;
    }
    if (paramTMssqlIfElse.getStmt() != null) {
      FormatterFactory.processStatement(getOption(), paramTMssqlIfElse.getStmt());
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\ifstmt\IfStmtBEProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */