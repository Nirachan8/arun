package gudusoft.gsqlparser.pp.processor.type.createfunction;

import gudusoft.gsqlparser.nodes.TParameterDeclaration;
import gudusoft.gsqlparser.nodes.TParameterDeclarationList;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.stmt.TStoredProcedureSqlStatement;

public class CreateFuncFirstParamInNewlineProcessor
  extends AbstractProcessor<TStoredProcedureSqlStatement>
{
  public void process(TStoredProcedureSqlStatement paramTStoredProcedureSqlStatement)
  {
    Boolean localBoolean;
    if (!(localBoolean = (Boolean)getParameter(Boolean.class)).booleanValue()) {
      return;
    }
    if ((paramTStoredProcedureSqlStatement.getParameterDeclarations() == null) || (paramTStoredProcedureSqlStatement.getParameterDeclarations().size() == 0)) {
      return;
    }
    if ((paramTStoredProcedureSqlStatement = paramTStoredProcedureSqlStatement.getParameterDeclarations().getParameterDeclarationItem(0).getStartToken()) == null) {
      return;
    }
    int i = SourceTokenOperator.curIndentLenVT(paramTStoredProcedureSqlStatement) + getOption().indentLen.intValue();
    SourceTokenOperator.addBefore(getOption(), paramTStoredProcedureSqlStatement, SourceTokenOperator.createReturnSourceToken());
    SourceTokenOperator.addBefore(getOption(), paramTStoredProcedureSqlStatement, SourceTokenOperator.createWhitespaceSourceToken(i));
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\createfunction\CreateFuncFirstParamInNewlineProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */