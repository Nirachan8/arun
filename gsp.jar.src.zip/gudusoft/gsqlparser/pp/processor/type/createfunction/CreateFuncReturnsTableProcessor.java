package gudusoft.gsqlparser.pp.processor.type.createfunction;

import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.stmtformatter.FormatterFactory;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TStoredProcedureSqlStatement;
import gudusoft.gsqlparser.stmt.mssql.TMssqlBlock;

public class CreateFuncReturnsTableProcessor
  extends AbstractProcessor<TStoredProcedureSqlStatement>
{
  public void process(TStoredProcedureSqlStatement paramTStoredProcedureSqlStatement)
  {
    TStatementList localTStatementList;
    if (((localTStatementList = paramTStoredProcedureSqlStatement.getBodyStatements()) == null) || (localTStatementList.size() == 0)) {
      return;
    }
    TSourceToken localTSourceToken1;
    int i = SourceTokenOperator.curColumnNumberVT(localTSourceToken1 = paramTStoredProcedureSqlStatement.getStartToken());
    if (localTStatementList.get(0) == null) {
      return;
    }
    Object localObject;
    if (((localObject = localTStatementList.get(0).getStartToken()) == null) || (localTSourceToken1 == null)) {
      return;
    }
    if ((localTSourceToken1 = SourceTokenSearcher.backforwardSearch((TSourceToken)localObject, 5, "as")) == null) {
      return;
    }
    SourceTokenOperator.addBefore(getOption(), localTSourceToken1, SourceTokenOperator.createReturnSourceToken());
    SourceTokenOperator.addBefore(getOption(), localTSourceToken1, SourceTokenOperator.createWhitespaceSourceToken(i));
    if ((paramTStoredProcedureSqlStatement = SourceTokenSearcher.backforwardSearch(localTSourceToken1, localTSourceToken1.posinlist - paramTStoredProcedureSqlStatement.getStartToken().posinlist, "returns")) != null)
    {
      SourceTokenOperator.addBefore(getOption(), paramTStoredProcedureSqlStatement, SourceTokenOperator.createReturnSourceToken());
      SourceTokenOperator.addBefore(getOption(), paramTStoredProcedureSqlStatement, SourceTokenOperator.createWhitespaceSourceToken(i));
    }
    for (paramTStoredProcedureSqlStatement = 0; paramTStoredProcedureSqlStatement < localTStatementList.size(); paramTStoredProcedureSqlStatement++) {
      if (!FormatterFactory.isNotNeedFormat(localObject = localTStatementList.get(paramTStoredProcedureSqlStatement))) {
        if ((localObject instanceof TMssqlBlock))
        {
          FormatterFactory.processBlockStmt(getOption(), (TMssqlBlock)localObject, localTSourceToken1);
        }
        else
        {
          TSourceToken localTSourceToken2;
          if ((localTSourceToken2 = ((TCustomSqlStatement)localObject).getStartToken()) != null)
          {
            SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createReturnSourceToken());
            SourceTokenOperator.addBefore(getOption(), localTSourceToken2, SourceTokenOperator.createWhitespaceSourceToken(i + getOption().beStyleBlockIndentSize.intValue()));
            FormatterFactory.processStatement(getOption(), (TCustomSqlStatement)localObject);
          }
        }
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\createfunction\CreateFuncReturnsTableProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */