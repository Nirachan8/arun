package gudusoft.gsqlparser.pp.processor.type.createfunction;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TParameterDeclarationList;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TStoredProcedureSqlStatement;

public class CreateFuncWSPaddingParenthesesProcessor
  extends AbstractProcessor<TStoredProcedureSqlStatement>
{
  public void process(TStoredProcedureSqlStatement paramTStoredProcedureSqlStatement)
  {
    if ((paramTStoredProcedureSqlStatement.getParameterDeclarations() == null) || (paramTStoredProcedureSqlStatement.getParameterDeclarations().size() == 0)) {
      return;
    }
    TSourceToken localTSourceToken = SourceTokenSearcher.backforwardSearch(paramTStoredProcedureSqlStatement.getParameterDeclarations().getStartToken(), 5, "(");
    paramTStoredProcedureSqlStatement = SourceTokenSearcher.forwardSearch(paramTStoredProcedureSqlStatement.getParameterDeclarations().getEndToken(), 5, ")");
    if ((localTSourceToken == null) || (paramTStoredProcedureSqlStatement == null)) {
      return;
    }
    SourceTokenOperator.removeWhitespaceAndReturnFromStart(getOption(), localTSourceToken.container, localTSourceToken.posinlist + 1);
    if (getOption().wsPaddingParenthesesInFunction.booleanValue()) {
      SourceTokenOperator.addAfter(getOption(), localTSourceToken, SourceTokenOperator.createWhitespaceSourceToken(1));
    }
    SourceTokenOperator.removeWhitespaceAndReturnFromEnd(getOption(), paramTStoredProcedureSqlStatement);
    if (getOption().wsPaddingParenthesesInFunction.booleanValue()) {
      SourceTokenOperator.addBefore(getOption(), paramTStoredProcedureSqlStatement, SourceTokenOperator.createWhitespaceSourceToken(1));
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\createfunction\CreateFuncWSPaddingParenthesesProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */