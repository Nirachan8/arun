package gudusoft.gsqlparser.pp.processor.type.createfunction;

import gudusoft.gsqlparser.nodes.TParameterDeclarationList;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.utils.SourceTokenOperator;
import gudusoft.gsqlparser.pp.utils.SourceTokenSearcher;
import gudusoft.gsqlparser.stmt.TStoredProcedureSqlStatement;

public class CreateFuncRightBEProcessor
  extends AbstractProcessor<TStoredProcedureSqlStatement>
{
  public void process(TStoredProcedureSqlStatement paramTStoredProcedureSqlStatement)
  {
    Boolean localBoolean = (Boolean)getParameter(Boolean.class);
    Integer localInteger = (Integer)getParameter(Integer.class, 1);
    if (!localBoolean.booleanValue()) {
      return;
    }
    if (paramTStoredProcedureSqlStatement.getParameterDeclarations() == null) {
      return;
    }
    int i = SourceTokenOperator.curIndentLenVT(paramTStoredProcedureSqlStatement.getStartToken()) + localInteger.intValue();
    if ((paramTStoredProcedureSqlStatement = SourceTokenSearcher.forwardSearch(paramTStoredProcedureSqlStatement = paramTStoredProcedureSqlStatement.getParameterDeclarations().getEndToken(), 5, ")")) == null) {
      return;
    }
    SourceTokenOperator.addBefore(getOption(), paramTStoredProcedureSqlStatement, SourceTokenOperator.createReturnSourceToken());
    SourceTokenOperator.addBefore(getOption(), paramTStoredProcedureSqlStatement, SourceTokenOperator.createWhitespaceSourceToken(i));
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\type\createfunction\CreateFuncRightBEProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */