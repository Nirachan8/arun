package gudusoft.gsqlparser.pp.processor;

import gudusoft.gsqlparser.pp.logger.PPLogger;
import gudusoft.gsqlparser.pp.para.GFmtOpt;
import gudusoft.gsqlparser.pp.para.styleenums.TAlignOption;
import gudusoft.gsqlparser.pp.para.styleenums.TAlignStyle;
import gudusoft.gsqlparser.pp.para.styleenums.TLinefeedsCommaOption;
import gudusoft.gsqlparser.pp.processor.type.alter.AlterTableOptionItemAlignProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.AbstractProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.AlignAliasProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.AppendNewLineAfterAndBeforeReverseKeyWordProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.AppendNewLineAfterReverseKeyWordProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.AppendNewLineBeforeKeyWordProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.AppendNewLineBeforeReverseKeyWordProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.CapitalisationProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.CaseWhenProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.ColumnlistCommaProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.CombineWhitespaceAndClearReturnProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.DistinctKeyWordProcessor;
import gudusoft.gsqlparser.pp.processor.type.comm.ExpressionProcessor;
import gudusoft.gsqlparser.pp.processor.type.createfunction.CreateFuncFirstParamInNewlineProcessor;
import gudusoft.gsqlparser.pp.processor.type.createfunction.CreateFuncLeftBEProcessor;
import gudusoft.gsqlparser.pp.processor.type.createfunction.CreateFuncReturnsTableProcessor;
import gudusoft.gsqlparser.pp.processor.type.createfunction.CreateFuncRightBEProcessor;
import gudusoft.gsqlparser.pp.processor.type.createfunction.CreateFuncWSPaddingParenthesesProcessor;
import gudusoft.gsqlparser.pp.processor.type.createtable.CreateTableBEInNewLineProcessor;
import gudusoft.gsqlparser.pp.processor.type.createtable.CreateTableConstraintAlignProcessor;
import gudusoft.gsqlparser.pp.processor.type.createtable.CreateTableItemAlignProcessor;
import gudusoft.gsqlparser.pp.processor.type.createview.CreateViewReturnProcessor;
import gudusoft.gsqlparser.pp.processor.type.declare.DeclareVarItemAlignProcessor;
import gudusoft.gsqlparser.pp.processor.type.delete.DeleteKeyWordAlignProcessor;
import gudusoft.gsqlparser.pp.processor.type.execute.ExecParaNewLineProcessor;
import gudusoft.gsqlparser.pp.processor.type.ifstmt.IfStmtBEProcessor;
import gudusoft.gsqlparser.pp.processor.type.insert.AppendLineAfterInsertTableNameProcessor;
import gudusoft.gsqlparser.pp.processor.type.insert.InsertKeyWordAlignProcessor;
import gudusoft.gsqlparser.pp.processor.type.insert.InsertOutputClauseProcessor;
import gudusoft.gsqlparser.pp.processor.type.insert.InsertValuesParenthsesAdjustProcessor;
import gudusoft.gsqlparser.pp.processor.type.rtn.ReturnStmtProcessor;
import gudusoft.gsqlparser.pp.processor.type.select.CTEProcessor;
import gudusoft.gsqlparser.pp.processor.type.select.JoinOnProcessor;
import gudusoft.gsqlparser.pp.processor.type.select.SelectKeyWordAlignProcessor;
import gudusoft.gsqlparser.pp.processor.type.select.UnionProcessor;
import gudusoft.gsqlparser.pp.processor.type.update.UpdateKeyWordAlignProcessor;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ProcessorFactory
{
  private static volatile Map<String, AbstractProcessor> a = new Hashtable();
  
  public static ColumnlistCommaProcessor createColumnlistCommaProcessor(GFmtOpt paramGFmtOpt, TLinefeedsCommaOption paramTLinefeedsCommaOption, TAlignStyle paramTAlignStyle)
  {
    return (ColumnlistCommaProcessor)create(ColumnlistCommaProcessor.class, paramGFmtOpt, new Object[] { paramTLinefeedsCommaOption, paramTAlignStyle });
  }
  
  public static AlignAliasProcessor createAlignAliasProcessor(GFmtOpt paramGFmtOpt, boolean paramBoolean, TAlignStyle paramTAlignStyle)
  {
    return (AlignAliasProcessor)create(AlignAliasProcessor.class, paramGFmtOpt, new Object[] { Boolean.valueOf(paramBoolean), paramTAlignStyle });
  }
  
  public static AppendNewLineAfterReverseKeyWordProcessor appendNewLineAfterReverseKeyWordProcessor(GFmtOpt paramGFmtOpt, boolean paramBoolean, String paramString)
  {
    return (AppendNewLineAfterReverseKeyWordProcessor)create(AppendNewLineAfterReverseKeyWordProcessor.class, paramGFmtOpt, new Object[] { Boolean.valueOf(paramBoolean), paramString });
  }
  
  public static DistinctKeyWordProcessor createDistinctKeyWordProcessor(GFmtOpt paramGFmtOpt, boolean paramBoolean)
  {
    return (DistinctKeyWordProcessor)create(DistinctKeyWordProcessor.class, paramGFmtOpt, new Object[] { Boolean.valueOf(paramBoolean) });
  }
  
  public static AppendNewLineAfterAndBeforeReverseKeyWordProcessor appendNewLineAfterAndBeforeReverseKeyWordProcessor(GFmtOpt paramGFmtOpt, boolean paramBoolean, String paramString1, String paramString2)
  {
    return (AppendNewLineAfterAndBeforeReverseKeyWordProcessor)create(AppendNewLineAfterAndBeforeReverseKeyWordProcessor.class, paramGFmtOpt, new Object[] { Boolean.valueOf(paramBoolean), paramString1, paramString2 });
  }
  
  public static JoinOnProcessor createJoinOnProcessor(GFmtOpt paramGFmtOpt, boolean paramBoolean1, boolean paramBoolean2)
  {
    return (JoinOnProcessor)create(JoinOnProcessor.class, paramGFmtOpt, new Object[] { Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2) });
  }
  
  public static UnionProcessor createUnionProcessor(GFmtOpt paramGFmtOpt)
  {
    return (UnionProcessor)create(UnionProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static ExpressionProcessor createExpressionProcessor(GFmtOpt paramGFmtOpt)
  {
    return createExpressionProcessor(paramGFmtOpt, Boolean.valueOf(false));
  }
  
  public static ExpressionProcessor createExpressionProcessor(GFmtOpt paramGFmtOpt, Boolean paramBoolean)
  {
    return (ExpressionProcessor)create(ExpressionProcessor.class, paramGFmtOpt, new Object[] { paramBoolean });
  }
  
  public static CaseWhenProcessor createCaseWhenProcessor(GFmtOpt paramGFmtOpt, Boolean paramBoolean, Integer paramInteger)
  {
    return (CaseWhenProcessor)create(CaseWhenProcessor.class, paramGFmtOpt, new Object[] { paramBoolean, paramInteger });
  }
  
  public static SelectKeyWordAlignProcessor createSelectKeyWordAlignProcessor(GFmtOpt paramGFmtOpt)
  {
    return (SelectKeyWordAlignProcessor)create(SelectKeyWordAlignProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static InsertKeyWordAlignProcessor createInsertKeyWordAlignProcessor(GFmtOpt paramGFmtOpt)
  {
    return (InsertKeyWordAlignProcessor)create(InsertKeyWordAlignProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static AppendLineAfterInsertTableNameProcessor createAppendLineAfterInsertTableNameProcessor(GFmtOpt paramGFmtOpt)
  {
    return (AppendLineAfterInsertTableNameProcessor)create(AppendLineAfterInsertTableNameProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static CapitalisationProcessor createCapitalisationProcessor(GFmtOpt paramGFmtOpt)
  {
    return (CapitalisationProcessor)create(CapitalisationProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static AppendNewLineBeforeReverseKeyWordProcessor createAppendNewLineBeforeReverseKeyWordProcessor(GFmtOpt paramGFmtOpt, boolean paramBoolean, String paramString)
  {
    return (AppendNewLineBeforeReverseKeyWordProcessor)create(AppendNewLineBeforeReverseKeyWordProcessor.class, paramGFmtOpt, new Object[] { Boolean.valueOf(paramBoolean), paramString });
  }
  
  public static InsertValuesParenthsesAdjustProcessor createInsertValuesParenthsesAdjustProcessor(GFmtOpt paramGFmtOpt)
  {
    return (InsertValuesParenthsesAdjustProcessor)create(InsertValuesParenthsesAdjustProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static DeleteKeyWordAlignProcessor createDeleteKeyWordAlignProcessor(GFmtOpt paramGFmtOpt)
  {
    return (DeleteKeyWordAlignProcessor)create(DeleteKeyWordAlignProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static UpdateKeyWordAlignProcessor createUpdateKeyWordAlignProcessor(GFmtOpt paramGFmtOpt)
  {
    return (UpdateKeyWordAlignProcessor)create(UpdateKeyWordAlignProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static CreateTableBEInNewLineProcessor createCreateTableBEInNewLineProcessor(GFmtOpt paramGFmtOpt, Boolean paramBoolean1, Boolean paramBoolean2, Boolean paramBoolean3)
  {
    return (CreateTableBEInNewLineProcessor)create(CreateTableBEInNewLineProcessor.class, paramGFmtOpt, new Object[] { paramBoolean1, paramBoolean2, paramBoolean3 });
  }
  
  public static CreateTableItemAlignProcessor createCreateTableItemAlignProcessor(GFmtOpt paramGFmtOpt, TAlignOption paramTAlignOption)
  {
    return (CreateTableItemAlignProcessor)create(CreateTableItemAlignProcessor.class, paramGFmtOpt, new Object[] { paramTAlignOption });
  }
  
  public static CTEProcessor createCTEProcessor(GFmtOpt paramGFmtOpt, Boolean paramBoolean)
  {
    return (CTEProcessor)create(CTEProcessor.class, paramGFmtOpt, new Object[] { paramBoolean });
  }
  
  public static DeclareVarItemAlignProcessor createDeclareVarItemAlignProcessor(GFmtOpt paramGFmtOpt)
  {
    return (DeclareVarItemAlignProcessor)create(DeclareVarItemAlignProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static CreateTableConstraintAlignProcessor createCreateTableConstraintAlignProcessor(GFmtOpt paramGFmtOpt)
  {
    return (CreateTableConstraintAlignProcessor)create(CreateTableConstraintAlignProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static CombineWhitespaceAndClearReturnProcessor createCombineWhitespaceAndClearReturnProcessor(GFmtOpt paramGFmtOpt)
  {
    return (CombineWhitespaceAndClearReturnProcessor)create(CombineWhitespaceAndClearReturnProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static InsertOutputClauseProcessor createInsertOutputClauseProcessor(GFmtOpt paramGFmtOpt)
  {
    return (InsertOutputClauseProcessor)create(InsertOutputClauseProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static ExecParaNewLineProcessor createExecParaNewLineProcessor(GFmtOpt paramGFmtOpt, Boolean paramBoolean)
  {
    return (ExecParaNewLineProcessor)create(ExecParaNewLineProcessor.class, paramGFmtOpt, new Object[] { paramBoolean });
  }
  
  public static CreateFuncLeftBEProcessor createCreateFuncLeftBEProcessor(GFmtOpt paramGFmtOpt, Boolean paramBoolean, Integer paramInteger)
  {
    return (CreateFuncLeftBEProcessor)create(CreateFuncLeftBEProcessor.class, paramGFmtOpt, new Object[] { paramBoolean, paramInteger });
  }
  
  public static CreateFuncRightBEProcessor createCreateFuncRightBEProcessor(GFmtOpt paramGFmtOpt, Boolean paramBoolean, Integer paramInteger)
  {
    return (CreateFuncRightBEProcessor)create(CreateFuncRightBEProcessor.class, paramGFmtOpt, new Object[] { paramBoolean, paramInteger });
  }
  
  public static CreateFuncFirstParamInNewlineProcessor createCreateFuncFirstParamInNewlineProcessor(GFmtOpt paramGFmtOpt, Boolean paramBoolean)
  {
    return (CreateFuncFirstParamInNewlineProcessor)create(CreateFuncFirstParamInNewlineProcessor.class, paramGFmtOpt, new Object[] { paramBoolean });
  }
  
  public static CreateFuncReturnsTableProcessor createCreateFuncReturnsTableProcessor(GFmtOpt paramGFmtOpt)
  {
    return (CreateFuncReturnsTableProcessor)create(CreateFuncReturnsTableProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static CreateFuncWSPaddingParenthesesProcessor createCreateFuncWSPaddingParenthesesProcessor(GFmtOpt paramGFmtOpt)
  {
    return (CreateFuncWSPaddingParenthesesProcessor)create(CreateFuncWSPaddingParenthesesProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static IfStmtBEProcessor createIfStmtBEProcessor(GFmtOpt paramGFmtOpt)
  {
    return (IfStmtBEProcessor)create(IfStmtBEProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static ReturnStmtProcessor createReturnStmtProcessor(GFmtOpt paramGFmtOpt)
  {
    return (ReturnStmtProcessor)create(ReturnStmtProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static CreateViewReturnProcessor createCreateViewReturnProcessor(GFmtOpt paramGFmtOpt)
  {
    return (CreateViewReturnProcessor)create(CreateViewReturnProcessor.class, paramGFmtOpt, new Object[0]);
  }
  
  public static AlterTableOptionItemAlignProcessor createAlterTableOptionAlignProcessor(GFmtOpt paramGFmtOpt, boolean paramBoolean)
  {
    return (AlterTableOptionItemAlignProcessor)create(AlterTableOptionItemAlignProcessor.class, paramGFmtOpt, new Object[] { Boolean.valueOf(paramBoolean) });
  }
  
  public static AppendNewLineBeforeKeyWordProcessor createAppendNewLineBeforeKeyWordProcessor(GFmtOpt paramGFmtOpt, boolean paramBoolean1, String paramString, boolean paramBoolean2)
  {
    return (AppendNewLineBeforeKeyWordProcessor)create(AppendNewLineBeforeKeyWordProcessor.class, paramGFmtOpt, new Object[] { Boolean.valueOf(paramBoolean1), paramString, Boolean.valueOf(paramBoolean2) });
  }
  
  public static <E extends AbstractProcessor> E create(Class<E> paramClass, GFmtOpt paramGFmtOpt, Object... paramVarArgs)
  {
    if (!AbstractProcessor.class.isAssignableFrom(paramClass)) {
      return null;
    }
    StringBuilder localStringBuilder;
    (localStringBuilder = new StringBuilder()).append(paramGFmtOpt.sessionId).append(":");
    localStringBuilder.append(paramClass.getName()).append(":");
    if (paramVarArgs != null)
    {
      Object[] arrayOfObject;
      int i = (arrayOfObject = paramVarArgs).length;
      for (int j = 0; j < i; j++)
      {
        Object localObject1 = arrayOfObject[j];
        localStringBuilder.append(localObject1 != null ? localObject1.toString() : ":");
      }
    }
    if (!a.containsKey(localStringBuilder.toString())) {
      synchronized (ProcessorFactory.class)
      {
        if (!a.containsKey(localStringBuilder.toString()))
        {
          AbstractProcessor localAbstractProcessor;
          (localAbstractProcessor = newInstance(paramClass)).init(paramGFmtOpt, paramVarArgs);
          a.put(localStringBuilder.toString(), localAbstractProcessor);
        }
      }
    }
    return (AbstractProcessor)a.get(localStringBuilder.toString());
  }
  
  public static <E extends AbstractProcessor> E newInstance(Class<E> paramClass)
  {
    try
    {
      return (AbstractProcessor)paramClass.newInstance();
    }
    catch (InstantiationException localInstantiationException)
    {
      PPLogger.error(paramClass = localInstantiationException);
      return null;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      PPLogger.error(paramClass = localIllegalAccessException);
    }
    return null;
  }
  
  public static void clear(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = a.keySet().iterator();
    String str;
    while (localIterator.hasNext()) {
      if ((str = (String)localIterator.next()).startsWith(paramString)) {
        localArrayList.add(str);
      }
    }
    localIterator = localArrayList.iterator();
    while (localIterator.hasNext())
    {
      str = (String)localIterator.next();
      a.remove(str);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\processor\ProcessorFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */