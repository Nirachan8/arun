package gudusoft.gsqlparser.pp.print;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.pp.output.OutputConfig;
import java.io.OutputStream;

public abstract interface IPrinter
{
  public abstract void print(TSourceTokenList paramTSourceTokenList);
  
  public abstract void print(TSourceToken paramTSourceToken);
  
  public abstract OutputStream getOut();
  
  public abstract void setOut(OutputStream paramOutputStream);
  
  public abstract void setOutputConfig(OutputConfig paramOutputConfig);
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\print\IPrinter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */