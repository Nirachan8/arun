package gudusoft.gsqlparser.pp.print;

import gudusoft.gsqlparser.pp.logger.PPLogger;
import java.io.OutputStream;

public class PrinterFactory
{
  public static TextPrinter createTextPrinter()
  {
    return (TextPrinter)createPrinter(TextPrinter.class);
  }
  
  public static TextPrinter createTextPrinter(OutputStream paramOutputStream)
  {
    return (TextPrinter)createPrinter(TextPrinter.class, paramOutputStream);
  }
  
  public static <E extends IPrinter> E createPrinter(Class<E> paramClass, OutputStream paramOutputStream)
  {
    (paramClass = createPrinter(paramClass)).setOut(paramOutputStream);
    return paramClass;
  }
  
  public static <E extends IPrinter> E createPrinter(Class<E> paramClass)
  {
    try
    {
      return (IPrinter)paramClass.newInstance();
    }
    catch (InstantiationException localInstantiationException)
    {
      PPLogger.error(paramClass = localInstantiationException);
      return null;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      PPLogger.error(paramClass = localIllegalAccessException);
    }
    return null;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\print\PrinterFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */