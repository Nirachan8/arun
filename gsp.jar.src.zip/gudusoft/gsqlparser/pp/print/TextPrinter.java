package gudusoft.gsqlparser.pp.print;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.pp.output.OutputConfig;
import java.io.IOException;
import java.io.OutputStream;

public class TextPrinter
  implements IPrinter
{
  private OutputStream a = System.out;
  private OutputConfig b = null;
  
  public void print(TSourceTokenList paramTSourceTokenList)
  {
    for (int i = 0; i < paramTSourceTokenList.size(); i++)
    {
      TSourceToken localTSourceToken;
      if (((localTSourceToken = paramTSourceTokenList.get(i)).getTokensBefore() != null) && (localTSourceToken.getTokensBefore().size() > 0)) {
        print(localTSourceToken.getTokensBefore());
      }
      if (localTSourceToken.getReplaceToken() != null) {
        print(localTSourceToken.getReplaceToken());
      } else {
        print(localTSourceToken);
      }
      if ((localTSourceToken.getTokensAfter() != null) && (localTSourceToken.getTokensAfter().size() > 0)) {
        print(localTSourceToken.getTokensAfter());
      }
    }
  }
  
  public void print(TSourceToken paramTSourceToken)
  {
    try
    {
      if (this.b != null)
      {
        this.a.write(this.b.renderHighlightingElement(paramTSourceToken).toString().getBytes());
      }
      else
      {
        this.a.write(paramTSourceToken.toString().getBytes());
        return;
      }
    }
    catch (IOException localIOException)
    {
      (paramTSourceToken = localIOException).printStackTrace();
    }
  }
  
  public OutputStream getOut()
  {
    return this.a;
  }
  
  public void setOut(OutputStream paramOutputStream)
  {
    this.a = paramOutputStream;
  }
  
  public void setOutputConfig(OutputConfig paramOutputConfig)
  {
    this.b = paramOutputConfig;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\pp\print\TextPrinter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */