package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TDb2StmtStub
  extends TCustomSqlStatement
{
  private ESqlStatementType c;
  
  public TDb2StmtStub(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2stmtstub;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    return 0;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
  
  public void setSqlStatementType(ESqlStatementType paramESqlStatementType)
  {
    this.c = paramESqlStatementType;
  }
  
  public ESqlStatementType getSqlStatementType()
  {
    return this.c;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2StmtStub.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */