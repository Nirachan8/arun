package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.nodes.TCaseExpression;
import gudusoft.gsqlparser.nodes.TExpression;
import gudusoft.gsqlparser.nodes.TStatementListSqlNode;
import gudusoft.gsqlparser.nodes.TStatementSqlNode;
import gudusoft.gsqlparser.nodes.TWhenClauseItemList;

public class TDb2CaseStmt
  extends TCustomDb2Stmt
{
  private TExpression c = null;
  private TWhenClauseItemList d = null;
  private TStatementList e = null;
  
  public TDb2CaseStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2casestmt;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    TCaseExpression localTCaseExpression = (TCaseExpression)this.rootNode;
    this.c = localTCaseExpression.getInput_expr();
    if (this.c != null) {
      this.c.doParse(this, ESqlClause.unknown);
    }
    this.d = localTCaseExpression.getWhenClauseItemList();
    this.d.doParse(this, ESqlClause.unknown);
    if (localTCaseExpression.getElse_statement_node_list() != null)
    {
      localTCaseExpression.getElse_statement_node_list().doParse(paramTCustomSqlStatement, ESqlClause.unknown);
      for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTCaseExpression.getElse_statement_node_list().size(); paramTCustomSqlStatement++) {
        getElseStatementList().add(localTCaseExpression.getElse_statement_node_list().getStatementSqlNode(paramTCustomSqlStatement).getStmt());
      }
    }
    return 0;
  }
  
  public TExpression getExpr()
  {
    return this.c;
  }
  
  public TWhenClauseItemList getWhenClauseItemList()
  {
    return this.d;
  }
  
  public TStatementList getElseStatementList()
  {
    if (this.e == null) {
      this.e = new TStatementList();
    }
    return this.e;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2CaseStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */