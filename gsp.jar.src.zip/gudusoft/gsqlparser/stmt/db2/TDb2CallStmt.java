package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TExpressionList;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TStubStmtSqlNode;

public class TDb2CallStmt
  extends TCustomDb2Stmt
{
  private TObjectName c = null;
  private TExpressionList d = null;
  
  public TDb2CallStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2callstmt;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    paramTCustomSqlStatement = (TStubStmtSqlNode)this.rootNode;
    this.c = paramTCustomSqlStatement.getObjectName();
    this.d = paramTCustomSqlStatement.getExprList();
    return 0;
  }
  
  public TExpressionList getParameters()
  {
    return this.d;
  }
  
  public TObjectName getProcedureName()
  {
    return this.c;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2CallStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */