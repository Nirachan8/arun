package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TExpression;
import gudusoft.gsqlparser.nodes.TReturnSqlNode;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class TDb2ReturnStmt
  extends TCustomDb2Stmt
{
  private TExpression c = null;
  private TSelectSqlStatement d = null;
  
  public TDb2ReturnStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2returnstmt;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TReturnSqlNode localTReturnSqlNode = (TReturnSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    if (localTReturnSqlNode.getExpr() != null) {
      this.c = localTReturnSqlNode.getExpr();
    }
    if (localTReturnSqlNode.getSelectSqlNode() != null)
    {
      this.d = new TSelectSqlStatement(this.dbvendor);
      this.d.rootNode = localTReturnSqlNode.getSelectSqlNode();
      this.d.doParseStatement(this);
    }
    return 0;
  }
  
  public TExpression getReturnExpr()
  {
    return this.c;
  }
  
  public TSelectSqlStatement getSubquery()
  {
    return this.d;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2ReturnStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */