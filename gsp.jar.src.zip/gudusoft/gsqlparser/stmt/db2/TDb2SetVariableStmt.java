package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TExpressionList;
import gudusoft.gsqlparser.nodes.TSetSqlNode;

public class TDb2SetVariableStmt
  extends TCustomDb2Stmt
{
  private TExpressionList c = null;
  
  public TDb2SetVariableStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2set;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    paramTCustomSqlStatement = (TSetSqlNode)this.rootNode;
    this.c = paramTCustomSqlStatement.getExprList();
    return 0;
  }
  
  public TExpressionList getExprList()
  {
    return this.c;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2SetVariableStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */