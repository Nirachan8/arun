package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TDb2ReturnCodesDeclaration
  extends TCustomDb2Stmt
{
  public TDb2ReturnCodesDeclaration(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2returncodesdeclaration;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    return 0;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2ReturnCodesDeclaration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */