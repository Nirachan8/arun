package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TDeclareSqlNode;
import gudusoft.gsqlparser.nodes.TDeclareVariableList;

public class TDb2SqlVariableDeclaration
  extends TCustomDb2Stmt
{
  private TDeclareVariableList c = null;
  
  public TDb2SqlVariableDeclaration(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2sqlvariabledeclaration;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TDeclareSqlNode localTDeclareSqlNode = (TDeclareSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = localTDeclareSqlNode.getVariables();
    return 0;
  }
  
  public TDeclareVariableList getVariables()
  {
    return this.c;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2SqlVariableDeclaration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */