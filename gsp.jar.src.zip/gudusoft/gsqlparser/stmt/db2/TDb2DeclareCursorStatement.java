package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TDeclareSqlNode;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class TDb2DeclareCursorStatement
  extends TCustomDb2Stmt
{
  private TSelectSqlStatement c = null;
  
  public TDb2DeclareCursorStatement(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2declarecursorstatement;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TDeclareSqlNode localTDeclareSqlNode = (TDeclareSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    localTDeclareSqlNode.getCursorName();
    this.c = new TSelectSqlStatement(this.dbvendor);
    this.c.rootNode = localTDeclareSqlNode.getSelectSqlNode();
    this.c.doParseStatement(this);
    return 0;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2DeclareCursorStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */