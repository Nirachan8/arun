package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.nodes.TElseIfSqlNodeList;
import gudusoft.gsqlparser.nodes.TExpression;
import gudusoft.gsqlparser.nodes.TIfSqlNode;
import gudusoft.gsqlparser.nodes.TStatementListSqlNode;
import gudusoft.gsqlparser.nodes.TStatementSqlNode;

public class TDb2IfStmt
  extends TCustomDb2Stmt
{
  private TExpression c = null;
  private TStatementList d = null;
  private TStatementList e = null;
  private TElseIfSqlNodeList f = null;
  
  public TDb2IfStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2ifstmt;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TIfSqlNode localTIfSqlNode = (TIfSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = localTIfSqlNode.getCondition();
    if (localTIfSqlNode.getThenStmts() != null)
    {
      localTIfSqlNode.getThenStmts().doParse(this, ESqlClause.unknown);
      for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTIfSqlNode.getThenStmts().size(); paramTCustomSqlStatement++) {
        getThenStmts().add(localTIfSqlNode.getThenStmts().getStatementSqlNode(paramTCustomSqlStatement).getStmt());
      }
    }
    if (localTIfSqlNode.getElseIfList() != null)
    {
      localTIfSqlNode.getElseIfList().doParse(this, ESqlClause.unknown);
      this.f = localTIfSqlNode.getElseIfList();
    }
    if (localTIfSqlNode.getElseStmts() != null)
    {
      localTIfSqlNode.getElseStmts().doParse(this, ESqlClause.unknown);
      for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTIfSqlNode.getElseStmts().size(); paramTCustomSqlStatement++) {
        getElseStmts().add(localTIfSqlNode.getElseStmts().getStatementSqlNode(paramTCustomSqlStatement).getStmt());
      }
    }
    return 0;
  }
  
  public TExpression getCondition()
  {
    return this.c;
  }
  
  public TStatementList getElseStmts()
  {
    if (this.e == null) {
      this.e = new TStatementList();
    }
    return this.e;
  }
  
  public TStatementList getThenStmts()
  {
    if (this.d == null) {
      this.d = new TStatementList();
    }
    return this.d;
  }
  
  public TElseIfSqlNodeList getElseIfList()
  {
    return this.f;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2IfStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */