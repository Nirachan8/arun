package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.nodes.TExpression;
import gudusoft.gsqlparser.nodes.TStatementListSqlNode;
import gudusoft.gsqlparser.nodes.TStatementSqlNode;
import gudusoft.gsqlparser.nodes.TWhileSqlNode;
import gudusoft.gsqlparser.stmt.TBlockSqlStatement;

public class TDb2WhileStmt
  extends TBlockSqlStatement
{
  private TExpression c = null;
  
  public TDb2WhileStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2whilestmt;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TWhileSqlNode localTWhileSqlNode = (TWhileSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = localTWhileSqlNode.getCondition();
    localTWhileSqlNode.getStmts().doParse(this, ESqlClause.unknown);
    for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTWhileSqlNode.getStmts().size(); paramTCustomSqlStatement++) {
      getBodyStatements().add(localTWhileSqlNode.getStmts().getStatementSqlNode(paramTCustomSqlStatement).getStmt());
    }
    return 0;
  }
  
  public TExpression getCondition()
  {
    return this.c;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2WhileStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */