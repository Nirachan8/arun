package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TDeclareSqlNode;
import gudusoft.gsqlparser.nodes.TStatementSqlNode;

public class TDb2HandlerDeclaration
  extends TCustomDb2Stmt
{
  private TCustomSqlStatement c = null;
  
  public TDb2HandlerDeclaration(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2handlerdeclaration;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TDeclareSqlNode localTDeclareSqlNode = (TDeclareSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    localTDeclareSqlNode.getStmtSqlNode().doParse(this, ESqlClause.unknown);
    this.c = localTDeclareSqlNode.getStmtSqlNode().getStmt();
    return 0;
  }
  
  public TCustomSqlStatement getStmt()
  {
    return this.c;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2HandlerDeclaration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */