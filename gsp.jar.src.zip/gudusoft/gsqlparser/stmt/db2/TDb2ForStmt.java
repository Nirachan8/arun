package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.nodes.TForSqlNode;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TStatementListSqlNode;
import gudusoft.gsqlparser.nodes.TStatementSqlNode;
import gudusoft.gsqlparser.stmt.TBlockSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class TDb2ForStmt
  extends TBlockSqlStatement
{
  private TObjectName c = null;
  private TObjectName d = null;
  private TSelectSqlStatement e = null;
  
  public TDb2ForStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2forstmt;
  }
  
  final void a() {}
  
  public TObjectName getCursorName()
  {
    return this.d;
  }
  
  public TObjectName getLoopName()
  {
    return this.c;
  }
  
  public TSelectSqlStatement getSubquery()
  {
    return this.e;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    paramTCustomSqlStatement = (TForSqlNode)this.rootNode;
    this.c = paramTCustomSqlStatement.getLoopName();
    this.d = paramTCustomSqlStatement.getCursorName();
    if (paramTCustomSqlStatement.getSelectNode() != null)
    {
      this.e = new TSelectSqlStatement(EDbVendor.dbvdb2);
      this.e.rootNode = paramTCustomSqlStatement.getSelectNode();
      this.e.doParseStatement(this);
    }
    if (paramTCustomSqlStatement.getStmtListNode() != null)
    {
      paramTCustomSqlStatement.getStmtListNode().doParse(this, ESqlClause.unknown);
      for (int i = 0; i < paramTCustomSqlStatement.getStmtListNode().size(); i++) {
        getBodyStatements().add(paramTCustomSqlStatement.getStmtListNode().getStatementSqlNode(i).getStmt());
      }
    }
    return 0;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2ForStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */