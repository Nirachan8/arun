package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.nodes.TCompoundSqlNode;
import gudusoft.gsqlparser.nodes.TCreateProcedureSqlNode;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParameterDeclarationList;
import gudusoft.gsqlparser.nodes.TStatementListSqlNode;
import gudusoft.gsqlparser.nodes.TStatementSqlNode;
import gudusoft.gsqlparser.nodes.TSymbolTableItem;
import gudusoft.gsqlparser.stmt.TStoredProcedureSqlStatement;
import java.util.Stack;

public class TDb2CreateProcedure
  extends TStoredProcedureSqlStatement
{
  private TObjectName c = null;
  
  public TDb2CreateProcedure(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2createprocedure;
  }
  
  final void a() {}
  
  public TObjectName getStoredProcedureName()
  {
    return this.c;
  }
  
  public TObjectName getProcedureName()
  {
    return this.c;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TCreateProcedureSqlNode localTCreateProcedureSqlNode;
    TCompoundSqlNode localTCompoundSqlNode = (localTCreateProcedureSqlNode = (TCreateProcedureSqlNode)this.rootNode).getCompoundSqls();
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = localTCreateProcedureSqlNode.getProcedureName();
    setParameterDeclarations(localTCreateProcedureSqlNode.getParameters());
    if (getParameterDeclarations() != null) {
      for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < getParameterDeclarations().size(); paramTCustomSqlStatement++) {
        getTopStatement().getSymbolTable().push(new TSymbolTableItem(9, this, getParameterDeclarations().getParameterDeclarationItem(paramTCustomSqlStatement)));
      }
    }
    if (localTCompoundSqlNode != null)
    {
      if (localTCompoundSqlNode.getDeclareStmts() != null)
      {
        localTCompoundSqlNode.getDeclareStmts().doParse(this, ESqlClause.unknown);
        for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTCompoundSqlNode.getDeclareStmts().size(); paramTCustomSqlStatement++)
        {
          getTopStatement().getSymbolTable().push(new TSymbolTableItem(10, this, localTCompoundSqlNode.getDeclareStmts().getStatementSqlNode(paramTCustomSqlStatement).getStmt()));
          getDeclareStatements().add(localTCompoundSqlNode.getDeclareStmts().getStatementSqlNode(paramTCustomSqlStatement).getStmt());
        }
      }
      if (localTCompoundSqlNode.getStmts() != null)
      {
        localTCompoundSqlNode.getStmts().doParse(this, ESqlClause.unknown);
        for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTCompoundSqlNode.getStmts().size(); paramTCustomSqlStatement++) {
          getBodyStatements().add(localTCompoundSqlNode.getStmts().getStatementSqlNode(paramTCustomSqlStatement).getStmt());
        }
      }
      if (localTCompoundSqlNode.getDeclareStmts() != null) {
        for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTCompoundSqlNode.getDeclareStmts().size(); paramTCustomSqlStatement++) {
          getTopStatement().getSymbolTable().pop();
        }
      }
    }
    if (getParameterDeclarations() != null) {
      for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < getParameterDeclarations().size(); paramTCustomSqlStatement++) {
        getTopStatement().getSymbolTable().pop();
      }
    }
    return 0;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2CreateProcedure.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */