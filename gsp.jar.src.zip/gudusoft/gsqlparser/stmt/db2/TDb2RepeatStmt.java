package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.nodes.TExpression;
import gudusoft.gsqlparser.nodes.TRepeatSqlNode;
import gudusoft.gsqlparser.nodes.TStatementListSqlNode;
import gudusoft.gsqlparser.nodes.TStatementSqlNode;
import gudusoft.gsqlparser.stmt.TBlockSqlStatement;

public class TDb2RepeatStmt
  extends TBlockSqlStatement
{
  private TExpression c = null;
  
  public TDb2RepeatStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2repeatstmt;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TRepeatSqlNode localTRepeatSqlNode = (TRepeatSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = localTRepeatSqlNode.getCondition();
    localTRepeatSqlNode.getStmts().doParse(this, ESqlClause.unknown);
    for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTRepeatSqlNode.getStmts().size(); paramTCustomSqlStatement++) {
      getBodyStatements().add(localTRepeatSqlNode.getStmts().getStatementSqlNode(paramTCustomSqlStatement).getStmt());
    }
    return 0;
  }
  
  public TExpression getCondition()
  {
    return this.c;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2RepeatStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */