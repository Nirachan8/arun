package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;

public class TDb2DummyStmt
  extends TCustomDb2Stmt
{
  public TDb2DummyStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2dummystmt;
  }
  
  final void a() {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2DummyStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */