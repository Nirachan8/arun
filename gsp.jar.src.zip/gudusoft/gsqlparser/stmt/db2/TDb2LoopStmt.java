package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.nodes.TLoopSqlNode;
import gudusoft.gsqlparser.nodes.TStatementListSqlNode;
import gudusoft.gsqlparser.nodes.TStatementSqlNode;
import gudusoft.gsqlparser.stmt.TBlockSqlStatement;

public class TDb2LoopStmt
  extends TBlockSqlStatement
{
  public TDb2LoopStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2loopstmt;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TLoopSqlNode localTLoopSqlNode = (TLoopSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    localTLoopSqlNode.getStmts().doParse(this, ESqlClause.unknown);
    for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTLoopSqlNode.getStmts().size(); paramTCustomSqlStatement++) {
      getBodyStatements().add(localTLoopSqlNode.getStmts().getStatementSqlNode(paramTCustomSqlStatement).getStmt());
    }
    return 0;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2LoopStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */