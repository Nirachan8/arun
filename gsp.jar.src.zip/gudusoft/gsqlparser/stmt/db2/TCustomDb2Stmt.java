package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TCustomDb2Stmt
  extends TCustomSqlStatement
{
  public TCustomDb2Stmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstunknown;
  }
  
  void a() {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TCustomDb2Stmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */