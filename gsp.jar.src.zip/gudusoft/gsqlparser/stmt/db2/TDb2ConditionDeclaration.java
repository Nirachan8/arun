package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TDeclareSqlNode;
import gudusoft.gsqlparser.nodes.TObjectName;

public class TDb2ConditionDeclaration
  extends TCustomDb2Stmt
{
  private TObjectName c = null;
  
  public TDb2ConditionDeclaration(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2conditiondeclaration;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TDeclareSqlNode localTDeclareSqlNode = (TDeclareSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = localTDeclareSqlNode.getConditionName();
    return 0;
  }
  
  public TObjectName getConditionName()
  {
    return this.c;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2ConditionDeclaration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */