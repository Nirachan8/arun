package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.nodes.TCompoundSqlNode;
import gudusoft.gsqlparser.nodes.TCreateTriggerSqlNode;
import gudusoft.gsqlparser.nodes.TExpression;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TStatementListSqlNode;
import gudusoft.gsqlparser.nodes.TStatementSqlNode;
import gudusoft.gsqlparser.nodes.TSymbolTableItem;
import gudusoft.gsqlparser.nodes.TTable;
import gudusoft.gsqlparser.nodes.TTableList;
import gudusoft.gsqlparser.nodes.TTriggerAction;
import gudusoft.gsqlparser.stmt.TStoredProcedureSqlStatement;
import java.util.Stack;

public class TDb2CreateTrigger
  extends TStoredProcedureSqlStatement
{
  private TObjectName c = null;
  private TTable d = null;
  private TExpression e = null;
  
  public TDb2CreateTrigger(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2createtrigger;
  }
  
  final void a() {}
  
  public TObjectName getStoredProcedureName()
  {
    return this.c;
  }
  
  public TObjectName getTriggerName()
  {
    return this.c;
  }
  
  public TTable getOnTable()
  {
    return this.d;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TCreateTriggerSqlNode localTCreateTriggerSqlNode = (TCreateTriggerSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = localTCreateTriggerSqlNode.getTriggerName();
    this.d = localTCreateTriggerSqlNode.getOnTable();
    this.tables.addTable(this.d);
    paramTCustomSqlStatement = localTCreateTriggerSqlNode.getTriggerAction();
    this.e = paramTCustomSqlStatement.getWhenExpr();
    if (paramTCustomSqlStatement.getStmtNode() != null)
    {
      paramTCustomSqlStatement.getStmtNode().doParse(this, ESqlClause.unknown);
      getBodyStatements().add(paramTCustomSqlStatement.getStmtNode().getStmt());
    }
    else if (paramTCustomSqlStatement.getCompoundSqlNode() != null)
    {
      int i;
      if ((paramTCustomSqlStatement = paramTCustomSqlStatement.getCompoundSqlNode()).getDeclareStmts() != null)
      {
        paramTCustomSqlStatement.getDeclareStmts().doParse(this, ESqlClause.unknown);
        for (i = 0; i < paramTCustomSqlStatement.getDeclareStmts().size(); i++)
        {
          getTopStatement().getSymbolTable().push(new TSymbolTableItem(10, this, paramTCustomSqlStatement.getDeclareStmts().getStatementSqlNode(i).getStmt()));
          getDeclareStatements().add(paramTCustomSqlStatement.getDeclareStmts().getStatementSqlNode(i).getStmt());
        }
      }
      if (paramTCustomSqlStatement.getStmts() != null)
      {
        paramTCustomSqlStatement.getStmts().doParse(this, ESqlClause.unknown);
        for (i = 0; i < paramTCustomSqlStatement.getStmts().size(); i++) {
          getBodyStatements().add(paramTCustomSqlStatement.getStmts().getStatementSqlNode(i).getStmt());
        }
      }
      if (paramTCustomSqlStatement.getDeclareStmts() != null) {
        for (i = 0; i < paramTCustomSqlStatement.getDeclareStmts().size(); i++) {
          getTopStatement().getSymbolTable().pop();
        }
      }
    }
    return 0;
  }
  
  public TExpression getWhenExpr()
  {
    return this.e;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2CreateTrigger.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */