package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TOpenSqlNode;

public class TDb2OpenCursorStmt
  extends TCustomDb2Stmt
{
  private TObjectName c = null;
  
  public TDb2OpenCursorStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2opencursorstmt;
  }
  
  final void a() {}
  
  public TObjectName getCursorName()
  {
    return this.c;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    paramTCustomSqlStatement = (TOpenSqlNode)this.rootNode;
    this.c = paramTCustomSqlStatement.getCursorName();
    return 0;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2OpenCursorStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */