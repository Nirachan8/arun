package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TFetchSqlNode;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TObjectNameList;

public class TDb2FetchCursorStmt
  extends TCustomDb2Stmt
{
  private TObjectName c = null;
  private TObjectNameList d = null;
  
  public TDb2FetchCursorStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2fetchcursorstmt;
  }
  
  final void a() {}
  
  public TObjectName getCursorName()
  {
    return this.c;
  }
  
  public TObjectNameList getVariableNames()
  {
    return this.d;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TFetchSqlNode localTFetchSqlNode = (TFetchSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = localTFetchSqlNode.getCursorName();
    this.d = localTFetchSqlNode.getVariableNames();
    return 0;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2FetchCursorStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */