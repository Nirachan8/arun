package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;

public class TDb2SqlProcedureStatement
  extends TCustomDb2Stmt
{
  public TDb2SqlProcedureStatement(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2sqlprocedurestatement;
  }
  
  final void a() {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2SqlProcedureStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */