package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.nodes.TCompoundSqlNode;
import gudusoft.gsqlparser.nodes.TCreateFunctionSqlNode;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParameterDeclarationList;
import gudusoft.gsqlparser.nodes.TReturnSqlNode;
import gudusoft.gsqlparser.nodes.TStatementListSqlNode;
import gudusoft.gsqlparser.nodes.TStatementSqlNode;
import gudusoft.gsqlparser.nodes.TSymbolTableItem;
import gudusoft.gsqlparser.stmt.TStoredProcedureSqlStatement;
import java.util.Stack;

public class TDb2CreateFunction
  extends TStoredProcedureSqlStatement
{
  private TObjectName c = null;
  private TDb2ReturnStmt d = null;
  
  public TDb2CreateFunction(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2createfunction;
  }
  
  final void a() {}
  
  public TObjectName getStoredProcedureName()
  {
    return this.c;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TCreateFunctionSqlNode localTCreateFunctionSqlNode;
    TCompoundSqlNode localTCompoundSqlNode = (localTCreateFunctionSqlNode = (TCreateFunctionSqlNode)this.rootNode).getCompoundSql();
    TReturnSqlNode localTReturnSqlNode = localTCreateFunctionSqlNode.getReturnSqlNode();
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = localTCreateFunctionSqlNode.getFunctionName();
    setParameterDeclarations(localTCreateFunctionSqlNode.getParameters());
    if (getParameterDeclarations() != null) {
      for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < getParameterDeclarations().size(); paramTCustomSqlStatement++) {
        getTopStatement().getSymbolTable().push(new TSymbolTableItem(9, this, getParameterDeclarations().getParameterDeclarationItem(paramTCustomSqlStatement)));
      }
    }
    if (localTCompoundSqlNode != null)
    {
      if (localTCompoundSqlNode.getDeclareStmts() != null)
      {
        localTCompoundSqlNode.getDeclareStmts().doParse(this, ESqlClause.unknown);
        for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTCompoundSqlNode.getDeclareStmts().size(); paramTCustomSqlStatement++)
        {
          getTopStatement().getSymbolTable().push(new TSymbolTableItem(10, this, localTCompoundSqlNode.getDeclareStmts().getStatementSqlNode(paramTCustomSqlStatement).getStmt()));
          getDeclareStatements().add(localTCompoundSqlNode.getDeclareStmts().getStatementSqlNode(paramTCustomSqlStatement).getStmt());
        }
      }
      if (localTCompoundSqlNode.getStmts() != null)
      {
        localTCompoundSqlNode.getStmts().doParse(this, ESqlClause.unknown);
        for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTCompoundSqlNode.getStmts().size(); paramTCustomSqlStatement++) {
          getBodyStatements().add(localTCompoundSqlNode.getStmts().getStatementSqlNode(paramTCustomSqlStatement).getStmt());
        }
      }
      if (localTCompoundSqlNode.getDeclareStmts() != null) {
        for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTCompoundSqlNode.getDeclareStmts().size(); paramTCustomSqlStatement++) {
          getTopStatement().getSymbolTable().pop();
        }
      }
    }
    else if (localTReturnSqlNode != null)
    {
      this.d = new TDb2ReturnStmt(EDbVendor.dbvdb2);
      this.d.rootNode = localTReturnSqlNode;
      this.d.doParseStatement(this);
    }
    if (getParameterDeclarations() != null) {
      for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < getParameterDeclarations().size(); paramTCustomSqlStatement++) {
        getTopStatement().getSymbolTable().pop();
      }
    }
    return 0;
  }
  
  public TObjectName getFunctionName()
  {
    return this.c;
  }
  
  public TDb2ReturnStmt getReturnStmt()
  {
    return this.d;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2CreateFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */