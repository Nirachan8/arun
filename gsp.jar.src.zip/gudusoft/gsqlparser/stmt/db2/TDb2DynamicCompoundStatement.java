package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;

public class TDb2DynamicCompoundStatement
  extends TCustomDb2Stmt
{
  public TDb2DynamicCompoundStatement(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2dynamiccompoundstatement;
  }
  
  final void a() {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2DynamicCompoundStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */