package gudusoft.gsqlparser.stmt.db2;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TStubStmtSqlNode;

public class TDb2GotoStmt
  extends TCustomDb2Stmt
{
  private TObjectName c = null;
  
  public TDb2GotoStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstdb2gotostmt;
  }
  
  final void a() {}
  
  public TObjectName getLabelName()
  {
    return this.c;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    paramTCustomSqlStatement = (TStubStmtSqlNode)this.rootNode;
    this.c = paramTCustomSqlStatement.getObjectName();
    return 0;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\db2\TDb2GotoStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */