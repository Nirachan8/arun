package gudusoft.gsqlparser.stmt.informix;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TColumnDefinitionList;
import gudusoft.gsqlparser.nodes.TCreateRowTypeSqlNode;
import gudusoft.gsqlparser.nodes.TObjectName;

public class TInformixCreateRowTypeStmt
  extends TCustomSqlStatement
{
  private TObjectName c;
  private TColumnDefinitionList d;
  private TObjectName e;
  
  public TColumnDefinitionList getColumnList()
  {
    return this.d;
  }
  
  public TObjectName getRowTypeName()
  {
    return this.c;
  }
  
  public TObjectName getSuperTableName()
  {
    return this.e;
  }
  
  public TInformixCreateRowTypeStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstinformixCreateRowType;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    paramTCustomSqlStatement = (TCreateRowTypeSqlNode)this.rootNode;
    this.c = paramTCustomSqlStatement.getRowTypeName();
    this.d = paramTCustomSqlStatement.getColumnList();
    this.e = paramTCustomSqlStatement.getSuperTableName();
    return 0;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\informix\TInformixCreateRowTypeStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */