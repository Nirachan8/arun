package gudusoft.gsqlparser.stmt.informix;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TDummy;
import gudusoft.gsqlparser.nodes.TObjectName;

public class TInformixDropRowTypeStmt
  extends TCustomSqlStatement
{
  private TObjectName c;
  
  public TInformixDropRowTypeStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstinformixDropRowType;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = ((TObjectName)((TDummy)this.rootNode).node1);
    return 0;
  }
  
  public TObjectName getRowTypeName()
  {
    return this.c;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\informix\TInformixDropRowTypeStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */