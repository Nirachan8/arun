package gudusoft.gsqlparser.stmt.mdx;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;
import gudusoft.gsqlparser.nodes.mdx.TMdxCreateMemberNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxWithMemberNode;

public class TMdxCreateMember
  extends TCustomSqlStatement
{
  private TMdxCreateMemberNode c;
  
  public TMdxCreateMember(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmdxcreatemember;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = ((TMdxCreateMemberNode)this.rootNode);
    return 0;
  }
  
  public TMdxWithMemberNode getSpecification()
  {
    return this.c.getSpecification();
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    getSpecification().accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mdx\TMdxCreateMember.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */