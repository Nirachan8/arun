package gudusoft.gsqlparser.stmt.mdx;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;
import gudusoft.gsqlparser.nodes.mdx.TMdxCreateSessionCubeNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxIdentifierNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxObjectNode;

public class TMdxCreateSessionCube
  extends TCustomSqlStatement
{
  private TMdxCreateSessionCubeNode c;
  
  public TMdxCreateSessionCube(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmdxcreatesessioncube;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = ((TMdxCreateSessionCubeNode)this.rootNode);
    return 0;
  }
  
  public TMdxIdentifierNode getCubeName()
  {
    return this.c.getCubeName();
  }
  
  public TPTNodeList<TMdxIdentifierNode> getCubeList()
  {
    return this.c.getCubeList();
  }
  
  public TPTNodeList<TMdxObjectNode> getParamList()
  {
    return this.c.getParamList();
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    getParamList().accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mdx\TMdxCreateSessionCube.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */