package gudusoft.gsqlparser.stmt.mdx;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;
import gudusoft.gsqlparser.nodes.mdx.TMdxCallNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxExpNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxIdentifierNode;

public class TMdxCall
  extends TCustomSqlStatement
{
  private TMdxCallNode c;
  
  public TMdxCall(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmdxcall;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = ((TMdxCallNode)this.rootNode);
    return 0;
  }
  
  public TMdxIdentifierNode getSpName()
  {
    return this.c.getSpName();
  }
  
  public TPTNodeList<TMdxExpNode> getArgs()
  {
    return this.c.getArgs();
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    if (getArgs() != null) {
      getArgs().accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mdx\TMdxCall.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */