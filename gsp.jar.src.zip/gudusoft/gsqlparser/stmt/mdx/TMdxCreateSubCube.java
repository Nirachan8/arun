package gudusoft.gsqlparser.stmt.mdx;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;
import gudusoft.gsqlparser.nodes.mdx.TMdxCreateSubCubeNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxIdentifierNode;

public class TMdxCreateSubCube
  extends TCustomSqlStatement
{
  private TMdxCreateSubCubeNode c;
  private TMdxSelect d;
  
  public TMdxCreateSubCube(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmdxcreatesubcube;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = ((TMdxCreateSubCubeNode)this.rootNode);
    this.d = new TMdxSelect(EDbVendor.dbvmdx);
    this.d.rootNode = this.c.getSelectNode();
    this.d.doParseStatement(this);
    return 0;
  }
  
  public TMdxIdentifierNode getCubeName()
  {
    return this.c.getCubeName();
  }
  
  public TMdxSelect getSubQuery()
  {
    return this.d;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.d.accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mdx\TMdxCreateSubCube.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */