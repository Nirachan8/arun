package gudusoft.gsqlparser.stmt.mdx;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.mdx.TMdxCreateSetNode;

public class TMdxCreateSet
  extends TCustomSqlStatement
{
  private TMdxCreateSetNode c;
  
  public TMdxCreateSet(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmdxcreateset;
  }
  
  public TMdxCreateSetNode getCreateSetNode()
  {
    return this.c;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = ((TMdxCreateSetNode)this.rootNode);
    return 0;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mdx\TMdxCreateSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */