package gudusoft.gsqlparser.stmt.mdx;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;
import gudusoft.gsqlparser.nodes.mdx.TMdxAxisNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxExpNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxIdentifierNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxSelectNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxWhereNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxWithNode;

public class TMdxSelect
  extends TCustomSqlStatement
{
  private TMdxSelectNode c;
  private TMdxSelect d;
  
  public TMdxSelect(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmdxselect;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = ((TMdxSelectNode)this.rootNode);
    if (this.c.getSubQuery() != null)
    {
      this.d = new TMdxSelect(EDbVendor.dbvmdx);
      this.d.rootNode = this.c.getSubQuery();
      this.d.doParseStatement(this);
    }
    return 0;
  }
  
  public TPTNodeList<TMdxWithNode> getWiths()
  {
    return this.c.getWiths();
  }
  
  public TPTNodeList<TMdxAxisNode> getAxes()
  {
    return this.c.getAxes();
  }
  
  public TMdxIdentifierNode getCube()
  {
    return this.c.getCube();
  }
  
  public TMdxSelect getSubQuery()
  {
    return this.d;
  }
  
  public TMdxWhereNode getWhere()
  {
    return this.c.getWhere();
  }
  
  public TPTNodeList<TMdxExpNode> getCellProps()
  {
    return this.c.getCellProps();
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    if (getWiths() != null) {
      getWiths().accept(paramTParseTreeVisitor);
    }
    if (getAxes() != null) {
      getAxes().accept(paramTParseTreeVisitor);
    }
    if (getSubQuery() != null) {
      getSubQuery().accept(paramTParseTreeVisitor);
    } else if (getCube() != null) {
      getCube().accept(paramTParseTreeVisitor);
    }
    if (getWhere() != null) {
      getWhere().accept(paramTParseTreeVisitor);
    }
    if (getCellProps() != null) {
      getCellProps().accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mdx\TMdxSelect.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */