package gudusoft.gsqlparser.stmt.mdx;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;
import gudusoft.gsqlparser.nodes.mdx.TMdxExpNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxScopeNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxSelectNode;

public class TMdxScope
  extends TCustomSqlStatement
{
  private TMdxScopeNode c;
  private TStatementList d = new TStatementList();
  
  public TMdxScope(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmdxscope;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = ((TMdxScopeNode)this.rootNode);
    if (this.c.getStatementList() == null) {
      return 0;
    }
    for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < this.c.getStatementList().size(); paramTCustomSqlStatement++)
    {
      Object localObject;
      if ((this.c.getStatementList().elementAt(paramTCustomSqlStatement) instanceof TMdxExpNode))
      {
        (localObject = new TMdxExpression(EDbVendor.dbvmdx)).rootNode = ((TParseTreeNode)this.c.getStatementList().elementAt(paramTCustomSqlStatement));
        ((TMdxExpression)localObject).doParseStatement(this);
        this.d.add((TCustomSqlStatement)localObject);
      }
      else if ((this.c.getStatementList().elementAt(paramTCustomSqlStatement) instanceof TMdxSelectNode))
      {
        (localObject = new TMdxSelect(EDbVendor.dbvmdx)).rootNode = ((TParseTreeNode)this.c.getStatementList().elementAt(paramTCustomSqlStatement));
        ((TMdxSelect)localObject).doParseStatement(this);
        this.d.add((TCustomSqlStatement)localObject);
      }
      else if ((this.c.getStatementList().elementAt(paramTCustomSqlStatement) instanceof TMdxScopeNode))
      {
        (localObject = new TMdxScope(EDbVendor.dbvmdx)).rootNode = ((TParseTreeNode)this.c.getStatementList().elementAt(paramTCustomSqlStatement));
        ((TMdxScope)localObject).doParseStatement(this);
        this.d.add((TCustomSqlStatement)localObject);
      }
    }
    return 0;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    getExprList().accept(paramTParseTreeVisitor);
    getStatementList().accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
  
  public TPTNodeList<TMdxExpNode> getExprList()
  {
    return this.c.getExprList();
  }
  
  public TStatementList getStatementList()
  {
    return this.d;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mdx\TMdxScope.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */