package gudusoft.gsqlparser.stmt.mdx;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;
import gudusoft.gsqlparser.nodes.mdx.TMdxDrillthroughNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxExpNode;

public class TMdxDrillthrough
  extends TCustomSqlStatement
{
  private TMdxDrillthroughNode c;
  private TMdxSelect d;
  
  public TMdxDrillthrough(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmdxdrillthrough;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = ((TMdxDrillthroughNode)this.rootNode);
    this.d = new TMdxSelect(EDbVendor.dbvmdx);
    this.d.rootNode = this.c.getSelectNode();
    this.d.doParseStatement(this);
    return 0;
  }
  
  public TMdxSelect getSubQuery()
  {
    return this.d;
  }
  
  public TPTNodeList<TMdxExpNode> getReturnAttrs()
  {
    return this.c.getReturnAttrs();
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.d.accept(paramTParseTreeVisitor);
    if (getReturnAttrs() != null) {
      getReturnAttrs().accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mdx\TMdxDrillthrough.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */