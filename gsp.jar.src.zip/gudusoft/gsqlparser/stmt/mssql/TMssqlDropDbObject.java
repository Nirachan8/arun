package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.EDbObjectType;
import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TDropDbObjectSqlNode;
import gudusoft.gsqlparser.nodes.TObjectNameList;

public class TMssqlDropDbObject
  extends TCustomSqlStatement
{
  private TObjectNameList c = null;
  private EDbObjectType d;
  
  public TMssqlDropDbObject(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmssqldropdbobject;
  }
  
  final void a() {}
  
  public TObjectNameList getObjectNameList()
  {
    return this.c;
  }
  
  public EDbObjectType getDbObjectType()
  {
    return this.d;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    super.doParseStatement(paramTCustomSqlStatement);
    if ((this.rootNode instanceof TDropDbObjectSqlNode))
    {
      paramTCustomSqlStatement = (TDropDbObjectSqlNode)this.rootNode;
      this.c = paramTCustomSqlStatement.getObjectNameList();
      this.d = paramTCustomSqlStatement.getDbObjectType();
    }
    return 0;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlDropDbObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */