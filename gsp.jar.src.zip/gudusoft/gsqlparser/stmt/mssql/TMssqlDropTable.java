package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TMssqlDropTable
  extends TCustomSqlStatement
{
  public TMssqlDropTable(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmssqldroptable;
  }
  
  final void a() {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlDropTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */