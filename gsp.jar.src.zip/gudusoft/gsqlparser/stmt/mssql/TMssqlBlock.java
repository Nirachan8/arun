package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.nodes.TBlockSqlNode;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;
import gudusoft.gsqlparser.nodes.TStatementListSqlNode;
import gudusoft.gsqlparser.nodes.TStatementSqlNode;
import gudusoft.gsqlparser.stmt.TBlockSqlStatement;

public class TMssqlBlock
  extends TBlockSqlStatement
{
  public TMssqlBlock(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmssqlblock;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TBlockSqlNode localTBlockSqlNode = (TBlockSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    if (localTBlockSqlNode.getStmts() != null)
    {
      localTBlockSqlNode.getStmts().doParse(this, ESqlClause.unknown);
      for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTBlockSqlNode.getStmts().size(); paramTCustomSqlStatement++) {
        getBodyStatements().add(localTBlockSqlNode.getStmts().getStatementSqlNode(paramTCustomSqlStatement).getStmt());
      }
    }
    return 0;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlBlock.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */