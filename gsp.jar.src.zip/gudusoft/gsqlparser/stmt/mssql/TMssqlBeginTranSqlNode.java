package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.nodes.TConstant;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TMssqlBeginTranSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private boolean b = false;
  private boolean c = false;
  private TConstant d = null;
  
  public TObjectName getTransactionName()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    if (paramObject != null)
    {
      this.a = ((TObjectName)paramObject);
      this.a.setObjectType(21);
    }
  }
  
  public void setWithMarkDescription(TConstant paramTConstant)
  {
    this.d = paramTConstant;
  }
  
  public TConstant getWithMarkDescription()
  {
    return this.d;
  }
  
  public void setWithMark(boolean paramBoolean)
  {
    this.c = paramBoolean;
  }
  
  public boolean isWithMark()
  {
    return this.c;
  }
  
  public void setDistributed(boolean paramBoolean)
  {
    this.b = paramBoolean;
  }
  
  public boolean isDistributed()
  {
    return this.b;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlBeginTranSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */