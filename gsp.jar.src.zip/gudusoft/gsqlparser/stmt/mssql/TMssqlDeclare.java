package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TDeclareSqlNode;
import gudusoft.gsqlparser.nodes.TDeclareVariableList;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class TMssqlDeclare
  extends TCustomSqlStatement
{
  private TSelectSqlStatement c = null;
  private TObjectName d = null;
  private int e = 1;
  private TDeclareVariableList f = null;
  
  public TMssqlDeclare(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmssqldeclare;
  }
  
  final void a() {}
  
  public TObjectName getCursorName()
  {
    return this.d;
  }
  
  public int getDeclareType()
  {
    return this.e;
  }
  
  public TSelectSqlStatement getSubquery()
  {
    return this.c;
  }
  
  public TDeclareVariableList getVariables()
  {
    return this.f;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TDeclareSqlNode localTDeclareSqlNode = (TDeclareSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    this.e = localTDeclareSqlNode.getDeclareType();
    this.d = localTDeclareSqlNode.getCursorName();
    if (this.e == 1) {
      this.f = localTDeclareSqlNode.getVariables();
    }
    if (localTDeclareSqlNode.getSelectSqlNode() != null)
    {
      this.c = new TSelectSqlStatement(this.dbvendor);
      this.c.rootNode = localTDeclareSqlNode.getSelectSqlNode();
      this.c.doParseStatement(this);
    }
    return 0;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlDeclare.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */