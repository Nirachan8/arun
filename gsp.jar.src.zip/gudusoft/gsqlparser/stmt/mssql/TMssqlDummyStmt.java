package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TMssqlDummyStmt
  extends TCustomSqlStatement
{
  public TMssqlDummyStmt(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmssqldummystmt;
  }
  
  final void a() {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlDummyStmt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */