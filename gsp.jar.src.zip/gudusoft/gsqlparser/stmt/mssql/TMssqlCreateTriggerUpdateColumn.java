package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TMssqlCreateTriggerUpdateColumn
  extends TParseTreeNode
{
  private TSourceToken a = null;
  private TSourceToken b = null;
  private TObjectName c = null;
  
  public TObjectName getColumnName()
  {
    return this.c;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.b = ((TSourceToken)paramObject1);
    this.a = ((TSourceToken)paramObject2);
    this.c = ((TObjectName)paramObject3);
  }
  
  public TSourceToken getAnd_or_nullToken()
  {
    return this.b;
  }
  
  public TSourceToken getNotToken()
  {
    return this.a;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlCreateTriggerUpdateColumn.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */