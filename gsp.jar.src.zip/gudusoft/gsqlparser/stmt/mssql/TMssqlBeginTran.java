package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TConstant;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMssqlBeginTran
  extends TCustomSqlStatement
{
  private TObjectName c = null;
  private boolean d = false;
  private boolean e = false;
  private TConstant f = null;
  
  public TMssqlBeginTran(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmssqlbegintran;
  }
  
  final void a() {}
  
  public TObjectName getTransactionName()
  {
    return this.c;
  }
  
  public boolean isDistributed()
  {
    return this.d;
  }
  
  public boolean isWithMark()
  {
    return this.e;
  }
  
  public TConstant getWithMarkDescription()
  {
    return this.f;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TMssqlBeginTranSqlNode localTMssqlBeginTranSqlNode = (TMssqlBeginTranSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = localTMssqlBeginTranSqlNode.getTransactionName();
    this.d = localTMssqlBeginTranSqlNode.isDistributed();
    this.e = localTMssqlBeginTranSqlNode.isWithMark();
    this.f = localTMssqlBeginTranSqlNode.getWithMarkDescription();
    return 0;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlBeginTran.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */