package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TMssqlBeginDialogSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TObjectName b = null;
  private TObjectName c = null;
  
  public TObjectName getDialogHandle()
  {
    return this.a;
  }
  
  public TObjectName getInitiatorServiceName()
  {
    return this.b;
  }
  
  public TObjectName getTargetServiceName()
  {
    return this.c;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.a = ((TObjectName)paramObject1);
    this.b = ((TObjectName)paramObject2);
    this.c = ((TObjectName)paramObject3);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlBeginDialogSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */