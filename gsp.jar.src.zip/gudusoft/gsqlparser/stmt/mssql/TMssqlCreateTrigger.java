package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.nodes.TCreateTriggerSqlNode;
import gudusoft.gsqlparser.nodes.TDummy;
import gudusoft.gsqlparser.nodes.TDummyList;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;
import gudusoft.gsqlparser.nodes.TStatementListSqlNode;
import gudusoft.gsqlparser.nodes.TStatementSqlNode;
import gudusoft.gsqlparser.nodes.TTable;
import gudusoft.gsqlparser.nodes.TTableList;
import gudusoft.gsqlparser.stmt.TStoredProcedureSqlStatement;

public class TMssqlCreateTrigger
  extends TStoredProcedureSqlStatement
{
  private TTable c = null;
  private TObjectName d = null;
  private int e = 0;
  private TSourceTokenList f = null;
  
  public TMssqlCreateTrigger(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmssqlcreatetrigger;
  }
  
  final void a() {}
  
  public TObjectName getStoredProcedureName()
  {
    return this.d;
  }
  
  public TTable getOnTable()
  {
    return this.c;
  }
  
  public TObjectName getTriggerName()
  {
    return this.d;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    if (!(this.rootNode instanceof TCreateTriggerSqlNode)) {
      return -1;
    }
    TCreateTriggerSqlNode localTCreateTriggerSqlNode = (TCreateTriggerSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    this.d = localTCreateTriggerSqlNode.getTriggerName();
    this.e = localTCreateTriggerSqlNode.getFireMode();
    this.c = localTCreateTriggerSqlNode.getOnTable();
    this.tables.addTable(this.c);
    for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTCreateTriggerSqlNode.getDmlTpyes().size(); paramTCustomSqlStatement++) {
      getDmlTpyes().add(localTCreateTriggerSqlNode.getDmlTpyes().getDummyItem(paramTCustomSqlStatement).st1);
    }
    if (localTCreateTriggerSqlNode.getStmts() != null)
    {
      localTCreateTriggerSqlNode.getStmts().doParse(this, ESqlClause.unknown);
      for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTCreateTriggerSqlNode.getStmts().size(); paramTCustomSqlStatement++) {
        getBodyStatements().add(localTCreateTriggerSqlNode.getStmts().getStatementSqlNode(paramTCustomSqlStatement).getStmt());
      }
    }
    return 0;
  }
  
  public TSourceTokenList getDmlTpyes()
  {
    if (this.f == null) {
      this.f = new TSourceTokenList();
    }
    return this.f;
  }
  
  public int getFireMode()
  {
    return this.e;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlCreateTrigger.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */