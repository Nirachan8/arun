package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMssqlBeginDialog
  extends TCustomSqlStatement
{
  public TMssqlBeginDialog(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmssqlbegindialog;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TMssqlBeginDialogSqlNode localTMssqlBeginDialogSqlNode = (TMssqlBeginDialogSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    localTMssqlBeginDialogSqlNode.getDialogHandle();
    localTMssqlBeginDialogSqlNode.getInitiatorServiceName();
    localTMssqlBeginDialogSqlNode.getTargetServiceName();
    return 0;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlBeginDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */