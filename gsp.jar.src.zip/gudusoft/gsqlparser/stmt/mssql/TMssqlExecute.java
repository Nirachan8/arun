package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.EErrorType;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.ETokenType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;
import gudusoft.gsqlparser.TSyntaxError;
import gudusoft.gsqlparser.nodes.TExecParameterList;
import gudusoft.gsqlparser.nodes.TExecuteSqlNode;
import gudusoft.gsqlparser.nodes.TExpressionList;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMssqlExecute
  extends TCustomSqlStatement
{
  private TObjectName c = null;
  private TObjectName d = null;
  private TExecParameterList e = null;
  private TExpressionList f = null;
  private int g = 0;
  
  public TMssqlExecute(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmssqlexec;
  }
  
  final void a() {}
  
  public TObjectName getModuleName()
  {
    return this.c;
  }
  
  public TExecParameterList getParameters()
  {
    return this.e;
  }
  
  public TObjectName getReturnStatus()
  {
    return this.d;
  }
  
  public TExpressionList getStringValues()
  {
    return this.f;
  }
  
  public int getExecType()
  {
    return this.g;
  }
  
  private static boolean a(TSourceTokenList paramTSourceTokenList, TSyntaxError paramTSyntaxError)
  {
    if (paramTSourceTokenList.size() <= 1) {
      return false;
    }
    TSourceToken localTSourceToken;
    if ((localTSourceToken = paramTSourceTokenList.get(0)).tokencode == 314)
    {
      paramTSourceTokenList = paramTSourceTokenList.nextsolidtoken(localTSourceToken, 1, false);
      paramTSyntaxError.hint = "Unknown object type in drop statement";
      if (paramTSourceTokenList != null)
      {
        paramTSyntaxError.tokentext = paramTSourceTokenList.toString();
        paramTSyntaxError.lineNo = paramTSourceTokenList.lineNo;
        paramTSyntaxError.columnNo = paramTSourceTokenList.columnNo;
      }
      return false;
    }
    if (paramTSourceTokenList.get(1).tokentype == ETokenType.ttperiod) {
      return true;
    }
    if (localTSourceToken.toString().startsWith("sp")) {
      return true;
    }
    if (localTSourceToken.toString().startsWith("select")) {
      return false;
    }
    if (localTSourceToken.toString().startsWith("del")) {
      return false;
    }
    if (localTSourceToken.toString().startsWith("update")) {
      return false;
    }
    if (localTSourceToken.toString().startsWith("insert")) {
      return false;
    }
    return !localTSourceToken.toString().startsWith("create");
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    if (!(this.rootNode instanceof TExecuteSqlNode))
    {
      if (this.sourcetokenlist.size() > 0)
      {
        localObject = this.sourcetokenlist.get(0);
        paramTCustomSqlStatement = new TSyntaxError(((TSourceToken)localObject).toString(), ((TSourceToken)localObject).lineNo, ((TSourceToken)localObject).columnNo, "syntax error", EErrorType.sperror, 10111);
        if (!a(this.sourcetokenlist, paramTCustomSqlStatement)) {
          parseerrormessagehandle(paramTCustomSqlStatement);
        }
      }
      return -1;
    }
    Object localObject = (TExecuteSqlNode)this.rootNode;
    this.g = ((TExecuteSqlNode)localObject).getExecType();
    super.doParseStatement(paramTCustomSqlStatement);
    if (((TExecuteSqlNode)localObject).getExecType() == 0)
    {
      this.c = ((TExecuteSqlNode)localObject).getModuleName();
      this.e = ((TExecuteSqlNode)localObject).getParameters();
      this.d = ((TExecuteSqlNode)localObject).getReturnStatus();
    }
    else if (((TExecuteSqlNode)localObject).getExecType() == 1)
    {
      this.f = ((TExecuteSqlNode)localObject).getStringValues();
    }
    else if ((((TExecuteSqlNode)localObject).getExecType() == 3) && (this.sourcetokenlist.size() > 0))
    {
      paramTCustomSqlStatement = this.sourcetokenlist.get(0);
      paramTCustomSqlStatement = new TSyntaxError(paramTCustomSqlStatement.toString(), paramTCustomSqlStatement.lineNo, paramTCustomSqlStatement.columnNo, "syntax error", EErrorType.sperror, 10111);
      if (!a(this.sourcetokenlist, paramTCustomSqlStatement)) {
        parseerrormessagehandle(paramTCustomSqlStatement);
      }
      this.c = new TObjectName();
      this.c.setGsqlparser(getGsqlparser());
      paramTCustomSqlStatement = 0;
      for (int i = 0; (i < this.sourcetokenlist.size()) && (this.sourcetokenlist.get(i).tokentype != ETokenType.ttwhitespace) && (this.sourcetokenlist.get(i).tokentype != ETokenType.ttreturn) && (this.sourcetokenlist.get(i).tokentype != ETokenType.ttsemicolon); i++) {
        paramTCustomSqlStatement++;
      }
      switch (paramTCustomSqlStatement)
      {
      case 1: 
        this.c.init(this.sourcetokenlist.get(0));
        break;
      case 3: 
        this.c.init(this.sourcetokenlist.get(0), this.sourcetokenlist.get(2));
        break;
      case 5: 
        this.c.init(this.sourcetokenlist.get(0), this.sourcetokenlist.get(2), this.sourcetokenlist.get(4));
        break;
      case 7: 
        this.c.init(this.sourcetokenlist.get(0), this.sourcetokenlist.get(2), this.sourcetokenlist.get(4), this.sourcetokenlist.get(6));
      }
      this.c.setObjectType(12);
    }
    return 0;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlExecute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */