package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.nodes.TParseTreeNodeList;

public class TMssqlCreateTriggerUpdateColumnList
  extends TParseTreeNodeList
{
  public void addCreateTriggerUpdateColumn(TMssqlCreateTriggerUpdateColumn paramTMssqlCreateTriggerUpdateColumn)
  {
    addElement(paramTMssqlCreateTriggerUpdateColumn);
  }
  
  public TMssqlCreateTriggerUpdateColumn getCreateTriggerUpdateColumn(int paramInt)
  {
    if (paramInt < size()) {
      return (TMssqlCreateTriggerUpdateColumn)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addCreateTriggerUpdateColumn((TMssqlCreateTriggerUpdateColumn)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlCreateTriggerUpdateColumnList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */