package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMssqlDeallocate
  extends TCustomSqlStatement
{
  private TObjectName c = null;
  private boolean d = false;
  
  public TMssqlDeallocate(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmssqldeallocate;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TMssqlDeallocateSqlNode localTMssqlDeallocateSqlNode = (TMssqlDeallocateSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = localTMssqlDeallocateSqlNode.getCursorName();
    this.d = localTMssqlDeallocateSqlNode.isGlobal();
    return 0;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
  
  public TObjectName getCursorName()
  {
    return this.c;
  }
  
  public boolean isGlobal()
  {
    return this.d;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlDeallocate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */