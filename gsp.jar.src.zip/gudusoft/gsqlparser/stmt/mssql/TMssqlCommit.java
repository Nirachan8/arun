package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TDummy;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMssqlCommit
  extends TCustomSqlStatement
{
  private TObjectName c = null;
  private TSourceToken d = null;
  
  public TMssqlCommit(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmssqlcommit;
  }
  
  final void a() {}
  
  public TObjectName getTransactionName()
  {
    return this.c;
  }
  
  public TSourceToken getTrans_or_work()
  {
    return this.d;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TDummy localTDummy = (TDummy)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = ((TObjectName)localTDummy.node1);
    if (this.c != null) {
      this.c.setObjectType(21);
    }
    this.d = localTDummy.st1;
    return 0;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlCommit.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */