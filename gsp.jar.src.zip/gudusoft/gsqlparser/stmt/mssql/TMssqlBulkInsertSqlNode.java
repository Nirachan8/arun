package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.nodes.TConstant;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TMssqlBulkInsertSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TConstant b = null;
  
  public TConstant getDatafile()
  {
    return this.b;
  }
  
  public TObjectName getTableName()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TObjectName)paramObject1);
    this.a.setObjectType(3);
    this.b = ((TConstant)paramObject2);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlBulkInsertSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */