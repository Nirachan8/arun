package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TMssqlDeallocateSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private boolean b = false;
  
  public void setGlobal(boolean paramBoolean)
  {
    this.b = paramBoolean;
  }
  
  public boolean isGlobal()
  {
    return this.b;
  }
  
  public TObjectName getCursorName()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TObjectName)paramObject);
    this.a.setObjectType(17);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlDeallocateSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */