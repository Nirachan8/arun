package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.nodes.TConstant;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMssqlBulkInsert
  extends TCustomSqlStatement
{
  private TObjectName c = null;
  private TConstant d = null;
  
  public TMssqlBulkInsert(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmssqlbulkinsert;
  }
  
  final void a() {}
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    TMssqlBulkInsertSqlNode localTMssqlBulkInsertSqlNode = (TMssqlBulkInsertSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = localTMssqlBulkInsertSqlNode.getTableName();
    this.d = localTMssqlBulkInsertSqlNode.getDatafile();
    return 0;
  }
  
  public TConstant getDatafile()
  {
    return this.d;
  }
  
  public TObjectName getTableName()
  {
    return this.c;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlBulkInsert.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */