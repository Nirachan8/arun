package gudusoft.gsqlparser.stmt.mssql;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.nodes.TCreateProcedureSqlNode;
import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParameterDeclarationList;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;
import gudusoft.gsqlparser.nodes.TStatementListSqlNode;
import gudusoft.gsqlparser.nodes.TStatementSqlNode;
import gudusoft.gsqlparser.nodes.TSymbolTableItem;
import gudusoft.gsqlparser.stmt.TStoredProcedureSqlStatement;
import java.util.Stack;

public class TMssqlCreateProcedure
  extends TStoredProcedureSqlStatement
{
  private TObjectName c = null;
  
  public TMssqlCreateProcedure(EDbVendor paramEDbVendor)
  {
    super(paramEDbVendor);
    this.sqlstatementtype = ESqlStatementType.sstmssqlcreateprocedure;
  }
  
  final void a() {}
  
  public TObjectName getStoredProcedureName()
  {
    return this.c;
  }
  
  public TObjectName getProcedureName()
  {
    return this.c;
  }
  
  public int doParseStatement(TCustomSqlStatement paramTCustomSqlStatement)
  {
    if (this.rootNode == null) {
      return -1;
    }
    if (!(this.rootNode instanceof TCreateProcedureSqlNode)) {
      return -1;
    }
    TCreateProcedureSqlNode localTCreateProcedureSqlNode = (TCreateProcedureSqlNode)this.rootNode;
    super.doParseStatement(paramTCustomSqlStatement);
    this.c = localTCreateProcedureSqlNode.getProcedureName();
    setParameterDeclarations(localTCreateProcedureSqlNode.getParameters());
    if (getParameterDeclarations() != null) {
      for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < getParameterDeclarations().size(); paramTCustomSqlStatement++) {
        getTopStatement().getSymbolTable().push(new TSymbolTableItem(9, this, getParameterDeclarations().getParameterDeclarationItem(paramTCustomSqlStatement)));
      }
    }
    if (localTCreateProcedureSqlNode.getStmts() != null)
    {
      localTCreateProcedureSqlNode.getStmts().doParse(this, ESqlClause.unknown);
      for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < localTCreateProcedureSqlNode.getStmts().size(); paramTCustomSqlStatement++) {
        getBodyStatements().add(localTCreateProcedureSqlNode.getStmts().getStatementSqlNode(paramTCustomSqlStatement).getStmt());
      }
    }
    if (getParameterDeclarations() != null) {
      for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < getParameterDeclarations().size(); paramTCustomSqlStatement++) {
        getTopStatement().getSymbolTable().pop();
      }
    }
    return 0;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\stmt\mssql\TMssqlCreateProcedure.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */