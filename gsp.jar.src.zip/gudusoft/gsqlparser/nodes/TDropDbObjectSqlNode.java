package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EDbObjectType;

public class TDropDbObjectSqlNode
  extends TParseTreeNode
{
  private TObjectNameList a = null;
  private EDbObjectType b;
  
  public TObjectNameList getObjectNameList()
  {
    return this.a;
  }
  
  public void setDbObjectType(EDbObjectType paramEDbObjectType)
  {
    this.b = paramEDbObjectType;
  }
  
  public EDbObjectType getDbObjectType()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TObjectNameList)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDropDbObjectSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */