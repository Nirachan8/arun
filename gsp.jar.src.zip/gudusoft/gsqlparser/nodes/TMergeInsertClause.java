package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TMergeInsertClause
  extends TParseTreeNode
{
  private TExpression a;
  private TObjectNameList b;
  private TResultColumnList c;
  
  public TObjectNameList getColumnList()
  {
    return this.b;
  }
  
  public TExpression getInsertWhereClause()
  {
    return this.a;
  }
  
  public TResultColumnList getValuelist()
  {
    return this.c;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.b = ((TObjectNameList)paramObject1);
    this.c = ((TResultColumnList)paramObject2);
    if (paramObject3 != null) {
      this.a = ((TExpression)paramObject3);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.b != null) {
      for (int i = 0; i < this.b.size(); i++)
      {
        (paramESqlClause = this.b.getObjectName(i)).setLocation(ESqlClause.resultColumn);
        paramTCustomSqlStatement.getTargetTable().getObjectNameReferences().addObjectName(paramESqlClause);
      }
    }
    if (this.c != null) {
      this.c.doParse(paramTCustomSqlStatement, ESqlClause.unknown);
    }
    if (this.a != null) {
      this.a.doParse(paramTCustomSqlStatement, ESqlClause.unknown);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TMergeInsertClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */