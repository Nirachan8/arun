package gudusoft.gsqlparser.nodes;

public class TWindowClause
  extends TParseTreeNode
{
  private TPTNodeList<TWindowDef> a;
  
  public TPTNodeList<TWindowDef> getWindowDefs()
  {
    return this.a;
  }
  
  public void setWindowDefs(TPTNodeList<TWindowDef> paramTPTNodeList)
  {
    this.a = paramTPTNodeList;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TWindowClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */