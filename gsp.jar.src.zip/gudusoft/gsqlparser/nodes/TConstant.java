package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TConstant
  extends TParseTreeNode
{
  private TSourceToken a;
  private TSourceToken b;
  
  public void setSign(TSourceToken paramTSourceToken)
  {
    this.b = paramTSourceToken;
  }
  
  public TSourceToken getSign()
  {
    return this.b;
  }
  
  public void setvalueToken(TSourceToken paramTSourceToken)
  {
    this.a = paramTSourceToken;
  }
  
  public TSourceToken getvalueToken()
  {
    return this.a;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TConstant.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */