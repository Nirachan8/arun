package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EJoinType;

public class TJoinExpr
  extends TNodeWithAliasClause
{
  public TObjectNameList usingColumns;
  public TExpression onCondition;
  private EJoinType a;
  public EJoinType original_jontype;
  private TFromTable b;
  private TFromTable c;
  
  public EJoinType getJointype()
  {
    return this.a;
  }
  
  public void setJointype(EJoinType paramEJoinType)
  {
    this.a = paramEJoinType;
  }
  
  public TFromTable getLeftOperand()
  {
    return this.b;
  }
  
  public TFromTable getRightOperand()
  {
    return this.c;
  }
  
  public void setLeftOperand(TFromTable paramTFromTable)
  {
    this.b = paramTFromTable;
  }
  
  public void setRightOperand(TFromTable paramTFromTable)
  {
    this.c = paramTFromTable;
  }
  
  public void init(Object paramObject)
  {
    this.a = EJoinType.nested;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.b = ((TFromTable)paramObject1);
    this.c = ((TFromTable)paramObject2);
  }
  
  public void setJoinCondition(TDummy paramTDummy)
  {
    if (paramTDummy.node1 != null)
    {
      this.onCondition = ((TExpression)paramTDummy.node1);
      return;
    }
    if (paramTDummy.list1 != null) {
      this.usingColumns = ((TObjectNameList)paramTDummy.list1);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TJoinExpr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */