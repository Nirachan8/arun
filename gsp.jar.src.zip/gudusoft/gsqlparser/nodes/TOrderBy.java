package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;

public class TOrderBy
  extends TParseTreeNode
{
  private TOrderByItemList a;
  
  public TOrderByItemList getItems()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TOrderByItemList)paramObject);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    getItems().accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
  
  public void addOrderByItem(String paramString)
  {
    if (this.a.size() == 0) {
      return;
    }
    TOrderByItem localTOrderByItem;
    (localTOrderByItem = new TOrderByItem()).setGsqlparser(getGsqlparser());
    localTOrderByItem.setString("," + paramString);
    paramString = this.a.getEndToken();
    localTOrderByItem.addAllMyTokensToTokenList(paramString.container, paramString.posinlist + 1);
    for (int i = 0; i < paramString.getNodesEndWithThisToken().size(); i++)
    {
      TParseTreeNode localTParseTreeNode;
      if (!((localTParseTreeNode = paramString.getNodesEndWithThisToken().getElement(i)) instanceof TOrderByItem)) {
        localTParseTreeNode.setEndToken(localTOrderByItem.getEndToken());
      }
    }
    this.a.addOrderByItem(localTOrderByItem);
  }
  
  public void removeOrderByItem(int paramInt)
  {
    if (this.a.size() > 1)
    {
      TSourceToken localTSourceToken;
      if (paramInt != this.a.size() - 1) {
        localTSourceToken = this.a.getOrderByItem(paramInt).getEndToken().searchToken(",", 1);
      } else {
        localTSourceToken = this.a.getOrderByItem(paramInt).getStartToken().searchToken(",", -1);
      }
      this.a.getOrderByItem(paramInt).removeAllMyTokensFromTokenList(localTSourceToken);
    }
    else if (this.a.size() == 1)
    {
      setString(" ");
    }
    this.a.a(paramInt);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TOrderBy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */