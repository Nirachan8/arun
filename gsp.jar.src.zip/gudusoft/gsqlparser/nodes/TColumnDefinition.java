package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EConstraintType;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;

public class TColumnDefinition
  extends TParseTreeNode
{
  private TObjectName a;
  private TTypeName b = null;
  private TConstraintList c = null;
  private TExpression d = null;
  private boolean e = false;
  private boolean f = false;
  private String g = null;
  private TExpression h;
  private TExpression i;
  private boolean j = false;
  private TExpression k = null;
  
  public TColumnDefinition() {}
  
  public TColumnDefinition(TObjectName paramTObjectName)
  {
    this.a = paramTObjectName;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.a = ((TObjectName)paramObject1);
    this.a.setObjectType(1);
    if (paramObject2 != null) {
      this.b = ((TTypeName)paramObject2);
    }
    this.c = ((TConstraintList)paramObject3);
  }
  
  public TObjectName getColumnName()
  {
    return this.a;
  }
  
  public TTypeName getDatatype()
  {
    return this.b;
  }
  
  public TConstraintList getConstraints()
  {
    return this.c;
  }
  
  public void setDefaultExpression(TExpression paramTExpression)
  {
    this.d = paramTExpression;
  }
  
  public TExpression getDefaultExpression()
  {
    return this.d;
  }
  
  public void setNull(boolean paramBoolean)
  {
    this.e = paramBoolean;
  }
  
  public boolean isNull()
  {
    return this.e;
  }
  
  public boolean isRowGuidCol()
  {
    return this.f;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
  
  public void setCollationName(String paramString)
  {
    this.g = paramString;
  }
  
  public String getCollationName()
  {
    return this.g;
  }
  
  public TExpression getIncrement()
  {
    return this.i;
  }
  
  public TExpression getSeed()
  {
    return this.h;
  }
  
  public boolean isIdentity()
  {
    return this.j;
  }
  
  public void setComputedColumnExpression(TExpression paramTExpression)
  {
    this.k = paramTExpression;
  }
  
  public TExpression getComputedColumnExpression()
  {
    return this.k;
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.c == null) {
      return;
    }
    for (paramTCustomSqlStatement = this.c.size() - 1; paramTCustomSqlStatement >= 0; paramTCustomSqlStatement--)
    {
      this.c.getConstraint(paramTCustomSqlStatement).setConstraintLevel(1);
      if (this.c.getConstraint(paramTCustomSqlStatement).getConstraint_type() == EConstraintType.fake_collate)
      {
        this.g = this.c.getConstraint(paramTCustomSqlStatement).getEndToken().toString();
        this.c.removeElementAt(paramTCustomSqlStatement);
      }
      else if (this.c.getConstraint(paramTCustomSqlStatement).getConstraint_type() == EConstraintType.fake_null)
      {
        setNull(true);
        this.c.removeElementAt(paramTCustomSqlStatement);
      }
      else if (this.c.getConstraint(paramTCustomSqlStatement).getConstraint_type() == EConstraintType.fake_rowguidcol)
      {
        this.f = true;
        this.c.removeElementAt(paramTCustomSqlStatement);
      }
      else if (this.c.getConstraint(paramTCustomSqlStatement).getConstraint_type() == EConstraintType.fake_identity)
      {
        this.j = true;
        this.h = this.c.getConstraint(paramTCustomSqlStatement).getSeed();
        this.i = this.c.getConstraint(paramTCustomSqlStatement).getIncrement();
        this.c.removeElementAt(paramTCustomSqlStatement);
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TColumnDefinition.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */