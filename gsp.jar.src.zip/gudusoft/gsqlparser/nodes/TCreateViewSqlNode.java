package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TCreateViewSqlNode
  extends TParseTreeNode
{
  private TSelectSqlNode a = null;
  private TObjectName b = null;
  private TViewAliasClause c = null;
  private TRestrictionClause d = null;
  private TSourceToken e = null;
  private TSourceToken f = null;
  private TObjectName g;
  
  public void setRowTypeName(TObjectName paramTObjectName)
  {
    this.g = paramTObjectName;
  }
  
  public TObjectName getRowTypeName()
  {
    return this.g;
  }
  
  public void setStForce(TSourceToken paramTSourceToken)
  {
    this.e = paramTSourceToken;
  }
  
  public void setStReplace(TSourceToken paramTSourceToken)
  {
    this.f = paramTSourceToken;
  }
  
  public TSourceToken getStForce()
  {
    return this.e;
  }
  
  public TSourceToken getStReplace()
  {
    return this.f;
  }
  
  public void setRestrictionClause(TRestrictionClause paramTRestrictionClause)
  {
    this.d = paramTRestrictionClause;
  }
  
  public TRestrictionClause getRestrictionClause()
  {
    return this.d;
  }
  
  public void setViewAliasClause(TViewAliasClause paramTViewAliasClause)
  {
    this.c = paramTViewAliasClause;
  }
  
  public TViewAliasClause getViewAliasClause()
  {
    return this.c;
  }
  
  public TSelectSqlNode getSelectSqlNode()
  {
    return this.a;
  }
  
  public TObjectName getViewName()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.b = ((TObjectName)paramObject1);
    this.b.setObjectType(18);
    this.a = ((TSelectSqlNode)paramObject2);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCreateViewSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */