package gudusoft.gsqlparser.nodes;

public class TCreateMaterializedViewSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TViewAliasClause b = null;
  private TSelectSqlNode c = null;
  
  public void setViewAliasClause(TViewAliasClause paramTViewAliasClause)
  {
    this.b = paramTViewAliasClause;
  }
  
  public TSelectSqlNode getSelectSqlNode()
  {
    return this.c;
  }
  
  public TObjectName getViewName()
  {
    return this.a;
  }
  
  public TViewAliasClause getViewAliasClause()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TObjectName)paramObject1);
    this.a.setObjectType(16);
    this.c = ((TSelectSqlNode)paramObject2);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCreateMaterializedViewSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */