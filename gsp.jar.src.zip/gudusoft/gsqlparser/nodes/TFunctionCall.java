package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EAggregateType;
import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.EFunctionType;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;

public class TFunctionCall
  extends TParseTreeNode
{
  private TResultColumnList a;
  private EAggregateType b = EAggregateType.none;
  private TOrderByItemList c;
  private TOrderBy d;
  private TWindowDef e;
  private TDatatypeAttribute f = null;
  private TDummy g = null;
  private TInExpr h = null;
  private TExpression i = null;
  private TExpression j = null;
  private TExpression k = null;
  private TObjectNameList l = null;
  private TExpression m = null;
  private TTypeName n = null;
  private TSourceToken o = null;
  private TExpression p = null;
  private TExpression q = null;
  private TExpression r = null;
  private EFunctionType s = EFunctionType.udf_t;
  private TExpression t = null;
  private TExpression u = null;
  private TObjectName v;
  public TExpression Trim_Expr = null;
  public TExpression Trim_From_Expr = null;
  private TTrimArgument w = null;
  private TExpressionList x = null;
  private TExpressionList y = null;
  private TAnalyticFunction z;
  /**
   * @deprecated
   */
  private int A = 0;
  /**
   * @deprecated
   */
  public static final int fntUdf = 0;
  /**
   * @deprecated
   */
  public static final int fntTrim = 1;
  /**
   * @deprecated
   */
  public static final int fntCast = 2;
  /**
   * @deprecated
   */
  public static final int fntConvert = 3;
  /**
   * @deprecated
   */
  public static final int fntExtract = 4;
  /**
   * @deprecated
   */
  public static final int fntTreat = 5;
  /**
   * @deprecated
   */
  public static final int fntContains = 6;
  /**
   * @deprecated
   */
  public static final int fntFreetext = 7;
  /**
   * @deprecated
   */
  public static final int fntCaseN = 10;
  /**
   * @deprecated
   */
  public static final int fntRangeN = 11;
  /**
   * @deprecated
   */
  public static final int fntPosition = 12;
  /**
   * @deprecated
   */
  public static final int fntSubstring = 13;
  /**
   * @deprecated
   */
  public static final int fntTranslate = 14;
  /**
   * @deprecated
   */
  public static final int fntTranslateCHK = 15;
  /**
   * @deprecated
   */
  public static final int fntCSUM = 16;
  /**
   * @deprecated
   */
  public static final int fntRank = 17;
  /**
   * @deprecated
   */
  public static final int fntXmlQuery = 18;
  /**
   * @deprecated
   */
  public static final int fntSubString = 31;
  /**
   * @deprecated
   */
  public static final int fntAddDate = 32;
  /**
   * @deprecated
   */
  public static final int fntDateAdd = 33;
  /**
   * @deprecated
   */
  public static final int fntSubDate = 34;
  /**
   * @deprecated
   */
  public static final int fntDateSub = 35;
  /**
   * @deprecated
   */
  public static final int fntTimestampAdd = 36;
  /**
   * @deprecated
   */
  public static final int fntTimestampDiff = 37;
  /**
   * @deprecated
   */
  public static final int fntGroupConcat = 38;
  /**
   * @deprecated
   */
  public static final int fntMatchAgainst = 39;
  /**
   * @deprecated
   */
  public static final int fntExtractXML = 50;
  /**
   * @deprecated
   */
  public static final int fntOGC = 60;
  
  public void setValueExprList(TResultColumnList paramTResultColumnList)
  {
    this.a = paramTResultColumnList;
  }
  
  public TResultColumnList getValueExprList()
  {
    return this.a;
  }
  
  public void setAggregateType(EAggregateType paramEAggregateType)
  {
    this.b = paramEAggregateType;
  }
  
  public EAggregateType getAggregateType()
  {
    return this.b;
  }
  
  public void setOrderByList(TOrderByItemList paramTOrderByItemList)
  {
    this.c = paramTOrderByItemList;
  }
  
  public TOrderByItemList getOrderByList()
  {
    return this.c;
  }
  
  public void setSortClause(TOrderBy paramTOrderBy)
  {
    this.d = paramTOrderBy;
  }
  
  public TOrderBy getSortClause()
  {
    return this.d;
  }
  
  public TWindowDef getWindowDef()
  {
    return this.e;
  }
  
  public void setWindowDef(TWindowDef paramTWindowDef)
  {
    this.e = paramTWindowDef;
  }
  
  public void setDatatypeAttribute(TDatatypeAttribute paramTDatatypeAttribute)
  {
    this.f = paramTDatatypeAttribute;
  }
  
  public TDatatypeAttribute getDatatypeAttribute()
  {
    return this.f;
  }
  
  public TSourceToken getExtract_time_token()
  {
    return this.o;
  }
  
  public void setExtract_time_token(TSourceToken paramTSourceToken)
  {
    this.o = paramTSourceToken;
  }
  
  public void setDummy(TDummy paramTDummy)
  {
    this.g = paramTDummy;
  }
  
  public TDummy getDummy()
  {
    return this.g;
  }
  
  public void setInExpr(TInExpr paramTInExpr)
  {
    this.h = paramTInExpr;
  }
  
  public TInExpr getInExpr()
  {
    return this.h;
  }
  
  public void setExtractXMLArg(TExpressionList paramTExpressionList)
  {
    if (paramTExpressionList.size() > 1)
    {
      this.i = paramTExpressionList.getExpression(0);
      this.j = paramTExpressionList.getExpression(1);
    }
    if (paramTExpressionList.size() > 2) {
      this.k = paramTExpressionList.getExpression(2);
    }
    this.s = EFunctionType.extractxml_t;
  }
  
  public TExpression getNamespace_String()
  {
    return this.k;
  }
  
  public TExpression getXPath_String()
  {
    return this.j;
  }
  
  public TExpression getXMLType_Instance()
  {
    return this.i;
  }
  
  public TObjectNameList getMatchColumns()
  {
    return this.l;
  }
  
  public TExpression getAgainstExpr()
  {
    return this.m;
  }
  
  public void setMatchColumns(TObjectNameList paramTObjectNameList)
  {
    this.l = paramTObjectNameList;
  }
  
  public void setAgainstExpr(TExpression paramTExpression)
  {
    this.m = paramTExpression;
  }
  
  public void setTypename(TTypeName paramTTypeName)
  {
    this.n = paramTTypeName;
  }
  
  public TTypeName getTypename()
  {
    return this.n;
  }
  
  public EFunctionType getFunctionType()
  {
    return this.s;
  }
  
  public TExpression getRangeSize()
  {
    return this.u;
  }
  
  public TExpression getBetweenExpr()
  {
    return this.t;
  }
  
  public void setRangeSize(TExpression paramTExpression)
  {
    this.u = paramTExpression;
  }
  
  public void setBetweenExpr(TExpression paramTExpression)
  {
    this.t = paramTExpression;
  }
  
  public TObjectName getFunctionName()
  {
    return this.v;
  }
  
  public void setTrimArgument(TTrimArgument paramTTrimArgument)
  {
    this.w = paramTTrimArgument;
  }
  
  public TTrimArgument getTrimArgument()
  {
    return this.w;
  }
  
  public void setExpr1(TExpression paramTExpression)
  {
    this.p = paramTExpression;
  }
  
  public void setExpr2(TExpression paramTExpression)
  {
    this.q = paramTExpression;
  }
  
  public TExpression getExpr1()
  {
    return this.p;
  }
  
  public TExpression getExpr2()
  {
    return this.q;
  }
  
  public void setExpr3(TExpression paramTExpression)
  {
    this.r = paramTExpression;
  }
  
  public TExpression getExpr3()
  {
    return this.r;
  }
  
  public void setExprList(TExpressionList paramTExpressionList)
  {
    this.x = paramTExpressionList;
  }
  
  public TExpressionList getExprList()
  {
    return this.x;
  }
  
  public void setArgs(TExpressionList paramTExpressionList)
  {
    this.y = paramTExpressionList;
  }
  
  public void init(Object paramObject)
  {
    this.v = ((TObjectName)paramObject);
    this.v.setObjectType(13);
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.s = ((EFunctionType)paramObject1);
    init(paramObject2);
  }
  
  public void setAnalyticFunction(TAnalyticFunction paramTAnalyticFunction)
  {
    this.z = paramTAnalyticFunction;
  }
  
  public TExpressionList getArgs()
  {
    return this.y;
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    switch (1.a[this.s.ordinal()])
    {
    case 1: 
    case 2: 
      if (this.y != null) {
        this.y.doParse(paramTCustomSqlStatement, paramESqlClause);
      }
      if (this.z != null) {
        this.z.doParse(paramTCustomSqlStatement, paramESqlClause);
      }
      if ((paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmssql) && ((b(this.v.getObjectToken())) || (a(this.v.getObjectToken()))) && (this.v.getSchemaToken() != null))
      {
        this.v.getSchemaToken().setDbObjType(1);
        if (this.v.getDatabaseToken() != null) {
          this.v.getDatabaseToken().setDbObjType(3);
        }
        TObjectName localTObjectName;
        (localTObjectName = new TObjectName()).init(this.v.getDatabaseToken(), this.v.getSchemaToken());
        localTObjectName.setGsqlparser(paramTCustomSqlStatement.getGsqlparser());
        paramTCustomSqlStatement.linkColumnReferenceToTable(localTObjectName, paramESqlClause);
        return;
      }
      break;
    case 3: 
      if (this.w != null)
      {
        this.w.doParse(paramTCustomSqlStatement, paramESqlClause);
        return;
      }
      break;
    case 4: 
      this.p.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 5: 
      this.p.doParse(paramTCustomSqlStatement, paramESqlClause);
      if (this.q != null)
      {
        this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
        return;
      }
      break;
    case 6: 
      if (this.p != null)
      {
        this.p.doParse(paramTCustomSqlStatement, paramESqlClause);
        return;
      }
      break;
    case 7: 
      this.p.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 8: 
      this.h.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.p.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 9: 
      this.h.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.p.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 10: 
      this.x.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 11: 
      this.t.doParse(paramTCustomSqlStatement, paramESqlClause);
      if (this.x != null) {
        this.x.doParse(paramTCustomSqlStatement, paramESqlClause);
      }
      if (this.u != null)
      {
        this.u.doParse(paramTCustomSqlStatement, paramESqlClause);
        return;
      }
      break;
    case 12: 
      this.p.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 13: 
      this.p.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      if (this.r != null)
      {
        this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
        return;
      }
      break;
    case 14: 
    case 15: 
      
    case 16: 
      for (int i1 = 0; i1 < getMatchColumns().size(); i1++) {
        paramTCustomSqlStatement.linkColumnReferenceToTable(getMatchColumns().getObjectName(i1), paramESqlClause);
      }
      getAgainstExpr().doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 17: 
    case 18: 
    case 19: 
    case 20: 
    case 21: 
    case 22: 
      this.p.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
  
  public TAnalyticFunction getAnalyticFunction()
  {
    return this.z;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    switch (1.a[this.s.ordinal()])
    {
    case 2: 
      if (this.y != null) {
        this.y.accept(paramTParseTreeVisitor);
      }
      if (this.z != null) {
        this.z.accept(paramTParseTreeVisitor);
      }
      break;
    case 3: 
      if (this.w != null) {
        this.w.accept(paramTParseTreeVisitor);
      }
      break;
    case 4: 
      this.p.accept(paramTParseTreeVisitor);
      break;
    case 5: 
      this.p.accept(paramTParseTreeVisitor);
      if (this.q != null) {
        this.q.accept(paramTParseTreeVisitor);
      }
      break;
    case 6: 
      if (this.p != null) {
        this.p.accept(paramTParseTreeVisitor);
      }
      break;
    case 7: 
      this.p.accept(paramTParseTreeVisitor);
      break;
    case 8: 
      this.h.accept(paramTParseTreeVisitor);
      this.p.accept(paramTParseTreeVisitor);
      break;
    case 9: 
      this.h.accept(paramTParseTreeVisitor);
      this.p.accept(paramTParseTreeVisitor);
      break;
    case 10: 
      this.x.accept(paramTParseTreeVisitor);
      break;
    case 11: 
      this.t.accept(paramTParseTreeVisitor);
      if (this.x != null) {
        this.x.accept(paramTParseTreeVisitor);
      }
      if (this.u != null) {
        this.u.accept(paramTParseTreeVisitor);
      }
      break;
    case 12: 
      this.p.accept(paramTParseTreeVisitor);
      this.q.accept(paramTParseTreeVisitor);
      break;
    case 13: 
      this.p.accept(paramTParseTreeVisitor);
      this.q.accept(paramTParseTreeVisitor);
      if (this.r != null) {
        this.r.accept(paramTParseTreeVisitor);
      }
      break;
    case 14: 
    case 15: 
      break;
    case 16: 
      getAgainstExpr().accept(paramTParseTreeVisitor);
      break;
    case 17: 
    case 18: 
    case 19: 
    case 20: 
    case 21: 
    case 22: 
      this.p.accept(paramTParseTreeVisitor);
      this.q.accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
  
  private static boolean a(TSourceToken paramTSourceToken)
  {
    return (paramTSourceToken.tokencode == 554) || (paramTSourceToken.tokencode == 555) || (paramTSourceToken.tokencode == 556) || (paramTSourceToken.tokencode == 557) || (paramTSourceToken.tokencode == 553);
  }
  
  private static boolean b(TSourceToken paramTSourceToken)
  {
    return (paramTSourceToken.tokencode == 532) || (paramTSourceToken.tokencode == 533) || (paramTSourceToken.tokencode == 534) || (paramTSourceToken.tokencode == 535) || (paramTSourceToken.tokencode == 536) || (paramTSourceToken.tokencode == 537) || (paramTSourceToken.tokencode == 538) || (paramTSourceToken.tokencode == 539) || (paramTSourceToken.tokencode == 540) || (paramTSourceToken.tokencode == 541) || (paramTSourceToken.tokencode == 542) || (paramTSourceToken.tokencode == 543) || (paramTSourceToken.tokencode == 544) || (paramTSourceToken.tokencode == 545) || (paramTSourceToken.tokencode == 546) || (paramTSourceToken.tokencode == 547) || (paramTSourceToken.tokencode == 548) || (paramTSourceToken.tokencode == 549) || (paramTSourceToken.tokencode == 550) || (paramTSourceToken.tokencode == 551) || (paramTSourceToken.tokencode == 552);
  }
  
  /**
   * @deprecated
   */
  public void setFuncType(int paramInt)
  {
    this.A = paramInt;
  }
  
  /**
   * @deprecated
   */
  public int getFuncType()
  {
    return this.A;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TFunctionCall.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */