package gudusoft.gsqlparser.nodes;

public class TWindowDef
  extends TParseTreeNode
{
  private TObjectName a;
  private TObjectName b;
  private TWindowDef c;
  private TFrameExclusionClause d;
  private TOrderBy e;
  private TPartitionClause f;
  private TExpression g;
  private TExpression h;
  
  public void setExclusionClause(TFrameExclusionClause paramTFrameExclusionClause)
  {
    this.d = paramTFrameExclusionClause;
  }
  
  public TFrameExclusionClause getExclusionClause()
  {
    return this.d;
  }
  
  public void setName(TObjectName paramTObjectName)
  {
    this.a = paramTObjectName;
  }
  
  public void setFrameClause(TWindowDef paramTWindowDef)
  {
    this.c = paramTWindowDef;
  }
  
  public TWindowDef getFrameClause()
  {
    return this.c;
  }
  
  public TObjectName getName()
  {
    return this.a;
  }
  
  public TObjectName getReferenceName()
  {
    return this.b;
  }
  
  public TOrderBy getSortClause()
  {
    return this.e;
  }
  
  public void setSortClause(TOrderBy paramTOrderBy)
  {
    this.e = paramTOrderBy;
  }
  
  public void setPartitionClause(TPartitionClause paramTPartitionClause)
  {
    this.f = paramTPartitionClause;
  }
  
  public TPartitionClause getPartitionClause()
  {
    return this.f;
  }
  
  public void setReferenceName(TObjectName paramTObjectName)
  {
    this.b = paramTObjectName;
  }
  
  public TExpression getStartOffset()
  {
    return this.g;
  }
  
  public TExpression getEndOffset()
  {
    return this.h;
  }
  
  public void setEndOffset(TExpression paramTExpression)
  {
    this.h = paramTExpression;
  }
  
  public void setStartOffset(TExpression paramTExpression)
  {
    this.g = paramTExpression;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TWindowDef.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */