package gudusoft.gsqlparser.nodes;

public class TTableReferenceList
  extends TParseTreeNodeList
{
  public void addTableReference(TTableReference paramTTableReference)
  {
    addElement(paramTTableReference);
  }
  
  public TTableReference getTableReference(int paramInt)
  {
    if (paramInt < size()) {
      return (TTableReference)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addTableReference((TTableReference)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTableReferenceList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */