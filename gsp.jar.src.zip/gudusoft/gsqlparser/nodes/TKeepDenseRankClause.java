package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TKeepDenseRankClause
  extends TParseTreeNode
{
  private TOrderBy a;
  
  public void init(Object paramObject)
  {
    this.a = ((TOrderBy)paramObject);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TKeepDenseRankClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */