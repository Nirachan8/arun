package gudusoft.gsqlparser.nodes;

public class TTruncateTableSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  
  public TObjectName getTableName()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TObjectName)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTruncateTableSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */