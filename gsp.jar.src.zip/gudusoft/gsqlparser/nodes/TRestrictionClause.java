package gudusoft.gsqlparser.nodes;

public class TRestrictionClause
  extends TParseTreeNode
{
  public static final int with_read_only = 1;
  public static final int with_check_option = 2;
  public static final int with_local_check_option = 3;
  public static final int with_cascaded_check_option = 4;
  private int a;
  private TObjectName b;
  
  public void setType(int paramInt)
  {
    this.a = paramInt;
  }
  
  public int getType()
  {
    return this.a;
  }
  
  public TObjectName getConstraintName()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    this.b = ((TObjectName)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TRestrictionClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */