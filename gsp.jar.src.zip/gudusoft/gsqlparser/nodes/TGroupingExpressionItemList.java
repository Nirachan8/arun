package gudusoft.gsqlparser.nodes;

/**
 * @deprecated
 */
public class TGroupingExpressionItemList
  extends TParseTreeNodeList
{
  public void addGroupingExpressionItem(TGroupingExpressionItem paramTGroupingExpressionItem)
  {
    addElement(paramTGroupingExpressionItem);
  }
  
  public TGroupingExpressionItem getGroupingExpressionItem(int paramInt)
  {
    if (paramInt < size()) {
      return (TGroupingExpressionItem)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addGroupingExpressionItem((TGroupingExpressionItem)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      getGroupingExpressionItem(i).accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TGroupingExpressionItemList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */