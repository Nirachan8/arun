package gudusoft.gsqlparser.nodes;

public class TReturnSqlNode
  extends TParseTreeNode
{
  private TSelectSqlNode a = null;
  private TExpression b = null;
  
  public TExpression getExpr()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TSelectSqlNode))
    {
      this.a = ((TSelectSqlNode)paramObject);
      return;
    }
    this.b = ((TExpression)paramObject);
  }
  
  public TSelectSqlNode getSelectSqlNode()
  {
    return this.a;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TReturnSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */