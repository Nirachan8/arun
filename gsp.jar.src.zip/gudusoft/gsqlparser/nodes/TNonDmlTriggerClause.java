package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TNonDmlTriggerClause
  extends TParseTreeNode
{
  private TSourceToken a = null;
  private int b = 2;
  private boolean c = false;
  private boolean d = false;
  private TObjectName e;
  private TDummyList f;
  private TDummyList g;
  
  public int getFireMode()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TSourceToken)paramObject);
    if (this.a.toString().startsWith("after"))
    {
      this.b = 2;
      return;
    }
    if (this.a.toString().startsWith("before")) {
      this.b = 1;
    }
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    init(paramObject1);
    this.e = ((TObjectName)paramObject2);
  }
  
  public boolean isDatabase()
  {
    return this.d;
  }
  
  public void setDatabase(boolean paramBoolean)
  {
    this.d = paramBoolean;
  }
  
  public void setSchema(boolean paramBoolean)
  {
    this.c = paramBoolean;
  }
  
  public boolean isSchema()
  {
    return this.c;
  }
  
  public TObjectName getSchemaName()
  {
    return this.e;
  }
  
  public void setDatabase_event_list(TDummyList paramTDummyList)
  {
    this.g = paramTDummyList;
  }
  
  public void setDdl_event_list(TDummyList paramTDummyList)
  {
    this.f = paramTDummyList;
  }
  
  public TDummyList getDatabase_event_list()
  {
    return this.g;
  }
  
  public TDummyList getDdl_event_list()
  {
    return this.f;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TNonDmlTriggerClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */