package gudusoft.gsqlparser.nodes;

public class TDeclareSqlNode
  extends TParseTreeNode
{
  private TSelectSqlNode a = null;
  private TDeclareVariableList b = null;
  private TObjectName c = null;
  private int d = 1;
  private TObjectName e = null;
  private TStatementSqlNode f = null;
  
  public int getDeclareType()
  {
    return this.d;
  }
  
  public TObjectName getConditionName()
  {
    return this.e;
  }
  
  public TObjectName getCursorName()
  {
    return this.c;
  }
  
  public void setDeclareType(int paramInt)
  {
    this.d = paramInt;
  }
  
  public TDeclareVariableList getVariables()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    if ((paramObject2 instanceof TDeclareVariableList))
    {
      this.b = ((TDeclareVariableList)paramObject2);
      this.d = 1;
      return;
    }
    if ((paramObject2 instanceof TSelectSqlNode))
    {
      this.c = ((TObjectName)paramObject1);
      this.a = ((TSelectSqlNode)paramObject2);
      this.d = 2;
      return;
    }
    if ((paramObject2 instanceof TStatementSqlNode))
    {
      this.f = ((TStatementSqlNode)paramObject2);
      return;
    }
    if (paramObject1 != null) {
      this.e = ((TObjectName)paramObject1);
    }
  }
  
  public TSelectSqlNode getSelectSqlNode()
  {
    return this.a;
  }
  
  public TStatementSqlNode getStmtSqlNode()
  {
    return this.f;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDeclareSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */