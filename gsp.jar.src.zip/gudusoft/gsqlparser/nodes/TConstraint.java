package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EConstraintType;

public class TConstraint
  extends TParseTreeNode
{
  private EConstraintType a;
  private TObjectName b = null;
  private TPTNodeList<TKeyAction> c;
  private int d = 2;
  private TExpression e = null;
  private TObjectNameList f = null;
  private TExpression g = null;
  private TPTNodeList<TAutomaticProperty> h = null;
  private TObjectName i = null;
  private TObjectNameList j = null;
  private TExpression k;
  private TExpression l;
  
  public void setKeyActions(TPTNodeList<TKeyAction> paramTPTNodeList)
  {
    this.c = paramTPTNodeList;
  }
  
  public TPTNodeList<TKeyAction> getKeyActions()
  {
    return this.c;
  }
  
  public void setConstraintLevel(int paramInt)
  {
    this.d = paramInt;
  }
  
  public int getConstraintLevel()
  {
    return this.d;
  }
  
  public void setDefaultExpression(TExpression paramTExpression)
  {
    this.e = paramTExpression;
  }
  
  public TExpression getDefaultExpression()
  {
    return this.e;
  }
  
  public void setConstraintName(TObjectName paramTObjectName)
  {
    this.b = paramTObjectName;
  }
  
  public TObjectName getConstraintName()
  {
    return this.b;
  }
  
  public void setConstraint_type(EConstraintType paramEConstraintType)
  {
    this.a = paramEConstraintType;
  }
  
  public EConstraintType getConstraint_type()
  {
    return this.a;
  }
  
  public void setAutomaticProperties(TPTNodeList<TAutomaticProperty> paramTPTNodeList)
  {
    this.h = paramTPTNodeList;
  }
  
  public TPTNodeList<TAutomaticProperty> getAutomaticProperties()
  {
    return this.h;
  }
  
  public TExpression getCheckCondition()
  {
    return this.g;
  }
  
  public TObjectNameList getColumnList()
  {
    return this.f;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TExpression))
    {
      this.g = ((TExpression)paramObject);
      return;
    }
    if ((paramObject instanceof TObjectNameList)) {
      this.f = ((TObjectNameList)paramObject);
    }
  }
  
  public void setReferencedColumnList(TObjectNameList paramTObjectNameList)
  {
    this.j = paramTObjectNameList;
  }
  
  public TObjectNameList getReferencedColumnList()
  {
    return this.j;
  }
  
  public void setReferencedObject(TObjectName paramTObjectName)
  {
    this.i = paramTObjectName;
  }
  
  public TObjectName getReferencedObject()
  {
    return this.i;
  }
  
  public void setIncrement(TExpression paramTExpression)
  {
    this.l = paramTExpression;
  }
  
  public void setSeed(TExpression paramTExpression)
  {
    this.k = paramTExpression;
  }
  
  public TExpression getIncrement()
  {
    return this.l;
  }
  
  public TExpression getSeed()
  {
    return this.k;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TConstraint.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */