package gudusoft.gsqlparser.nodes;

public class TCallSpec
  extends TParseTreeNode
{
  public static final int lang_java = 1;
  public static final int lang_c = 2;
  private int a = 1;
  private TConstant b;
  
  public int getLang()
  {
    return this.a;
  }
  
  public TConstant getDeclaration()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    this.b = ((TConstant)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCallSpec.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */