package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TContainsTable
  extends TParseTreeNode
{
  public static final int containstable = 1;
  public static final int freetexttable = 2;
  private int a = 1;
  private TObjectName b = null;
  private TInExpr c = null;
  private TExpression d = null;
  
  public void setType(int paramInt)
  {
    this.a = paramInt;
  }
  
  public int getType()
  {
    return this.a;
  }
  
  public TInExpr getColumn_or_columnList()
  {
    return this.c;
  }
  
  public TExpression getContains_search_condition()
  {
    return this.d;
  }
  
  public TObjectName getTableName()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.b = ((TObjectName)paramObject1);
    this.c = ((TInExpr)paramObject2);
    this.d = ((TExpression)paramObject3);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    this.c.doParse(paramTCustomSqlStatement, paramESqlClause);
    this.d.doParse(paramTCustomSqlStatement, paramESqlClause);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TContainsTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */