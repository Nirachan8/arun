package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TLimitClause
  extends TParseTreeNode
{
  private TConstant a = null;
  private TConstant b = null;
  private TExpression c;
  private TExpression d;
  
  public void setSelectFetchFirstValue(TExpression paramTExpression)
  {
    this.d = paramTExpression;
  }
  
  public void setSelectLimitValue(TExpression paramTExpression)
  {
    this.c = paramTExpression;
  }
  
  public TExpression getSelectFetchFirstValue()
  {
    return this.d;
  }
  
  public TExpression getSelectLimitValue()
  {
    return this.c;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TConstant)paramObject1);
    this.b = ((TConstant)paramObject2);
  }
  
  public TConstant getOffset()
  {
    return this.a;
  }
  
  public TConstant getRow_count()
  {
    return this.b;
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause) {}
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TLimitClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */