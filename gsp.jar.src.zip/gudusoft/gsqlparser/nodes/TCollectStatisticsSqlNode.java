package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TCollectStatisticsSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TObjectName b = null;
  private TObjectName c = null;
  private TObjectNameList d = null;
  private TSourceToken e = null;
  
  public TSourceToken getColumn_or_index()
  {
    return this.e;
  }
  
  public TObjectNameList getColumnList()
  {
    return this.d;
  }
  
  public TObjectName getColumnName()
  {
    return this.b;
  }
  
  public TObjectName getIndexName()
  {
    return this.c;
  }
  
  public TObjectName getTableName()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.a = ((TObjectName)paramObject1);
    this.e = ((TSourceToken)paramObject2);
    if ((paramObject3 instanceof TObjectNameList))
    {
      this.d = ((TObjectNameList)paramObject3);
      return;
    }
    if (this.e.tokencode == 309)
    {
      this.c = ((TObjectName)paramObject3);
      return;
    }
    this.b = ((TObjectName)paramObject3);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCollectStatisticsSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */