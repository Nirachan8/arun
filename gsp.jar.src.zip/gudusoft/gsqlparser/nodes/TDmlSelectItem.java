package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TDmlSelectItem
  extends TNodeWithAliasClause
{
  public void init(Object paramObject1, Object paramObject2)
  {
    if (paramObject2 != null) {
      setAliasClause((TAliasClause)paramObject2);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause) {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDmlSelectItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */