package gudusoft.gsqlparser.nodes;

public class TDeclareVariableList
  extends TParseTreeNodeList
{
  public void addDeclareVariable(TDeclareVariable paramTDeclareVariable)
  {
    addElement(paramTDeclareVariable);
  }
  
  public TDeclareVariable getDeclareVariable(int paramInt)
  {
    if (paramInt < size()) {
      return (TDeclareVariable)elementAt(paramInt);
    }
    return null;
  }
  
  public void setTypeAndDefaultValueOfEachVariable(TTypeName paramTTypeName, TExpression paramTExpression)
  {
    for (int i = 0; i < size(); i++)
    {
      TDeclareVariable localTDeclareVariable;
      (localTDeclareVariable = getDeclareVariable(0)).setDatatype(paramTTypeName);
      localTDeclareVariable.setDefaultValue(paramTExpression);
    }
  }
  
  final void a(Object paramObject)
  {
    addDeclareVariable((TDeclareVariable)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDeclareVariableList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */