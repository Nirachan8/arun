package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TInformixOuterClause
  extends TParseTreeNode
{
  private TFromTable a = null;
  private TFromTableList b = null;
  private TTableList c;
  
  public void init(Object paramObject)
  {
    this.c = new TTableList();
    if ((paramObject instanceof TFromTable))
    {
      this.a = ((TFromTable)paramObject);
      return;
    }
    if ((paramObject instanceof TFromTableList)) {
      this.b = ((TFromTableList)paramObject);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null)
    {
      this.c.addTable(paramTCustomSqlStatement.analyzeFromTable(this.a));
      return;
    }
    if (this.b != null) {
      for (paramESqlClause = 0; paramESqlClause < this.b.size(); paramESqlClause++) {
        this.c.addTable(paramTCustomSqlStatement.analyzeFromTable(this.b.getFromTable(paramESqlClause)));
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TInformixOuterClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */