package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TDeleteSqlNode
  extends TParseTreeNode
{
  private TSourceToken a = null;
  private TTopClause b = null;
  private TFromTable c = null;
  private TWhereClause d = null;
  private TReturningClause e = null;
  public TCTEList cteList = null;
  private TOutputClause f = null;
  private TFromTableList g = null;
  private TFromTableList h = null;
  private TOrderBy i = null;
  private TLimitClause j = null;
  private TIsolationClause k = null;
  
  public void setDeleteToken(TSourceToken paramTSourceToken)
  {
    this.a = paramTSourceToken;
  }
  
  public TSourceToken getDeleteToken()
  {
    return this.a;
  }
  
  public TTopClause getTopClause()
  {
    return this.b;
  }
  
  public TFromTable getTargetTable()
  {
    return this.c;
  }
  
  public TReturningClause getReturningClause()
  {
    return this.e;
  }
  
  public TWhereClause getWhereCondition()
  {
    return this.d;
  }
  
  public void setReturningClause(TReturningClause paramTReturningClause)
  {
    this.e = paramTReturningClause;
  }
  
  public void setWhereCondition(TWhereClause paramTWhereClause)
  {
    this.d = paramTWhereClause;
  }
  
  public TOutputClause getOutputClause()
  {
    return this.f;
  }
  
  public void setOutputClause(TOutputClause paramTOutputClause)
  {
    this.f = paramTOutputClause;
  }
  
  public void setSourceTableList(TFromTableList paramTFromTableList)
  {
    this.g = paramTFromTableList;
  }
  
  public void setTargetTableByTableList(TFromTableList paramTFromTableList)
  {
    this.c = paramTFromTableList.getFromTable(0);
    if (paramTFromTableList.size() > 1)
    {
      this.g = new TFromTableList();
      for (int m = 1; m < paramTFromTableList.size(); m++) {
        this.g.addFromTable(paramTFromTableList.getFromTable(m));
      }
    }
  }
  
  public void setTargetTable(TFromTable paramTFromTable)
  {
    this.c = paramTFromTable;
  }
  
  public TFromTableList getSourceTableList()
  {
    return this.g;
  }
  
  public void setReferenceTableList(TFromTableList paramTFromTableList)
  {
    this.h = paramTFromTableList;
  }
  
  public TFromTableList getReferenceTableList()
  {
    return this.h;
  }
  
  public void setTopClause(TTopClause paramTTopClause)
  {
    this.b = paramTTopClause;
  }
  
  public void setOrderByClause(TOrderBy paramTOrderBy)
  {
    this.i = paramTOrderBy;
  }
  
  public TOrderBy getOrderByClause()
  {
    return this.i;
  }
  
  public void setLimitClause(TLimitClause paramTLimitClause)
  {
    this.j = paramTLimitClause;
  }
  
  public TLimitClause getLimitClause()
  {
    return this.j;
  }
  
  public void setIsolationClause(TIsolationClause paramTIsolationClause)
  {
    this.k = paramTIsolationClause;
  }
  
  public TIsolationClause getIsolationClause()
  {
    return this.k;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDeleteSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */