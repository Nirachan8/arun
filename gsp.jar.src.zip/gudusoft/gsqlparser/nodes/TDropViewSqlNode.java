package gudusoft.gsqlparser.nodes;

public class TDropViewSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TObjectNameList b = null;
  
  public TObjectName getViewName()
  {
    return this.a;
  }
  
  public TObjectNameList getViewNameList()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TObjectName))
    {
      this.a = ((TObjectName)paramObject);
      this.a.setObjectType(18);
      return;
    }
    if ((paramObject instanceof TObjectNameList))
    {
      this.b = ((TObjectNameList)paramObject);
      for (paramObject = 0; paramObject < this.b.size(); paramObject++) {
        this.b.getObjectName(paramObject).setObjectType(18);
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDropViewSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */