package gudusoft.gsqlparser.nodes;

public class TLoopSqlNode
  extends TParseTreeNode
{
  private TStatementListSqlNode a = null;
  
  public TStatementListSqlNode getStmts()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TStatementListSqlNode)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TLoopSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */