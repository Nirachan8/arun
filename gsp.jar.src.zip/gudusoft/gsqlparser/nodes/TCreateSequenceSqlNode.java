package gudusoft.gsqlparser.nodes;

public class TCreateSequenceSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TDummyList b = null;
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TObjectName)paramObject1);
    this.a.setObjectType(29);
    this.b = ((TDummyList)paramObject2);
  }
  
  public TDummyList getOptions()
  {
    return this.b;
  }
  
  public TObjectName getSequenceName()
  {
    return this.a;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCreateSequenceSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */