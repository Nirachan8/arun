package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

/**
 * @deprecated
 */
public class TInExpr
  extends TParseTreeNode
{
  private TSelectSqlNode a = null;
  private TSelectSqlStatement b = null;
  private TGroupingExpressionItemList c = null;
  private TExpression d = null;
  private TExpressionList e = null;
  
  public TExpressionList getExprList()
  {
    return this.e;
  }
  
  public TExpression getFunc_expr()
  {
    return this.d;
  }
  
  public TGroupingExpressionItemList getGroupingExpressionItemList()
  {
    return this.c;
  }
  
  public TSelectSqlStatement getSubQuery()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TSelectSqlNode))
    {
      this.a = ((TSelectSqlNode)paramObject);
      return;
    }
    if ((paramObject instanceof TGroupingExpressionItemList))
    {
      this.c = ((TGroupingExpressionItemList)paramObject);
      return;
    }
    if (!(paramObject instanceof TObjectName))
    {
      if ((paramObject instanceof TExpression))
      {
        this.d = ((TExpression)paramObject);
        return;
      }
      if ((paramObject instanceof TExpressionList)) {
        this.e = ((TExpressionList)paramObject);
      }
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null)
    {
      if (this.b == null)
      {
        this.b = new TSelectSqlStatement(paramTCustomSqlStatement.dbvendor);
        this.b.rootNode = this.a;
      }
      this.b.doParseStatement(paramTCustomSqlStatement);
      return;
    }
    if (this.c != null)
    {
      this.c.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    }
    if (this.d != null)
    {
      this.d.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    }
    if (this.e != null) {
      this.e.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    if (this.b != null) {
      this.b.accept(paramTParseTreeVisitor);
    }
    if (getGroupingExpressionItemList() != null) {
      getGroupingExpressionItemList().accept(paramTParseTreeVisitor);
    }
    if (this.d != null) {
      this.d.accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TInExpr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */