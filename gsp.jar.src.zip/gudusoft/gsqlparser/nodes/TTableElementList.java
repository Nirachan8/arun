package gudusoft.gsqlparser.nodes;

public class TTableElementList
  extends TParseTreeNodeList
{
  public void addTableElement(TTableElement paramTTableElement)
  {
    addElement(paramTTableElement);
  }
  
  public TTableElement getTableElement(int paramInt)
  {
    if (paramInt < size()) {
      return (TTableElement)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addTableElement((TTableElement)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTableElementList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */