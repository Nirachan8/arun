package gudusoft.gsqlparser.nodes;

public class TTriggerAction
  extends TParseTreeNode
{
  private TExpression a = null;
  private TStatementSqlNode b = null;
  private TCompoundSqlNode c = null;
  
  public TCompoundSqlNode getCompoundSqlNode()
  {
    return this.c;
  }
  
  public TStatementSqlNode getStmtNode()
  {
    return this.b;
  }
  
  public TExpression getWhenExpr()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    if (paramObject1 != null) {
      this.a = ((TExpression)((TDummy)paramObject1).node1);
    }
    if ((paramObject2 instanceof TStatementSqlNode))
    {
      this.b = ((TStatementSqlNode)paramObject2);
      return;
    }
    if ((paramObject2 instanceof TCompoundSqlNode)) {
      this.c = ((TCompoundSqlNode)paramObject2);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTriggerAction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */