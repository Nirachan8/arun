package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EKeyActionType;

public class TKeyAction
  extends TParseTreeNode
{
  private EKeyActionType a;
  private TKeyReference b;
  
  public void setKeyReference(TKeyReference paramTKeyReference)
  {
    this.b = paramTKeyReference;
  }
  
  public TKeyReference getKeyReference()
  {
    return this.b;
  }
  
  public EKeyActionType getActionType()
  {
    return this.a;
  }
  
  public void setActionType(EKeyActionType paramEKeyActionType)
  {
    this.a = paramEKeyActionType;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TKeyAction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */