package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ETableSource;

public class TCreateTriggerSqlNode
  extends TParseTreeNode
{
  private TStatementListSqlNode a = null;
  private TObjectName b = null;
  private TTable c = null;
  private TExpression d = null;
  private int e = 0;
  private TBlockSqlNode f = null;
  private TDummyList g = null;
  private TParseTreeNode h = null;
  private TStatementSqlNode i = null;
  private TTriggerAction j = null;
  
  public void setBlcok(TBlockSqlNode paramTBlockSqlNode)
  {
    this.f = paramTBlockSqlNode;
  }
  
  public TBlockSqlNode getBlcok()
  {
    return this.f;
  }
  
  public void setDmlTpyes(TDummyList paramTDummyList)
  {
    this.g = paramTDummyList;
  }
  
  public TDummyList getDmlTpyes()
  {
    return this.g;
  }
  
  public void setFireMode(int paramInt)
  {
    this.e = paramInt;
  }
  
  public int getFireMode()
  {
    return this.e;
  }
  
  public TObjectName getTriggerName()
  {
    return this.b;
  }
  
  public void setTrigger_event_clause(TParseTreeNode paramTParseTreeNode)
  {
    this.h = paramTParseTreeNode;
  }
  
  public TParseTreeNode getTrigger_event_clause()
  {
    return this.h;
  }
  
  public void setWhenCondition(TExpression paramTExpression)
  {
    this.d = paramTExpression;
  }
  
  public TExpression getWhenCondition()
  {
    return this.d;
  }
  
  public TStatementSqlNode getStmt()
  {
    return this.i;
  }
  
  public void setStmt(TStatementSqlNode paramTStatementSqlNode)
  {
    this.i = paramTStatementSqlNode;
  }
  
  public TTable getOnTable()
  {
    return this.c;
  }
  
  public TStatementListSqlNode getStmts()
  {
    return this.a;
  }
  
  public void setStmts(TStatementListSqlNode paramTStatementListSqlNode)
  {
    this.a = paramTStatementListSqlNode;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.b = ((TObjectName)paramObject1);
    this.b.setObjectType(24);
    this.c = new TTable();
    ((TObjectName)paramObject2).setObjectType(3);
    this.c.setTableName((TObjectName)paramObject2);
    this.c.setTableType(ETableSource.objectname);
  }
  
  public void init(Object paramObject)
  {
    this.b = ((TObjectName)paramObject);
    this.b.setObjectType(24);
  }
  
  public TTriggerAction getTriggerAction()
  {
    return this.j;
  }
  
  public void setTriggerAction(TTriggerAction paramTTriggerAction)
  {
    this.j = paramTTriggerAction;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCreateTriggerSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */