package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TTeradataWithClause
  extends TParseTreeNode
{
  private TTeradataWithClauseItemList a = null;
  
  public void init(Object paramObject)
  {
    this.a = ((TTeradataWithClauseItemList)paramObject);
  }
  
  public TTeradataWithClauseItemList getItems()
  {
    return this.a;
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTeradataWithClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */