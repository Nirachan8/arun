package gudusoft.gsqlparser.nodes;

public class TOutputFormatPhraseList
  extends TParseTreeNodeList
{
  public void addOutputFormatPhrase(TOutputFormatPhrase paramTOutputFormatPhrase)
  {
    addElement(paramTOutputFormatPhrase);
  }
  
  public TOutputFormatPhrase getOutputFormatPhrase(int paramInt)
  {
    if (paramInt < size()) {
      return (TOutputFormatPhrase)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addOutputFormatPhrase((TOutputFormatPhrase)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TOutputFormatPhraseList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */