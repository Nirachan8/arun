package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TResultColumnList
  extends TParseTreeNodeList
{
  public void removeResultColumn(int paramInt)
  {
    TSourceToken localTSourceToken = null;
    if (size() > 1) {
      if (paramInt != size() - 1) {
        localTSourceToken = getResultColumn(paramInt).getEndToken().searchToken(",", 1);
      } else {
        localTSourceToken = getResultColumn(paramInt).getStartToken().searchToken(",", -1);
      }
    }
    getResultColumn(paramInt).removeAllMyTokensFromTokenList(localTSourceToken);
    a(paramInt);
  }
  
  public void addResultColumn(String paramString)
  {
    if (size() == 0) {
      return;
    }
    TResultColumn localTResultColumn;
    (localTResultColumn = new TResultColumn()).setGsqlparser(getGsqlparser());
    localTResultColumn.setString("," + paramString);
    paramString = (paramString = getResultColumn(size() - 1)).getEndToken();
    localTResultColumn.addAllMyTokensToTokenList(paramString.container, paramString.posinlist + 1);
    for (int i = 0; i < paramString.getNodesEndWithThisToken().size(); i++)
    {
      TParseTreeNode localTParseTreeNode;
      if (!((localTParseTreeNode = paramString.getNodesEndWithThisToken().getElement(i)) instanceof TResultColumn)) {
        localTParseTreeNode.setEndToken(localTResultColumn.getEndToken());
      }
    }
  }
  
  public void addResultColumn(TResultColumn paramTResultColumn)
  {
    addElement(paramTResultColumn);
  }
  
  public TResultColumn getResultColumn(int paramInt)
  {
    if (paramInt < size()) {
      return (TResultColumn)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addResultColumn((TResultColumn)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      getResultColumn(i).accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
  
  public TSourceToken getStartToken()
  {
    TSourceToken localTSourceToken = null;
    for (int i = 0; (i < size()) && ((localTSourceToken = getResultColumn(i).getStartToken()) == null); i++) {}
    return localTSourceToken;
  }
  
  public TSourceToken getEndToken()
  {
    TSourceToken localTSourceToken = null;
    for (int i = size() - 1; (i >= 0) && ((localTSourceToken = getResultColumn(i).getEndToken()) == null); i--) {}
    return localTSourceToken;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TResultColumnList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */