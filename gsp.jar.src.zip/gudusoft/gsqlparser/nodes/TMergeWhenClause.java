package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TMergeWhenClause
  extends TParseTreeNode
{
  public static final int matched = 1;
  public static final int not_matched = 2;
  public static final int matched_with_condition = 3;
  public static final int not_matched_with_condition = 4;
  public static final int not_matched_by_target = 5;
  public static final int not_matched_by_target_with_condition = 6;
  public static final int not_matched_by_source = 7;
  public static final int not_matched_by_source_with_condition = 8;
  private int a = 1;
  private TExpression b;
  private TMergeUpdateClause c;
  private TMergeInsertClause d;
  private TMergeDeleteClause e;
  
  public void setCondition(TExpression paramTExpression)
  {
    this.b = paramTExpression;
  }
  
  private void a(TDummy paramTDummy)
  {
    this.a = paramTDummy.int1;
    if ((this.a == 3) || (this.a == 4)) {
      this.b = ((TExpression)paramTDummy.node1);
    }
  }
  
  public int getType()
  {
    return this.a;
  }
  
  public TExpression getCondition()
  {
    return this.b;
  }
  
  public TMergeUpdateClause getUpdateClause()
  {
    return this.c;
  }
  
  public TMergeDeleteClause getDeleteClause()
  {
    return this.e;
  }
  
  public TMergeInsertClause getInsertClause()
  {
    return this.d;
  }
  
  public void setType(int paramInt)
  {
    this.a = paramInt;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    if (paramObject1 != null) {
      a((TDummy)paramObject1);
    }
    if (paramObject2 != null)
    {
      if ((paramObject2 instanceof TMergeUpdateClause))
      {
        this.c = ((TMergeUpdateClause)paramObject2);
        return;
      }
      if ((paramObject2 instanceof TMergeInsertClause))
      {
        this.d = ((TMergeInsertClause)paramObject2);
        return;
      }
      if ((paramObject2 instanceof TMergeDeleteClause)) {
        this.e = ((TMergeDeleteClause)paramObject2);
      }
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if (this.c != null) {
      this.c.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if (this.d != null) {
      this.d.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if (this.e != null) {
      this.e.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TMergeWhenClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */