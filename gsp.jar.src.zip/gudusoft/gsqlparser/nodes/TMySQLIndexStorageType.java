package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TMySQLIndexStorageType
  extends TParseTreeNode
{
  private TSourceToken a;
  
  public TSourceToken getTypeToken()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TSourceToken)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TMySQLIndexStorageType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */