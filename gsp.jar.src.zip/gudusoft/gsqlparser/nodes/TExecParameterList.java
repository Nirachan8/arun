package gudusoft.gsqlparser.nodes;

public class TExecParameterList
  extends TParseTreeNodeList
{
  public void addExecParameter(TExecParameter paramTExecParameter)
  {
    addElement(paramTExecParameter);
  }
  
  public TExecParameter getExecParameter(int paramInt)
  {
    if (paramInt < size()) {
      return (TExecParameter)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addExecParameter((TExecParameter)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TExecParameterList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */