package gudusoft.gsqlparser.nodes;

public class TCreateRowTypeSqlNode
  extends TParseTreeNode
{
  private TObjectName a;
  private TColumnDefinitionList b;
  private TObjectName c;
  
  public TColumnDefinitionList getColumnList()
  {
    return this.b;
  }
  
  public void setSuperTableName(TObjectName paramTObjectName)
  {
    this.c = paramTObjectName;
  }
  
  public TObjectName getRowTypeName()
  {
    return this.a;
  }
  
  public TObjectName getSuperTableName()
  {
    return this.c;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TObjectName)paramObject1);
    if (paramObject2 != null) {
      this.b = ((TColumnDefinitionList)paramObject2);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCreateRowTypeSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */