package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TTeradataWithClauseItem
  extends TParseTreeNode
{
  private TExpressionList a = null;
  private TOrderByItemList b = null;
  
  public TOrderByItemList getByItemList()
  {
    return this.b;
  }
  
  public TExpressionList getExprList()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TExpressionList)paramObject1);
    if (paramObject2 != null) {
      this.b = ((TOrderByItemList)paramObject2);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null) {
      this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTeradataWithClauseItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */