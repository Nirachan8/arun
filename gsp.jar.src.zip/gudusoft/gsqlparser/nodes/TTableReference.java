package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TTableReference
  extends TParseTreeNode
{
  public TObjectName objectname;
  public TSourceToken sourcetoken;
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TObjectName))
    {
      this.objectname = ((TObjectName)paramObject);
      this.objectname.setObjectType(3);
      return;
    }
    if ((paramObject instanceof TSourceToken)) {
      this.sourcetoken = ((TSourceToken)paramObject);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTableReference.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */