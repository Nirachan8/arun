package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EIndexType;
import gudusoft.gsqlparser.TSourceToken;

public class TCreateIndexSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private EIndexType b = EIndexType.itNormal;
  private TObjectName c = null;
  private TOrderByItemList d = null;
  
  public TOrderByItemList getColumnNameList()
  {
    return this.d;
  }
  
  public void setColumnNameList(TOrderByItemList paramTOrderByItemList)
  {
    this.d = paramTOrderByItemList;
  }
  
  public void setTableName(TObjectName paramTObjectName)
  {
    this.c = paramTObjectName;
  }
  
  public TObjectName getTableName()
  {
    return this.c;
  }
  
  public void setIndexTypeViaToken(TSourceToken paramTSourceToken)
  {
    if (paramTSourceToken == null) {
      return;
    }
    switch (paramTSourceToken.tokencode)
    {
    case 514: 
      this.b = EIndexType.itUnique;
      return;
    }
    if (paramTSourceToken.toString().equalsIgnoreCase("bitmap"))
    {
      this.b = EIndexType.itBitMap;
      return;
    }
    if (paramTSourceToken.toString().equalsIgnoreCase("fulltext"))
    {
      this.b = EIndexType.itFulltext;
      return;
    }
    if (paramTSourceToken.toString().equalsIgnoreCase("spatial")) {
      this.b = EIndexType.itSpatial;
    }
  }
  
  public EIndexType getIndexType()
  {
    return this.b;
  }
  
  public TObjectName getIndexName()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    if (paramObject != null)
    {
      this.a = ((TObjectName)paramObject);
      this.a.setObjectType(15);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCreateIndexSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */