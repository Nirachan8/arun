package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class THierarchical
  extends TParseTreeNode
{
  private boolean a;
  private TExpression b = null;
  private TExpression c = null;
  
  public void setNoCycle(boolean paramBoolean)
  {
    this.a = paramBoolean;
  }
  
  public boolean isNoCycle()
  {
    return this.a;
  }
  
  public TExpression getStartWithClause()
  {
    return this.c;
  }
  
  public TExpression getConnectByClause()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.b = ((TExpression)paramObject1);
    this.c = ((TExpression)paramObject2);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, ESqlClause.hierarchical);
    }
    if (this.c != null) {
      this.c.doParse(paramTCustomSqlStatement, ESqlClause.hierarchical);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\THierarchical.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */