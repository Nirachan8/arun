package gudusoft.gsqlparser.nodes;

public class TTeradataWithClauseItemList
  extends TParseTreeNodeList
{
  public void addWithClauseItem(TTeradataWithClauseItem paramTTeradataWithClauseItem)
  {
    addElement(paramTTeradataWithClauseItem);
  }
  
  public TTeradataWithClauseItem getWithClauseItem(int paramInt)
  {
    if (paramInt < size()) {
      return (TTeradataWithClauseItem)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addWithClauseItem((TTeradataWithClauseItem)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTeradataWithClauseItemList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */