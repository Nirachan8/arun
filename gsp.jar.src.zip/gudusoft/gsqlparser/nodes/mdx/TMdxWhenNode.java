package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxWhenNode
  extends TMdxExpNode
{
  private TMdxExpNode a;
  private TMdxExpNode b;
  
  public EMdxDataType getMdxDataType()
  {
    return EMdxDataType.Unknown;
  }
  
  public TMdxExpNode getWhenExpr()
  {
    return this.a;
  }
  
  public TMdxExpNode getThenExpr()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TMdxExpNode)paramObject1);
    this.b = ((TMdxExpNode)paramObject2);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.a.accept(paramTParseTreeVisitor);
    this.b.accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxWhenNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */