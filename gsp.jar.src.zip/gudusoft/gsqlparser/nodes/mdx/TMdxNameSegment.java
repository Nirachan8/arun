package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TMdxNameSegment
  extends TParseTreeNode
  implements IMdxIdentifierSegment
{
  private String a;
  private EMdxQuoting b;
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TSourceToken)paramObject1).toString();
    this.b = ((EMdxQuoting)paramObject2);
    if (paramObject1 == null) {
      throw new NullPointerException();
    }
    if ((paramObject2 != EMdxQuoting.QUOTED) && (paramObject2 != EMdxQuoting.UNQUOTED)) {
      throw new IllegalArgumentException();
    }
    setStartToken((TSourceToken)paramObject1);
    setEndToken((TSourceToken)paramObject1);
  }
  
  public void init(Object paramObject)
  {
    init(paramObject, EMdxQuoting.QUOTED);
  }
  
  public String getName()
  {
    return this.a;
  }
  
  public EMdxQuoting getQuoting()
  {
    return this.b;
  }
  
  public TPTNodeList<TMdxNameSegment> getKeyParts()
  {
    return null;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxNameSegment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */