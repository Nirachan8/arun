package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TMdxObjectNode
  extends TParseTreeNode
{
  private TMdxIdentifierNode a;
  private TMdxIdentifierNode b;
  
  public TMdxIdentifierNode getAsObjectName()
  {
    return this.b;
  }
  
  public TMdxIdentifierNode getObjectName()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TMdxIdentifierNode)paramObject1);
    this.b = ((TMdxIdentifierNode)paramObject2);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxObjectNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */