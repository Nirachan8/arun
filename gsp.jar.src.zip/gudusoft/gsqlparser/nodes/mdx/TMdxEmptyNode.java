package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxEmptyNode
  extends TMdxExpNode
{
  public EMdxDataType getMdxDataType()
  {
    return EMdxDataType.Unknown;
  }
  
  public String toString()
  {
    return "";
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxEmptyNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */