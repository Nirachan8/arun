package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TMdxKeySegment
  extends TParseTreeNode
  implements IMdxIdentifierSegment
{
  private TPTNodeList<TMdxNameSegment> a;
  
  public void init(Object paramObject)
  {
    this.a = ((TPTNodeList)paramObject);
    setStartToken(((TPTNodeList)paramObject).getStartToken());
    setEndToken(((TPTNodeList)paramObject).getEndToken());
  }
  
  public EMdxQuoting getQuoting()
  {
    return EMdxQuoting.KEY;
  }
  
  public String getName()
  {
    return toString();
  }
  
  public TPTNodeList<TMdxNameSegment> getKeyParts()
  {
    return this.a;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxKeySegment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */