package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxLevelContentNode
  extends TParseTreeNode
{
  private TPTNodeList<TMdxIdentifierNode> a;
  
  public void init(Object paramObject)
  {
    this.a = ((TPTNodeList)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    if (this.a != null) {
      this.a.accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxLevelContentNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */