package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxWhereNode
  extends TParseTreeNode
{
  private TMdxExpNode a;
  
  public TMdxExpNode getFilter()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TMdxExpNode)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.a.accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxWhereNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */