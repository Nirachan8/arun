package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TMdxCreateSetNode
  extends TParseTreeNode
{
  private TMdxWithSetNode a;
  
  public TMdxWithSetNode getWithSetNode()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TMdxWithSetNode)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxCreateSetNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */