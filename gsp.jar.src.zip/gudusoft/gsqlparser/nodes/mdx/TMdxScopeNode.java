package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TMdxScopeNode
  extends TParseTreeNode
{
  private TPTNodeList<TMdxExpNode> a;
  private TPTNodeList<TParseTreeNode> b;
  
  public TPTNodeList<TMdxExpNode> getExprList()
  {
    return this.a;
  }
  
  public TPTNodeList<TParseTreeNode> getStatementList()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TPTNodeList)paramObject);
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TPTNodeList)paramObject1);
    this.b = ((TPTNodeList)paramObject2);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxScopeNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */