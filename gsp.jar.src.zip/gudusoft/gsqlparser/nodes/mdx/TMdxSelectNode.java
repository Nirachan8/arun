package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TMdxSelectNode
  extends TParseTreeNode
{
  private TPTNodeList<TMdxWithNode> a;
  private TPTNodeList<TMdxAxisNode> b;
  private TMdxIdentifierNode c;
  private TMdxSelectNode d;
  private TMdxWhereNode e;
  private TPTNodeList<TMdxExpNode> f;
  
  public TPTNodeList<TMdxAxisNode> getAxes()
  {
    return this.b;
  }
  
  public TPTNodeList<TMdxExpNode> getCellProps()
  {
    return this.f;
  }
  
  public TMdxIdentifierNode getCube()
  {
    return this.c;
  }
  
  public TMdxSelectNode getSubQuery()
  {
    return this.d;
  }
  
  public TMdxWhereNode getWhere()
  {
    return this.e;
  }
  
  public TPTNodeList<TMdxWithNode> getWiths()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6)
  {
    this.a = ((TPTNodeList)paramObject1);
    this.b = ((TPTNodeList)paramObject2);
    this.c = ((TMdxIdentifierNode)paramObject3);
    this.d = ((TMdxSelectNode)paramObject4);
    this.e = ((TMdxWhereNode)paramObject5);
    this.f = ((TPTNodeList)paramObject6);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxSelectNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */