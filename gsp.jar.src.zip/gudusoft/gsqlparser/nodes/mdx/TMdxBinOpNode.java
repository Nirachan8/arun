package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxBinOpNode
  extends TMdxExpNode
{
  private TSourceToken a;
  private TMdxExpNode b;
  private TMdxExpNode c;
  
  public EMdxDataType getMdxDataType()
  {
    return EMdxDataType.Unknown;
  }
  
  public TMdxExpNode getLeftExprNode()
  {
    return this.b;
  }
  
  public TSourceToken getOperator()
  {
    return this.a;
  }
  
  public TMdxExpNode getRightExprNode()
  {
    return this.c;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.a = ((TSourceToken)paramObject1);
    this.b = ((TMdxExpNode)paramObject2);
    this.c = ((TMdxExpNode)paramObject3);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.b.accept(paramTParseTreeVisitor);
    this.c.accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxBinOpNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */