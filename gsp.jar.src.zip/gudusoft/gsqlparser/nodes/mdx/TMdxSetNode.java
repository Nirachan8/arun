package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxSetNode
  extends TMdxExpNode
{
  private TPTNodeList<TMdxExpNode> a;
  
  public EMdxDataType getMdxDataType()
  {
    return EMdxDataType.Set;
  }
  
  public TPTNodeList<TMdxExpNode> getTupleList()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TPTNodeList)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.a.accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxSetNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */