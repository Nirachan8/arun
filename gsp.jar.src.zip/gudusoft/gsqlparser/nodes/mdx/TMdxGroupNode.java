package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxGroupNode
  extends TMdxObjectNode
{
  private TPTNodeList<TMdxObjectNode> a;
  
  public void init(Object paramObject1, Object paramObject2)
  {
    super.init(paramObject1, null);
    this.a = ((TPTNodeList)paramObject2);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.a.accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxGroupNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */