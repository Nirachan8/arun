package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TDummy;
import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxAxisNode
  extends TMdxExpNode
{
  private TMdxNonEmptyNode a;
  private TPTNodeList<TMdxIdentifierNode> b;
  private TMdxExpNode c;
  private TSourceToken d;
  
  public EMdxDataType getMdxDataType()
  {
    return EMdxDataType.Unknown;
  }
  
  public TPTNodeList<TMdxIdentifierNode> getDimensionProperties()
  {
    return this.b;
  }
  
  public TMdxExpNode getExpNode()
  {
    return this.c;
  }
  
  public TSourceToken getName_OR_Number()
  {
    return this.d;
  }
  
  public TMdxNonEmptyNode getNonEmptyNode()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4)
  {
    this.a = ((TMdxNonEmptyNode)paramObject1);
    this.c = ((TMdxExpNode)paramObject2);
    if ((paramObject3 != null) && ((paramObject3 instanceof TDummy))) {
      this.b = ((TPTNodeList)((TDummy)paramObject3).node1);
    }
    this.d = ((TSourceToken)paramObject4);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.c.accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxAxisNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */