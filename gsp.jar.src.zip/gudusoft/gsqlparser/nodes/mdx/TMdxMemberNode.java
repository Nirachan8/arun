package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxMemberNode
  extends TMdxObjectNode
{
  public void init(Object paramObject1, Object paramObject2)
  {
    super.init(paramObject1, paramObject2);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxMemberNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */