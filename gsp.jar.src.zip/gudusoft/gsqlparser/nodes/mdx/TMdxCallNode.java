package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TMdxCallNode
  extends TParseTreeNode
{
  private TMdxIdentifierNode a;
  private TPTNodeList<TMdxExpNode> b;
  
  public TPTNodeList<TMdxExpNode> getArgs()
  {
    return this.b;
  }
  
  public TMdxIdentifierNode getSpName()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TMdxIdentifierNode)paramObject1);
    this.b = ((TPTNodeList)paramObject2);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxCallNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */