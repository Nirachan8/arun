package gudusoft.gsqlparser.nodes.mdx;

public enum EMdxConstruct
{
  private EMdxConstruct() {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\EMdxConstruct.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */