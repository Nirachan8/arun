package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxCalcPropNode
  extends TParseTreeNode
{
  private TMdxIdentifierNode a;
  private TMdxExpNode b;
  
  public EMdxDataType getMdxDataType()
  {
    return EMdxDataType.Unknown;
  }
  
  public TMdxExpNode getPropExpr()
  {
    return this.b;
  }
  
  public TMdxIdentifierNode getPropName()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TMdxIdentifierNode)paramObject1);
    this.b = ((TMdxExpNode)paramObject2);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.b.accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxCalcPropNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */