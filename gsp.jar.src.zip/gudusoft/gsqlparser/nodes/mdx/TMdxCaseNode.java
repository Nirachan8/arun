package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxCaseNode
  extends TMdxExpNode
{
  private TMdxExpNode a;
  private TPTNodeList<TMdxExpNode> b;
  private TMdxExpNode c;
  
  public EMdxDataType getMdxDataType()
  {
    return EMdxDataType.Unknown;
  }
  
  public TMdxExpNode getCondition()
  {
    return this.a;
  }
  
  public TMdxExpNode getElseExpr()
  {
    return this.c;
  }
  
  public TPTNodeList<TMdxExpNode> getWhenList()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.a = ((TMdxExpNode)paramObject1);
    this.b = ((TPTNodeList)paramObject2);
    this.c = ((TMdxExpNode)paramObject3);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    if (this.a != null) {
      this.a.accept(paramTParseTreeVisitor);
    }
    if (this.b != null) {
      this.b.accept(paramTParseTreeVisitor);
    }
    if (this.c != null) {
      this.c.accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxCaseNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */