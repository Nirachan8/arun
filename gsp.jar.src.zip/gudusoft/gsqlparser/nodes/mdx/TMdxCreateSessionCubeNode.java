package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TMdxCreateSessionCubeNode
  extends TParseTreeNode
{
  private TMdxIdentifierNode a;
  private TPTNodeList<TMdxIdentifierNode> b;
  private TPTNodeList<TMdxObjectNode> c;
  
  public TPTNodeList<TMdxIdentifierNode> getCubeList()
  {
    return this.b;
  }
  
  public TMdxIdentifierNode getCubeName()
  {
    return this.a;
  }
  
  public TPTNodeList<TMdxObjectNode> getParamList()
  {
    return this.c;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.a = ((TMdxIdentifierNode)paramObject1);
    this.b = ((TPTNodeList)paramObject2);
    this.c = ((TPTNodeList)paramObject3);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxCreateSessionCubeNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */