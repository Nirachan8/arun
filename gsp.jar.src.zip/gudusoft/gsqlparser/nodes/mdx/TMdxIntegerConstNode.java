package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxIntegerConstNode
  extends TMdxConstNode
{
  private TSourceToken a;
  
  public void init(Object paramObject)
  {
    this.a = ((TSourceToken)paramObject);
  }
  
  public TSourceToken getIntToken()
  {
    return this.a;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxIntegerConstNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */