package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxIdentifierNode
  extends TMdxExpNode
{
  private final TPTNodeList<IMdxIdentifierSegment> a = new TPTNodeList();
  
  public EMdxDataType getMdxDataType()
  {
    return EMdxDataType.Member;
  }
  
  public TPTNodeList<IMdxIdentifierSegment> getSegments()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a.addElement((IMdxIdentifierSegment)paramObject);
    setStartToken(this.a.getStartToken());
    setEndToken(this.a.getEndToken());
  }
  
  public TPTNodeList<IMdxIdentifierSegment> getSegmentList()
  {
    return this.a;
  }
  
  public void add(IMdxIdentifierSegment paramIMdxIdentifierSegment)
  {
    this.a.addElement(paramIMdxIdentifierSegment);
  }
  
  public void insertAt(IMdxIdentifierSegment paramIMdxIdentifierSegment, int paramInt)
  {
    this.a.insertElementAt(paramIMdxIdentifierSegment, paramInt);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxIdentifierNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */