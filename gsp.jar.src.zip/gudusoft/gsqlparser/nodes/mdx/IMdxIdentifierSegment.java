package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;

public abstract interface IMdxIdentifierSegment
{
  public abstract EMdxQuoting getQuoting();
  
  public abstract String getName();
  
  public abstract TPTNodeList<TMdxNameSegment> getKeyParts();
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\IMdxIdentifierSegment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */