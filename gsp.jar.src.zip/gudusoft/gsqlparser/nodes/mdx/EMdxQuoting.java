package gudusoft.gsqlparser.nodes.mdx;

public enum EMdxQuoting
{
  private EMdxQuoting() {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\EMdxQuoting.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */