package gudusoft.gsqlparser.nodes.mdx;

public abstract class TMdxBaseFunctionNode
  extends TMdxExpNode
{}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxBaseFunctionNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */