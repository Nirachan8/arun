package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxUnaryOpNode
  extends TMdxExpNode
{
  private TSourceToken a;
  private TMdxExpNode b;
  
  public EMdxDataType getMdxDataType()
  {
    return EMdxDataType.Unknown;
  }
  
  public TMdxExpNode getExpNode()
  {
    return this.b;
  }
  
  public TSourceToken getOperator()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TSourceToken)paramObject1);
    this.b = ((TMdxExpNode)paramObject2);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.b.accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxUnaryOpNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */