package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxDimensionNode
  extends TMdxObjectNode
{
  private TMdxIdentifierNode a;
  private TMdxDimContentNode b;
  
  public TMdxDimContentNode getDimensionContentNode()
  {
    return this.b;
  }
  
  public TMdxIdentifierNode getFromDimensionName()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4)
  {
    super.init(paramObject1, paramObject2);
    this.a = ((TMdxIdentifierNode)paramObject3);
    this.b = ((TMdxDimContentNode)paramObject4);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxDimensionNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */