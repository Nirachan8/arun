package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxFunctionNode
  extends TMdxBaseFunctionNode
{
  private TPTNodeList<TMdxExpNode> a;
  private IMdxIdentifierSegment b;
  private EMdxExpSyntax c;
  
  public void TMdxFunctionNode()
  {
    this.a = new TPTNodeList();
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.a = ((TPTNodeList)paramObject1);
    this.b = ((IMdxIdentifierSegment)paramObject2);
    this.c = ((EMdxExpSyntax)paramObject3);
  }
  
  public String getFunctionName()
  {
    return this.b.getName();
  }
  
  public IMdxIdentifierSegment getFunctionSegment()
  {
    return this.b;
  }
  
  public TPTNodeList<TMdxExpNode> getArguments()
  {
    return this.a;
  }
  
  public EMdxDataType getMdxDataType()
  {
    return EMdxDataType.Unknown;
  }
  
  public EMdxExpSyntax getExpSyntax()
  {
    return this.c;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    if (this.a != null) {
      this.a.accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxFunctionNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */