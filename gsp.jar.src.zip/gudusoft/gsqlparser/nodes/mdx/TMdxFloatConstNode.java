package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxFloatConstNode
  extends TMdxConstNode
{
  private TSourceToken a;
  
  public void init(Object paramObject)
  {
    this.a = ((TSourceToken)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
  
  public TSourceToken getDoubleToken()
  {
    return this.a;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxFloatConstNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */