package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TMdxCreateSubCubeNode
  extends TParseTreeNode
{
  private TMdxIdentifierNode a;
  private TMdxSelectNode b;
  
  public TMdxIdentifierNode getCubeName()
  {
    return this.a;
  }
  
  public TMdxSelectNode getSelectNode()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TMdxIdentifierNode)paramObject1);
    this.b = ((TMdxSelectNode)paramObject2);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxCreateSubCubeNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */