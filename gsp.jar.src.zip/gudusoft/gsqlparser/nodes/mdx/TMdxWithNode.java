package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxWithNode
  extends TParseTreeNode
{
  private TMdxIdentifierNode a;
  private TMdxExpNode b;
  private TPTNodeList<TMdxCalcPropNode> c;
  
  public TPTNodeList<TMdxCalcPropNode> getCalcProps()
  {
    return this.c;
  }
  
  public TMdxExpNode getExprNode()
  {
    return this.b;
  }
  
  public TMdxIdentifierNode getNameNode()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.a = ((TMdxIdentifierNode)paramObject1);
    this.b = ((TMdxExpNode)paramObject2);
    this.c = ((TPTNodeList)paramObject3);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.b.accept(paramTParseTreeVisitor);
    if (this.c != null) {
      this.c.accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxWithNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */