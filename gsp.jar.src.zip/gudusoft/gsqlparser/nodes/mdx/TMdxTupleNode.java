package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxTupleNode
  extends TMdxExpNode
{
  private TPTNodeList<TMdxExpNode> a;
  
  public TPTNodeList<TMdxExpNode> getExprList()
  {
    return this.a;
  }
  
  public EMdxDataType getMdxDataType()
  {
    return EMdxDataType.Tuple;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TPTNodeList)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.a.accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxTupleNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */