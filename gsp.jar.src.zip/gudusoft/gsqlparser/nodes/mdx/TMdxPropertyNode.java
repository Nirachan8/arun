package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxPropertyNode
  extends TMdxBaseFunctionNode
{
  private TPTNodeList<TMdxExpNode> a;
  private IMdxIdentifierSegment b;
  private EMdxExpSyntax c;
  
  public void TMdxPropertyNode()
  {
    this.a = new TPTNodeList();
  }
  
  public EMdxDataType getMdxDataType()
  {
    return EMdxDataType.Member;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.a = ((TPTNodeList)paramObject1);
    this.b = ((IMdxIdentifierSegment)paramObject2);
    this.c = ((EMdxExpSyntax)paramObject3);
  }
  
  public String getFunctionName()
  {
    return null;
  }
  
  public IMdxIdentifierSegment getFunctionSegment()
  {
    return this.b;
  }
  
  public TPTNodeList<TMdxExpNode> getArguments()
  {
    return this.a;
  }
  
  public EMdxExpSyntax getExpSyntax()
  {
    return this.c;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.a.accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxPropertyNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */