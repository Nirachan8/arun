package gudusoft.gsqlparser.nodes.mdx;

import gudusoft.gsqlparser.nodes.TPTNodeList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;
import gudusoft.gsqlparser.nodes.TParseTreeVisitor;

public class TMdxDimContentNode
  extends TParseTreeNode
{
  private TPTNodeList<TMdxLevelNode> a;
  private TPTNodeList<TMdxGroupNode> b;
  private TPTNodeList<TMdxMemberNode> c;
  private TMdxExpNode d;
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4)
  {
    this.a = ((TPTNodeList)paramObject1);
    this.b = ((TPTNodeList)paramObject2);
    this.c = ((TPTNodeList)paramObject3);
    this.d = ((TMdxExpNode)paramObject4);
  }
  
  public TMdxExpNode getDefaultMember()
  {
    return this.d;
  }
  
  public TPTNodeList<TMdxGroupNode> getGroupingList()
  {
    return this.b;
  }
  
  public TPTNodeList<TMdxLevelNode> getLevelList()
  {
    return this.a;
  }
  
  public TPTNodeList<TMdxMemberNode> getMemberList()
  {
    return this.c;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.a.accept(paramTParseTreeVisitor);
    if (this.b != null) {
      this.b.accept(paramTParseTreeVisitor);
    }
    if (this.c != null) {
      this.c.accept(paramTParseTreeVisitor);
    }
    if (this.d != null) {
      this.d.accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\mdx\TMdxDimContentNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */