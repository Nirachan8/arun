package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TJoinList
  extends TParseTreeNodeList
{
  public void addJoin(TJoin paramTJoin)
  {
    addElement(paramTJoin);
  }
  
  public TJoin getJoin(int paramInt)
  {
    if (paramInt < size()) {
      return (TJoin)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addJoin((TJoin)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      getJoin(i).accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
  
  public void removeJoin(int paramInt)
  {
    TSourceToken localTSourceToken = null;
    if (size() > 1) {
      if (paramInt != size() - 1) {
        localTSourceToken = getJoin(paramInt).getEndToken().searchToken(",", 1);
      } else {
        localTSourceToken = getJoin(paramInt).getStartToken().searchToken(",", -1);
      }
    }
    getJoin(paramInt).removeAllMyTokensFromTokenList(localTSourceToken);
    a(paramInt);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TJoinList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */