package gudusoft.gsqlparser.nodes;

public class TElseIfSqlNodeList
  extends TParseTreeNodeList
{
  public void addElseIf(TElseIfSqlNode paramTElseIfSqlNode)
  {
    addElement(paramTElseIfSqlNode);
  }
  
  public TElseIfSqlNode getExecParameter(int paramInt)
  {
    if (paramInt < size()) {
      return (TElseIfSqlNode)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addElseIf((TElseIfSqlNode)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TElseIfSqlNodeList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */