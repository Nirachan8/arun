package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TDescribeSqlNode
  extends TParseTreeNode
{
  private TObjectName a;
  private TObjectName b;
  private TSourceToken c;
  
  public TObjectName getColumnName()
  {
    return this.b;
  }
  
  public TSourceToken getDescToken()
  {
    return this.c;
  }
  
  public TObjectName getTableName()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.c = ((TSourceToken)paramObject1);
    this.a = ((TObjectName)paramObject2);
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    init(paramObject1, paramObject2);
    this.b = ((TObjectName)paramObject3);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDescribeSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */