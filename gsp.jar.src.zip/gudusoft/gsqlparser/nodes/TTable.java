package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ETableSource;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class TTable
  extends TNodeWithAliasClause
{
  private TPartitionExtensionClause a;
  private TInformixOuterClause b;
  private TXmlTable c;
  private TFromTableList d;
  private TOpenQuery e = null;
  private TPTNodeList<TTableHint> f;
  private TOpenDatasource g = null;
  private TOpenXML h = null;
  private TOpenRowSet i = null;
  private TContainsTable j = null;
  private TFunctionCall k = null;
  private TMultiTargetList l;
  private TObjectNameList m = null;
  private boolean n = false;
  public TSelectSqlStatement subquery = null;
  private TExpression o;
  private ETableSource p;
  private TObjectName q;
  private TPivotClause r = null;
  private TObjectNameList s = null;
  public TTableReferenceList tablerefs = new TTableReferenceList();
  private TDataChangeTable t = null;
  
  public void setPartitionExtensionClause(TPartitionExtensionClause paramTPartitionExtensionClause)
  {
    this.a = paramTPartitionExtensionClause;
  }
  
  public TPartitionExtensionClause getPartitionExtensionClause()
  {
    return this.a;
  }
  
  public void setOuterClause(TInformixOuterClause paramTInformixOuterClause)
  {
    this.b = paramTInformixOuterClause;
  }
  
  public TInformixOuterClause getOuterClause()
  {
    return this.b;
  }
  
  public void setFromTableList(TFromTableList paramTFromTableList)
  {
    this.d = paramTFromTableList;
  }
  
  public TFromTableList getFromTableList()
  {
    return this.d;
  }
  
  public TXmlTable getXmlTable()
  {
    return this.c;
  }
  
  public void setXmlTable(TXmlTable paramTXmlTable)
  {
    this.c = paramTXmlTable;
  }
  
  public void setTableHintList(TPTNodeList<TTableHint> paramTPTNodeList)
  {
    this.f = paramTPTNodeList;
  }
  
  public TPTNodeList<TTableHint> getTableHintList()
  {
    return this.f;
  }
  
  public TOpenQuery getOpenquery()
  {
    return this.e;
  }
  
  public TSelectSqlStatement getSubquery()
  {
    return this.subquery;
  }
  
  public void setOpenquery(TOpenQuery paramTOpenQuery)
  {
    this.e = paramTOpenQuery;
  }
  
  public void setOpenDatasource(TOpenDatasource paramTOpenDatasource)
  {
    this.g = paramTOpenDatasource;
  }
  
  public TOpenDatasource getOpenDatasource()
  {
    return this.g;
  }
  
  public void setOpenXML(TOpenXML paramTOpenXML)
  {
    this.h = paramTOpenXML;
  }
  
  public TOpenXML getOpenXML()
  {
    return this.h;
  }
  
  public TOpenRowSet getOpenRowSet()
  {
    return this.i;
  }
  
  public void setOpenRowSet(TOpenRowSet paramTOpenRowSet)
  {
    this.i = paramTOpenRowSet;
  }
  
  public TContainsTable getContainsTable()
  {
    return this.j;
  }
  
  public void setContainsTable(TContainsTable paramTContainsTable)
  {
    this.j = paramTContainsTable;
  }
  
  public TFunctionCall getFuncCall()
  {
    return this.k;
  }
  
  public void setFuncCall(TFunctionCall paramTFunctionCall)
  {
    this.k = paramTFunctionCall;
  }
  
  public TMultiTargetList getRowList()
  {
    return this.l;
  }
  
  public boolean isBaseTable()
  {
    boolean bool;
    if (((bool = this.p == ETableSource.objectname ? 1 : 0) != 0) && (isCTEName())) {
      bool = false;
    }
    if ((bool) && (getFullName().startsWith("@"))) {
      bool = false;
    }
    return bool;
  }
  
  public void setCteColomnReferences(TObjectNameList paramTObjectNameList)
  {
    this.m = paramTObjectNameList;
  }
  
  public TObjectNameList getCteColomnReferences()
  {
    return this.m;
  }
  
  public void setObjectNameReferences(TObjectNameList paramTObjectNameList)
  {
    this.s = paramTObjectNameList;
  }
  
  public boolean isCTEName()
  {
    return this.n;
  }
  
  public void setCTEName(boolean paramBoolean)
  {
    this.n = paramBoolean;
  }
  
  public TExpression getTableExpr()
  {
    return this.o;
  }
  
  public void setTableExpr(TExpression paramTExpression)
  {
    this.o = paramTExpression;
  }
  
  public void setTableType(ETableSource paramETableSource)
  {
    this.p = paramETableSource;
  }
  
  public ETableSource getTableType()
  {
    return this.p;
  }
  
  public void setTableName(TObjectName paramTObjectName)
  {
    this.q = paramTObjectName;
    if (getStartToken() == null) {
      setStartToken(paramTObjectName.getStartToken());
    }
    if (getEndToken() == null) {
      setEndToken(paramTObjectName.getEndToken());
    }
  }
  
  public TObjectName getTableName()
  {
    return this.q;
  }
  
  public TTable(TObjectName paramTObjectName)
  {
    this.q = paramTObjectName;
  }
  
  public TTable()
  {
    this.q = null;
  }
  
  public String getName()
  {
    return this.q.getObjectString();
  }
  
  public String getFullNameWithAliasString()
  {
    if (getAliasClause() != null) {
      return getFullName() + " " + getAliasClause().toString();
    }
    return getFullName();
  }
  
  public String getFullName()
  {
    return this.q.toString();
  }
  
  public TObjectNameList getObjectNameReferences()
  {
    if (this.s == null)
    {
      this.s = new TObjectNameList();
      this.s.setObjectType(1);
    }
    return this.s;
  }
  
  public void setPivotClause(TPivotClause paramTPivotClause)
  {
    this.r = paramTPivotClause;
  }
  
  public TPivotClause getPivotClause()
  {
    return this.r;
  }
  
  public void setDatachangeTable(TDataChangeTable paramTDataChangeTable)
  {
    this.t = paramTDataChangeTable;
  }
  
  public TDataChangeTable getDatachangeTable()
  {
    return this.t;
  }
  
  public boolean isTableRefBelongToThisTable(TTableReference paramTTableReference)
  {
    boolean bool;
    if ((bool = this.q == paramTTableReference.objectname ? 1 : 0) != 0) {
      return true;
    }
    if (this.q.getObjectString().equalsIgnoreCase(paramTTableReference.objectname.getObjectString())) {
      if ((this.q.getSchemaString() == null) || (paramTTableReference.objectname.getSchemaString() == null)) {
        bool = true;
      } else {
        bool = this.q.getSchemaString().equalsIgnoreCase(paramTTableReference.objectname.getSchemaString());
      }
    }
    return bool;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
  
  public void setRowList(TMultiTargetList paramTMultiTargetList)
  {
    this.l = paramTMultiTargetList;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */