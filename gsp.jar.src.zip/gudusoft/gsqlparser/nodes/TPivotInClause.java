package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class TPivotInClause
  extends TParseTreeNode
{
  private TResultColumnList a;
  private TSelectSqlNode b;
  private TSelectSqlStatement c;
  
  public TSelectSqlStatement getSubQuery()
  {
    return this.c;
  }
  
  public TResultColumnList getItems()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TResultColumnList))
    {
      this.a = ((TResultColumnList)paramObject);
      return;
    }
    if ((paramObject instanceof TSelectSqlNode)) {
      this.b = ((TSelectSqlNode)paramObject);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.b != null)
    {
      this.c = new TSelectSqlStatement(paramTCustomSqlStatement.dbvendor);
      this.c.rootNode = this.b;
      this.c.doParseStatement(paramTCustomSqlStatement);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TPivotInClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */