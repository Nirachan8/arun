package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TWhereClause
  extends TParseTreeNode
{
  private TExpression a = null;
  
  public void TWhereClause() {}
  
  public TExpression getCondition()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TExpression)paramObject);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TWhereClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */