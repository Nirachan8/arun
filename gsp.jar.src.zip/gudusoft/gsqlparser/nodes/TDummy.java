package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EDbObjectType;
import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TSourceToken;

public class TDummy
  extends TParseTreeNode
{
  public EDbVendor dbvendor;
  public int int1 = 0;
  public int int2 = 0;
  public TSourceToken st1 = null;
  public TSourceToken st2 = null;
  public TParseTreeNode node1 = null;
  public TParseTreeNode node2 = null;
  public TParseTreeNode node3 = null;
  public TParseTreeNodeList list1 = null;
  public TParseTreeNodeList list2 = null;
  public EDbObjectType objectType;
  public ESqlStatementType sqlstatementtype;
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TParseTreeNodeList))
    {
      this.list1 = ((TParseTreeNodeList)paramObject);
      return;
    }
    if ((paramObject instanceof TSourceToken))
    {
      this.st1 = ((TSourceToken)paramObject);
      return;
    }
    if ((paramObject instanceof TParseTreeNode)) {
      this.node1 = ((TParseTreeNode)paramObject);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDummy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */