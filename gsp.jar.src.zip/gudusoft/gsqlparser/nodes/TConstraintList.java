package gudusoft.gsqlparser.nodes;

public class TConstraintList
  extends TParseTreeNodeList
{
  public void addConstraint(TConstraint paramTConstraint)
  {
    addElement(paramTConstraint);
  }
  
  public TConstraint getConstraint(int paramInt)
  {
    if (paramInt < size()) {
      return (TConstraint)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addConstraint((TConstraint)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      getConstraint(i).accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TConstraintList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */