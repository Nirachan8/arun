package gudusoft.gsqlparser.nodes;

public class TObjectReferenceList
  extends TParseTreeNodeList
{
  public void addObjectReference(TObjectReference paramTObjectReference)
  {
    addElement(paramTObjectReference);
  }
  
  public TObjectReference getObjectReference(int paramInt)
  {
    if (paramInt < size()) {
      return (TObjectReference)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addObjectReference((TObjectReference)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TObjectReferenceList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */