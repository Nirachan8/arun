package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EExpressionType;
import gudusoft.gsqlparser.EFunctionType;
import gudusoft.gsqlparser.TGSqlParser;
import gudusoft.gsqlparser.TSourceToken;
import java.io.PrintStream;

public class TNodeFactory
{
  private TGSqlParser a = null;
  
  public void setGsqlParser(TGSqlParser paramTGSqlParser)
  {
    this.a = paramTGSqlParser;
  }
  
  public TColumnReference createColumnReference(TObjectName paramTObjectName)
  {
    return paramTObjectName = (TColumnReference)createNode(ENodeType.T_ColumnReference.getId(), paramTObjectName);
  }
  
  public TColumnReference createColumnReference(TSourceToken paramTSourceToken)
  {
    return paramTSourceToken = (TColumnReference)createNode(ENodeType.T_ColumnReference.getId(), paramTSourceToken);
  }
  
  public TTableReference createTableReference(TObjectName paramTObjectName)
  {
    return paramTObjectName = (TTableReference)createNode(ENodeType.T_TableReference.getId(), paramTObjectName);
  }
  
  public TObjectReference createObjectReference(TObjectName paramTObjectName, int paramInt)
  {
    (paramTObjectName = (TObjectReference)createNode(ENodeType.T_ObjectReference.getId(), paramTObjectName)).setObjectType(paramInt);
    return paramTObjectName;
  }
  
  public TParseTreeNode createIntervalExpression()
  {
    TIntervalExpression localTIntervalExpression;
    return localTIntervalExpression = (TIntervalExpression)createNode(ENodeType.T_IntervalExression.getId());
  }
  
  public TParseTreeNode createDatetimeExpression()
  {
    TDatetimeExpression localTDatetimeExpression;
    return localTDatetimeExpression = (TDatetimeExpression)createNode(ENodeType.T_DatetimeExression.getId());
  }
  
  public TParseTreeNode createFunctionCall(EFunctionType paramEFunctionType, TObjectName paramTObjectName)
  {
    return paramEFunctionType = (TFunctionCall)createNode(ENodeType.T_FunctionCall.getId(), paramEFunctionType, paramTObjectName);
  }
  
  public TParseTreeNode createSelectSqlNode()
  {
    TSelectSqlNode localTSelectSqlNode;
    return localTSelectSqlNode = (TSelectSqlNode)createNode(ENodeType.T_SelectSqlNode.getId());
  }
  
  public TParseTreeNode createExpression(EExpressionType paramEExpressionType)
  {
    return paramEExpressionType = (TExpression)createNode(ENodeType.T_Expression.getId(), paramEExpressionType);
  }
  
  public TParseTreeNode createExpression(EExpressionType paramEExpressionType, TExpression paramTExpression1, TExpression paramTExpression2)
  {
    (paramEExpressionType = (TExpression)createNode(ENodeType.T_Expression.getId(), paramEExpressionType)).setLeftOperand(paramTExpression1);
    paramEExpressionType.setRightOperand(paramTExpression2);
    return paramEExpressionType;
  }
  
  public TParseTreeNode createCompoundExpression(EExpressionType paramEExpressionType, TExpression paramTExpression1, TExpression paramTExpression2)
  {
    (paramEExpressionType = (TExpression)createNode(ENodeType.T_Expression.getId(), paramEExpressionType)).setLeftOperand(paramTExpression1);
    paramEExpressionType.setRightOperand(paramTExpression2);
    return paramEExpressionType;
  }
  
  public TExpression createSimpleExpression(TObjectName paramTObjectName)
  {
    TExpression localTExpression;
    (localTExpression = (TExpression)createNode(ENodeType.T_Expression.getId(), EExpressionType.simple_object_name_t)).setObjectOperand(paramTObjectName);
    localTExpression.setStartToken(paramTObjectName);
    localTExpression.setEndToken(paramTObjectName);
    return localTExpression;
  }
  
  public TObjectName createObjectName(TSourceToken paramTSourceToken1, TSourceToken paramTSourceToken2, TSourceToken paramTSourceToken3)
  {
    TObjectName localTObjectName = (TObjectName)createNode(ENodeType.T_ObjectName.getId(), paramTSourceToken1, paramTSourceToken2, paramTSourceToken3);
    if (paramTSourceToken3 != null) {
      localTObjectName.setEndToken(paramTSourceToken3);
    } else if (paramTSourceToken2 != null) {
      localTObjectName.setEndToken(paramTSourceToken2);
    } else if (paramTSourceToken1 != null) {
      localTObjectName.setEndToken(paramTSourceToken1);
    }
    if (paramTSourceToken1 != null) {
      localTObjectName.setStartToken(paramTSourceToken1);
    } else if (paramTSourceToken2 != null) {
      localTObjectName.setStartToken(paramTSourceToken2);
    } else if (paramTSourceToken3 != null) {
      localTObjectName.setStartToken(paramTSourceToken3);
    }
    return localTObjectName;
  }
  
  public TObjectName createObjectNameWithPart(TSourceToken paramTSourceToken)
  {
    return createObjectName(null, null, paramTSourceToken);
  }
  
  public TObjectName createObjectNameWithObject(TSourceToken paramTSourceToken)
  {
    return createObjectName(null, paramTSourceToken, null);
  }
  
  public TObjectName createObjectNameWithPartAndObject(TSourceToken paramTSourceToken1, TSourceToken paramTSourceToken2)
  {
    return createObjectName(null, paramTSourceToken1, paramTSourceToken2);
  }
  
  public TParseTreeNode createSimpleExpression(TConstant paramTConstant)
  {
    TExpression localTExpression;
    (localTExpression = (TExpression)createNode(ENodeType.T_Expression.getId(), EExpressionType.simple_constant_t)).setConstantOperand(paramTConstant);
    localTExpression.setStartToken(paramTConstant.getStartToken());
    localTExpression.setEndToken(paramTConstant.getEndToken());
    return localTExpression;
  }
  
  public TParseTreeNode createSimpleExpression(TSourceToken paramTSourceToken)
  {
    TExpression localTExpression;
    (localTExpression = (TExpression)createNode(ENodeType.T_Expression.getId(), EExpressionType.simple_source_token_t)).setSourcetokenOperand(paramTSourceToken);
    localTExpression.setStartToken(paramTSourceToken);
    localTExpression.setEndToken(paramTSourceToken);
    return localTExpression;
  }
  
  public TParseTreeNode createConstant(TSourceToken paramTSourceToken, ENodeType paramENodeType)
  {
    (paramENodeType = (TConstant)createNode(paramENodeType.getId())).setvalueToken(paramTSourceToken);
    return paramENodeType;
  }
  
  public TParseTreeNode createNode(int paramInt)
  {
    Class localClass = null;
    TParseTreeNode localTParseTreeNode = null;
    String str = nodeName(paramInt);
    try
    {
      localClass = Class.forName(str);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      System.out.println(localClassNotFoundException.toString() + ", nodename: " + str);
    }
    try
    {
      localTParseTreeNode = (TParseTreeNode)localClass.newInstance();
    }
    catch (Exception localException)
    {
      System.out.println(localException.toString() + ", nodeType: " + paramInt);
    }
    localTParseTreeNode.setNodeType(paramInt);
    localTParseTreeNode.setGsqlparser(this.a);
    return localTParseTreeNode;
  }
  
  public <T> TPTNodeList<T> createPTNodeList(T paramT)
  {
    int i = ENodeType.T_PTNodeList.getId();
    TPTNodeList localTPTNodeList;
    (localTPTNodeList = new TPTNodeList()).setNodeType(i);
    localTPTNodeList.setGsqlparser(this.a);
    localTPTNodeList.init(paramT);
    return localTPTNodeList;
  }
  
  protected String nodeName(int paramInt)
  {
    return ENodeType.fromId(paramInt).toString();
  }
  
  public final TParseTreeNode createNode(int paramInt, Object paramObject)
  {
    (paramInt = createNode(paramInt)).init(paramObject);
    return paramInt;
  }
  
  public final TParseTreeNode createNode(int paramInt, Object paramObject1, Object paramObject2)
  {
    (paramInt = createNode(paramInt)).init(paramObject1, paramObject2);
    return paramInt;
  }
  
  public final TParseTreeNode createNode(int paramInt, Object paramObject1, Object paramObject2, Object paramObject3)
  {
    (paramInt = createNode(paramInt)).init(paramObject1, paramObject2, paramObject3);
    return paramInt;
  }
  
  public final TParseTreeNode createNode(int paramInt, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4)
  {
    (paramInt = createNode(paramInt)).init(paramObject1, paramObject2, paramObject3, paramObject4);
    return paramInt;
  }
  
  public final TParseTreeNode createNode(int paramInt, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5)
  {
    (paramInt = createNode(paramInt)).init(paramObject1, paramObject2, paramObject3, paramObject4, paramObject5);
    return paramInt;
  }
  
  public final TParseTreeNode createNode(int paramInt, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6)
  {
    (paramInt = createNode(paramInt)).init(paramObject1, paramObject2, paramObject3, paramObject4, paramObject5, paramObject6);
    return paramInt;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TNodeFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */