package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TIntoClause
  extends TParseTreeNode
{
  private TExpressionList a = null;
  
  public TExpressionList getExprList()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TExpressionList)) {
      this.a = ((TExpressionList)paramObject);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null) {
      this.a.doParse(paramTCustomSqlStatement, ESqlClause.selectInto);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TIntoClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */