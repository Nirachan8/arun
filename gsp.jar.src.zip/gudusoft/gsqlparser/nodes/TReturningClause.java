package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TReturningClause
  extends TParseTreeNode
{
  private TExpressionList a = null;
  private TExpressionList b = null;
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TExpressionList)paramObject1);
    this.b = ((TExpressionList)paramObject2);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
  
  public TExpressionList getColumnValueList()
  {
    return this.a;
  }
  
  public TExpressionList getVariableList()
  {
    return this.b;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TReturningClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */