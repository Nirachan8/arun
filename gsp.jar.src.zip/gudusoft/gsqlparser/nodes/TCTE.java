package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.stmt.TDeleteSqlStatement;
import gudusoft.gsqlparser.stmt.TInsertSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import gudusoft.gsqlparser.stmt.TUpdateSqlStatement;

public class TCTE
  extends TParseTreeNode
{
  private TSelectSqlNode a;
  private TSelectSqlStatement b;
  private TInsertSqlNode c;
  private TInsertSqlStatement d;
  private TUpdateSqlNode e;
  private TUpdateSqlStatement f;
  private TDeleteSqlNode g;
  private TDeleteSqlStatement h;
  private TCustomSqlStatement i;
  private TObjectName j;
  private TObjectNameList k = null;
  
  public TCustomSqlStatement getPreparableStmt()
  {
    this.i = null;
    if (this.b != null) {
      this.i = this.b;
    } else if (this.f != null) {
      this.i = this.f;
    } else if (this.h != null) {
      this.i = this.h;
    } else if (this.d != null) {
      this.i = this.d;
    }
    return this.i;
  }
  
  public TUpdateSqlStatement getUpdateStmt()
  {
    return this.f;
  }
  
  public TInsertSqlStatement getInsertStmt()
  {
    return this.d;
  }
  
  public TDeleteSqlStatement getDeleteStmt()
  {
    return this.h;
  }
  
  public TObjectName getTableName()
  {
    return this.j;
  }
  
  public void setColumnList(TObjectNameList paramTObjectNameList)
  {
    this.k = paramTObjectNameList;
  }
  
  public TSelectSqlStatement getSubquery()
  {
    return this.b;
  }
  
  public TObjectNameList getColumnList()
  {
    return this.k;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.j = ((TObjectName)paramObject1);
    this.j.setObjectType(5);
    if ((paramObject2 instanceof TSelectSqlNode))
    {
      this.a = ((TSelectSqlNode)paramObject2);
      return;
    }
    if ((paramObject2 instanceof TInsertSqlNode))
    {
      this.c = ((TInsertSqlNode)paramObject2);
      return;
    }
    if ((paramObject2 instanceof TUpdateSqlNode))
    {
      this.e = ((TUpdateSqlNode)paramObject2);
      return;
    }
    if ((paramObject2 instanceof TDeleteSqlNode)) {
      this.g = ((TDeleteSqlNode)paramObject2);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null)
    {
      this.b = new TSelectSqlStatement(paramTCustomSqlStatement.dbvendor);
      this.b.rootNode = this.a;
      this.b.doParseStatement(paramTCustomSqlStatement);
      return;
    }
    if (this.c != null)
    {
      this.d = new TInsertSqlStatement(paramTCustomSqlStatement.dbvendor);
      this.d.rootNode = this.c;
      this.d.doParseStatement(paramTCustomSqlStatement);
      return;
    }
    if (this.g != null)
    {
      this.h = new TDeleteSqlStatement(paramTCustomSqlStatement.dbvendor);
      this.h.rootNode = this.g;
      this.h.doParseStatement(paramTCustomSqlStatement);
      return;
    }
    if (this.e != null)
    {
      this.f = new TUpdateSqlStatement(paramTCustomSqlStatement.dbvendor);
      this.f.rootNode = this.e;
      this.f.doParseStatement(paramTCustomSqlStatement);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCTE.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */