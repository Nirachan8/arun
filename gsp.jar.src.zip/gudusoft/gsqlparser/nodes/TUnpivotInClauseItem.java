package gudusoft.gsqlparser.nodes;

public class TUnpivotInClauseItem
  extends TParseTreeNode
{
  private TObjectName a;
  private TObjectNameList b;
  private TConstant c;
  private TPTNodeList<TConstant> d;
  
  public TObjectName getColumn()
  {
    return this.a;
  }
  
  public TObjectNameList getColumnList()
  {
    return this.b;
  }
  
  public TConstant getConstant()
  {
    return this.c;
  }
  
  public TPTNodeList<TConstant> getConstantList()
  {
    return this.d;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    if ((paramObject1 instanceof TObjectName)) {
      this.a = ((TObjectName)paramObject1);
    } else if ((paramObject1 instanceof TObjectNameList)) {
      this.b = ((TObjectNameList)paramObject1);
    }
    if (paramObject2 != null)
    {
      if (((paramObject1 = (TDummy)paramObject2).node1 instanceof TConstant))
      {
        this.c = ((TConstant)((TDummy)paramObject1).node1);
        return;
      }
      if ((((TDummy)paramObject1).node1 instanceof TPTNodeList)) {
        this.d = ((TPTNodeList)((TDummy)paramObject1).node1);
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TUnpivotInClauseItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */