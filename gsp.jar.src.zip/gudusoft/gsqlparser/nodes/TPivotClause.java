package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TPivotClause
  extends TNodeWithAliasClause
{
  public static final int pivot = 1;
  public static final int unpivot = 2;
  private int a = 1;
  private TPivotInClause b;
  private TUnpivotInClause c;
  private TResultColumnList d;
  private TResultColumnList e;
  private TObjectNameList f;
  private TFunctionCall g = null;
  private TObjectName h = null;
  private TObjectNameList i = null;
  private TObjectName j = null;
  private TObjectNameList k = null;
  
  public TPivotInClause getPivotInClause()
  {
    return this.b;
  }
  
  public TUnpivotInClause getUnpivotInClause()
  {
    return this.c;
  }
  
  public TObjectNameList getPrivotColumnList()
  {
    return this.f;
  }
  
  public TResultColumnList getIn_result_list()
  {
    return this.e;
  }
  
  public TResultColumnList getAggregation_function_list()
  {
    return this.d;
  }
  
  public void setType(int paramInt)
  {
    this.a = paramInt;
  }
  
  public int getType()
  {
    return this.a;
  }
  
  public TObjectNameList getValueColumnList()
  {
    return this.i;
  }
  
  public TFunctionCall getAggregation_function()
  {
    return this.g;
  }
  
  public TObjectNameList getColumnList()
  {
    return null;
  }
  
  public TObjectName getPrivotColumn()
  {
    return this.j;
  }
  
  public TObjectName getValueColumn()
  {
    return this.h;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    if ((paramObject1 instanceof TFunctionCall)) {
      this.g = ((TFunctionCall)paramObject1);
    } else if ((paramObject1 instanceof TObjectName)) {
      this.h = ((TObjectName)paramObject1);
    } else if ((paramObject1 instanceof TObjectNameList)) {
      this.i = ((TObjectNameList)paramObject1);
    } else if ((paramObject1 instanceof TResultColumnList)) {
      this.d = ((TResultColumnList)paramObject1);
    }
    if ((paramObject2 instanceof TObjectName))
    {
      this.j = ((TObjectName)paramObject2);
      return;
    }
    if ((paramObject2 instanceof TObjectNameList)) {
      this.f = ((TObjectNameList)paramObject2);
    }
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    init(paramObject1, paramObject2);
    if ((paramObject3 instanceof TResultColumnList))
    {
      this.e = ((TResultColumnList)paramObject3);
      return;
    }
    if ((paramObject3 instanceof TUnpivotInClause))
    {
      this.c = ((TUnpivotInClause)paramObject3);
      return;
    }
    if ((paramObject3 instanceof TPivotInClause)) {
      this.b = ((TPivotInClause)paramObject3);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.d != null) {
      this.d.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if (this.e != null) {
      this.e.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TPivotClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */