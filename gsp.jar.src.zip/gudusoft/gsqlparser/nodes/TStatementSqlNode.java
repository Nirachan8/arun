package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ESqlStatementType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.stmt.TAlterTableStatement;
import gudusoft.gsqlparser.stmt.TCreateIndexSqlStatement;
import gudusoft.gsqlparser.stmt.TCreateTableSqlStatement;
import gudusoft.gsqlparser.stmt.TDeleteSqlStatement;
import gudusoft.gsqlparser.stmt.TDropIndexSqlStatement;
import gudusoft.gsqlparser.stmt.TDropTableSqlStatement;
import gudusoft.gsqlparser.stmt.TDropViewSqlStatement;
import gudusoft.gsqlparser.stmt.TInsertSqlStatement;
import gudusoft.gsqlparser.stmt.TParseErrorSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import gudusoft.gsqlparser.stmt.TTruncateStatement;
import gudusoft.gsqlparser.stmt.TUpdateSqlStatement;
import gudusoft.gsqlparser.stmt.db2.TDb2CallStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2CaseStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2CloseCursorStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2ConditionDeclaration;
import gudusoft.gsqlparser.stmt.db2.TDb2CreateFunction;
import gudusoft.gsqlparser.stmt.db2.TDb2CreateProcedure;
import gudusoft.gsqlparser.stmt.db2.TDb2DeclareCursorStatement;
import gudusoft.gsqlparser.stmt.db2.TDb2FetchCursorStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2ForStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2GotoStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2HandlerDeclaration;
import gudusoft.gsqlparser.stmt.db2.TDb2IfStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2IterateStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2LeaveStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2LoopStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2OpenCursorStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2RepeatStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2ReturnCodesDeclaration;
import gudusoft.gsqlparser.stmt.db2.TDb2ReturnStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2SetStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2SetVariableStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2SignalStmt;
import gudusoft.gsqlparser.stmt.db2.TDb2SqlVariableDeclaration;
import gudusoft.gsqlparser.stmt.db2.TDb2StatementDeclaration;
import gudusoft.gsqlparser.stmt.db2.TDb2StmtStub;
import gudusoft.gsqlparser.stmt.db2.TDb2WhileStmt;
import gudusoft.gsqlparser.stmt.mssql.TMssqlBeginDialog;
import gudusoft.gsqlparser.stmt.mssql.TMssqlBeginTran;
import gudusoft.gsqlparser.stmt.mssql.TMssqlBlock;
import gudusoft.gsqlparser.stmt.mssql.TMssqlBreak;
import gudusoft.gsqlparser.stmt.mssql.TMssqlBulkInsert;
import gudusoft.gsqlparser.stmt.mssql.TMssqlClose;
import gudusoft.gsqlparser.stmt.mssql.TMssqlCommit;
import gudusoft.gsqlparser.stmt.mssql.TMssqlContinue;
import gudusoft.gsqlparser.stmt.mssql.TMssqlCreateFunction;
import gudusoft.gsqlparser.stmt.mssql.TMssqlCreateProcedure;
import gudusoft.gsqlparser.stmt.mssql.TMssqlDeallocate;
import gudusoft.gsqlparser.stmt.mssql.TMssqlDeclare;
import gudusoft.gsqlparser.stmt.mssql.TMssqlDropDbObject;
import gudusoft.gsqlparser.stmt.mssql.TMssqlEndConversation;
import gudusoft.gsqlparser.stmt.mssql.TMssqlExecute;
import gudusoft.gsqlparser.stmt.mssql.TMssqlExecuteAs;
import gudusoft.gsqlparser.stmt.mssql.TMssqlFetch;
import gudusoft.gsqlparser.stmt.mssql.TMssqlGo;
import gudusoft.gsqlparser.stmt.mssql.TMssqlGoTo;
import gudusoft.gsqlparser.stmt.mssql.TMssqlGrant;
import gudusoft.gsqlparser.stmt.mssql.TMssqlIfElse;
import gudusoft.gsqlparser.stmt.mssql.TMssqlLabel;
import gudusoft.gsqlparser.stmt.mssql.TMssqlOpen;
import gudusoft.gsqlparser.stmt.mssql.TMssqlPrint;
import gudusoft.gsqlparser.stmt.mssql.TMssqlRaiserror;
import gudusoft.gsqlparser.stmt.mssql.TMssqlReturn;
import gudusoft.gsqlparser.stmt.mssql.TMssqlRevert;
import gudusoft.gsqlparser.stmt.mssql.TMssqlRollback;
import gudusoft.gsqlparser.stmt.mssql.TMssqlSaveTran;
import gudusoft.gsqlparser.stmt.mssql.TMssqlSendOnConversation;
import gudusoft.gsqlparser.stmt.mssql.TMssqlSet;
import gudusoft.gsqlparser.stmt.mssql.TMssqlStmtStub;
import gudusoft.gsqlparser.stmt.mssql.TMssqlStmtStubSqlNode;
import gudusoft.gsqlparser.stmt.mssql.TMssqlUpdateText;
import gudusoft.gsqlparser.stmt.mssql.TMssqlUse;
import gudusoft.gsqlparser.stmt.mysql.TMySQLBlock;
import gudusoft.gsqlparser.stmt.mysql.TMySQLCaseStmt;
import gudusoft.gsqlparser.stmt.mysql.TMySQLDeclare;
import gudusoft.gsqlparser.stmt.mysql.TMySQLFetchCursor;
import gudusoft.gsqlparser.stmt.mysql.TMySQLIfStmt;
import gudusoft.gsqlparser.stmt.mysql.TMySQLLoopStmt;
import gudusoft.gsqlparser.stmt.mysql.TMySQLOpenCursor;
import gudusoft.gsqlparser.stmt.mysql.TMySQLRepeatStmt;
import gudusoft.gsqlparser.stmt.mysql.TMySQLStmtStub;
import gudusoft.gsqlparser.stmt.mysql.TMySQLWhileStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlBlock;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlCreateFunction;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlCreateProcedure;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlExecImmeStmt;
import java.io.PrintStream;

public class TStatementSqlNode
  extends TParseTreeNode
{
  public static final int caseExpression = 41;
  public static final int stubStmtSqlNode = 80;
  public static final int truncateTable = 77;
  public static final int select = 100;
  public static final int delete = 101;
  public static final int update = 102;
  public static final int insert = 103;
  public static final int createtable = 104;
  public static final int CreateProcedureSqlNode = 105;
  public static final int CreateFunctionSqlNode = 106;
  public static final int block = 107;
  public static final int returnstmt = 108;
  public static final int ifstmt = 112;
  public static final int declare = 113;
  public static final int CreateIndexSqlNode = 116;
  public static final int DropTableSqlNode = 119;
  public static final int DropIndexSqlNode = 120;
  public static final int DropViewSqlNode = 121;
  public static final int AlterTableSqlNode = 123;
  public static final int ContinueSqlNode = 125;
  public static final int BreakSqlNode = 126;
  public static final int GrantSqlNode = 127;
  public static final int FetchSqlNode = 128;
  public static final int OpenSqlNode = 129;
  public static final int CloseSqlNode = 130;
  public static final int ExecuteAsSqlNode = 131;
  public static final int ExecuteSqlNode = 132;
  public static final int RevokeSqlNode = 133;
  public static final int DropDbObjectSqlNode = 135;
  public static final int CollectStatisticsSqlNode = 136;
  public static final int ExecImmeNode = 514;
  public static final int MssqlSetSqlNode = 611;
  public static final int MssqlBeginTranSqlNode = 612;
  public static final int MssqlRaiserrorSqlNode = 613;
  public static final int MssqlGotoSqlNode = 614;
  public static final int MssqlLabelSqlNode = 615;
  public static final int MssqlDeallocateSqlNode = 616;
  public static final int MssqlBeginDialogSqlNode = 619;
  public static final int MssqlSendOnConversationSqlNode = 620;
  public static final int MssqlEndConversationSqlNode = 621;
  public static final int MssqlRevertSqlNode = 622;
  public static final int MssqlBulkInsert = 625;
  public static final int MssqlUpdateTextSqlNode = 626;
  public static final int MssqlStmtStubSqlNode = 627;
  public static final int ForSqlNode = 913;
  public static final int SetSqlNode = 919;
  public static final int WhileSqlNode = 921;
  public static final int RepeatSqlNode = 923;
  public static final int LoopSqlNode = 925;
  public static final int ParseErrorNode = 990;
  public static final int dummyNode = 1000;
  public static final int dummyListNode = 1001;
  private TParseTreeNode a = null;
  private TCustomSqlStatement b = null;
  private boolean c = true;
  private TObjectName d;
  private TObjectName e;
  
  public TCustomSqlStatement getStmt()
  {
    return this.b;
  }
  
  public void setParsed(boolean paramBoolean)
  {
    this.c = paramBoolean;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TCustomSqlStatement))
    {
      this.b = ((TCustomSqlStatement)paramObject);
      return;
    }
    this.a = ((TParseTreeNode)paramObject);
  }
  
  public void setEndlabelName(TObjectName paramTObjectName)
  {
    this.d = paramTObjectName;
  }
  
  public TObjectName getEndlabelName()
  {
    return this.d;
  }
  
  public void setLabelName(TObjectName paramTObjectName)
  {
    this.e = paramTObjectName;
  }
  
  public TObjectName getLabelName()
  {
    return this.e;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    init(paramObject1);
    this.e = ((TObjectName)paramObject2);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.b != null)
    {
      if (!this.c) {
        this.b.parsestatement(paramTCustomSqlStatement, this.c);
      } else {
        this.b.doParseStatement(paramTCustomSqlStatement);
      }
      this.b.setLabelName(this.e);
      return;
    }
    if (this.a == null) {
      return;
    }
    switch (this.a.getNodeType())
    {
    case 100: 
      this.b = new TSelectSqlStatement(paramTCustomSqlStatement.dbvendor);
      break;
    case 101: 
      this.b = new TDeleteSqlStatement(paramTCustomSqlStatement.dbvendor);
      break;
    case 102: 
      this.b = new TUpdateSqlStatement(paramTCustomSqlStatement.dbvendor);
      break;
    case 103: 
      this.b = new TInsertSqlStatement(paramTCustomSqlStatement.dbvendor);
      break;
    case 625: 
      this.b = new TMssqlBulkInsert(paramTCustomSqlStatement.dbvendor);
      break;
    case 626: 
      this.b = new TMssqlUpdateText(paramTCustomSqlStatement.dbvendor);
      break;
    case 104: 
      this.b = new TCreateTableSqlStatement(paramTCustomSqlStatement.dbvendor);
      break;
    case 113: 
      if ((paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmssql) || (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvsybase)) {
        this.b = new TMssqlDeclare(paramTCustomSqlStatement.dbvendor);
      } else if ((paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmssql) || (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvsybase)) {
        this.b = new TMySQLDeclare(paramTCustomSqlStatement.dbvendor);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvdb2) {
        switch ((paramESqlClause = (TDeclareSqlNode)this.a).getDeclareType())
        {
        case 1: 
          this.b = new TDb2SqlVariableDeclaration(paramTCustomSqlStatement.dbvendor);
          break;
        case 3: 
          this.b = new TDb2ConditionDeclaration(paramTCustomSqlStatement.dbvendor);
          break;
        case 6: 
          this.b = new TDb2ReturnCodesDeclaration(paramTCustomSqlStatement.dbvendor);
          break;
        case 5: 
          this.b = new TDb2StatementDeclaration(paramTCustomSqlStatement.dbvendor);
          break;
        case 2: 
          this.b = new TDb2DeclareCursorStatement(paramTCustomSqlStatement.dbvendor);
          break;
        case 4: 
          this.b = new TDb2HandlerDeclaration(paramTCustomSqlStatement.dbvendor);
        }
      }
      break;
    case 107: 
      if ((paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmssql) || (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvsybase)) {
        this.b = new TMssqlBlock(paramTCustomSqlStatement.dbvendor);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvoracle) {
        this.b = new TPlsqlBlock(paramTCustomSqlStatement.dbvendor);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmysql) {
        this.b = new TMySQLBlock(paramTCustomSqlStatement.dbvendor);
      } else {
        System.out.println("block type not implemented: " + paramTCustomSqlStatement.dbvendor.toString());
      }
      break;
    case 108: 
      if ((paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmssql) || (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvsybase)) {
        this.b = new TMssqlReturn(paramTCustomSqlStatement.dbvendor);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvdb2) {
        this.b = new TDb2ReturnStmt(paramTCustomSqlStatement.dbvendor);
      }
      break;
    case 112: 
      if ((paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmssql) || (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvsybase)) {
        this.b = new TMssqlIfElse(paramTCustomSqlStatement.dbvendor);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvdb2) {
        this.b = new TDb2IfStmt(paramTCustomSqlStatement.dbvendor);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmysql) {
        this.b = new TMySQLIfStmt(paramTCustomSqlStatement.dbvendor);
      }
      break;
    case 105: 
      if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvoracle)
      {
        this.b = new TPlsqlCreateProcedure(EDbVendor.dbvoracle);
        ((TPlsqlCreateProcedure)this.b).setKind(((TCreateProcedureSqlNode)this.a).getKind());
      }
      else if ((paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmssql) || (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvsybase))
      {
        this.b = new TMssqlCreateProcedure(paramTCustomSqlStatement.dbvendor);
      }
      else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvdb2)
      {
        this.b = new TDb2CreateProcedure(paramTCustomSqlStatement.dbvendor);
      }
      else
      {
        System.out.println("create procedure not implemented: " + paramTCustomSqlStatement.dbvendor.toString());
      }
      break;
    case 106: 
      if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvoracle)
      {
        this.b = new TPlsqlCreateFunction(EDbVendor.dbvoracle);
        ((TPlsqlCreateFunction)this.b).setKind(((TCreateFunctionSqlNode)this.a).getKind());
      }
      else if ((paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmssql) || (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvsybase))
      {
        this.b = new TMssqlCreateFunction(paramTCustomSqlStatement.dbvendor);
      }
      else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvdb2)
      {
        this.b = new TDb2CreateFunction(paramTCustomSqlStatement.dbvendor);
      }
      else
      {
        System.out.println("create function not implemented: " + paramTCustomSqlStatement.dbvendor.toString());
      }
      break;
    case 514: 
      this.b = new TPlsqlExecImmeStmt(EDbVendor.dbvoracle);
      break;
    case 125: 
      this.b = new TMssqlContinue(paramTCustomSqlStatement.dbvendor);
      break;
    case 126: 
      this.b = new TMssqlBreak(paramTCustomSqlStatement.dbvendor);
      break;
    case 127: 
      this.b = new TMssqlGrant(paramTCustomSqlStatement.dbvendor);
      break;
    case 128: 
      if ((paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmssql) || (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvsybase)) {
        this.b = new TMssqlFetch(paramTCustomSqlStatement.dbvendor);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvdb2) {
        this.b = new TDb2FetchCursorStmt(paramTCustomSqlStatement.dbvendor);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmysql) {
        this.b = new TMySQLFetchCursor(paramTCustomSqlStatement.dbvendor);
      }
      break;
    case 129: 
      if ((paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmssql) || (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvsybase)) {
        this.b = new TMssqlOpen(paramTCustomSqlStatement.dbvendor);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvdb2) {
        this.b = new TDb2OpenCursorStmt(paramTCustomSqlStatement.dbvendor);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmysql) {
        this.b = new TMySQLOpenCursor(paramTCustomSqlStatement.dbvendor);
      }
      break;
    case 130: 
      if ((paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmssql) || (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvsybase)) {
        this.b = new TMssqlClose(paramTCustomSqlStatement.dbvendor);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvdb2) {
        this.b = new TDb2CloseCursorStmt(paramTCustomSqlStatement.dbvendor);
      }
      break;
    case 116: 
      this.b = new TCreateIndexSqlStatement(paramTCustomSqlStatement.dbvendor);
      break;
    case 119: 
      this.b = new TDropTableSqlStatement(paramTCustomSqlStatement.dbvendor);
      break;
    case 120: 
      this.b = new TDropIndexSqlStatement(paramTCustomSqlStatement.dbvendor);
      break;
    case 121: 
      this.b = new TDropViewSqlStatement(paramTCustomSqlStatement.dbvendor);
      break;
    case 135: 
      this.b = new TMssqlDropDbObject(paramTCustomSqlStatement.dbvendor);
      break;
    case 123: 
      this.b = new TAlterTableStatement(paramTCustomSqlStatement.dbvendor);
      break;
    case 616: 
      this.b = new TMssqlDeallocate(paramTCustomSqlStatement.dbvendor);
      break;
    case 132: 
      this.b = new TMssqlExecute(paramTCustomSqlStatement.dbvendor);
      break;
    case 131: 
      this.b = new TMssqlExecuteAs(paramTCustomSqlStatement.dbvendor);
      break;
    case 612: 
      this.b = new TMssqlBeginTran(paramTCustomSqlStatement.dbvendor);
      break;
    case 613: 
      this.b = new TMssqlRaiserror(paramTCustomSqlStatement.dbvendor);
      break;
    case 615: 
      this.b = new TMssqlLabel(paramTCustomSqlStatement.dbvendor);
      break;
    case 614: 
      this.b = new TMssqlGoTo(paramTCustomSqlStatement.dbvendor);
      break;
    case 622: 
      this.b = new TMssqlRevert(paramTCustomSqlStatement.dbvendor);
      break;
    case 620: 
      this.b = new TMssqlSendOnConversation(paramTCustomSqlStatement.dbvendor);
      break;
    case 621: 
      this.b = new TMssqlEndConversation(paramTCustomSqlStatement.dbvendor);
      break;
    case 619: 
      this.b = new TMssqlBeginDialog(paramTCustomSqlStatement.dbvendor);
      break;
    case 611: 
      this.b = new TMssqlSet(paramTCustomSqlStatement.dbvendor);
      break;
    case 925: 
      if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvdb2) {
        this.b = new TDb2LoopStmt(EDbVendor.dbvdb2);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmysql) {
        this.b = new TMySQLLoopStmt(EDbVendor.dbvmysql);
      }
      break;
    case 923: 
      if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvdb2) {
        this.b = new TDb2RepeatStmt(EDbVendor.dbvdb2);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmysql) {
        this.b = new TMySQLRepeatStmt(EDbVendor.dbvmysql);
      }
      break;
    case 921: 
      if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvdb2) {
        this.b = new TDb2WhileStmt(EDbVendor.dbvdb2);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmysql) {
        this.b = new TMySQLWhileStmt(EDbVendor.dbvmysql);
      }
      break;
    case 913: 
      this.b = new TDb2ForStmt(EDbVendor.dbvdb2);
      break;
    case 919: 
      this.b = new TDb2SetVariableStmt(EDbVendor.dbvdb2);
      break;
    case 41: 
      if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvdb2) {
        this.b = new TDb2CaseStmt(EDbVendor.dbvdb2);
      } else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmysql) {
        this.b = new TMySQLCaseStmt(EDbVendor.dbvmysql);
      }
      break;
    case 627: 
      if (((TMssqlStmtStubSqlNode)this.a).getSqlStatementType() == ESqlStatementType.sstmssqlset)
      {
        this.b = new TMssqlSet(paramTCustomSqlStatement.dbvendor);
        this.b.setStartToken(this.a);
        this.b.setEndToken(this.a);
      }
      else
      {
        this.b = new TMssqlStmtStub(paramTCustomSqlStatement.dbvendor);
        ((TMssqlStmtStub)this.b).setSqlStatementType(((TMssqlStmtStubSqlNode)this.a).getSqlStatementType());
      }
      break;
    case 80: 
      if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvdb2)
      {
        paramESqlClause = (TStubStmtSqlNode)this.a;
        switch (1.a[paramESqlClause.getSqlStatementType().ordinal()])
        {
        case 1: 
          this.b = new TDb2IterateStmt(EDbVendor.dbvdb2);
          break;
        case 2: 
          this.b = new TDb2CallStmt(EDbVendor.dbvdb2);
          break;
        case 3: 
          this.b = new TDb2LeaveStmt(EDbVendor.dbvdb2);
          break;
        case 4: 
          this.b = new TDb2SignalStmt(EDbVendor.dbvdb2);
          break;
        case 5: 
          this.b = new TDb2GotoStmt(EDbVendor.dbvdb2);
          break;
        case 6: 
          this.b = new TDb2SetStmt(EDbVendor.dbvdb2);
          break;
        default: 
          this.b = new TDb2StmtStub(EDbVendor.dbvdb2);
          ((TDb2StmtStub)this.b).setSqlStatementType(((TStubStmtSqlNode)this.a).getSqlStatementType());
          break;
        }
      }
      else if (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmysql)
      {
        this.b = new TMySQLStmtStub(EDbVendor.dbvmysql);
        ((TMySQLStmtStub)this.b).setSqlStatementType(((TStubStmtSqlNode)this.a).getSqlStatementType());
      }
      break;
    case 1000: 
      if ((paramESqlClause = (TDummy)this.a).sqlstatementtype == ESqlStatementType.sstmssqlcommit) {
        this.b = new TMssqlCommit(paramTCustomSqlStatement.dbvendor);
      } else if (paramESqlClause.sqlstatementtype == ESqlStatementType.sstmssqlrollback) {
        this.b = new TMssqlRollback(paramTCustomSqlStatement.dbvendor);
      } else if (paramESqlClause.sqlstatementtype == ESqlStatementType.sstmssqlsavetran) {
        this.b = new TMssqlSaveTran(paramTCustomSqlStatement.dbvendor);
      } else if (paramESqlClause.sqlstatementtype == ESqlStatementType.sstmssqlprint) {
        this.b = new TMssqlPrint(paramTCustomSqlStatement.dbvendor);
      } else if (paramESqlClause.sqlstatementtype == ESqlStatementType.sstmssqluse) {
        this.b = new TMssqlUse(paramTCustomSqlStatement.dbvendor);
      } else if (paramESqlClause.sqlstatementtype == ESqlStatementType.sstmssqlgo) {
        this.b = new TMssqlGo(paramTCustomSqlStatement.dbvendor);
      }
      break;
    case 990: 
      this.b = new TParseErrorSqlStatement(paramTCustomSqlStatement.dbvendor);
      break;
    case 77: 
      this.b = new TTruncateStatement(paramTCustomSqlStatement.dbvendor);
    }
    if (this.b != null)
    {
      this.b.rootNode = this.a;
      this.b.setStartToken(this.a);
      this.b.setEndToken(this.a);
      this.b.setLabelName(this.e);
      this.b.doParseStatement(paramTCustomSqlStatement);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TStatementSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */