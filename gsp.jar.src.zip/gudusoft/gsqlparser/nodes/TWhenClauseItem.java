package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EExpressionType;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;

public class TWhenClauseItem
  extends TParseTreeNode
{
  private TExpression a = null;
  private TExpression b = null;
  private TStatementListSqlNode c = null;
  private TConstantList d = null;
  private TStatementList e = null;
  
  public TConstantList getCount_fraction_description_list()
  {
    return this.d;
  }
  
  public TExpression getComparison_expr()
  {
    return this.a;
  }
  
  public TExpression getReturn_expr()
  {
    return this.b;
  }
  
  public TStatementList getStatement_list()
  {
    if (this.e == null) {
      this.e = new TStatementList();
    }
    return this.e;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TExpression)paramObject1);
    if (this.a.getExpressionType() == EExpressionType.assignment_t) {
      this.a.setExpressionType(EExpressionType.simple_comparison_t);
    }
    if ((paramObject2 instanceof TExpression))
    {
      this.b = ((TExpression)paramObject2);
      return;
    }
    if ((paramObject2 instanceof TConstantList))
    {
      this.d = ((TConstantList)paramObject2);
      return;
    }
    this.c = ((TStatementListSqlNode)paramObject2);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
    if (this.b != null)
    {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    }
    if (this.c != null)
    {
      this.c.doParse(paramTCustomSqlStatement, paramESqlClause);
      for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < this.c.size(); paramTCustomSqlStatement++) {
        getStatement_list().add(this.c.getStatementSqlNode(paramTCustomSqlStatement).getStmt());
      }
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TWhenClauseItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */