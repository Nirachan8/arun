package gudusoft.gsqlparser.nodes;

public class TValueRowItemList
  extends TParseTreeNodeList
{
  public void addValueRowItem(TValueRowItem paramTValueRowItem)
  {
    addElement(paramTValueRowItem);
  }
  
  public TValueRowItem getValueRowItem(int paramInt)
  {
    if (paramInt < size()) {
      return (TValueRowItem)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addValueRowItem((TValueRowItem)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      getValueRowItem(i).accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TValueRowItemList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */