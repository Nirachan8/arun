package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TMySQLCreateTableOption
  extends TParseTreeNode
{
  private String a;
  private String b;
  private TSourceToken c;
  private TSourceToken d;
  private TConstant e;
  private TObjectNameList f;
  
  public String getOptionValue()
  {
    return this.b;
  }
  
  public String getOptionName()
  {
    return this.a;
  }
  
  public TObjectNameList getValueList()
  {
    return this.f;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    if ((paramObject1 instanceof String))
    {
      this.a = ((String)paramObject1);
    }
    else if ((paramObject1 instanceof TSourceToken))
    {
      this.c = ((TSourceToken)paramObject1);
      this.a = this.c.toString();
    }
    if ((paramObject2 instanceof String))
    {
      this.b = ((String)paramObject2);
      return;
    }
    if ((paramObject2 instanceof TSourceToken))
    {
      this.d = ((TSourceToken)paramObject2);
      this.b = this.d.toString();
      return;
    }
    if ((paramObject2 instanceof TConstant))
    {
      this.e = ((TConstant)paramObject2);
      this.b = this.e.toString();
      return;
    }
    if ((paramObject2 instanceof TObjectNameList))
    {
      this.f = ((TObjectNameList)paramObject2);
      for (paramObject1 = 0; paramObject1 < this.f.size(); paramObject1++)
      {
        this.b += this.f.getObjectName(paramObject1).toString();
        if (paramObject1 != this.f.size() - 1) {
          this.b += ",";
        }
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TMySQLCreateTableOption.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */