package gudusoft.gsqlparser.nodes;

public class TAutomaticProperty
  extends TParseTreeNode
{}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TAutomaticProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */