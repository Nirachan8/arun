package gudusoft.gsqlparser.nodes;

public class TTypeAttributeList
  extends TParseTreeNodeList
{
  public void addAttributeItem(TTypeAttribute paramTTypeAttribute)
  {
    addElement(paramTTypeAttribute);
  }
  
  public TTypeAttribute getAttributeItem(int paramInt)
  {
    if (paramInt < size()) {
      return (TTypeAttribute)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addAttributeItem((TTypeAttribute)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      getAttributeItem(i).accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTypeAttributeList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */