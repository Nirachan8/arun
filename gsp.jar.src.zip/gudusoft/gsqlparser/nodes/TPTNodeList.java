package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;
import java.util.Vector;

public class TPTNodeList<E>
  extends TParseTreeNode
{
  private Vector a = new Vector();
  
  public void TPTNodeList() {}
  
  public final int size()
  {
    return this.a.size();
  }
  
  public E elementAt(int paramInt)
  {
    return (E)this.a.elementAt(paramInt);
  }
  
  public final void addElement(E paramE)
  {
    this.a.addElement(paramE);
  }
  
  public final void removeElementAt(int paramInt)
  {
    this.a.removeElementAt(paramInt);
  }
  
  public final void removeElement(E paramE)
  {
    this.a.removeElement(paramE);
  }
  
  final E a(int paramInt)
  {
    return (E)this.a.remove(0);
  }
  
  final void a()
  {
    this.a.removeAllElements();
  }
  
  public final void insertElementAt(E paramE, int paramInt)
  {
    this.a.insertElementAt(paramE, paramInt);
  }
  
  public void init(Object paramObject)
  {
    if (paramObject != null) {
      a(paramObject);
    }
  }
  
  private void a(E paramE)
  {
    addElement(paramE);
  }
  
  public void addNode(E paramE)
  {
    a(paramE);
  }
  
  public E getElement(int paramInt)
  {
    return (E)elementAt(paramInt);
  }
  
  public void appendList(TPTNodeList<E> paramTPTNodeList)
  {
    for (int i = 0; i < paramTPTNodeList.size(); i++) {
      addElement(paramTPTNodeList.getElement(i));
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    for (int i = 0; i < size(); i++) {
      if (elementAt(i) != null) {
        ((TParseTreeNode)elementAt(i)).doParse(paramTCustomSqlStatement, paramESqlClause);
      }
    }
  }
  
  public TSourceToken getStartToken()
  {
    if (size() == 0) {
      return null;
    }
    return ((TParseTreeNode)elementAt(0)).getStartToken();
  }
  
  public TSourceToken getEndToken()
  {
    if (size() == 0) {
      return null;
    }
    return ((TParseTreeNode)elementAt(size() - 1)).getEndToken();
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      if (elementAt(i) != null) {
        ((TParseTreeNode)elementAt(i)).accept(paramTParseTreeVisitor);
      }
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TPTNodeList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */