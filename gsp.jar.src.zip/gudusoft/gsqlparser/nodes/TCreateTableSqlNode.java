package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ETableSource;

public class TCreateTableSqlNode
  extends TParseTreeNode
{
  private TObjectName a;
  private TObjectName b;
  private TPTNodeList<TMySQLCreateTableOption> c;
  private TTable d = null;
  private TTableElementList e = null;
  private TObjectNameList f = null;
  private TSelectSqlNode g = null;
  
  public void setRowTypeName(TObjectName paramTObjectName)
  {
    this.a = paramTObjectName;
  }
  
  public void setSuperTableName(TObjectName paramTObjectName)
  {
    this.b = paramTObjectName;
  }
  
  public TObjectName getRowTypeName()
  {
    return this.a;
  }
  
  public TObjectName getSuperTableName()
  {
    return this.b;
  }
  
  public void setMySQLTableOptionList(TPTNodeList<TMySQLCreateTableOption> paramTPTNodeList)
  {
    this.c = paramTPTNodeList;
  }
  
  public TPTNodeList<TMySQLCreateTableOption> getMySQLTableOptionList()
  {
    return this.c;
  }
  
  public void setTableElementList(TTableElementList paramTTableElementList)
  {
    this.e = paramTTableElementList;
  }
  
  public TObjectNameList getColumnList()
  {
    return this.f;
  }
  
  public TTableElementList getTableElementList()
  {
    return this.e;
  }
  
  public TTable getTable()
  {
    return this.d;
  }
  
  public void setColumnList(TObjectNameList paramTObjectNameList)
  {
    this.f = paramTObjectNameList;
  }
  
  public TSelectSqlNode getSubQueryNode()
  {
    return this.g;
  }
  
  public void setSubQueryNode(TSelectSqlNode paramTSelectSqlNode)
  {
    this.g = paramTSelectSqlNode;
  }
  
  public void init(Object paramObject)
  {
    this.d = new TTable();
    ((TObjectName)paramObject).setObjectType(3);
    this.d.setTableName((TObjectName)paramObject);
    this.d.setTableType(ETableSource.objectname);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCreateTableSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */