package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TArrayAccess
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TExpression b = null;
  private TExpression c = null;
  private TExpression d = null;
  private TObjectName e = null;
  
  public TExpression getIndex3()
  {
    return this.d;
  }
  
  public TObjectName getArrayName()
  {
    return this.a;
  }
  
  public TExpression getIndex1()
  {
    return this.b;
  }
  
  public TExpression getIndex2()
  {
    return this.c;
  }
  
  public TObjectName getPropertyName()
  {
    return this.e;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4)
  {
    this.a = ((TObjectName)paramObject1);
    if ((paramObject2 instanceof TExpressionList)) {
      this.b = ((TExpressionList)paramObject2).getExpression(0);
    } else if ((paramObject3 instanceof TExpression)) {
      this.c = ((TExpression)paramObject3);
    }
    if (paramObject4 != null)
    {
      if ((paramObject4 instanceof TObjectName))
      {
        this.e = ((TObjectName)paramObject4);
        return;
      }
      if ((paramObject4 instanceof TExpression)) {
        this.d = ((TExpression)paramObject4);
      }
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if (this.c != null) {
      this.c.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if (this.d != null) {
      this.d.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TArrayAccess.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */