package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TMergeUpdateClause
  extends TParseTreeNode
{
  private TResultColumnList a;
  private TExpression b;
  private TExpression c;
  
  public TResultColumnList getUpdateColumnList()
  {
    return this.a;
  }
  
  public TExpression getUpdateWhereClause()
  {
    return this.b;
  }
  
  public TExpression getDeleteWhereClause()
  {
    return this.c;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.a = ((TResultColumnList)paramObject1);
    if (paramObject2 != null) {
      this.b = ((TExpression)paramObject2);
    }
    if (paramObject3 != null) {
      this.c = ((TExpression)paramObject3);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null) {
      this.a.doParse(paramTCustomSqlStatement, ESqlClause.set);
    }
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, ESqlClause.unknown);
    }
    if (this.c != null) {
      this.c.doParse(paramTCustomSqlStatement, ESqlClause.unknown);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TMergeUpdateClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */