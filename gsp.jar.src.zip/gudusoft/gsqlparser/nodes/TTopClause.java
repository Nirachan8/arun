package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class TTopClause
  extends TParseTreeNode
{
  private TExpression a = null;
  private TSelectSqlNode b = null;
  private TSelectSqlStatement c = null;
  private boolean d = false;
  private boolean e = false;
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TExpression))
    {
      this.a = ((TExpression)paramObject);
      return;
    }
    if ((paramObject instanceof TSelectSqlNode)) {
      this.b = ((TSelectSqlNode)paramObject);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null) {
      this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if ((this.b != null) && (this.c != null))
    {
      this.c = new TSelectSqlStatement(paramTCustomSqlStatement.dbvendor);
      this.c.rootNode = this.b;
      this.c.doParseStatement(paramTCustomSqlStatement);
    }
  }
  
  public TSelectSqlStatement getSubquery()
  {
    return this.c;
  }
  
  public TExpression getExpr()
  {
    return this.a;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
  
  public void setPercent(boolean paramBoolean)
  {
    this.d = paramBoolean;
  }
  
  public void setWithties(boolean paramBoolean)
  {
    this.e = paramBoolean;
  }
  
  public boolean isPercent()
  {
    return this.d;
  }
  
  public boolean isWithties()
  {
    return this.e;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTopClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */