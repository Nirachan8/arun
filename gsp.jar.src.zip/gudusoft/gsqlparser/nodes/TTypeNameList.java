package gudusoft.gsqlparser.nodes;

public class TTypeNameList
  extends TParseTreeNodeList
{
  public void addTypeName(TTypeName paramTTypeName)
  {
    addElement(paramTTypeName);
  }
  
  public TTypeName getTypeName(int paramInt)
  {
    if (paramInt < size()) {
      return (TTypeName)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addTypeName((TTypeName)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      getTypeName(i).accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTypeNameList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */