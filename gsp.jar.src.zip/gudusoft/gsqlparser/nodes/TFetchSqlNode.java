package gudusoft.gsqlparser.nodes;

public class TFetchSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TObjectNameList b = null;
  
  public TObjectName getCursorName()
  {
    return this.a;
  }
  
  public TObjectNameList getVariableNames()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TObjectName)paramObject1);
    this.a.setObjectType(17);
    if (paramObject2 != null)
    {
      this.b = ((TObjectNameList)paramObject2);
      for (paramObject1 = 0; paramObject1 < this.b.size(); paramObject1++) {
        this.b.getObjectName(paramObject1).setObjectType(10);
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TFetchSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */