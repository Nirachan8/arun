package gudusoft.gsqlparser.nodes;

public class TObjectAccess
  extends TParseTreeNode
{
  private TExpression a;
  private TFunctionCall b;
  private TObjectNameList c;
  
  public TObjectNameList getAttributes()
  {
    return this.c;
  }
  
  public TFunctionCall getMethod()
  {
    return this.b;
  }
  
  public TExpression getObjectExpr()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.a = ((TExpression)paramObject1);
    this.c = ((TObjectNameList)paramObject2);
    this.b = ((TFunctionCall)paramObject3);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TObjectAccess.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */