package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EDataType;
import gudusoft.gsqlparser.ETokenType;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;

public class TTypeName
  extends TParseTreeNode
{
  private EDataType a = EDataType.unknown_t;
  private TConstant b;
  private TConstant c;
  private TConstant d;
  private TConstant e;
  private TConstant f;
  private TConstant g;
  private TConstant h;
  private TPTNodeList<TIndices> i;
  private TPTNodeList<TDatatypeAttribute> j;
  private int k = 2;
  /**
   * @deprecated
   */
  public static final int lfdUnknown = 2;
  /**
   * @deprecated
   */
  public static final int lfdGeneric = 3;
  /**
   * @deprecated
   */
  public static final int lfdFloat = 4;
  /**
   * @deprecated
   */
  public static final int lfdDoublePrecision = 8;
  /**
   * @deprecated
   */
  public static final int lfdDecimal = 9;
  /**
   * @deprecated
   */
  public static final int lfdDec = 10;
  /**
   * @deprecated
   */
  public static final int lfdNumeric = 11;
  /**
   * @deprecated
   */
  public static final int lfdnumber = 12;
  /**
   * @deprecated
   */
  public static final int lfdNum = 13;
  /**
   * @deprecated
   */
  public static final int lfdInteger = 14;
  /**
   * @deprecated
   */
  public static final int lfdBit = 22;
  /**
   * @deprecated
   */
  public static final int lfdBoolean = 23;
  /**
   * @deprecated
   */
  public static final int lfdVarbinary = 33;
  /**
   * @deprecated
   */
  public static final int lfdBinary = 34;
  /**
   * @deprecated
   */
  public static final int lfdInt = 40;
  /**
   * @deprecated
   */
  public static final int lfdSmallint = 41;
  /**
   * @deprecated
   */
  public static final int lfdReal = 42;
  /**
   * @deprecated
   */
  public static final int lfdTinyInt = 43;
  /**
   * @deprecated
   */
  public static final int lfdBigInt = 45;
  /**
   * @deprecated
   */
  public static final int lfdCharacter = 46;
  /**
   * @deprecated
   */
  public static final int lfdChar = 47;
  /**
   * @deprecated
   */
  public static final int lfdVarchar = 48;
  /**
   * @deprecated
   */
  public static final int lfdVarchar2 = 49;
  /**
   * @deprecated
   */
  public static final int lfdLongvarchar = 56;
  /**
   * @deprecated
   */
  public static final int lfdLongvarbinary = 57;
  /**
   * @deprecated
   */
  public static final int lfdYear = 59;
  /**
   * @deprecated
   */
  public static final int lfdNationalChar = 61;
  /**
   * @deprecated
   */
  public static final int lfdNchar = 62;
  /**
   * @deprecated
   */
  public static final int lfdDate = 63;
  /**
   * @deprecated
   */
  public static final int lfdTimestamp = 64;
  /**
   * @deprecated
   */
  public static final int lfdTimeStampWithTZ = 65;
  /**
   * @deprecated
   */
  public static final int lfdTimeStampWithLTZ = 66;
  /**
   * @deprecated
   */
  public static final int lfdTime = 68;
  /**
   * @deprecated
   */
  public static final int lfdDatetime = 69;
  /**
   * @deprecated
   */
  public static final int lfdIntervalYTM = 71;
  /**
   * @deprecated
   */
  public static final int lfdIntervalDTS = 72;
  /**
   * @deprecated
   */
  public static final int lfdLong = 73;
  /**
   * @deprecated
   */
  public static final int lfdRaw = 74;
  /**
   * @deprecated
   */
  public static final int lfdLongRaw = 75;
  /**
   * @deprecated
   */
  public static final int lfdBlob = 76;
  /**
   * @deprecated
   */
  public static final int lfdClob = 77;
  /**
   * @deprecated
   */
  public static final int lfdNClob = 78;
  /**
   * @deprecated
   */
  public static final int lfdBfile = 79;
  /**
   * @deprecated
   */
  public static final int lfdTinyblob = 81;
  /**
   * @deprecated
   */
  public static final int lfdMediumblob = 82;
  /**
   * @deprecated
   */
  public static final int lfdLongblob = 83;
  /**
   * @deprecated
   */
  public static final int lfdTinytext = 84;
  /**
   * @deprecated
   */
  public static final int lfdText = 85;
  /**
   * @deprecated
   */
  public static final int lfdntext = 86;
  /**
   * @deprecated
   */
  public static final int lfdMediumtext = 88;
  /**
   * @deprecated
   */
  public static final int lfdLongtext = 89;
  /**
   * @deprecated
   */
  public static final int lfdURowid = 90;
  /**
   * @deprecated
   */
  public static final int lfdEnum = 91;
  /**
   * @deprecated
   */
  public static final int lfdBinaryLargeObject = 102;
  /**
   * @deprecated
   */
  public static final int lfdGraphic = 103;
  /**
   * @deprecated
   */
  public static final int lfdVarGraphic = 104;
  /**
   * @deprecated
   */
  public static final int lfdLongVarGraphic = 105;
  /**
   * @deprecated
   */
  public static final int lfdDatalink = 106;
  /**
   * @deprecated
   */
  public static final int lfdBinaryInteger = 107;
  /**
   * @deprecated
   */
  public static final int lfdPlsInteger = 108;
  /**
   * @deprecated
   */
  public static final int lfdByteint = 120;
  /**
   * @deprecated
   */
  public static final int lfdTimeWithTZ = 121;
  /**
   * @deprecated
   */
  public static final int lfdIntervalYear = 130;
  /**
   * @deprecated
   */
  public static final int lfdIntervalYearToMonth = 131;
  /**
   * @deprecated
   */
  public static final int lfdIntervalMonth = 132;
  /**
   * @deprecated
   */
  public static final int lfdIntervalDay = 133;
  /**
   * @deprecated
   */
  public static final int lfdIntervalDayToHour = 134;
  /**
   * @deprecated
   */
  public static final int lfdIntervalDayToMinute = 135;
  /**
   * @deprecated
   */
  public static final int lfdIntervalDayToSecond = 136;
  /**
   * @deprecated
   */
  public static final int lfdIntervalHour = 137;
  /**
   * @deprecated
   */
  public static final int lfdIntervalHourToMinute = 138;
  /**
   * @deprecated
   */
  public static final int lfdIntervalHourToSecond = 139;
  /**
   * @deprecated
   */
  public static final int lfdIntervalMinute = 140;
  /**
   * @deprecated
   */
  public static final int lfdIntervalMinuteToSecond = 141;
  /**
   * @deprecated
   */
  public static final int lfdIntervalSecond = 142;
  /**
   * @deprecated
   */
  public static final int lfdByte = 143;
  /**
   * @deprecated
   */
  public static final int lfdVarByte = 144;
  /**
   * @deprecated
   */
  public static final int lfdCharacterVarying = 145;
  /**
   * @deprecated
   */
  public static final int lfdCharVarying = 146;
  /**
   * @deprecated
   */
  public static final int lfdPeriod = 147;
  /**
   * @deprecated
   */
  public static final int lfdCharacterLargeObject = 148;
  /**
   * @deprecated
   */
  public static final int lfdGeoMetry = 150;
  /**
   * @deprecated
   */
  public static final int lfdGeoGraphy = 151;
  /**
   * @deprecated
   */
  public static final int lfdNationalCharVarying = 162;
  /**
   * @deprecated
   */
  public static final int lfdNcharVarying = 163;
  /**
   * @deprecated
   */
  public static final int lfdSet = 164;
  /**
   * @deprecated
   */
  public static final int lfdCharLargeObject = 171;
  /**
   * @deprecated
   */
  public static final int lfdDBClob = 172;
  /**
   * @deprecated
   */
  public static final int lfdInterval = 181;
  /**
   * @deprecated
   */
  public static final int lfdTypeAtribute = 107;
  /**
   * @deprecated
   */
  public static final int lfdRowTypeAtribute = 108;
  
  public void setDataTypeByToken(TSourceToken paramTSourceToken)
  {
    if (paramTSourceToken == null) {
      return;
    }
    if (paramTSourceToken.toString().equalsIgnoreCase("simple_integer"))
    {
      this.a = EDataType.simple_integer_t;
      return;
    }
    if (paramTSourceToken.toString().equalsIgnoreCase("double_precision"))
    {
      this.a = EDataType.double_precision_t;
      return;
    }
    if (paramTSourceToken.toString().equalsIgnoreCase("long_raw"))
    {
      this.a = EDataType.long_raw_t;
      return;
    }
    if (paramTSourceToken.toString().equalsIgnoreCase("rowid"))
    {
      this.a = EDataType.rowid_t;
      return;
    }
    if (paramTSourceToken.toString().equalsIgnoreCase("string"))
    {
      this.a = EDataType.string_t;
      return;
    }
    if (paramTSourceToken.toString().equalsIgnoreCase("boolean"))
    {
      this.a = EDataType.boolean_t;
      return;
    }
    if (paramTSourceToken.toString().equalsIgnoreCase("signtype"))
    {
      this.a = EDataType.signtype_t;
      return;
    }
    if (paramTSourceToken.toString().equalsIgnoreCase("nvarchar")) {
      this.a = EDataType.nvarchar_t;
    }
  }
  
  public void setDataType(EDataType paramEDataType)
  {
    this.a = paramEDataType;
  }
  
  public EDataType getDataType()
  {
    return this.a;
  }
  
  public void setStart(TConstant paramTConstant)
  {
    this.b = paramTConstant;
  }
  
  public TConstant getStart()
  {
    return this.b;
  }
  
  public void setMax(TConstant paramTConstant)
  {
    this.c = paramTConstant;
  }
  
  public void setReserve(TConstant paramTConstant)
  {
    this.d = paramTConstant;
  }
  
  public TConstant getMax()
  {
    return this.c;
  }
  
  public TConstant getReserve()
  {
    return this.d;
  }
  
  public void setLength(TConstant paramTConstant)
  {
    this.e = paramTConstant;
  }
  
  public TConstant getLength()
  {
    return this.e;
  }
  
  public TConstant getSecondsPrecision()
  {
    return this.h;
  }
  
  public void setPrecision(TConstant paramTConstant)
  {
    this.f = paramTConstant;
  }
  
  public TConstant getScale()
  {
    return this.g;
  }
  
  public TConstant getPrecision()
  {
    return this.f;
  }
  
  public void setScale(TConstant paramTConstant)
  {
    this.g = paramTConstant;
  }
  
  public void setPrecisionScale(TPrecisionScale paramTPrecisionScale)
  {
    if (paramTPrecisionScale != null)
    {
      this.f = paramTPrecisionScale.getPrecision();
      this.g = paramTPrecisionScale.getScale();
    }
  }
  
  public TPTNodeList<TIndices> getArrays()
  {
    return this.i;
  }
  
  public void setArrays(TPTNodeList<TIndices> paramTPTNodeList)
  {
    this.i = paramTPTNodeList;
  }
  
  public void setDatatypeAttributeList(TPTNodeList<TDatatypeAttribute> paramTPTNodeList)
  {
    this.j = paramTPTNodeList;
  }
  
  public TPTNodeList<TDatatypeAttribute> getDatatypeAttributeList()
  {
    if (this.j == null) {
      this.j = new TPTNodeList();
    }
    return this.j;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    init(paramObject1, paramObject2);
    if (paramObject3 != null) {
      switch (1.a[this.a.ordinal()])
      {
      case 1: 
        
      case 2: 
      case 3: 
      case 4: 
      case 5: 
        this.h = ((TConstant)paramObject3);
      }
    }
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    init(paramObject1);
    if (paramObject2 != null)
    {
      if ((paramObject2 instanceof TPrecisionScale))
      {
        this.f = ((TPrecisionScale)paramObject2).getPrecision();
        this.g = ((TPrecisionScale)paramObject2).getScale();
        if (this.a == EDataType.period_t) {
          this.h = ((TPrecisionScale)paramObject2).getPrecision();
        }
      }
      else if ((paramObject2 instanceof TDummy))
      {
        this.e = ((TConstant)((TDummy)paramObject2).node1);
      }
      else if ((paramObject2 instanceof TConstant))
      {
        this.e = ((TConstant)paramObject2);
      }
      switch (1.a[this.a.ordinal()])
      {
      case 1: 
      case 2: 
      case 3: 
      case 4: 
      case 5: 
      case 6: 
      case 7: 
      case 8: 
      case 9: 
      case 10: 
      case 11: 
        this.f = ((TConstant)paramObject2);
        this.e = null;
      }
    }
  }
  
  public void init(Object paramObject)
  {
    this.a = ((EDataType)paramObject);
  }
  
  public void setVarying(TSourceToken paramTSourceToken)
  {
    if (paramTSourceToken != null) {
      switch (1.a[this.a.ordinal()])
      {
      case 12: 
        this.a = EDataType.varchar_t;
        return;
      case 13: 
        this.a = EDataType.nvarchar_t;
        return;
      case 14: 
        this.a = EDataType.varbit_t;
      }
    }
  }
  
  public void setDataTypeInTokens()
  {
    if (getStartToken() == null) {
      return;
    }
    if (getEndToken() == null) {
      return;
    }
    TSourceTokenList localTSourceTokenList = getStartToken().container;
    int m = 0;
    for (int n = getStartToken().posinlist; n <= getEndToken().posinlist; n++)
    {
      TSourceToken localTSourceToken;
      if ((localTSourceToken = localTSourceTokenList.get(n)).tokentype == ETokenType.ttleftparenthesis) {
        m++;
      } else if (localTSourceToken.tokentype == ETokenType.ttrightparenthesis) {
        m--;
      } else if (m == 0) {
        localTSourceToken.setDbObjType(30);
      }
    }
    if (((this.k == 3) || (this.a == EDataType.generic_t)) && (getStartToken().toString().equalsIgnoreCase("datetime")))
    {
      this.k = 69;
      this.a = EDataType.datetime_t;
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
  
  public void setType(int paramInt)
  {
    this.k = paramInt;
  }
  
  public int getType()
  {
    return this.k;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTypeName.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */