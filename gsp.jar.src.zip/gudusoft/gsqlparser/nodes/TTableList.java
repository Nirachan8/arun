package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ETableSource;
import gudusoft.gsqlparser.TSourceToken;

public class TTableList
  extends TParseTreeNodeList
{
  public void addTable(TTable paramTTable)
  {
    addElement(paramTTable);
  }
  
  public void addTableByTableRefernce(TTableReference paramTTableReference)
  {
    int i = 0;
    for (int j = 0; j < size(); j++) {
      if (getTable(j).isTableRefBelongToThisTable(paramTTableReference))
      {
        getTable(j).tablerefs.addTableReference(paramTTableReference);
        i = 1;
        break;
      }
    }
    if (i == 0) {
      addTable(new TTable(paramTTableReference.objectname));
    }
  }
  
  public TTable getTable(int paramInt)
  {
    if (paramInt < size()) {
      return (TTable)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addTable((TTable)paramObject);
  }
  
  public int checkColumnReferenceInTables(TObjectName paramTObjectName)
  {
    if (paramTObjectName.getObjectToken() == null) {
      return -2;
    }
    for (int i = 0; i < size(); i++)
    {
      TTable localTTable;
      if ((localTTable = getTable(i)).getAliasClause() != null)
      {
        if (localTTable.getAliasClause().toString().compareToIgnoreCase(paramTObjectName.getObjectToken().toString()) == 0)
        {
          paramTObjectName.getObjectToken().setDbObjType(4);
          return i;
        }
      }
      else if ((localTTable.getTableType() == ETableSource.objectname) && (localTTable.getTableName().getObjectToken().toString().compareToIgnoreCase(paramTObjectName.getObjectToken().toString()) == 0))
      {
        paramTObjectName.getObjectToken().setDbObjType(3);
        return i;
      }
    }
    return -1;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTableList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */