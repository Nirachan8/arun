package gudusoft.gsqlparser.nodes;

public class TDeclareVariable
  extends TParseTreeNode
{
  private TObjectName a = null;
  private int b = 1;
  private TTypeName c = null;
  private TExpression d = null;
  private TTableElementList e = null;
  
  public void setTableTypeDefinitions(TTableElementList paramTTableElementList)
  {
    this.e = paramTTableElementList;
  }
  
  public void setVariableType(int paramInt)
  {
    this.b = paramInt;
  }
  
  public TTableElementList getTableTypeDefinitions()
  {
    return this.e;
  }
  
  public void setDefaultValue(TExpression paramTExpression)
  {
    this.d = paramTExpression;
  }
  
  public TTypeName getDatatype()
  {
    return this.c;
  }
  
  public TExpression getDefaultValue()
  {
    return this.d;
  }
  
  public TObjectName getVariableName()
  {
    return this.a;
  }
  
  public int getVariableType()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TObjectName)paramObject);
  }
  
  public void setDatatype(TTypeName paramTTypeName)
  {
    this.c = paramTTypeName;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    init(paramObject1);
    if (paramObject2 != null)
    {
      if ((paramObject1 = (TTypeName)paramObject2).toString().equalsIgnoreCase("cursor"))
      {
        this.b = 2;
      }
      else
      {
        this.b = 1;
        this.c = ((TTypeName)paramObject2);
      }
    }
    else {
      this.b = 3;
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDeclareVariable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */