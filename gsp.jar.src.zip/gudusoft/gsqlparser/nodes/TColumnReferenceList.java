package gudusoft.gsqlparser.nodes;

public class TColumnReferenceList
  extends TParseTreeNodeList
{
  public void addColumnReference(TColumnReference paramTColumnReference)
  {
    addElement(paramTColumnReference);
  }
  
  public TColumnReference getColumnReference(int paramInt)
  {
    if (paramInt < size()) {
      return (TColumnReference)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addColumnReference((TColumnReference)paramObject);
  }
  
  public int searchColumnReference(TColumnReference paramTColumnReference)
  {
    int i = -1;
    for (int j = 0; j < size(); j++) {
      if (getColumnReference(j).toString().compareToIgnoreCase(paramTColumnReference.toString()) == 0)
      {
        i = j;
        break;
      }
    }
    return i;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TColumnReferenceList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */