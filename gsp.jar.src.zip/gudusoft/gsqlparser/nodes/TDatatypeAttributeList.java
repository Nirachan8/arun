package gudusoft.gsqlparser.nodes;

public class TDatatypeAttributeList
  extends TParseTreeNodeList
{
  public void addDatatypeAttribute(TDatatypeAttribute paramTDatatypeAttribute)
  {
    addElement(paramTDatatypeAttribute);
  }
  
  public TDatatypeAttribute getDatatypeAttribute(int paramInt)
  {
    if (paramInt < size()) {
      return (TDatatypeAttribute)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addDatatypeAttribute((TDatatypeAttribute)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDatatypeAttributeList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */