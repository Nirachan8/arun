package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TColumnReference
  extends TParseTreeNode
{
  public TObjectName objectname;
  public TSourceToken sourcetoken;
  
  public TSourceToken getObjectToken()
  {
    if (this.objectname == null) {
      return null;
    }
    TSourceToken localTSourceToken;
    return localTSourceToken = this.objectname.getObjectToken();
  }
  
  public TColumnReference() {}
  
  public TColumnReference(TObjectName paramTObjectName)
  {
    this.objectname = paramTObjectName;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TObjectName))
    {
      this.objectname = ((TObjectName)paramObject);
      return;
    }
    if ((paramObject instanceof TSourceToken)) {
      this.sourcetoken = ((TSourceToken)paramObject);
    }
  }
  
  public String getColumnNameOnly()
  {
    if (this.objectname != null) {
      return this.objectname.getPartToken().toString();
    }
    if (this.sourcetoken != null) {
      return this.sourcetoken.toString();
    }
    return null;
  }
  
  public long getColumns()
  {
    if (this.objectname != null) {
      return this.objectname.getColumnNo();
    }
    if (this.sourcetoken != null) {
      return this.sourcetoken.columnNo;
    }
    return -1L;
  }
  
  public long getLines()
  {
    if (this.objectname != null) {
      return this.objectname.getLineNo();
    }
    if (this.sourcetoken != null) {
      return this.sourcetoken.lineNo;
    }
    return -1L;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TColumnReference.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */