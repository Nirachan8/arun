package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.nodes.oracle.TInvokerRightsClause;
import gudusoft.gsqlparser.stmt.oracle.TExceptionClause;

public class TCreatePackageSqlNode
  extends TParseTreeNode
{
  private TInvokerRightsClause a;
  private TObjectName b = null;
  private int c = 1;
  private TStatementListSqlNode d = null;
  private TExceptionClause e = null;
  private TStatementListSqlNode f = null;
  
  public void setInvokerRightsClause(TInvokerRightsClause paramTInvokerRightsClause)
  {
    this.a = paramTInvokerRightsClause;
  }
  
  public TInvokerRightsClause getInvokerRightsClause()
  {
    return this.a;
  }
  
  public TObjectName getPackageName()
  {
    return this.b;
  }
  
  public int getKind()
  {
    return this.c;
  }
  
  public void setKind(int paramInt)
  {
    this.c = paramInt;
  }
  
  public void setStmts(TStatementListSqlNode paramTStatementListSqlNode)
  {
    this.d = paramTStatementListSqlNode;
  }
  
  public TStatementListSqlNode getDefinitions_or_declarations()
  {
    return this.f;
  }
  
  public TExceptionClause getExceptionClause()
  {
    return this.e;
  }
  
  public TStatementListSqlNode getStmts()
  {
    return this.d;
  }
  
  public void setExceptionClause(TExceptionClause paramTExceptionClause)
  {
    this.e = paramTExceptionClause;
  }
  
  public void setDefinitions_or_declarations(TStatementListSqlNode paramTStatementListSqlNode)
  {
    this.f = paramTStatementListSqlNode;
  }
  
  public void init(Object paramObject)
  {
    this.b = ((TObjectName)paramObject);
    this.b.setObjectType(28);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCreatePackageSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */