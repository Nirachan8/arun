package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EJoinType;

public class TJoinItem
  extends TParseTreeNode
{
  private int a;
  private TJoin b;
  private TTable c;
  private TObjectNameList d;
  private TExpression e;
  private EJoinType f;
  
  public TJoin getJoin()
  {
    return this.b;
  }
  
  public EJoinType getJoinType()
  {
    return this.f;
  }
  
  public TTable getTable()
  {
    return this.c;
  }
  
  public void setJoin(TJoin paramTJoin)
  {
    this.b = paramTJoin;
  }
  
  public void setKind(int paramInt)
  {
    this.a = paramInt;
  }
  
  public int getKind()
  {
    return this.a;
  }
  
  public void setTable(TTable paramTTable)
  {
    this.c = paramTTable;
  }
  
  public void setUsingColumns(TObjectNameList paramTObjectNameList)
  {
    this.d = paramTObjectNameList;
  }
  
  public TObjectNameList getUsingColumns()
  {
    return this.d;
  }
  
  public void setOnCondition(TExpression paramTExpression)
  {
    this.e = paramTExpression;
  }
  
  public TExpression getOnCondition()
  {
    return this.e;
  }
  
  public void setJoinType(EJoinType paramEJoinType)
  {
    this.f = paramEJoinType;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TJoinItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */