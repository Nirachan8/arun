package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TForUpdate
  extends TParseTreeNode
{
  private TObjectNameList a;
  
  public TObjectNameList getColumnRefs()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TObjectNameList)paramObject);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null) {
      this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TForUpdate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */