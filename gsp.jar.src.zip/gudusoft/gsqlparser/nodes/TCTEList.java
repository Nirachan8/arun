package gudusoft.gsqlparser.nodes;

public class TCTEList
  extends TParseTreeNodeList
{
  public void addCTE(TCTE paramTCTE)
  {
    addElement(paramTCTE);
  }
  
  public TCTE getCTE(int paramInt)
  {
    if (paramInt < size()) {
      return (TCTE)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addCTE((TCTE)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      getCTE(i).accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCTEList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */