package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EDataTypeAttribute;

public class TDatatypeAttribute
  extends TParseTreeNode
{
  private EDataTypeAttribute a = EDataTypeAttribute.unknown_t;
  private String b;
  private TObjectName c;
  private TConstant d;
  
  public void setType(EDataTypeAttribute paramEDataTypeAttribute)
  {
    this.a = paramEDataTypeAttribute;
  }
  
  public EDataTypeAttribute getType()
  {
    return this.a;
  }
  
  public String getValue()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((EDataTypeAttribute)paramObject);
  }
  
  public TConstant getValue_literal()
  {
    return this.d;
  }
  
  public TObjectName getValue_identifier()
  {
    return this.c;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    init(paramObject1);
    if ((paramObject2 instanceof TObjectName))
    {
      this.c = ((TObjectName)paramObject2);
      this.b = this.c.toString();
      return;
    }
    if ((paramObject2 instanceof TConstant))
    {
      this.d = ((TConstant)paramObject2);
      this.b = this.d.toString();
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDatatypeAttribute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */