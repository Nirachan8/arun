package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EDataTypeAttribute;
import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.EExpressionType;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomParser;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;

public class TResultColumn
  extends TNodeWithAliasClause
{
  private TExpression a = null;
  private boolean b = false;
  
  public void TResultColumn() {}
  
  public void setPlaceHolder(boolean paramBoolean)
  {
    this.b = paramBoolean;
  }
  
  public boolean isPlaceHolder()
  {
    return this.b;
  }
  
  public TExpression getExpr()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TExpression)) {
      this.a = ((TExpression)paramObject);
    }
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    init(paramObject1);
    if ((paramObject2 instanceof TAliasClause))
    {
      setAliasClause((TAliasClause)paramObject2);
      ((TAliasClause)paramObject2).getAliasName().setObjectType(2);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (isPlaceHolder()) {
      return;
    }
    if ((paramTCustomSqlStatement.dbvendor == EDbVendor.dbvteradata) && (this.a.getOutputFormatPhraseList() != null))
    {
      int i = 0;
      Object localObject;
      int j;
      if ((this.a.getOutputFormatPhraseList().size() == 1) && ((localObject = this.a.getOutputFormatPhraseList().getOutputFormatPhrase(0)).getDatatypeAttribute() != null) && ((localObject = ((TOutputFormatPhrase)localObject).getDatatypeAttribute()).getType() == EDataTypeAttribute.named_t))
      {
        TAliasClause localTAliasClause = new TAliasClause();
        if (((TDatatypeAttribute)localObject).getValue_literal() != null)
        {
          localTAliasClause.init(((TDatatypeAttribute)localObject).getValue_literal());
          localTAliasClause.setStartToken(((TDatatypeAttribute)localObject).getValue_literal().getStartToken());
          localTAliasClause.setEndToken(((TDatatypeAttribute)localObject).getValue_literal().getEndToken());
        }
        else if (((TDatatypeAttribute)localObject).getValue_identifier() != null)
        {
          localTAliasClause.init(((TDatatypeAttribute)localObject).getValue_identifier());
          localTAliasClause.setStartToken(((TDatatypeAttribute)localObject).getValue_identifier());
          localTAliasClause.setEndToken(((TDatatypeAttribute)localObject).getValue_identifier());
        }
        localTAliasClause.setTeradataNamedAlais(true);
        localTAliasClause.setAsToken(((TDatatypeAttribute)localObject).getStartToken());
        setAliasClause(localTAliasClause);
        j = 1;
      }
      if (j == 0) {
        this.a.setEndToken(this.a.getOutputFormatPhraseList().getEndToken());
      }
    }
    if ((paramESqlClause == ESqlClause.set) && (this.a.getExpressionType() == EExpressionType.function_t))
    {
      this.a.getFunctionCall().getFunctionName().setObjectType(11);
      paramTCustomSqlStatement.linkColumnReferenceToTable(paramTCustomSqlStatement.parser.nf.createObjectName(null, null, this.a.getFunctionCall().getFunctionName().getPartToken()), paramESqlClause);
      return;
    }
    if ((this.a.getExpressionType() == EExpressionType.simple_comparison_t) && ((paramTCustomSqlStatement.dbvendor == EDbVendor.dbvmssql) || (paramTCustomSqlStatement.dbvendor == EDbVendor.dbvsybase)) && (paramESqlClause == ESqlClause.resultColumn))
    {
      if ((this.a.getComparisonOperator().toString().equalsIgnoreCase("=")) && (!this.a.getLeftOperand().toString().startsWith("@"))) {
        this.a.setExpressionType(EExpressionType.sqlserver_proprietary_column_alias_t);
      }
      this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    }
    this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
  }
  
  public TObjectName getFieldAttr()
  {
    TObjectName localTObjectName = null;
    if (this.a.getExpressionType() == EExpressionType.simple_object_name_t) {
      localTObjectName = this.a.getObjectOperand();
    }
    return localTObjectName;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TResultColumn.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */