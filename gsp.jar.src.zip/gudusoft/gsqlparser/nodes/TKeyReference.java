package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EKeyReferenceType;

public class TKeyReference
  extends TParseTreeNode
{
  private EKeyReferenceType a;
  
  public void setReferenceType(EKeyReferenceType paramEKeyReferenceType)
  {
    this.a = paramEKeyReferenceType;
  }
  
  public EKeyReferenceType getReferenceType()
  {
    return this.a;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TKeyReference.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */