package gudusoft.gsqlparser.nodes;

public class TTypeAttribute
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TTypeName b = null;
  
  public TObjectName getAttributeName()
  {
    return this.a;
  }
  
  public TTypeName getDatatype()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TObjectName)paramObject1);
    this.b = ((TTypeName)paramObject2);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTypeAttribute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */