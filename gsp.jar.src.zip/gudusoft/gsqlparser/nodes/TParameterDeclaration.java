package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EDbVendor;
import gudusoft.gsqlparser.TSourceToken;

public class TParameterDeclaration
  extends TParseTreeNode
{
  private int a = 0;
  private boolean b = false;
  private TObjectName c = null;
  private TTypeName d = null;
  private TExpression e = null;
  private int f = 0;
  private Boolean g = Boolean.valueOf(false);
  private boolean h = false;
  private TConstant i = null;
  
  public void setNocopy(boolean paramBoolean)
  {
    this.b = paramBoolean;
  }
  
  public TTypeName getDataType()
  {
    return this.d;
  }
  
  public boolean isNocopy()
  {
    return this.b;
  }
  
  public void setMode(int paramInt)
  {
    this.a = paramInt;
  }
  
  public int getMode()
  {
    return this.a;
  }
  
  public TExpression getDefaultValue()
  {
    return this.e;
  }
  
  public TObjectName getParameterName()
  {
    return this.c;
  }
  
  public void setNotNull(Boolean paramBoolean)
  {
    this.g = paramBoolean;
  }
  
  public Boolean getNotNull()
  {
    return this.g;
  }
  
  public int getHowtoSetValue()
  {
    return this.f;
  }
  
  public boolean isVarying()
  {
    return this.h;
  }
  
  public TConstant getVaryPrecision()
  {
    return this.i;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    if (paramObject1 != null)
    {
      this.c = ((TObjectName)paramObject1);
      this.c.setObjectType(9);
    }
    this.d = ((TTypeName)paramObject2);
    if (paramObject3 != null) {
      if (((paramObject1 = (TDummy)paramObject3).dbvendor == EDbVendor.dbvoracle) || (((TDummy)paramObject1).dbvendor == EDbVendor.dbvdb2))
      {
        if (((TDummy)paramObject1).int1 == 1)
        {
          this.e = ((TExpression)((TDummy)paramObject1).node1);
          this.f = ((TDummy)paramObject1).int1;
          return;
        }
        if (((TDummy)paramObject1).int1 == 2)
        {
          this.e = ((TExpression)((TDummy)paramObject1).node1);
          this.f = ((TDummy)paramObject1).int1;
        }
      }
      else if ((((TDummy)paramObject1).dbvendor == EDbVendor.dbvmssql) || (((TDummy)paramObject1).dbvendor == EDbVendor.dbvsybase))
      {
        if (((TDummy)paramObject1).st2 != null)
        {
          this.h = true;
          if (((TDummy)paramObject1).node2 != null) {
            this.i = ((TConstant)((TDummy)((TDummy)paramObject1).node2).node1);
          }
        }
        this.f = ((TDummy)paramObject1).int1;
        if (((TDummy)paramObject1).node1 != null) {
          this.e = ((TExpression)((TDummy)paramObject1).node1);
        }
        if (((TDummy)paramObject1).st1 != null)
        {
          if (((TDummy)paramObject1).st1.toString().equalsIgnoreCase("out")) {
            this.a = 2;
          } else if (((TDummy)paramObject1).st1.toString().equalsIgnoreCase("output")) {
            this.a = 4;
          }
          if (((TDummy)paramObject1).st1.toString().equalsIgnoreCase("readonly")) {
            this.a = 5;
          }
        }
      }
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TParameterDeclaration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */