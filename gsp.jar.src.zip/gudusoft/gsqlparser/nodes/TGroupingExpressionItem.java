package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

/**
 * @deprecated
 */
public class TGroupingExpressionItem
  extends TParseTreeNode
{
  private TExpression a;
  private TExpressionList b;
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TExpression))
    {
      this.a = ((TExpression)paramObject);
      return;
    }
    if ((paramObject instanceof TExpressionList)) {
      this.b = ((TExpressionList)paramObject);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null)
    {
      this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    }
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
  
  public TExpression getExpr()
  {
    return this.a;
  }
  
  public TExpressionList getExprList()
  {
    return this.b;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TGroupingExpressionItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */