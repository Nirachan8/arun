package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TTableElement
  extends TParseTreeNode
{
  public static final int type_column_def = 1;
  public static final int type_table_constraint = 2;
  private int a = 1;
  private TColumnDefinition b = null;
  private TConstraint c = null;
  
  public TConstraint getConstraint()
  {
    return this.c;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TColumnDefinition))
    {
      this.b = ((TColumnDefinition)paramObject);
      this.a = 1;
      return;
    }
    if ((paramObject instanceof TConstraint))
    {
      this.c = ((TConstraint)paramObject);
      this.a = 2;
    }
  }
  
  public TColumnDefinition getColumnDefinition()
  {
    return this.b;
  }
  
  public int getType()
  {
    return this.a;
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if (this.c != null) {
      this.c.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTableElement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */