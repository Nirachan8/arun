package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ETableSource;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlCreateTrigger;

public class TSimpleDmlTriggerClause
  extends TParseTreeNode
{
  private TDmlEventClause a = null;
  private TDummy b = null;
  private int c = 2;
  
  public TDmlEventClause getDmlEventClause()
  {
    return this.a;
  }
  
  public int getFireMode()
  {
    return this.c;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TDmlEventClause)paramObject1);
    this.b = ((TDummy)paramObject2);
    if (this.b.toString().startsWith("after"))
    {
      this.c = 2;
      return;
    }
    if (this.b.toString().startsWith("before"))
    {
      this.c = 1;
      return;
    }
    if (this.b.toString().startsWith("instead")) {
      this.c = 3;
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if ((paramTCustomSqlStatement instanceof TPlsqlCreateTrigger))
    {
      (paramESqlClause = new TTable()).setTableType(ETableSource.objectname);
      paramESqlClause.setTableName(this.a.getTableName());
      paramTCustomSqlStatement.tables.addTable(paramESqlClause);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TSimpleDmlTriggerClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */