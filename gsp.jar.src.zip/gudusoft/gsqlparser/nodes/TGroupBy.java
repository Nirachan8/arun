package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;

public class TGroupBy
  extends TParseTreeNode
{
  private TGroupByItemList a = null;
  private TExpression b = null;
  private TSourceToken c = null;
  private TSourceToken d = null;
  private TSourceToken e = null;
  
  public void setBY(TSourceToken paramTSourceToken)
  {
    this.d = paramTSourceToken;
  }
  
  public void setGROUP(TSourceToken paramTSourceToken)
  {
    this.c = paramTSourceToken;
  }
  
  public void setHAVING(TSourceToken paramTSourceToken)
  {
    this.e = paramTSourceToken;
  }
  
  public TSourceToken getBY()
  {
    return this.d;
  }
  
  public TSourceToken getGROUP()
  {
    return this.c;
  }
  
  public TSourceToken getHAVING()
  {
    return this.e;
  }
  
  public TExpression getHavingClause()
  {
    return this.b;
  }
  
  public TGroupByItemList getItems()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    if (paramObject1 != null) {
      if ((paramObject1 instanceof TGroupByItemList))
      {
        this.a = ((TGroupByItemList)paramObject1);
      }
      else if ((paramObject1 instanceof TExpressionList))
      {
        this.a = new TGroupByItemList();
        paramObject1 = (TExpressionList)paramObject1;
        for (int i = 0; i < ((TExpressionList)paramObject1).size(); i++)
        {
          TGroupByItem localTGroupByItem;
          (localTGroupByItem = new TGroupByItem()).setExpr(((TExpressionList)paramObject1).getExpression(i));
          localTGroupByItem.setStartToken(((TExpressionList)paramObject1).getExpression(i));
          localTGroupByItem.setEndToken(((TExpressionList)paramObject1).getExpression(i));
          this.a.addGroupByItem(localTGroupByItem);
        }
      }
    }
    if (paramObject2 != null) {
      this.b = ((TExpression)paramObject2);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null) {
      this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    if (getItems() != null) {
      getItems().accept(paramTParseTreeVisitor);
    }
    if (getHavingClause() != null) {
      getHavingClause().accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TGroupBy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */