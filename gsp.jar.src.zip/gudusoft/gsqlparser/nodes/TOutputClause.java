package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TOutputClause
  extends TParseTreeNode
{
  private TResultColumnList a = null;
  private TResultColumnList b = null;
  private TObjectName c = null;
  private TObjectNameList d = null;
  
  public void setSelectItemList2(TResultColumnList paramTResultColumnList)
  {
    this.b = paramTResultColumnList;
  }
  
  public void setIntoColumnList(TObjectNameList paramTObjectNameList)
  {
    this.d = paramTObjectNameList;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TResultColumnList)paramObject1);
    if (paramObject2 != null) {
      this.c = ((TObjectName)paramObject2);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    this.a.doParse(paramTCustomSqlStatement, ESqlClause.output);
    if (this.c != null)
    {
      this.c.setObjectType(3);
      (paramESqlClause = new TTable()).setTableName(this.c);
      if (this.d != null) {
        for (int i = 0; i < this.d.size(); i++) {
          paramESqlClause.getObjectNameReferences().addObjectName(this.d.getObjectName(i));
        }
      }
      paramTCustomSqlStatement.tables.addTable(paramESqlClause);
    }
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, ESqlClause.output);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TOutputClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */