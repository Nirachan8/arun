package gudusoft.gsqlparser.nodes;

public class TPartitionExtensionClause
  extends TParseTreeNode
{
  private TObjectName a;
  private TExpressionList b;
  
  public TExpressionList getKeyValues()
  {
    return this.b;
  }
  
  public TObjectName getPartitionName()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TObjectName))
    {
      this.a = ((TObjectName)paramObject);
      return;
    }
    if ((paramObject instanceof TExpressionList)) {
      this.b = ((TExpressionList)paramObject);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TPartitionExtensionClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */