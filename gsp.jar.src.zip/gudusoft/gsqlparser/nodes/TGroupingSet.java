package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TGroupingSet
  extends TParseTreeNode
{
  private TGroupingSetItemList a;
  
  public void init(Object paramObject)
  {
    this.a = ((TGroupingSetItemList)paramObject);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
  }
  
  public TGroupingSetItemList getItems()
  {
    return this.a;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    if (getItems() != null) {
      getItems().accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TGroupingSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */