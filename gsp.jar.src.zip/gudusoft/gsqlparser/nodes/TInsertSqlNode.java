package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EExpressionType;
import gudusoft.gsqlparser.TSourceToken;

public class TInsertSqlNode
  extends TParseTreeNode
{
  private TPTNodeList<TInsertCondition> a;
  private TPTNodeList<TInsertIntoValue> b;
  private TSourceToken c = null;
  private int d = 1;
  public TCTEList cteList = null;
  private TTopClause e = null;
  private TOutputClause f = null;
  private TFromTable g = null;
  private TObjectNameList h = null;
  private TReturningClause i = null;
  private TResultColumnList j = null;
  private TSourceToken k;
  private TSourceToken l;
  private TMultiTargetList m = null;
  private TSelectSqlNode n = null;
  private TFunctionCall o = null;
  private TObjectName p = null;
  private TResultColumnList q = null;
  private TIsolationClause r = null;
  
  public TCTEList getCteList()
  {
    return this.cteList;
  }
  
  public TPTNodeList<TInsertCondition> getInsertConditions()
  {
    return this.a;
  }
  
  public TPTNodeList<TInsertIntoValue> getInsertIntoValues()
  {
    return this.b;
  }
  
  public void setInsertConditions(TPTNodeList<TInsertCondition> paramTPTNodeList)
  {
    this.a = paramTPTNodeList;
  }
  
  public void setInsertIntoValues(TPTNodeList<TInsertIntoValue> paramTPTNodeList)
  {
    this.b = paramTPTNodeList;
  }
  
  public void setInsertToken(TSourceToken paramTSourceToken)
  {
    this.c = paramTSourceToken;
  }
  
  public TSourceToken getInsertToken()
  {
    return this.c;
  }
  
  public TSelectSqlNode getSubQueryNode()
  {
    return this.n;
  }
  
  public TMultiTargetList getValues()
  {
    return this.m;
  }
  
  public void setSubQueryNode(TSelectSqlNode paramTSelectSqlNode)
  {
    this.n = paramTSelectSqlNode;
  }
  
  public int getValueType()
  {
    return this.d;
  }
  
  public void setValueType(int paramInt)
  {
    this.d = paramInt;
  }
  
  public TReturningClause getReturningClause()
  {
    return this.i;
  }
  
  public TObjectNameList getColumnList()
  {
    return this.h;
  }
  
  public TOutputClause getOutputClause()
  {
    return this.f;
  }
  
  public TFromTable getTargetTable()
  {
    return this.g;
  }
  
  public TTopClause getTopClause()
  {
    return this.e;
  }
  
  public void setOnDuplicateKeyUpdate(TResultColumnList paramTResultColumnList)
  {
    this.j = paramTResultColumnList;
  }
  
  public TResultColumnList getOnDuplicateKeyUpdate()
  {
    return this.j;
  }
  
  public void setIgnore(TSourceToken paramTSourceToken)
  {
    this.k = paramTSourceToken;
  }
  
  public void setPriority_delayed(TSourceToken paramTSourceToken)
  {
    this.l = paramTSourceToken;
  }
  
  public TSourceToken getIgnore()
  {
    return this.k;
  }
  
  public TSourceToken getPriority_delayed()
  {
    return this.l;
  }
  
  public void setReturningClause(TReturningClause paramTReturningClause)
  {
    this.i = paramTReturningClause;
  }
  
  public void setColumnListByResultColumnList(TResultColumnList paramTResultColumnList)
  {
    this.h = new TObjectNameList();
    for (int i1 = 0; i1 < paramTResultColumnList.size(); i1++)
    {
      Object localObject;
      if ((localObject = (localObject = paramTResultColumnList.getResultColumn(i1)).getExpr()).getExpressionType() == EExpressionType.simple_object_name_t) {
        this.h.addObjectName(((TExpression)localObject).getObjectOperand());
      }
    }
  }
  
  public void setColumnList(TObjectNameList paramTObjectNameList)
  {
    this.h = paramTObjectNameList;
  }
  
  public void setTargetTable(TFromTable paramTFromTable)
  {
    this.g = paramTFromTable;
  }
  
  public void setOutputClause(TOutputClause paramTOutputClause)
  {
    this.f = paramTOutputClause;
  }
  
  public void setTopClause(TTopClause paramTTopClause)
  {
    this.e = paramTTopClause;
  }
  
  public TFunctionCall getFunctionCall()
  {
    return this.o;
  }
  
  public TObjectName getRecordName()
  {
    return this.p;
  }
  
  public void setValuesByMultiTarget(TMultiTarget paramTMultiTarget)
  {
    this.d = 1;
    this.m = new TMultiTargetList();
    this.m.addMultiTarget(paramTMultiTarget);
  }
  
  public TResultColumnList getSetColumnValues()
  {
    return this.q;
  }
  
  public void setIsolationClause(TIsolationClause paramTIsolationClause)
  {
    this.r = paramTIsolationClause;
  }
  
  public TIsolationClause getIsolationClause()
  {
    return this.r;
  }
  
  public void setValues(TDummy paramTDummy)
  {
    this.d = paramTDummy.int1;
    switch (this.d)
    {
    case 1: 
      this.m = ((TMultiTargetList)paramTDummy.list1);
      return;
    case 2: 
      this.n = ((TSelectSqlNode)paramTDummy.node1);
      return;
    case 3: 
      
    case 4: 
      
    case 5: 
      this.o = ((TFunctionCall)paramTDummy.node1);
      return;
    case 8: 
      this.p = ((TObjectName)paramTDummy.node1);
      return;
    case 6: 
      
    case 7: 
      this.q = ((TResultColumnList)paramTDummy.list1);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TInsertSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */