package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TRollupCube
  extends TParseTreeNode
{
  public static final int rollup = 1;
  public static final int cube = 2;
  private int a = 1;
  private TExpressionList b;
  
  public void setOperation(int paramInt)
  {
    this.a = paramInt;
  }
  
  public int getOperation()
  {
    return this.a;
  }
  
  public TExpressionList getItems()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    this.b = ((TExpressionList)paramObject);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TRollupCube.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */