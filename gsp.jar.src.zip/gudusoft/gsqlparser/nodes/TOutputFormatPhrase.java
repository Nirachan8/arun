package gudusoft.gsqlparser.nodes;

public class TOutputFormatPhrase
  extends TParseTreeNode
{
  private TDatatypeAttribute a = null;
  private TTypeName b;
  
  public TDatatypeAttribute getDatatypeAttribute()
  {
    return this.a;
  }
  
  public TTypeName getTypeName()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TDatatypeAttribute))
    {
      this.a = ((TDatatypeAttribute)paramObject);
      return;
    }
    if ((paramObject instanceof TTypeName)) {
      this.b = ((TTypeName)paramObject);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TOutputFormatPhrase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */