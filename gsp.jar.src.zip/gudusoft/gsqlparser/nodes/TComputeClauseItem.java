package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TComputeClauseItem
  extends TParseTreeNode
{
  private TComputeExprList a = null;
  private TExpressionList b = null;
  
  public void init(Object paramObject1, Object paramObject2)
  {
    if (paramObject1 != null) {
      this.a = ((TComputeExprList)paramObject1);
    }
    if (paramObject2 != null) {
      this.b = ((TExpressionList)paramObject2);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null) {
      this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TComputeClauseItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */