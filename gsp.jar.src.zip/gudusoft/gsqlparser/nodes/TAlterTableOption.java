package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EAlterTableOptionType;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;

public class TAlterTableOption
  extends TParseTreeNode
{
  private TColumnDefinitionList a = null;
  private TConstraintList b = null;
  private TObjectNameList c = null;
  private TObjectName d = null;
  private TObjectName e = null;
  private TObjectName f = null;
  private TObjectName g = null;
  private TObjectName h = null;
  private TObjectNameList i = null;
  private TObjectName j = null;
  private TMySQLIndexStorageType k = null;
  private TSourceToken l = null;
  private EAlterTableOptionType m = EAlterTableOptionType.Unknown;
  
  public EAlterTableOptionType getOptionType()
  {
    return this.m;
  }
  
  public void setOptionType(EAlterTableOptionType paramEAlterTableOptionType)
  {
    this.m = paramEAlterTableOptionType;
  }
  
  public void setMySQLIndexTypeToken(TSourceToken paramTSourceToken)
  {
    this.l = paramTSourceToken;
  }
  
  public TSourceToken getMySQLIndexTypeToken()
  {
    return this.l;
  }
  
  public void setMySQLIndexStorageType(TMySQLIndexStorageType paramTMySQLIndexStorageType)
  {
    this.k = paramTMySQLIndexStorageType;
  }
  
  public TMySQLIndexStorageType getMySQLIndexStorageType()
  {
    return this.k;
  }
  
  public void setNewTableName(TObjectName paramTObjectName)
  {
    this.j = paramTObjectName;
  }
  
  public TObjectName getNewTableName()
  {
    return this.j;
  }
  
  public void setReferencedColumnList(TObjectNameList paramTObjectNameList)
  {
    this.i = paramTObjectNameList;
  }
  
  public void setReferencedObjectName(TObjectName paramTObjectName)
  {
    this.h = paramTObjectName;
  }
  
  public void setColumnName(TObjectName paramTObjectName)
  {
    this.d = paramTObjectName;
  }
  
  public TConstraintList getConstraintList()
  {
    return this.b;
  }
  
  public TObjectNameList getColumnNameList()
  {
    if (this.c == null) {
      this.c = new TObjectNameList();
    }
    return this.c;
  }
  
  public TColumnDefinitionList getColumnDefinitionList()
  {
    return this.a;
  }
  
  public TObjectName getColumnName()
  {
    return this.d;
  }
  
  public TObjectName getConstraintName()
  {
    return this.f;
  }
  
  public TObjectName getNewColumnName()
  {
    return this.e;
  }
  
  public TObjectName getNewConstraintName()
  {
    return this.g;
  }
  
  public TObjectNameList getReferencedColumnList()
  {
    return this.i;
  }
  
  public TObjectName getReferencedObjectName()
  {
    return this.h;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TColumnDefinitionList))
    {
      this.a = ((TColumnDefinitionList)paramObject);
      return;
    }
    if ((paramObject instanceof TConstraintList))
    {
      this.b = ((TConstraintList)paramObject);
      return;
    }
    if ((paramObject instanceof TObjectNameList))
    {
      this.c = ((TObjectNameList)paramObject);
      return;
    }
    if ((paramObject instanceof TDummyList))
    {
      paramObject = (TDummyList)paramObject;
      for (int n = 0; n < ((TDummyList)paramObject).size(); n++)
      {
        TDummy localTDummy = ((TDummyList)paramObject).getDummyItem(n);
        getColumnNameList().addObjectName((TObjectName)localTDummy.node1);
      }
    }
  }
  
  public void setNewConstraintName(TObjectName paramTObjectName)
  {
    this.g = paramTObjectName;
  }
  
  public void setConstraintName(TDummy paramTDummy)
  {
    if (paramTDummy == null) {
      return;
    }
    if (paramTDummy.node1 == null) {
      return;
    }
    this.f = ((TObjectName)paramTDummy.node1);
  }
  
  public void setConstraintName(TObjectName paramTObjectName)
  {
    this.f = paramTObjectName;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.d = ((TObjectName)paramObject1);
    this.e = ((TObjectName)paramObject2);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause) {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TAlterTableOption.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */