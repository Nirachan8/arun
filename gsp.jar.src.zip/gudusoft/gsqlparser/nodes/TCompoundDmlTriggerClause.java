package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ETableSource;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlCreateTrigger;

public class TCompoundDmlTriggerClause
  extends TParseTreeNode
{
  private TDmlEventClause a = null;
  
  public void init(Object paramObject)
  {
    this.a = ((TDmlEventClause)paramObject);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if ((paramTCustomSqlStatement instanceof TPlsqlCreateTrigger))
    {
      (paramESqlClause = new TTable()).setTableType(ETableSource.objectname);
      paramESqlClause.setTableName(this.a.getTableName());
      paramTCustomSqlStatement.tables.addTable(paramESqlClause);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCompoundDmlTriggerClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */