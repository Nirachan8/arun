package gudusoft.gsqlparser.nodes;

public class TObjectReference
  extends TParseTreeNode
{
  public TObjectName objectname;
  
  public void setObjectType(int paramInt)
  {
    this.objectname.setObjectType(paramInt);
    this.objectname.getObjectType();
  }
  
  public int getObjectType()
  {
    return this.objectname.getObjectType();
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TObjectName)) {
      this.objectname = ((TObjectName)paramObject);
    }
  }
  
  public boolean isEqual(TObjectReference paramTObjectReference)
  {
    if ((paramTObjectReference = this.objectname.getObjectType() == paramTObjectReference.getObjectType() ? 1 : 0) == 0) {
      return false;
    }
    switch (this.objectname.getObjectType())
    {
    case 1: 
      break;
    case 3: 
      break;
    default: 
      paramTObjectReference = 0;
    }
    return paramTObjectReference;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TObjectReference.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */