package gudusoft.gsqlparser.nodes;

public class TSelectLimit
  extends TParseTreeNode
{
  private TLimitClause a;
  private TOffsetClause b;
  
  public TLimitClause getLimitClause()
  {
    return this.a;
  }
  
  public TOffsetClause getOffsetClause()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    if (paramObject1 != null) {
      this.a = ((TLimitClause)paramObject1);
    }
    if (paramObject2 != null) {
      this.b = ((TOffsetClause)paramObject2);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TSelectLimit.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */