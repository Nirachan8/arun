package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TOpenDatasource
  extends TParseTreeNode
{
  private TConstant a = null;
  private TConstant b = null;
  private TSourceToken c = null;
  
  public void setTableToken(TSourceToken paramTSourceToken)
  {
    this.c = paramTSourceToken;
  }
  
  public TSourceToken getTableToken()
  {
    return this.c;
  }
  
  public TConstant getInit_string()
  {
    return this.b;
  }
  
  public TConstant getProvider_name()
  {
    return this.a;
  }
  
  public void setSchemaToken(TSourceToken paramTSourceToken) {}
  
  public void setDatabaseToken(TSourceToken paramTSourceToken) {}
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TConstant)paramObject1);
    this.b = ((TConstant)paramObject2);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TOpenDatasource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */