package gudusoft.gsqlparser.nodes;

public class TDropTableSqlNode
  extends TParseTreeNode
{
  private TObjectName a;
  private TObjectNameList b = null;
  
  public TObjectNameList getTableNameList()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TObjectName))
    {
      this.a = ((TObjectName)paramObject);
      this.a.setObjectType(3);
      return;
    }
    if ((paramObject instanceof TObjectNameList))
    {
      this.b = ((TObjectNameList)paramObject);
      for (paramObject = 0; paramObject < this.b.size(); paramObject++) {
        this.b.getObjectName(paramObject).setObjectType(3);
      }
    }
  }
  
  public TObjectName getTableName()
  {
    return this.a;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDropTableSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */