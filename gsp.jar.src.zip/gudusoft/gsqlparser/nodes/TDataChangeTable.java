package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.stmt.TDeleteSqlStatement;
import gudusoft.gsqlparser.stmt.TInsertSqlStatement;
import gudusoft.gsqlparser.stmt.TUpdateSqlStatement;

public class TDataChangeTable
  extends TParseTreeNode
{
  private TParseTreeNode a = null;
  private TCustomSqlStatement b = null;
  
  public TCustomSqlStatement getStmt()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TParseTreeNode)paramObject);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if ((this.a instanceof TDeleteSqlNode)) {
      this.b = new TDeleteSqlStatement(paramTCustomSqlStatement.dbvendor);
    } else if ((this.a instanceof TInsertSqlNode)) {
      this.b = new TInsertSqlStatement(paramTCustomSqlStatement.dbvendor);
    } else if ((this.a instanceof TUpdateSqlNode)) {
      this.b = new TUpdateSqlStatement(paramTCustomSqlStatement.dbvendor);
    }
    if (this.b != null)
    {
      this.b.rootNode = this.a;
      this.b.doParseStatement(paramTCustomSqlStatement);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDataChangeTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */