package gudusoft.gsqlparser.nodes;

public class TCreateSynonymSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TObjectName b = null;
  private boolean c = false;
  
  public void setPublic(boolean paramBoolean)
  {
    this.c = paramBoolean;
  }
  
  public boolean isPublic()
  {
    return this.c;
  }
  
  public TObjectName getForName()
  {
    return this.b;
  }
  
  public TObjectName getSynonymName()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TObjectName)paramObject1);
    this.b = ((TObjectName)paramObject2);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCreateSynonymSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */