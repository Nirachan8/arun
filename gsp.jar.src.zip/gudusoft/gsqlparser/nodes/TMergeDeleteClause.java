package gudusoft.gsqlparser.nodes;

public class TMergeDeleteClause
  extends TParseTreeNode
{}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TMergeDeleteClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */