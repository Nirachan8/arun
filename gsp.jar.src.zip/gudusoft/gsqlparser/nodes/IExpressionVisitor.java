package gudusoft.gsqlparser.nodes;

public abstract interface IExpressionVisitor
{
  public abstract boolean exprVisit(TParseTreeNode paramTParseTreeNode, boolean paramBoolean);
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\IExpressionVisitor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */