package gudusoft.gsqlparser.nodes;

public class TLockingClause
  extends TParseTreeNode
{
  private TObjectNameList a;
  private boolean b;
  
  public boolean isNowait()
  {
    return this.b;
  }
  
  public void setNowait(boolean paramBoolean)
  {
    this.b = paramBoolean;
  }
  
  public TObjectNameList getLockObjects()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TObjectNameList)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TLockingClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */