package gudusoft.gsqlparser.nodes;

public class TCreateDatabaseSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  
  public TObjectName getDatabaseName()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TObjectName)paramObject);
    this.a.setObjectType(22);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCreateDatabaseSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */