package gudusoft.gsqlparser.nodes;

public class TCommentSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TConstant b = null;
  private int c = 0;
  
  public void setDbObjType(int paramInt)
  {
    this.c = paramInt;
  }
  
  public int getDbObjType()
  {
    return this.c;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TObjectName)paramObject1);
    this.b = ((TConstant)paramObject2);
  }
  
  public TConstant getMessage()
  {
    return this.b;
  }
  
  public TObjectName getObjectName()
  {
    return this.a;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCommentSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */