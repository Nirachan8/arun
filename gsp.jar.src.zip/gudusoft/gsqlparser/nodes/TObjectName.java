package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TSourceToken;

public class TObjectName
  extends TParseTreeNode
{
  public static final int ttobjNotAObject = -1;
  public static final int ttobjUnknown = 0;
  public static final int ttobjColumn = 1;
  public static final int ttobjColumnAlias = 2;
  public static final int ttobjTable = 3;
  public static final int ttObjTableAlias = 4;
  public static final int ttobjTableCTE = 5;
  public static final int ttobjTableTemp = 6;
  public static final int ttobjTablePivot = 7;
  public static final int ttobjTableVar = 8;
  public static final int ttobjParameter = 9;
  public static final int ttobjVariable = 10;
  public static final int ttobjColumnMethod = 11;
  public static final int ttobjProcedureName = 12;
  public static final int ttobjFunctionName = 13;
  public static final int ttobjLabelName = 14;
  public static final int ttobjIndexName = 15;
  public static final int ttobjMaterializedViewName = 16;
  public static final int ttobjCursorName = 17;
  public static final int ttobjViewName = 18;
  public static final int ttobjConstraintName = 19;
  public static final int ttobjPropertyName = 20;
  public static final int ttobjTransactionName = 21;
  public static final int ttobjDatabaseName = 22;
  public static final int ttobjStringConstant = 23;
  public static final int ttobjTrigger = 24;
  public static final int ttobjAliasName = 25;
  public static final int ttobjAttribute = 26;
  public static final int ttobjTypeName = 27;
  public static final int ttobjPackage = 28;
  public static final int ttobjSequence = 29;
  public static final int ttobjDatatype = 30;
  public static final int ttobjSchemaName = 31;
  public static final int ttobjServerName = 32;
  public static final int ttobjOperator = 40;
  public static final int ttobjIndexType = 42;
  public static final int ttobjMaterializedView = 44;
  public static final int ttobjMiningModel = 46;
  public static final int ttobjFieldName = 51;
  public static final int ttobjPositionalParameters = 61;
  public static final int ttObjOracleHint = 70;
  public static final int ttobjMixed = 100;
  private int a = 0;
  private TObjectNameList b = null;
  private boolean c;
  private TIndirection d;
  private boolean e = true;
  private TSourceToken f = null;
  private TSourceToken g = null;
  private TSourceToken h;
  private TSourceToken i;
  private TSourceToken j;
  private TSourceToken k = null;
  private TSourceToken l = null;
  private TSourceToken m;
  private TObjectName n;
  private ESqlClause o = ESqlClause.unknown;
  private TSourceToken p;
  private TObjectNameList q;
  private TSourceToken r;
  
  public TObjectName()
  {
    Boolean.valueOf(false);
    this.q = null;
    this.r = null;
  }
  
  public void TObjectName() {}
  
  private void a(TSourceToken paramTSourceToken)
  {
    this.i = this.j;
    this.j = paramTSourceToken;
  }
  
  public boolean isSubscripts()
  {
    return this.c;
  }
  
  public void setIndirection(TIndirection paramTIndirection)
  {
    if (paramTIndirection == null) {
      return;
    }
    this.d = paramTIndirection;
    if (getObjectType() == 61)
    {
      if (paramTIndirection.isRealIndices())
      {
        this.c = true;
        return;
      }
      a(((TIndices)paramTIndirection.getIndices().getElement(0)).getAttributeName().getPartToken());
      return;
    }
    if (paramTIndirection.isRealIndices())
    {
      if (paramTIndirection.getIndices().size() == 1)
      {
        this.c = true;
        return;
      }
      if ((paramTIndirection.getIndices().size() >= 2) && (!((TIndices)paramTIndirection.getIndices().getElement(0)).isRealIndices()))
      {
        b(((TIndices)paramTIndirection.getIndices().getElement(0)).getAttributeName().getPartToken());
        this.c = true;
        this.d.getIndices().a(0);
      }
    }
    else if (paramTIndirection.getIndices().size() == 1)
    {
      b(((TIndices)paramTIndirection.getIndices().getElement(0)).getAttributeName().getPartToken());
    }
  }
  
  public TIndirection getIndirection()
  {
    return this.d;
  }
  
  private void b(TSourceToken paramTSourceToken)
  {
    b();
    this.j = paramTSourceToken;
    this.j.setDbObjType(1);
  }
  
  public void setPropertyToken(TSourceToken paramTSourceToken)
  {
    this.k = paramTSourceToken;
  }
  
  public TSourceToken getAtsign()
  {
    return this.m;
  }
  
  public TSourceToken getMethodToken()
  {
    return this.l;
  }
  
  public TSourceToken getPropertyToken()
  {
    return this.k;
  }
  
  public TSourceToken getServerToken()
  {
    return this.f;
  }
  
  public TSourceToken getExclamationmark()
  {
    return this.p;
  }
  
  public TObjectName getDblink()
  {
    return this.n;
  }
  
  public TSourceToken getDatabaseToken()
  {
    return this.g;
  }
  
  public void setTableDetermined(boolean paramBoolean)
  {
    this.e = paramBoolean;
  }
  
  public boolean isTableDetermined()
  {
    return this.e;
  }
  
  public void attributesToPropertyToken(TObjectNameList paramTObjectNameList)
  {
    if (paramTObjectNameList.size() == 1) {
      this.k = paramTObjectNameList.getObjectName(0).getPartToken();
    }
  }
  
  public void setAttributes(TObjectNameList paramTObjectNameList)
  {
    this.b = paramTObjectNameList;
  }
  
  public TObjectNameList getAttributes()
  {
    return this.b;
  }
  
  public void setObjectType(int paramInt)
  {
    this.a = paramInt;
    switch (getObjectType())
    {
    case 3: 
    case 5: 
    case 6: 
    case 8: 
      b();
      this.i.setDbObjType(this.a);
      return;
    case 1: 
      this.j.setDbObjType(this.a);
      return;
    case 2: 
      if ((this.i == null) && (this.j != null)) {
        a();
      }
      this.i.setDbObjType(this.a);
      return;
    case 4: 
      a();
      this.i.setDbObjType(this.a);
      return;
    case 9: 
    case 10: 
      a();
      this.i.setDbObjType(this.a);
      return;
    case 11: 
      d();
      this.j.setDbObjType(1);
      this.l.setDbObjType(11);
      return;
    case 12: 
    case 13: 
      c();
      this.i.setDbObjType(this.a);
      return;
    case 14: 
      a();
      this.i.setDbObjType(this.a);
      return;
    case 15: 
      a();
      this.i.setDbObjType(this.a);
      return;
    case 16: 
    case 18: 
      a();
      this.i.setDbObjType(this.a);
      return;
    case 17: 
      a();
      this.i.setDbObjType(this.a);
      return;
    case 19: 
      a();
      this.i.setDbObjType(this.a);
      return;
    case 20: 
      this.k.setDbObjType(this.a);
      return;
    case 21: 
      a();
      this.i.setDbObjType(this.a);
      return;
    case 22: 
      a();
      this.i.setDbObjType(this.a);
      return;
    case 23: 
      a();
      this.i.setDbObjType(this.a);
      return;
    case 25: 
      a();
      this.i.setDbObjType(this.a);
      return;
    case 26: 
      this.j.setDbObjType(this.a);
      return;
    case 27: 
      a();
      this.i.setDbObjType(this.a);
      return;
    case 28: 
      a();
      this.i.setDbObjType(this.a);
      return;
    case 29: 
      a();
      this.i.setDbObjType(this.a);
      return;
    case 24: 
      a();
      this.i.setDbObjType(this.a);
    }
  }
  
  public int getObjectType()
  {
    return this.a;
  }
  
  public void setAtsign(TSourceToken paramTSourceToken)
  {
    this.m = paramTSourceToken;
  }
  
  public void setDblink(TObjectName paramTObjectName)
  {
    this.n = paramTObjectName;
  }
  
  public void setLocation(ESqlClause paramESqlClause)
  {
    this.o = paramESqlClause;
  }
  
  public ESqlClause getLocation()
  {
    return this.o;
  }
  
  public TSourceToken getObjectToken()
  {
    return this.i;
  }
  
  public TSourceToken getPartToken()
  {
    return this.j;
  }
  
  public TSourceToken getSchemaToken()
  {
    return this.h;
  }
  
  public String getSchemaString()
  {
    if (this.h != null) {
      return this.h.astext;
    }
    return null;
  }
  
  public String getObjectString()
  {
    if (this.i != null) {
      return this.i.astext;
    }
    return null;
  }
  
  public String getPartString()
  {
    if (this.j != null) {
      return this.j.astext;
    }
    return null;
  }
  
  public void setExclamationmark(TSourceToken paramTSourceToken)
  {
    this.p = paramTSourceToken;
  }
  
  private void a()
  {
    b();
  }
  
  private void b()
  {
    if (this.g != null)
    {
      this.f = this.g;
      this.f.setDbObjType(32);
    }
    if (this.h != null)
    {
      this.g = this.h;
      this.g.setDbObjType(22);
    }
    if (this.i != null)
    {
      this.h = this.i;
      this.h.setDbObjType(31);
    }
    this.i = this.j;
    this.j = null;
  }
  
  private void c()
  {
    b();
  }
  
  private void d()
  {
    this.a = 11;
    this.l = this.i;
    this.j = this.h;
    this.i = null;
    this.h = null;
  }
  
  public void init(Object paramObject)
  {
    this.j = ((TSourceToken)paramObject);
    setStartToken(this.j);
    setEndToken(this.j);
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.i = ((TSourceToken)paramObject1);
    this.j = ((TSourceToken)paramObject2);
    if (this.i != null) {
      setStartToken(this.i);
    } else {
      setStartToken(this.j);
    }
    if (this.j != null)
    {
      setEndToken(this.j);
      return;
    }
    setEndToken(this.i);
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.h = ((TSourceToken)paramObject1);
    this.i = ((TSourceToken)paramObject2);
    this.j = ((TSourceToken)paramObject3);
    setStartToken(this.h);
    setEndToken(this.j);
    if (this.h != null) {
      this.h.setDbObjType(31);
    }
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4)
  {
    this.g = ((TSourceToken)paramObject1);
    this.h = ((TSourceToken)paramObject2);
    this.i = ((TSourceToken)paramObject3);
    this.j = ((TSourceToken)paramObject4);
    setStartToken(this.g);
    setEndToken(this.j);
    if (this.g != null) {
      this.g.setDbObjType(22);
    }
    if (this.h != null) {
      this.h.setDbObjType(31);
    }
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5)
  {
    this.f = ((TSourceToken)paramObject1);
    this.g = ((TSourceToken)paramObject2);
    this.h = ((TSourceToken)paramObject3);
    this.i = ((TSourceToken)paramObject4);
    this.j = ((TSourceToken)paramObject5);
    setStartToken(this.f);
    setEndToken(this.j);
    if (this.f != null) {
      this.f.setDbObjType(32);
    }
    if (this.g != null) {
      this.g.setDbObjType(22);
    }
    if (this.h != null) {
      this.h.setDbObjType(31);
    }
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6)
  {
    this.f = ((TSourceToken)paramObject1);
    this.g = ((TSourceToken)paramObject2);
    this.h = ((TSourceToken)paramObject3);
    this.i = ((TSourceToken)paramObject4);
    this.j = ((TSourceToken)paramObject5);
    this.k = ((TSourceToken)paramObject6);
    setStartToken(this.f);
    setEndToken(this.k);
    if (this.f != null) {
      this.f.setDbObjType(32);
    }
    if (this.g != null) {
      this.g.setDbObjType(22);
    }
    if (this.h != null) {
      this.h.setDbObjType(31);
    }
  }
  
  public long getColumnNo()
  {
    long l1 = -1L;
    if (this.j != null) {
      l1 = this.j.columnNo;
    }
    if (this.i != null) {
      l1 = this.i.columnNo;
    }
    if (this.h != null) {
      l1 = this.h.columnNo;
    }
    if (this.g != null) {
      l1 = this.g.columnNo;
    }
    if (this.f != null) {
      l1 = this.f.columnNo;
    }
    return l1;
  }
  
  public long getLineNo()
  {
    long l1 = -1L;
    if (this.j != null) {
      l1 = this.j.lineNo;
    }
    if (this.i != null) {
      l1 = this.i.lineNo;
    }
    if (this.h != null) {
      l1 = this.h.lineNo;
    }
    if (this.g != null) {
      l1 = this.g.lineNo;
    }
    if (this.f != null) {
      l1 = this.f.lineNo;
    }
    return l1;
  }
  
  public TObjectNameList getReferencedObjects()
  {
    if (this.q == null) {
      this.q = new TObjectNameList();
    }
    return this.q;
  }
  
  public String getColumnNameOnly()
  {
    return getPartToken().toString();
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
  
  public void setSortType(TSourceToken paramTSourceToken)
  {
    this.r = paramTSourceToken;
  }
  
  public TSourceToken getSortType()
  {
    return this.r;
  }
  
  public TSourceToken getColumnToken()
  {
    TSourceToken localTSourceToken = null;
    if (getObjectType() == 1) {
      localTSourceToken = getPartToken();
    }
    return localTSourceToken;
  }
  
  public boolean isAttributeNameInObjectName(TSourceToken paramTSourceToken1, TSourceToken paramTSourceToken2)
  {
    if ((this.j == null) || (this.i == null)) {
      return false;
    }
    this.a = 1;
    this.b = new TObjectNameList();
    (paramTSourceToken1 = new TObjectName()).a = 26;
    paramTSourceToken1.init(this.j);
    paramTSourceToken1.setEndToken(paramTSourceToken2);
    this.b.addObjectName(paramTSourceToken1);
    this.j = this.i;
    if (this.h != null) {
      this.i = this.h;
    }
    return true;
  }
  
  static
  {
    TObjectName.class.desiredAssertionStatus();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TObjectName.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */