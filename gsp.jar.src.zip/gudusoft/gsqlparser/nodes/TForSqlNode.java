package gudusoft.gsqlparser.nodes;

public class TForSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TObjectName b = null;
  private TSelectSqlNode c = null;
  private TStatementListSqlNode d = null;
  
  public void setCursorName(TObjectName paramTObjectName)
  {
    this.b = paramTObjectName;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.a = ((TObjectName)paramObject1);
    this.c = ((TSelectSqlNode)paramObject2);
    this.d = ((TStatementListSqlNode)paramObject3);
  }
  
  public TObjectName getCursorName()
  {
    return this.b;
  }
  
  public TObjectName getLoopName()
  {
    return this.a;
  }
  
  public TSelectSqlNode getSelectNode()
  {
    return this.c;
  }
  
  public TStatementListSqlNode getStmtListNode()
  {
    return this.d;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TForSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */