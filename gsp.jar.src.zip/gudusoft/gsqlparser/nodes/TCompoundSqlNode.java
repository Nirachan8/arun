package gudusoft.gsqlparser.nodes;

public class TCompoundSqlNode
  extends TParseTreeNode
{
  private TStatementListSqlNode a = null;
  private TStatementListSqlNode b = null;
  
  public TStatementListSqlNode getStmts()
  {
    return this.b;
  }
  
  public TStatementListSqlNode getDeclareStmts()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    if (paramObject1 != null) {
      this.a = ((TStatementListSqlNode)paramObject1);
    }
    if (paramObject2 != null) {
      this.b = ((TStatementListSqlNode)paramObject2);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCompoundSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */