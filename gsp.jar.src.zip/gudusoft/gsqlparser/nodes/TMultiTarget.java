package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class TMultiTarget
  extends TParseTreeNode
{
  private TSelectSqlNode a = null;
  private TSelectSqlStatement b = null;
  private TResultColumnList c = null;
  
  public TResultColumnList getColumnList()
  {
    return this.c;
  }
  
  public TSelectSqlStatement getSubQuery()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TSelectSqlNode))
    {
      this.a = ((TSelectSqlNode)paramObject);
      return;
    }
    if ((paramObject instanceof TResultColumnList)) {
      this.c = ((TResultColumnList)paramObject);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null)
    {
      if (this.b == null)
      {
        this.b = new TSelectSqlStatement(paramTCustomSqlStatement.dbvendor);
        this.b.rootNode = this.a;
      }
      this.b.doParseStatement(paramTCustomSqlStatement);
      return;
    }
    if (this.c != null) {
      this.c.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TMultiTarget.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */