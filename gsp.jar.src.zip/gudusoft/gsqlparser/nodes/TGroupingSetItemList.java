package gudusoft.gsqlparser.nodes;

public class TGroupingSetItemList
  extends TParseTreeNodeList
{
  public void addGroupingSetItem(TGroupingSetItem paramTGroupingSetItem)
  {
    addElement(paramTGroupingSetItem);
  }
  
  public TGroupingSetItem getGroupingSetItem(int paramInt)
  {
    if (paramInt < size()) {
      return (TGroupingSetItem)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addGroupingSetItem((TGroupingSetItem)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TGroupingSetItemList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */