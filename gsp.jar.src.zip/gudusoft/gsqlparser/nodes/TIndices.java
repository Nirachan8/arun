package gudusoft.gsqlparser.nodes;

public class TIndices
  extends TParseTreeNode
{
  private TExpression a;
  private TExpression b;
  private TObjectName c;
  
  public TObjectName getAttributeName()
  {
    return this.c;
  }
  
  public TExpression getLowerSubscript()
  {
    return this.a;
  }
  
  public TExpression getUpperSubscript()
  {
    return this.b;
  }
  
  public boolean isRealIndices()
  {
    return this.c == null;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.c = ((TObjectName)paramObject1);
    this.a = ((TExpression)paramObject2);
    this.b = ((TExpression)paramObject3);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TIndices.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */