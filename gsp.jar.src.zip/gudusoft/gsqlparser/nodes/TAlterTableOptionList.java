package gudusoft.gsqlparser.nodes;

public class TAlterTableOptionList
  extends TParseTreeNodeList
{
  public void addAlterTableOption(TAlterTableOption paramTAlterTableOption)
  {
    addElement(paramTAlterTableOption);
  }
  
  public TAlterTableOption getAlterTableOption(int paramInt)
  {
    if (paramInt < size()) {
      return (TAlterTableOption)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addAlterTableOption((TAlterTableOption)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TAlterTableOptionList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */