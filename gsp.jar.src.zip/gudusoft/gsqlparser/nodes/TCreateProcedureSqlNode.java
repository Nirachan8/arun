package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.nodes.oracle.TInvokerRightsClause;
import gudusoft.gsqlparser.stmt.oracle.TExceptionClause;

public class TCreateProcedureSqlNode
  extends TParseTreeNode
{
  private TInvokerRightsClause a;
  private TCallSpec b = null;
  private TObjectName c = null;
  private TParameterDeclarationList d = null;
  private TStatementListSqlNode e = null;
  private TStatementSqlNode f = null;
  private TBlockSqlNode g = null;
  private int h = 1;
  private TExceptionClause i = null;
  private TStatementListSqlNode j = null;
  private TStatementListSqlNode k = null;
  private TCompoundSqlNode l = null;
  
  public void setInvokerRightsClause(TInvokerRightsClause paramTInvokerRightsClause)
  {
    this.a = paramTInvokerRightsClause;
  }
  
  public TInvokerRightsClause getInvokerRightsClause()
  {
    return this.a;
  }
  
  public void setCallSpec(TCallSpec paramTCallSpec)
  {
    this.b = paramTCallSpec;
  }
  
  public TCallSpec getCallSpec()
  {
    return this.b;
  }
  
  public TObjectName getProcedureName()
  {
    return this.c;
  }
  
  public TParameterDeclarationList getParameters()
  {
    return this.d;
  }
  
  public void setParameters(TParameterDeclarationList paramTParameterDeclarationList)
  {
    this.d = paramTParameterDeclarationList;
  }
  
  public void setInnerStmts(TStatementListSqlNode paramTStatementListSqlNode)
  {
    this.e = paramTStatementListSqlNode;
  }
  
  public void setStmt(TStatementSqlNode paramTStatementSqlNode)
  {
    this.f = paramTStatementSqlNode;
  }
  
  public TStatementSqlNode getStmt()
  {
    return this.f;
  }
  
  public void setBlcok(TBlockSqlNode paramTBlockSqlNode)
  {
    this.g = paramTBlockSqlNode;
  }
  
  public TBlockSqlNode getBlcok()
  {
    return this.g;
  }
  
  public void init(Object paramObject)
  {
    this.c = ((TObjectName)paramObject);
    this.c.setObjectType(12);
  }
  
  public int getKind()
  {
    return this.h;
  }
  
  public void setKind(int paramInt)
  {
    this.h = paramInt;
  }
  
  public TExceptionClause getExceptionClause()
  {
    return this.i;
  }
  
  public void setExceptionClause(TExceptionClause paramTExceptionClause)
  {
    this.i = paramTExceptionClause;
  }
  
  public TStatementListSqlNode getInnerStmts()
  {
    return this.e;
  }
  
  public TStatementListSqlNode getStmts()
  {
    return this.j;
  }
  
  public TStatementListSqlNode getDeclareStmts()
  {
    return this.k;
  }
  
  public void setDeclareStmts(TStatementListSqlNode paramTStatementListSqlNode)
  {
    this.k = paramTStatementListSqlNode;
  }
  
  public void setStmts(TStatementListSqlNode paramTStatementListSqlNode)
  {
    this.j = paramTStatementListSqlNode;
  }
  
  public void setCompoundSqls(TCompoundSqlNode paramTCompoundSqlNode)
  {
    this.l = paramTCompoundSqlNode;
  }
  
  public TCompoundSqlNode getCompoundSqls()
  {
    return this.l;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCreateProcedureSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */