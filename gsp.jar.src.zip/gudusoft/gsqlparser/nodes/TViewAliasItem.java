package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TViewAliasItem
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TConstraint b = null;
  private TConstraintList c = null;
  
  public TObjectName getAlias()
  {
    return this.a;
  }
  
  public TConstraintList getColumnConstraintList()
  {
    return this.c;
  }
  
  public TConstraint getTableConstraint()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    if (paramObject1 != null)
    {
      this.a = ((TObjectName)paramObject1);
      this.a.setObjectType(25);
    }
    if (paramObject2 != null)
    {
      if ((paramObject2 instanceof TConstraint))
      {
        this.b = ((TConstraint)paramObject2);
        return;
      }
      if ((paramObject2 instanceof TConstraintList)) {
        this.c = ((TConstraintList)paramObject2);
      }
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.b != null)
    {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    }
    if (this.c != null) {
      this.c.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TViewAliasItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */