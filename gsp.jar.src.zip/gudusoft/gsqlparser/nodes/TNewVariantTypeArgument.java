package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TNewVariantTypeArgument
  extends TParseTreeNode
{
  private TExpression a = null;
  private TObjectName b = null;
  
  public TObjectName getAliasName()
  {
    return this.b;
  }
  
  public TExpression getExpr()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TExpression)paramObject1);
    this.b = ((TObjectName)paramObject2);
    this.b.setObjectType(25);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TNewVariantTypeArgument.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */