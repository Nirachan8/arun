package gudusoft.gsqlparser.nodes;

public enum ENodeType
{
  private final int a;
  private final String b;
  
  private ENodeType(int paramInt, String paramString)
  {
    this.a = paramInt;
    this.b = paramString;
  }
  
  public final int getId()
  {
    return this.a;
  }
  
  public final String toString()
  {
    return this.b;
  }
  
  public static ENodeType fromString(String paramString)
  {
    ENodeType[] arrayOfENodeType;
    int i = (arrayOfENodeType = values()).length;
    for (int j = 0; j < i; j++)
    {
      ENodeType localENodeType;
      if ((localENodeType = arrayOfENodeType[j]).toString().equalsIgnoreCase(paramString)) {
        return localENodeType;
      }
    }
    return null;
  }
  
  public static ENodeType fromId(int paramInt)
  {
    ENodeType[] arrayOfENodeType;
    int i = (arrayOfENodeType = values()).length;
    for (int j = 0; j < i; j++)
    {
      ENodeType localENodeType;
      if ((localENodeType = arrayOfENodeType[j]).a == paramInt) {
        return localENodeType;
      }
    }
    return null;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\ENodeType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */