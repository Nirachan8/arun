package gudusoft.gsqlparser.nodes;

public class TDmlEventClause
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TDummyList b;
  private TObjectNameList c;
  private boolean d = false;
  private boolean e = false;
  private boolean f = false;
  
  public TObjectName getTableName()
  {
    return this.a;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TObjectName)paramObject1);
    this.a.setObjectType(3);
    this.b = ((TDummyList)paramObject2);
    for (paramObject2 = 0; paramObject2 < this.b.size(); paramObject2++) {
      if ((paramObject1 = this.b.getDummyItem(paramObject2)).toString().startsWith("delete"))
      {
        this.d = true;
      }
      else if (((TDummy)paramObject1).toString().startsWith("insert"))
      {
        this.e = true;
      }
      else if (((TDummy)paramObject1).toString().startsWith("update"))
      {
        this.f = true;
        if (((TDummy)paramObject1).list1 != null) {
          this.c = ((TObjectNameList)((TDummy)paramObject1).list1);
        }
      }
    }
  }
  
  public boolean isDelete()
  {
    return this.d;
  }
  
  public boolean isUpdate()
  {
    return this.f;
  }
  
  public boolean isInsert()
  {
    return this.e;
  }
  
  public TObjectNameList getColumnList()
  {
    return this.c;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDmlEventClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */