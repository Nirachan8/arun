package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.stmt.mssql.TMssqlCreateTriggerUpdateColumnList;

public class TIfSqlNode
  extends TParseTreeNode
{
  private TStatementSqlNode a = null;
  private TStatementSqlNode b = null;
  private int c = 1;
  private TExpression d = null;
  private TMssqlCreateTriggerUpdateColumnList e = null;
  private TStatementListSqlNode f = null;
  private TStatementListSqlNode g = null;
  private TElseIfSqlNodeList h = null;
  
  public void setStmtType(int paramInt)
  {
    this.c = paramInt;
  }
  
  public int getStmtType()
  {
    return this.c;
  }
  
  public TExpression getCondition()
  {
    return this.d;
  }
  
  public TMssqlCreateTriggerUpdateColumnList getUpdateColumnList()
  {
    return this.e;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    if ((paramObject1 instanceof TExpression)) {
      this.d = ((TExpression)paramObject1);
    } else {
      this.e = ((TMssqlCreateTriggerUpdateColumnList)paramObject1);
    }
    if (paramObject2 != null) {
      this.a = ((TStatementSqlNode)paramObject2);
    }
    if (paramObject3 != null) {
      this.b = ((TStatementSqlNode)paramObject3);
    }
  }
  
  public TStatementSqlNode getElseStmtSqlNode()
  {
    return this.b;
  }
  
  public TStatementSqlNode getStmtSqlNode()
  {
    return this.a;
  }
  
  public void setElseIfList(TElseIfSqlNodeList paramTElseIfSqlNodeList)
  {
    this.h = paramTElseIfSqlNodeList;
  }
  
  public void setElseStmts(TStatementListSqlNode paramTStatementListSqlNode)
  {
    this.g = paramTStatementListSqlNode;
  }
  
  public TElseIfSqlNodeList getElseIfList()
  {
    return this.h;
  }
  
  public TStatementListSqlNode getElseStmts()
  {
    return this.g;
  }
  
  public TStatementListSqlNode getThenStmts()
  {
    return this.f;
  }
  
  public void setThenStmts(TStatementListSqlNode paramTStatementListSqlNode)
  {
    this.f = paramTStatementListSqlNode;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TIfSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */