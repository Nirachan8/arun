package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.ETokenType;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TGSqlParser;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;

public abstract class TParseTreeNode
  implements Visitable
{
  private TGSqlParser a = null;
  private int b;
  private TSourceToken c;
  private TSourceToken d;
  private long e = -1L;
  private long f = -1L;
  private int g;
  
  public TGSqlParser getGsqlparser()
  {
    if ((this.a == null) && (getStartToken() != null)) {
      this.a = getStartToken().getGsqlparser();
    }
    return this.a;
  }
  
  public void setGsqlparser(TGSqlParser paramTGSqlParser)
  {
    this.a = paramTGSqlParser;
  }
  
  public void setDummyTag(int paramInt)
  {
    this.b = paramInt;
  }
  
  public int getDummyTag()
  {
    return this.b;
  }
  
  public TSourceToken getStartToken()
  {
    return this.c;
  }
  
  public TSourceToken getEndToken()
  {
    return this.d;
  }
  
  public long getColumnNo()
  {
    if (getStartToken() != null) {
      this.f = getStartToken().columnNo;
    }
    return this.f;
  }
  
  public long getLineNo()
  {
    if (getStartToken() != null) {
      this.e = getStartToken().lineNo;
    }
    return this.e;
  }
  
  public void setNodeType(int paramInt)
  {
    this.g = paramInt;
  }
  
  public int getNodeType()
  {
    return this.g;
  }
  
  public void init(Object paramObject) {}
  
  public void init(Object paramObject1, Object paramObject2) {}
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3) {}
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4) {}
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5) {}
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6) {}
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause) {}
  
  public void setStartToken(TSourceToken paramTSourceToken)
  {
    if (paramTSourceToken == null) {
      return;
    }
    this.c = paramTSourceToken;
    if (this.c != null) {
      this.c.getNodesStartFromThisToken().addNode(this);
    }
  }
  
  public void setStartToken(TParseTreeNode paramTParseTreeNode)
  {
    if (paramTParseTreeNode == null) {
      return;
    }
    this.c = paramTParseTreeNode.getStartToken();
    if (this.c != null) {
      this.c.getNodesStartFromThisToken().addNode(this);
    }
  }
  
  public void setEndToken(TSourceToken paramTSourceToken)
  {
    if (paramTSourceToken == null) {
      return;
    }
    this.d = paramTSourceToken;
    if (this.d != null) {
      this.d.getNodesEndWithThisToken().addNode(this);
    }
  }
  
  public void setEndToken(TParseTreeNode paramTParseTreeNode)
  {
    if (paramTParseTreeNode == null) {
      return;
    }
    this.d = paramTParseTreeNode.getEndToken();
    if (this.d != null) {
      this.d.getNodesEndWithThisToken().addNode(this);
    }
  }
  
  private void a()
  {
    this.c = null;
  }
  
  private void b()
  {
    this.d = null;
  }
  
  private static void a(TSourceTokenList paramTSourceTokenList, int paramInt1, int paramInt2, boolean paramBoolean, TSourceToken paramTSourceToken1, TSourceToken paramTSourceToken2)
  {
    for (int i = paramInt1; i <= paramInt2; i++)
    {
      TSourceToken localTSourceToken1 = paramTSourceTokenList.get(i);
      int j = 0;
      TParseTreeNode localTParseTreeNode;
      TSourceToken localTSourceToken2 = (localTParseTreeNode = localTSourceToken1.getNodesStartFromThisToken().getElement(j)).getEndToken();
      if ((paramBoolean) && ((i == paramInt1) || (i == paramInt2)))
      {
        localTParseTreeNode.setStartToken(paramTSourceToken1);
      }
      else if (localTSourceToken2 == null)
      {
        localTParseTreeNode.a();
      }
      else if (localTSourceToken2.posinlist > paramInt2)
      {
        localTParseTreeNode.setStartToken(paramTSourceTokenList.get(paramInt2 + 1));
      }
      else
      {
        localTParseTreeNode.a();
        localTParseTreeNode.b();
      }
      j++;
      for (j = 0; j < localTSourceToken1.getNodesEndWithThisToken().size(); j++)
      {
        localTSourceToken2 = (localTParseTreeNode = localTSourceToken1.getNodesEndWithThisToken().getElement(j)).getStartToken();
        if ((paramBoolean) && ((i == paramInt1) || (i == paramInt2)))
        {
          localTParseTreeNode.setEndToken(paramTSourceToken2);
        }
        else if (localTSourceToken2 == null)
        {
          localTParseTreeNode.b();
        }
        else if ((localTSourceToken2.posinlist <= paramInt2) && (localTSourceToken2.posinlist < paramInt1))
        {
          localTParseTreeNode.setEndToken(paramTSourceTokenList.get(paramInt1 - 1));
        }
        else
        {
          localTParseTreeNode.a();
          localTParseTreeNode.b();
        }
      }
    }
  }
  
  public void setString(String paramString)
  {
    TGSqlParser localTGSqlParser;
    (localTGSqlParser = new TGSqlParser(getGsqlparser().getDbVendor())).sqltext = paramString;
    localTGSqlParser.tokenizeSqltext();
    if ((getStartToken() == null) && (getEndToken() == null))
    {
      localTGSqlParser.sourcetokenlist.get(0).container = localTGSqlParser.sourcetokenlist;
      localTGSqlParser.sourcetokenlist.get(localTGSqlParser.sourcetokenlist.size() - 1).container = localTGSqlParser.sourcetokenlist;
      setStartToken(localTGSqlParser.sourcetokenlist.get(0));
      setEndToken(localTGSqlParser.sourcetokenlist.get(localTGSqlParser.sourcetokenlist.size() - 1));
      return;
    }
    TSourceToken localTSourceToken1 = getStartToken();
    TSourceToken localTSourceToken2;
    TSourceTokenList localTSourceTokenList = (localTSourceToken2 = getEndToken()).container;
    String str1 = localTSourceToken1.posinlist;
    String str2 = localTSourceToken2.posinlist;
    if ((paramString.length() == 0) || (paramString == " "))
    {
      a(localTSourceTokenList, str1, str2, false, null, null);
      for (paramString = str2; paramString >= str1; paramString--) {
        localTSourceTokenList.remove(paramString);
      }
      for (paramString = str1; paramString < localTSourceTokenList.size(); paramString++) {
        localTSourceTokenList.get(paramString).posinlist = paramString;
      }
      return;
    }
    paramString = localTGSqlParser.sourcetokenlist.get(0);
    TSourceToken localTSourceToken4 = localTGSqlParser.sourcetokenlist.get(localTGSqlParser.sourcetokenlist.size() - 1);
    a(localTSourceTokenList, str1, str2, true, paramString, localTSourceToken4);
    for (paramString = str2; paramString >= str1; paramString--) {
      localTSourceTokenList.remove(paramString);
    }
    TSourceToken localTSourceToken3;
    for (paramString = localTGSqlParser.sourcetokenlist.size() - 1; paramString >= 0; paramString--)
    {
      (localTSourceToken3 = localTGSqlParser.sourcetokenlist.get(paramString)).container = localTSourceTokenList;
      localTSourceTokenList.add(str1, localTSourceToken3);
    }
    for (paramString = str1; paramString < localTSourceTokenList.size(); paramString++) {
      (localTSourceToken3 = localTSourceTokenList.get(paramString)).posinlist = paramString;
    }
  }
  
  public String toString()
  {
    TSourceToken localTSourceToken1;
    if ((localTSourceToken1 = getStartToken()) == null) {
      return null;
    }
    TSourceToken localTSourceToken2;
    if ((localTSourceToken2 = getEndToken()) == null) {
      return null;
    }
    TSourceTokenList localTSourceTokenList;
    if ((localTSourceTokenList = localTSourceToken1.container) == null) {
      return null;
    }
    int i = localTSourceToken1.posinlist;
    int j = localTSourceToken2.posinlist;
    StringBuffer localStringBuffer = new StringBuffer("");
    for (i = i; i <= j; i++) {
      localStringBuffer.append(localTSourceTokenList.get(i).toString());
    }
    return localStringBuffer.toString();
  }
  
  public int addAllMyTokensToTokenList(TSourceTokenList paramTSourceTokenList, int paramInt)
  {
    TSourceToken localTSourceToken1;
    if ((localTSourceToken1 = getStartToken()) == null) {
      return -1;
    }
    TSourceToken localTSourceToken2;
    if ((localTSourceToken2 = getEndToken()) == null) {
      return -1;
    }
    TSourceTokenList localTSourceTokenList;
    if ((localTSourceTokenList = localTSourceToken1.container) == null) {
      return -1;
    }
    for (int i = localTSourceToken2.posinlist; i >= localTSourceToken1.posinlist; i--)
    {
      paramTSourceTokenList.add(paramInt, localTSourceTokenList.get(i));
      localTSourceTokenList.get(i).container = paramTSourceTokenList;
    }
    for (i = paramInt; i < paramTSourceTokenList.size(); i++) {
      paramTSourceTokenList.get(i).posinlist = i;
    }
    return localTSourceToken2.posinlist - localTSourceToken1.posinlist + 1;
  }
  
  protected int removeAllMyTokensFromTokenList(TSourceToken paramTSourceToken)
  {
    Object localObject;
    if ((localObject = getStartToken()) == null) {
      return -1;
    }
    TSourceToken localTSourceToken1 = ((TSourceToken)localObject).posinlist;
    TSourceToken localTSourceToken2;
    if ((localTSourceToken2 = getEndToken()) == null) {
      return -1;
    }
    TSourceToken localTSourceToken3 = localTSourceToken2.posinlist;
    if ((localObject = ((TSourceToken)localObject).container) == null) {
      return -1;
    }
    if ((paramTSourceToken != null) && (paramTSourceToken.tokentype != ETokenType.ttRemoved)) {
      if (paramTSourceToken.posinlist < localTSourceToken1)
      {
        localTSourceToken1 = paramTSourceToken.posinlist;
        paramTSourceToken.tokentype = ETokenType.ttRemoved;
      }
      else if (paramTSourceToken.posinlist > localTSourceToken3)
      {
        localTSourceToken3 = paramTSourceToken.posinlist;
        paramTSourceToken.tokentype = ETokenType.ttRemoved;
      }
    }
    a((TSourceTokenList)localObject, localTSourceToken1, localTSourceToken3, false, null, null);
    for (paramTSourceToken = localTSourceToken3; paramTSourceToken >= localTSourceToken1; paramTSourceToken--) {
      ((TSourceTokenList)localObject).remove(paramTSourceToken);
    }
    for (paramTSourceToken = localTSourceToken1; paramTSourceToken < ((TSourceTokenList)localObject).size(); paramTSourceToken++) {
      ((TSourceTokenList)localObject).get(paramTSourceToken).posinlist = paramTSourceToken;
    }
    return localTSourceToken1 - localTSourceToken3 + 1;
  }
  
  protected void appendString(String paramString)
  {
    if (paramString.length() == 0) {
      return;
    }
    if (getStartToken() == null) {
      return;
    }
    if (getEndToken() == null) {
      return;
    }
    TSourceToken localTSourceToken;
    TSourceTokenList localTSourceTokenList = (localTSourceToken = getEndToken()).container;
    int i = localTSourceToken.posinlist;
    TGSqlParser localTGSqlParser;
    (localTGSqlParser = new TGSqlParser(getGsqlparser().getDbVendor())).sqltext = paramString;
    localTGSqlParser.tokenizeSqltext();
    if (localTGSqlParser.sourcetokenlist.size() == 0) {
      return;
    }
    paramString = localTGSqlParser.sourcetokenlist.get(localTGSqlParser.sourcetokenlist.size() - 1);
    Object localObject;
    for (int j = localTGSqlParser.sourcetokenlist.size() - 1; j >= 0; j--)
    {
      (localObject = localTGSqlParser.sourcetokenlist.get(j)).container = localTSourceTokenList;
      localTSourceTokenList.add(i + 1, (TSourceToken)localObject);
    }
    for (j = i + 1; j < localTSourceTokenList.size(); j++) {
      localTSourceTokenList.get(j).posinlist = j;
    }
    for (j = 0; j < localTSourceToken.getNodesEndWithThisToken().size(); j++) {
      (localObject = localTSourceToken.getNodesEndWithThisToken().getElement(j)).setEndToken(paramString);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor) {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TParseTreeNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */