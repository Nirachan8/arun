package gudusoft.gsqlparser.nodes;

public class TComputeExprList
  extends TParseTreeNodeList
{
  public void addComputeExpr(TComputeExpr paramTComputeExpr)
  {
    addElement(paramTComputeExpr);
  }
  
  public TComputeExpr getComputeExpr(int paramInt)
  {
    if (paramInt < size()) {
      return (TComputeExpr)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addComputeExpr((TComputeExpr)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TComputeExprList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */