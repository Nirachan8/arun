package gudusoft.gsqlparser.nodes;

public class TTableHint
  extends TParseTreeNode
{
  private TObjectName a;
  private TPTNodeList<TExpression> b;
  private boolean c;
  
  public void setHint(TObjectName paramTObjectName)
  {
    this.a = paramTObjectName;
  }
  
  public TPTNodeList<TExpression> getExprList()
  {
    return this.b;
  }
  
  public TObjectName getHint()
  {
    return this.a;
  }
  
  public boolean isIndex()
  {
    return this.c;
  }
  
  public void setIndex(boolean paramBoolean)
  {
    this.c = paramBoolean;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TObjectName))
    {
      this.a = ((TObjectName)paramObject);
      return;
    }
    if ((paramObject instanceof TPTNodeList))
    {
      this.b = ((TPTNodeList)paramObject);
      this.c = true;
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTableHint.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */