package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.stmt.oracle.TExceptionClause;

public class TBlockSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TExceptionClause b = null;
  private TStatementListSqlNode c = null;
  private TStatementListSqlNode d = null;
  
  public TObjectName getLabelName()
  {
    return this.a;
  }
  
  public void setLabelName(TObjectName paramTObjectName)
  {
    this.a = paramTObjectName;
    this.a.setObjectType(14);
  }
  
  public TExceptionClause getExceptionClause()
  {
    return this.b;
  }
  
  public void setExceptionClause(TExceptionClause paramTExceptionClause)
  {
    this.b = paramTExceptionClause;
  }
  
  public TStatementListSqlNode getDeclareStmts()
  {
    return this.d;
  }
  
  public TStatementListSqlNode getStmts()
  {
    return this.c;
  }
  
  public void setDeclareStmts(TStatementListSqlNode paramTStatementListSqlNode)
  {
    this.d = paramTStatementListSqlNode;
  }
  
  public void init(Object paramObject)
  {
    this.c = ((TStatementListSqlNode)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TBlockSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */