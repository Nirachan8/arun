package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.nodes.oracle.TInvokerRightsClause;
import gudusoft.gsqlparser.nodes.oracle.TParallelEnableClause;
import gudusoft.gsqlparser.nodes.oracle.TResultCacheClause;
import gudusoft.gsqlparser.stmt.oracle.TExceptionClause;

public class TCreateFunctionSqlNode
  extends TParseTreeNode
{
  private boolean a;
  private TInvokerRightsClause b;
  private TParallelEnableClause c;
  private TResultCacheClause d;
  private TObjectName e;
  private TObjectName f = null;
  private TParameterDeclarationList g = null;
  private TCallSpec h = null;
  private int i = 1;
  private TBlockSqlNode j = null;
  private TStatementListSqlNode k = null;
  private TStatementListSqlNode l = null;
  private TStatementSqlNode m = null;
  private TExceptionClause n = null;
  private TReturnSqlNode o = null;
  private TTypeName p = null;
  private TDummy q = null;
  private TCompoundSqlNode r = null;
  private TReturnSqlNode s = null;
  
  public void setImplementionType(TObjectName paramTObjectName)
  {
    this.e = paramTObjectName;
  }
  
  public TObjectName getImplementionType()
  {
    return this.e;
  }
  
  public void setFuncHintList(TDummyList paramTDummyList)
  {
    if (paramTDummyList == null) {
      return;
    }
    for (int i1 = 0; i1 < paramTDummyList.size(); i1++)
    {
      TDummy localTDummy;
      if ((localTDummy = paramTDummyList.getDummyItem(i1)).st1 != null) {
        this.a = true;
      } else if ((localTDummy.node1 instanceof TInvokerRightsClause)) {
        this.b = ((TInvokerRightsClause)localTDummy.node1);
      } else if ((localTDummy.node1 instanceof TParallelEnableClause)) {
        this.c = ((TParallelEnableClause)localTDummy.node1);
      } else if ((localTDummy.node1 instanceof TResultCacheClause)) {
        this.d = ((TResultCacheClause)localTDummy.node1);
      }
    }
  }
  
  public boolean isDeterministic()
  {
    return this.a;
  }
  
  public TParallelEnableClause getParallelEnableClause()
  {
    return this.c;
  }
  
  public TResultCacheClause getResultCacheClause()
  {
    return this.d;
  }
  
  public TInvokerRightsClause getInvokerRightsClause()
  {
    return this.b;
  }
  
  public TObjectName getFunctionName()
  {
    return this.f;
  }
  
  public void setParameters(TParameterDeclarationList paramTParameterDeclarationList)
  {
    this.g = paramTParameterDeclarationList;
  }
  
  public void init(Object paramObject)
  {
    this.f = ((TObjectName)paramObject);
    this.f.setObjectType(13);
  }
  
  public void setKind(int paramInt)
  {
    this.i = paramInt;
  }
  
  public int getKind()
  {
    return this.i;
  }
  
  public TCallSpec getCallSpec()
  {
    return this.h;
  }
  
  public void setCallSpec(TCallSpec paramTCallSpec)
  {
    this.h = paramTCallSpec;
  }
  
  public void setStmt(TStatementSqlNode paramTStatementSqlNode)
  {
    this.m = paramTStatementSqlNode;
  }
  
  public TStatementSqlNode getStmt()
  {
    return this.m;
  }
  
  public TExceptionClause getExceptionClause()
  {
    return this.n;
  }
  
  public void setExceptionClause(TExceptionClause paramTExceptionClause)
  {
    this.n = paramTExceptionClause;
  }
  
  public TStatementListSqlNode getDeclareStmts()
  {
    return this.l;
  }
  
  public void setDeclareStmts(TStatementListSqlNode paramTStatementListSqlNode)
  {
    this.l = paramTStatementListSqlNode;
  }
  
  public TStatementListSqlNode getStmts()
  {
    return this.k;
  }
  
  public void setStmts(TStatementListSqlNode paramTStatementListSqlNode)
  {
    this.k = paramTStatementListSqlNode;
  }
  
  public TBlockSqlNode getBlcok()
  {
    return this.j;
  }
  
  public TReturnSqlNode getReturnSqlNode()
  {
    return this.o;
  }
  
  public void setReturnSqlNode(TReturnSqlNode paramTReturnSqlNode)
  {
    this.o = paramTReturnSqlNode;
  }
  
  public void setBlcok(TBlockSqlNode paramTBlockSqlNode)
  {
    this.j = paramTBlockSqlNode;
  }
  
  public TParameterDeclarationList getParameters()
  {
    return this.g;
  }
  
  public void setReturnDataType(TTypeName paramTTypeName)
  {
    this.p = paramTTypeName;
  }
  
  public TTypeName getReturnDataType()
  {
    return this.p;
  }
  
  public void setReturnTable(TDummy paramTDummy)
  {
    this.q = paramTDummy;
  }
  
  public TDummy getReturnTable()
  {
    return this.q;
  }
  
  public TCompoundSqlNode getCompoundSql()
  {
    return this.r;
  }
  
  public TReturnSqlNode getReturnSql()
  {
    return this.s;
  }
  
  public void setBody(Object paramObject)
  {
    if ((paramObject instanceof TReturnSqlNode))
    {
      this.s = ((TReturnSqlNode)paramObject);
      return;
    }
    if ((paramObject instanceof TCompoundSqlNode)) {
      this.r = ((TCompoundSqlNode)paramObject);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCreateFunctionSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */