package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TGroupingSetItem
  extends TParseTreeNode
{
  private TRollupCube a;
  private TGroupingExpressionItem b;
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TRollupCube))
    {
      this.a = ((TRollupCube)paramObject);
      return;
    }
    if ((paramObject instanceof TGroupingExpressionItem)) {
      this.b = ((TGroupingExpressionItem)paramObject);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null)
    {
      this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    }
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
  
  public TGroupingExpressionItem getExpressionItem()
  {
    return this.b;
  }
  
  public TRollupCube getRollupCubeClause()
  {
    return this.a;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TGroupingSetItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */