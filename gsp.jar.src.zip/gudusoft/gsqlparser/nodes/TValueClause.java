package gudusoft.gsqlparser.nodes;

public class TValueClause
  extends TParseTreeNode
{
  public void init(Object paramObject1, Object paramObject2) {}
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TValueClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */