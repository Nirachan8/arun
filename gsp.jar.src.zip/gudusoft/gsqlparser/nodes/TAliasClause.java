package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TAliasClause
  extends TParseTreeNode
{
  private boolean a;
  private TObjectName b = null;
  private TObjectNameList c = null;
  private TSourceToken d = null;
  
  public void setTeradataNamedAlais(boolean paramBoolean)
  {
    this.a = paramBoolean;
  }
  
  public boolean isTeradataNamedAlais()
  {
    return this.a;
  }
  
  public TObjectNameList getColumns()
  {
    return this.c;
  }
  
  public void setAsToken(TSourceToken paramTSourceToken)
  {
    this.d = paramTSourceToken;
  }
  
  public TSourceToken getAsToken()
  {
    return this.d;
  }
  
  public TObjectName getAliasName()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    init(paramObject1);
    this.c = ((TObjectNameList)paramObject2);
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TObjectName))
    {
      this.b = ((TObjectName)paramObject);
    }
    else if ((paramObject instanceof TConstant))
    {
      this.b = new TObjectName();
      this.b.init(null, ((TConstant)paramObject).getvalueToken());
    }
    else if ((paramObject instanceof TSourceToken))
    {
      this.b = new TObjectName();
      this.b.init(null, (TSourceToken)paramObject);
    }
    if (this.b != null) {
      this.b.setObjectType(4);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TAliasClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */