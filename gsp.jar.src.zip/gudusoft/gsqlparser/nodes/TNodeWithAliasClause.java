package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.TSourceTokenList;

public class TNodeWithAliasClause
  extends TParseTreeNode
{
  private TAliasClause a = null;
  
  public void setAliasClause(TAliasClause paramTAliasClause)
  {
    this.a = paramTAliasClause;
  }
  
  public TAliasClause getAliasClause()
  {
    return this.a;
  }
  
  public String toString()
  {
    Object localObject1;
    Object localObject2;
    if (getAliasClause() == null)
    {
      localObject1 = super.toString();
    }
    else
    {
      if ((localObject1 = getStartToken()) == null) {
        return null;
      }
      TSourceToken localTSourceToken;
      if (getAliasClause().getAsToken() != null) {
        localTSourceToken = getAliasClause().getAsToken().container.nextsolidtoken(getAliasClause().getAsToken(), -1, false);
      } else {
        localTSourceToken = getAliasClause().getStartToken().container.nextsolidtoken(getAliasClause().getStartToken(), -1, false);
      }
      if (localTSourceToken == null) {
        return null;
      }
      if (getGsqlparser() == null) {
        setGsqlparser(((TSourceToken)localObject1).getGsqlparser());
      }
      TSourceTokenList localTSourceTokenList;
      if ((localTSourceTokenList = ((TSourceToken)localObject1).container) == null) {
        return null;
      }
      StringBuffer localStringBuffer = new StringBuffer("");
      int i = localTSourceTokenList.indexOf((TSourceToken)localObject1);
      int j = localTSourceTokenList.indexOf(localTSourceToken);
      for (int k = i; k <= j; k++)
      {
        localObject2 = localTSourceTokenList.get(k);
        localStringBuffer.append(((TSourceToken)localObject2).toString());
      }
      localObject2 = localStringBuffer.toString();
    }
    return (String)localObject2;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TNodeWithAliasClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */