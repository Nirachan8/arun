package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EFunctionType;
import gudusoft.gsqlparser.ETableSource;
import gudusoft.gsqlparser.TSourceToken;

public class TFromTable
  extends TNodeWithAliasClause
{
  private TPartitionExtensionClause a;
  private TXmlTable b;
  private TObjectName c;
  private TPTNodeList<TTableHint> d;
  private TSelectSqlNode e;
  private TExpression f;
  private TMultiTargetList g;
  private TJoinExpr h;
  private ETableSource i;
  private TOpenDatasource j = null;
  private TOpenXML k = null;
  private TOpenRowSet l = null;
  private TOpenQuery m = null;
  private TContainsTable n = null;
  private TDataChangeTable o = null;
  private TRelationExpr p;
  private TPivotClause q = null;
  private TFunctionCall r = null;
  private TInformixOuterClause s;
  private TFromTableList t;
  
  public TPartitionExtensionClause getPartitionExtensionClause()
  {
    return this.a;
  }
  
  public void setPartitionExtensionClause(TPartitionExtensionClause paramTPartitionExtensionClause)
  {
    this.a = paramTPartitionExtensionClause;
  }
  
  public TXmlTable getXmlTable()
  {
    return this.b;
  }
  
  public TObjectName getTableObjectName()
  {
    return this.c;
  }
  
  public TExpression getTableExpr()
  {
    return this.f;
  }
  
  public void setTableObjectName(TObjectName paramTObjectName)
  {
    this.c = paramTObjectName;
    this.c.setObjectType(3);
  }
  
  public TOpenQuery getOpenQuery()
  {
    return this.m;
  }
  
  public void setTableHintList(TPTNodeList<TTableHint> paramTPTNodeList)
  {
    this.d = paramTPTNodeList;
  }
  
  public TPTNodeList<TTableHint> getTableHintList()
  {
    return this.d;
  }
  
  public TSelectSqlNode getSubquerynode()
  {
    return this.e;
  }
  
  public TMultiTargetList getRowList()
  {
    return this.g;
  }
  
  public TJoinExpr getJoinExpr()
  {
    return this.h;
  }
  
  public ETableSource getFromtableType()
  {
    return this.i;
  }
  
  public TOpenDatasource getOpenDatasource()
  {
    return this.j;
  }
  
  public TOpenRowSet getOpenRowSet()
  {
    return this.l;
  }
  
  public TOpenXML getOpenXML()
  {
    return this.k;
  }
  
  public TContainsTable getContainsTable()
  {
    return this.n;
  }
  
  public void setTableonly(TSourceToken paramTSourceToken) {}
  
  public void setTableSample(TTableSample paramTTableSample) {}
  
  public void setPxGranule(TPxGranule paramTPxGranule) {}
  
  public void setFlashback(TFlashback paramTFlashback) {}
  
  public TRelationExpr getRelationExpr()
  {
    return this.p;
  }
  
  public TDataChangeTable getDatachangeTable()
  {
    return this.o;
  }
  
  public void setPivotClause(TPivotClause paramTPivotClause)
  {
    this.q = paramTPivotClause;
  }
  
  public TPivotClause getPivotClause()
  {
    return this.q;
  }
  
  public TFunctionCall getFuncCall()
  {
    return this.r;
  }
  
  public TFromTableList getFromTableList()
  {
    return this.t;
  }
  
  public TInformixOuterClause getOuterClause()
  {
    return this.s;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TObjectName))
    {
      setTableObjectName((TObjectName)paramObject);
      this.i = ETableSource.objectname;
      return;
    }
    if ((paramObject instanceof TSelectSqlNode))
    {
      this.e = ((TSelectSqlNode)paramObject);
      this.i = ETableSource.subquery;
      return;
    }
    if ((paramObject instanceof TExpression))
    {
      this.f = ((TExpression)paramObject);
      this.i = ETableSource.tableExpr;
      return;
    }
    if ((paramObject instanceof TJoinExpr))
    {
      this.h = ((TJoinExpr)paramObject);
      this.i = ETableSource.join;
      return;
    }
    if ((paramObject instanceof TDummy))
    {
      a((TDummy)paramObject);
      return;
    }
    if ((paramObject instanceof TContainsTable))
    {
      this.n = ((TContainsTable)paramObject);
      this.i = ETableSource.containsTable;
      return;
    }
    if ((paramObject instanceof TOpenRowSet))
    {
      this.l = ((TOpenRowSet)paramObject);
      this.i = ETableSource.openrowset;
      return;
    }
    if ((paramObject instanceof TOpenXML))
    {
      this.k = ((TOpenXML)paramObject);
      this.i = ETableSource.openxml;
      return;
    }
    if ((paramObject instanceof TOpenDatasource))
    {
      this.j = ((TOpenDatasource)paramObject);
      this.i = ETableSource.opendatasource;
      return;
    }
    if ((paramObject instanceof TOpenQuery))
    {
      this.m = ((TOpenQuery)paramObject);
      this.i = ETableSource.openquery;
      return;
    }
    if ((paramObject instanceof TDataChangeTable))
    {
      this.o = ((TDataChangeTable)paramObject);
      this.i = ETableSource.datachangeTable;
      return;
    }
    if ((paramObject instanceof TRelationExpr))
    {
      this.p = ((TRelationExpr)paramObject);
      setTableObjectName(this.p.getRelationName());
      this.i = ETableSource.objectname;
      return;
    }
    if ((paramObject instanceof TFunctionCall))
    {
      this.r = ((TFunctionCall)paramObject);
      this.i = ETableSource.function;
      return;
    }
    if ((paramObject instanceof TMultiTargetList))
    {
      this.g = ((TMultiTargetList)paramObject);
      this.i = ETableSource.rowList;
      return;
    }
    if ((paramObject instanceof TXmlTable))
    {
      this.b = ((TXmlTable)paramObject);
      this.i = ETableSource.xmltable;
      return;
    }
    if ((paramObject instanceof TInformixOuterClause))
    {
      this.s = ((TInformixOuterClause)paramObject);
      this.i = ETableSource.informixOuter;
      return;
    }
    if ((paramObject instanceof TFromTableList))
    {
      this.i = ETableSource.table_ref_list;
      this.t = ((TFromTableList)paramObject);
    }
  }
  
  private TPTNodeList<TTableHint> a(Object paramObject)
  {
    TPTNodeList localTPTNodeList = new TPTNodeList();
    int i1;
    Object localObject;
    TTableHint localTTableHint;
    if ((paramObject instanceof TObjectNameList))
    {
      paramObject = (TObjectNameList)paramObject;
      for (i1 = 0; i1 < ((TObjectNameList)paramObject).size(); i1++) {
        if (a((localObject = ((TObjectNameList)paramObject).getObjectName(i1)).toString()))
        {
          (localTTableHint = new TTableHint()).setHint((TObjectName)localObject);
          if (i1 == 0) {
            localTTableHint.setStartToken(((TObjectName)localObject).getStartToken());
          }
          if (i1 == ((TObjectNameList)paramObject).size() - 1) {
            localTTableHint.setEndToken(((TObjectName)localObject).getStartToken());
          }
          localTPTNodeList.addElement(localTTableHint);
        }
        else
        {
          localTPTNodeList.a();
          break;
        }
      }
    }
    else if ((paramObject instanceof TExpressionList))
    {
      paramObject = (TExpressionList)paramObject;
      for (i1 = 0; i1 < ((TExpressionList)paramObject).size(); i1++) {
        if (a((localObject = ((TExpressionList)paramObject).getExpression(i1)).toString()))
        {
          (localTTableHint = new TTableHint()).setHint(((TExpression)localObject).getObjectOperand());
          if (i1 == 0) {
            localTTableHint.setStartToken(((TExpression)localObject).getStartToken());
          }
          if (i1 == ((TExpressionList)paramObject).size() - 1) {
            localTTableHint.setEndToken(((TExpression)localObject).getStartToken());
          }
          localTPTNodeList.addElement(localTTableHint);
        }
        else
        {
          localTPTNodeList.a();
          break;
        }
      }
    }
    if (localTPTNodeList.size() > 0) {
      return localTPTNodeList;
    }
    return null;
  }
  
  private static boolean a(String paramString)
  {
    boolean bool = false;
    String[] arrayOfString = { "fastfirstrow", "holdlock", "nolock", "nowait", "paglock", "readcommitted", "readcommittedlock", "readpast", "readuncommitted", "repeatableread", "rowlock", "serializable", "tablock", "tablockx", "updlock", "xlock", "keepidentity", "keepdefaults", "ignore_constraints", "ignore_triggers", "index" };
    for (int i1 = 0; i1 < 21; i1++) {
      if (arrayOfString[i1].compareToIgnoreCase(paramString) == 0)
      {
        bool = true;
        break;
      }
    }
    return bool;
  }
  
  private void a(TDummy paramTDummy)
  {
    this.i = ETableSource.objectname;
    if (paramTDummy.int1 == 0) {
      setTableObjectName((TObjectName)paramTDummy.node1);
    } else if (paramTDummy.int1 == 1)
    {
      if (paramTDummy.list1 == null)
      {
        this.r = new TFunctionCall();
        this.r.init(EFunctionType.udf_t, (TObjectName)paramTDummy.node1);
        this.r.setArgs(null);
        this.i = ETableSource.function;
      }
      else
      {
        this.d = a((TExpressionList)paramTDummy.list1);
        if (this.d != null)
        {
          setTableObjectName((TObjectName)paramTDummy.node1);
        }
        else
        {
          this.r = new TFunctionCall();
          this.r.init(EFunctionType.udf_t, (TObjectName)paramTDummy.node1);
          this.r.setArgs((TExpressionList)paramTDummy.list1);
          this.i = ETableSource.function;
        }
      }
    }
    else if (paramTDummy.int1 == 2) {
      setTableObjectName((TObjectName)paramTDummy.node1);
    }
    if (paramTDummy.node2 != null)
    {
      setAliasClause((TAliasClause)paramTDummy.node2);
      if (getAliasClause().getColumns() != null) {
        this.d = a(getAliasClause().getColumns());
      }
    }
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    init(paramObject1);
    if (paramObject2 != null) {
      setAliasClause((TAliasClause)paramObject2);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TFromTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */