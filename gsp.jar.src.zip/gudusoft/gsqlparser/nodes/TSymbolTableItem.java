package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TCustomSqlStatement;

public class TSymbolTableItem
{
  private int a = 0;
  private TCustomSqlStatement b = null;
  private TParseTreeNode c = null;
  
  public TParseTreeNode getData()
  {
    return this.c;
  }
  
  public TCustomSqlStatement getStmt()
  {
    return this.b;
  }
  
  public int getType()
  {
    return this.a;
  }
  
  public TSymbolTableItem(int paramInt, TCustomSqlStatement paramTCustomSqlStatement, TParseTreeNode paramTParseTreeNode)
  {
    this.a = paramInt;
    this.b = paramTCustomSqlStatement;
    this.c = paramTParseTreeNode;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TSymbolTableItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */