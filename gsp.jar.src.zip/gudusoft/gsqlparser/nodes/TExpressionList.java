package gudusoft.gsqlparser.nodes;

public class TExpressionList
  extends TParseTreeNodeList
{
  public void addExpression(TExpression paramTExpression)
  {
    addElement(paramTExpression);
  }
  
  public TExpression getExpression(int paramInt)
  {
    if (paramInt < size()) {
      return (TExpression)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addExpression((TExpression)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      getExpression(i).accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TExpressionList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */