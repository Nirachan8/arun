package gudusoft.gsqlparser.nodes;

public class TMergeSqlNode
  extends TParseTreeNode
{
  private TFromTable a = null;
  private TFromTable b = null;
  private TExpression c = null;
  private TObjectNameList d = null;
  public TCTEList cteList = null;
  private TPTNodeList<TMergeWhenClause> e;
  
  public TObjectNameList getColumnList()
  {
    return this.d;
  }
  
  public void setColumnList(TObjectNameList paramTObjectNameList)
  {
    this.d = paramTObjectNameList;
  }
  
  public TPTNodeList<TMergeWhenClause> getWhenClauses()
  {
    return this.e;
  }
  
  public void setWhenClauses(TPTNodeList<TMergeWhenClause> paramTPTNodeList)
  {
    this.e = paramTPTNodeList;
  }
  
  public TFromTable getTargetTable()
  {
    return this.a;
  }
  
  public TFromTable getUsingTable()
  {
    return this.b;
  }
  
  public TExpression getCondition()
  {
    return this.c;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.a = ((TFromTable)paramObject1);
    this.b = ((TFromTable)paramObject2);
    this.c = ((TExpression)paramObject3);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TMergeSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */