package gudusoft.gsqlparser.nodes;

public class TRepeatSqlNode
  extends TParseTreeNode
{
  private TExpression a = null;
  private TStatementListSqlNode b = null;
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TExpression)paramObject1);
    this.b = ((TStatementListSqlNode)paramObject2);
  }
  
  public TExpression getCondition()
  {
    return this.a;
  }
  
  public TStatementListSqlNode getStmts()
  {
    return this.b;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TRepeatSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */