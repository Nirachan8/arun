package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TInsertIntoValue
  extends TParseTreeNode
{
  private TFromTable a;
  private TMultiTargetList b;
  private TObjectNameList c;
  private TTable d;
  
  public TTable getTable()
  {
    return this.d;
  }
  
  public TObjectNameList getColumnList()
  {
    return this.c;
  }
  
  public TMultiTargetList getTargetList()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TFromTable)((TDummy)paramObject1).node1);
    if (((TDummy)paramObject1).node1 != null) {
      this.c = ((TObjectNameList)((TDummy)paramObject1).node2);
    }
    if (paramObject2 != null) {
      this.b = ((TMultiTargetList)((TDummy)paramObject2).list1);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    this.d = paramTCustomSqlStatement.analyzeFromTable(this.a);
    if (this.c != null) {
      for (int i = 0; i < this.c.size(); i++)
      {
        (paramESqlClause = this.c.getObjectName(i)).setLocation(ESqlClause.resultColumn);
        this.d.getObjectNameReferences().addObjectName(paramESqlClause);
      }
    }
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, ESqlClause.insertValues);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TInsertIntoValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */