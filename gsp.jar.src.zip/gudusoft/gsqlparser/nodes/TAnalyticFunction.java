package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TAnalyticFunction
  extends TParseTreeNode
{
  private TKeepDenseRankClause a = null;
  private TExpressionList b = null;
  private TOrderBy c = null;
  
  public void setOrderBy(TOrderBy paramTOrderBy)
  {
    this.c = paramTOrderBy;
  }
  
  public void setPartitionBy_ExprList(TExpressionList paramTExpressionList)
  {
    this.b = paramTExpressionList;
  }
  
  public void setKeepDenseRankClause(TKeepDenseRankClause paramTKeepDenseRankClause)
  {
    this.a = paramTKeepDenseRankClause;
  }
  
  public TKeepDenseRankClause getKeepDenseRankClause()
  {
    return this.a;
  }
  
  public TOrderBy getOrderBy()
  {
    return this.c;
  }
  
  public TExpressionList getPartitionBy_ExprList()
  {
    return this.b;
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null) {
      this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if (this.c != null) {
      this.c.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TAnalyticFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */