package gudusoft.gsqlparser.nodes;

public class TPrecisionScale
  extends TParseTreeNode
{
  private TConstant a;
  private TConstant b;
  
  public TConstant getPrecision()
  {
    return this.a;
  }
  
  public TConstant getScale()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TConstant)paramObject1);
    this.b = ((TConstant)paramObject2);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TPrecisionScale.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */