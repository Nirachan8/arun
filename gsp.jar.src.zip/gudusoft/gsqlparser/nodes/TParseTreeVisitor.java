package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TStatementList;
import gudusoft.gsqlparser.nodes.mdx.TMdxAxisNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxBinOpNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxCalcPropNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxCaseNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxDimContentNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxDimensionNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxEmptyNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxExpNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxFloatConstNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxFunctionNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxGroupNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxIdentifierNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxIntegerConstNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxLevelContentNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxLevelNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxMeasureNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxMemberNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxNonEmptyNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxPropertyNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxSetNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxStringConstNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxTupleNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxUnaryOpNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxWhenNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxWhereNode;
import gudusoft.gsqlparser.nodes.mdx.TMdxWithNode;
import gudusoft.gsqlparser.stmt.TAlterSessionStatement;
import gudusoft.gsqlparser.stmt.TAlterTableStatement;
import gudusoft.gsqlparser.stmt.TCreateIndexSqlStatement;
import gudusoft.gsqlparser.stmt.TCreateMaterializedSqlStatement;
import gudusoft.gsqlparser.stmt.TCreateSequenceStmt;
import gudusoft.gsqlparser.stmt.TCreateSynonymStmt;
import gudusoft.gsqlparser.stmt.TCreateTableSqlStatement;
import gudusoft.gsqlparser.stmt.TCreateViewSqlStatement;
import gudusoft.gsqlparser.stmt.TDeleteSqlStatement;
import gudusoft.gsqlparser.stmt.TDropIndexSqlStatement;
import gudusoft.gsqlparser.stmt.TDropTableSqlStatement;
import gudusoft.gsqlparser.stmt.TDropViewSqlStatement;
import gudusoft.gsqlparser.stmt.TInsertSqlStatement;
import gudusoft.gsqlparser.stmt.TMergeSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import gudusoft.gsqlparser.stmt.TTruncateStatement;
import gudusoft.gsqlparser.stmt.TUnknownSqlStatement;
import gudusoft.gsqlparser.stmt.TUpdateSqlStatement;
import gudusoft.gsqlparser.stmt.db2.TDb2StmtStub;
import gudusoft.gsqlparser.stmt.mdx.TMdxCall;
import gudusoft.gsqlparser.stmt.mdx.TMdxCreateMember;
import gudusoft.gsqlparser.stmt.mdx.TMdxCreateSessionCube;
import gudusoft.gsqlparser.stmt.mdx.TMdxCreateSubCube;
import gudusoft.gsqlparser.stmt.mdx.TMdxDrillthrough;
import gudusoft.gsqlparser.stmt.mdx.TMdxExpression;
import gudusoft.gsqlparser.stmt.mdx.TMdxScope;
import gudusoft.gsqlparser.stmt.mdx.TMdxSelect;
import gudusoft.gsqlparser.stmt.mssql.TMssqlBeginDialog;
import gudusoft.gsqlparser.stmt.mssql.TMssqlBeginTran;
import gudusoft.gsqlparser.stmt.mssql.TMssqlBlock;
import gudusoft.gsqlparser.stmt.mssql.TMssqlBreak;
import gudusoft.gsqlparser.stmt.mssql.TMssqlBulkInsert;
import gudusoft.gsqlparser.stmt.mssql.TMssqlClose;
import gudusoft.gsqlparser.stmt.mssql.TMssqlCommit;
import gudusoft.gsqlparser.stmt.mssql.TMssqlContinue;
import gudusoft.gsqlparser.stmt.mssql.TMssqlCreateFunction;
import gudusoft.gsqlparser.stmt.mssql.TMssqlCreateProcedure;
import gudusoft.gsqlparser.stmt.mssql.TMssqlCreateTrigger;
import gudusoft.gsqlparser.stmt.mssql.TMssqlDeallocate;
import gudusoft.gsqlparser.stmt.mssql.TMssqlDeclare;
import gudusoft.gsqlparser.stmt.mssql.TMssqlEndConversation;
import gudusoft.gsqlparser.stmt.mssql.TMssqlExecute;
import gudusoft.gsqlparser.stmt.mssql.TMssqlExecuteAs;
import gudusoft.gsqlparser.stmt.mssql.TMssqlFetch;
import gudusoft.gsqlparser.stmt.mssql.TMssqlGo;
import gudusoft.gsqlparser.stmt.mssql.TMssqlGoTo;
import gudusoft.gsqlparser.stmt.mssql.TMssqlGrant;
import gudusoft.gsqlparser.stmt.mssql.TMssqlIfElse;
import gudusoft.gsqlparser.stmt.mssql.TMssqlLabel;
import gudusoft.gsqlparser.stmt.mssql.TMssqlOpen;
import gudusoft.gsqlparser.stmt.mssql.TMssqlPrint;
import gudusoft.gsqlparser.stmt.mssql.TMssqlRaiserror;
import gudusoft.gsqlparser.stmt.mssql.TMssqlReturn;
import gudusoft.gsqlparser.stmt.mssql.TMssqlRevert;
import gudusoft.gsqlparser.stmt.mssql.TMssqlRollback;
import gudusoft.gsqlparser.stmt.mssql.TMssqlSaveTran;
import gudusoft.gsqlparser.stmt.mssql.TMssqlSendOnConversation;
import gudusoft.gsqlparser.stmt.mssql.TMssqlStmtStub;
import gudusoft.gsqlparser.stmt.mssql.TMssqlTruncateTable;
import gudusoft.gsqlparser.stmt.mssql.TMssqlUpdateText;
import gudusoft.gsqlparser.stmt.mssql.TMssqlUse;
import gudusoft.gsqlparser.stmt.mysql.TMySQLCreateFunction;
import gudusoft.gsqlparser.stmt.mysql.TMySQLCreateProcedure;
import gudusoft.gsqlparser.stmt.mysql.TMySQLCreateTrigger;
import gudusoft.gsqlparser.stmt.mysql.TMySQLDeclare;
import gudusoft.gsqlparser.stmt.mysql.TMySQLStmtStub;
import gudusoft.gsqlparser.stmt.oracle.TExceptionClause;
import gudusoft.gsqlparser.stmt.oracle.TExceptionHandler;
import gudusoft.gsqlparser.stmt.oracle.TExceptionHandlerList;
import gudusoft.gsqlparser.stmt.oracle.TOracleCommentOnSqlStmt;
import gudusoft.gsqlparser.stmt.oracle.TOracleExecuteProcedure;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlAssignStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlBasicStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlBlock;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlCaseStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlCloseStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlCreateFunction;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlCreatePackage;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlCreateProcedure;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlCreateTrigger;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlCreateType;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlCreateTypeBody;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlCreateType_Placeholder;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlCursorDeclStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlDummyStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlElsifStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlExecImmeStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlExitStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlFetchStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlForallStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlGotoStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlIfStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlLoopStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlNullStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlOpenStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlOpenforStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlPipeRowStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlPragmaDeclStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlProcedureSpecStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlRaiseStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlRecordTypeDefStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlReturnStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlSqlStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlSubProgram;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlTableTypeDefStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlVarDeclStmt;
import gudusoft.gsqlparser.stmt.oracle.TPlsqlVarrayTypeDefStmt;
import gudusoft.gsqlparser.stmt.oracle.TSqlplusCmdStatement;

public class TParseTreeVisitor
{
  public void preVisit(TObjectName paramTObjectName) {}
  
  public void postVisit(TObjectName paramTObjectName) {}
  
  public void preVisit(TObjectNameList paramTObjectNameList) {}
  
  public void postVisit(TObjectNameList paramTObjectNameList) {}
  
  public void preVisit(TConstant paramTConstant) {}
  
  public void postVisit(TConstant paramTConstant) {}
  
  public void preVisit(TConstantList paramTConstantList) {}
  
  public void postVisit(TConstantList paramTConstantList) {}
  
  public void preVisit(TExpression paramTExpression) {}
  
  public void postVisit(TExpression paramTExpression) {}
  
  public void preVisit(TExpressionList paramTExpressionList) {}
  
  public void postVisit(TExpressionList paramTExpressionList) {}
  
  public void preVisit(TInExpr paramTInExpr) {}
  
  public void postVisit(TInExpr paramTInExpr) {}
  
  public void preVisit(TGroupingExpressionItem paramTGroupingExpressionItem) {}
  
  public void postVisit(TGroupingExpressionItem paramTGroupingExpressionItem) {}
  
  public void preVisit(TGroupingExpressionItemList paramTGroupingExpressionItemList) {}
  
  public void postVisit(TGroupingExpressionItemList paramTGroupingExpressionItemList) {}
  
  public void preVisit(TResultColumn paramTResultColumn) {}
  
  public void postVisit(TResultColumn paramTResultColumn) {}
  
  public void preVisit(TResultColumnList paramTResultColumnList) {}
  
  public void postVisit(TResultColumnList paramTResultColumnList) {}
  
  public void preVisit(TTable paramTTable) {}
  
  public void postVisit(TTable paramTTable) {}
  
  public void preVisit(TCTE paramTCTE) {}
  
  public void postVisit(TCTE paramTCTE) {}
  
  public void preVisit(TCTEList paramTCTEList) {}
  
  public void postVisit(TCTEList paramTCTEList) {}
  
  public void preVisit(TTopClause paramTTopClause) {}
  
  public void postVisit(TTopClause paramTTopClause) {}
  
  public void preVisit(TIntoClause paramTIntoClause) {}
  
  public void postVisit(TIntoClause paramTIntoClause) {}
  
  public void preVisit(TPivotClause paramTPivotClause) {}
  
  public void postVisit(TPivotClause paramTPivotClause) {}
  
  public void preVisit(TCaseExpression paramTCaseExpression) {}
  
  public void postVisit(TCaseExpression paramTCaseExpression) {}
  
  public void preVisit(TWhenClauseItem paramTWhenClauseItem) {}
  
  public void postVisit(TWhenClauseItem paramTWhenClauseItem) {}
  
  public void preVisit(TWhenClauseItemList paramTWhenClauseItemList) {}
  
  public void postVisit(TWhenClauseItemList paramTWhenClauseItemList) {}
  
  public void preVisit(TJoin paramTJoin) {}
  
  public void postVisit(TJoin paramTJoin) {}
  
  public void preVisit(TJoinList paramTJoinList) {}
  
  public void postVisit(TJoinList paramTJoinList) {}
  
  public void preVisit(TJoinItem paramTJoinItem) {}
  
  public void postVisit(TJoinItem paramTJoinItem) {}
  
  public void preVisit(TJoinItemList paramTJoinItemList) {}
  
  public void postVisit(TJoinItemList paramTJoinItemList) {}
  
  public void preVisit(TWhereClause paramTWhereClause) {}
  
  public void postVisit(TWhereClause paramTWhereClause) {}
  
  public void preVisit(TOpenDatasource paramTOpenDatasource) {}
  
  public void postVisit(TOpenDatasource paramTOpenDatasource) {}
  
  public void preVisit(TContainsTable paramTContainsTable) {}
  
  public void postVisit(TContainsTable paramTContainsTable) {}
  
  public void preVisit(TOpenXML paramTOpenXML) {}
  
  public void postVisit(TOpenXML paramTOpenXML) {}
  
  public void preVisit(TOpenRowSet paramTOpenRowSet) {}
  
  public void postVisit(TOpenRowSet paramTOpenRowSet) {}
  
  public void preVisit(TTypeAttribute paramTTypeAttribute) {}
  
  public void postVisit(TTypeAttribute paramTTypeAttribute) {}
  
  public void preVisit(TTypeAttributeList paramTTypeAttributeList) {}
  
  public void postVisit(TTypeAttributeList paramTTypeAttributeList) {}
  
  public void preVisit(THierarchical paramTHierarchical) {}
  
  public void postVisit(THierarchical paramTHierarchical) {}
  
  public void preVisit(TGroupBy paramTGroupBy) {}
  
  public void postVisit(TGroupBy paramTGroupBy) {}
  
  public void preVisit(TGroupByItem paramTGroupByItem) {}
  
  public void postVisit(TGroupByItem paramTGroupByItem) {}
  
  public void preVisit(TGroupByItemList paramTGroupByItemList) {}
  
  public void postVisit(TGroupByItemList paramTGroupByItemList) {}
  
  public void preVisit(TOrderBy paramTOrderBy) {}
  
  public void postVisit(TOrderBy paramTOrderBy) {}
  
  public void preVisit(TOrderByItem paramTOrderByItem) {}
  
  public void postVisit(TOrderByItem paramTOrderByItem) {}
  
  public void preVisit(TOrderByItemList paramTOrderByItemList) {}
  
  public void postVisit(TOrderByItemList paramTOrderByItemList) {}
  
  public void preVisit(TForUpdate paramTForUpdate) {}
  
  public void postVisit(TForUpdate paramTForUpdate) {}
  
  public void preVisit(TComputeClause paramTComputeClause) {}
  
  public void postVisit(TComputeClause paramTComputeClause) {}
  
  public void preVisit(TComputeClauseItem paramTComputeClauseItem) {}
  
  public void postVisit(TComputeClauseItem paramTComputeClauseItem) {}
  
  public void preVisit(TComputeClauseItemList paramTComputeClauseItemList) {}
  
  public void postVisit(TComputeClauseItemList paramTComputeClauseItemList) {}
  
  public void preVisit(TAliasClause paramTAliasClause) {}
  
  public void postVisit(TAliasClause paramTAliasClause) {}
  
  public void preVisit(TStatementList paramTStatementList) {}
  
  public void postVisit(TStatementList paramTStatementList) {}
  
  public void preVisit(TPlsqlBlock paramTPlsqlBlock) {}
  
  public void postVisit(TPlsqlBlock paramTPlsqlBlock) {}
  
  public void preVisit(TExceptionClause paramTExceptionClause) {}
  
  public void postVisit(TExceptionClause paramTExceptionClause) {}
  
  public void preVisit(TExceptionHandler paramTExceptionHandler) {}
  
  public void postVisit(TExceptionHandler paramTExceptionHandler) {}
  
  public void preVisit(TExceptionHandlerList paramTExceptionHandlerList) {}
  
  public void postVisit(TExceptionHandlerList paramTExceptionHandlerList) {}
  
  public void preVisit(TPlsqlAssignStmt paramTPlsqlAssignStmt) {}
  
  public void postVisit(TPlsqlAssignStmt paramTPlsqlAssignStmt) {}
  
  public void preVisit(TPlsqlBasicStmt paramTPlsqlBasicStmt) {}
  
  public void postVisit(TPlsqlBasicStmt paramTPlsqlBasicStmt) {}
  
  public void preVisit(TPlsqlCaseStmt paramTPlsqlCaseStmt) {}
  
  public void postVisit(TPlsqlCaseStmt paramTPlsqlCaseStmt) {}
  
  public void preVisit(TPlsqlCloseStmt paramTPlsqlCloseStmt) {}
  
  public void postVisit(TPlsqlCloseStmt paramTPlsqlCloseStmt) {}
  
  public void preVisit(TPlsqlCreateFunction paramTPlsqlCreateFunction) {}
  
  public void postVisit(TPlsqlCreateFunction paramTPlsqlCreateFunction) {}
  
  public void preVisit(TPlsqlCreatePackage paramTPlsqlCreatePackage) {}
  
  public void postVisit(TPlsqlCreatePackage paramTPlsqlCreatePackage) {}
  
  public void preVisit(TPlsqlCreateProcedure paramTPlsqlCreateProcedure) {}
  
  public void postVisit(TPlsqlCreateProcedure paramTPlsqlCreateProcedure) {}
  
  public void preVisit(TPlsqlCreateTrigger paramTPlsqlCreateTrigger) {}
  
  public void postVisit(TPlsqlCreateTrigger paramTPlsqlCreateTrigger) {}
  
  public void preVisit(TPlsqlCreateType paramTPlsqlCreateType) {}
  
  public void postVisit(TPlsqlCreateType paramTPlsqlCreateType) {}
  
  public void preVisit(TPlsqlCreateType_Placeholder paramTPlsqlCreateType_Placeholder) {}
  
  public void postVisit(TPlsqlCreateType_Placeholder paramTPlsqlCreateType_Placeholder) {}
  
  public void preVisit(TPlsqlCreateTypeBody paramTPlsqlCreateTypeBody) {}
  
  public void postVisit(TPlsqlCreateTypeBody paramTPlsqlCreateTypeBody) {}
  
  public void postVisit(TPlsqlCursorDeclStmt paramTPlsqlCursorDeclStmt) {}
  
  public void postVisit(TPlsqlDummyStmt paramTPlsqlDummyStmt) {}
  
  public void postVisit(TPlsqlElsifStmt paramTPlsqlElsifStmt) {}
  
  public void postVisit(TPlsqlExecImmeStmt paramTPlsqlExecImmeStmt) {}
  
  public void postVisit(TPlsqlExitStmt paramTPlsqlExitStmt) {}
  
  public void postVisit(TPlsqlFetchStmt paramTPlsqlFetchStmt) {}
  
  public void postVisit(TPlsqlForallStmt paramTPlsqlForallStmt) {}
  
  public void postVisit(TPlsqlGotoStmt paramTPlsqlGotoStmt) {}
  
  public void postVisit(TPlsqlIfStmt paramTPlsqlIfStmt) {}
  
  public void postVisit(TPlsqlLoopStmt paramTPlsqlLoopStmt) {}
  
  public void postVisit(TPlsqlNullStmt paramTPlsqlNullStmt) {}
  
  public void postVisit(TPlsqlOpenforStmt paramTPlsqlOpenforStmt) {}
  
  public void postVisit(TPlsqlOpenStmt paramTPlsqlOpenStmt) {}
  
  public void postVisit(TPlsqlPipeRowStmt paramTPlsqlPipeRowStmt) {}
  
  public void postVisit(TPlsqlPragmaDeclStmt paramTPlsqlPragmaDeclStmt) {}
  
  public void postVisit(TPlsqlProcedureSpecStmt paramTPlsqlProcedureSpecStmt) {}
  
  public void postVisit(TPlsqlRaiseStmt paramTPlsqlRaiseStmt) {}
  
  public void postVisit(TPlsqlRecordTypeDefStmt paramTPlsqlRecordTypeDefStmt) {}
  
  public void postVisit(TPlsqlReturnStmt paramTPlsqlReturnStmt) {}
  
  public void postVisit(TPlsqlSqlStmt paramTPlsqlSqlStmt) {}
  
  public void postVisit(TPlsqlSubProgram paramTPlsqlSubProgram) {}
  
  public void postVisit(TPlsqlTableTypeDefStmt paramTPlsqlTableTypeDefStmt) {}
  
  public void postVisit(TPlsqlVarDeclStmt paramTPlsqlVarDeclStmt) {}
  
  public void postVisit(TPlsqlVarrayTypeDefStmt paramTPlsqlVarrayTypeDefStmt) {}
  
  public void postVisit(TSqlplusCmdStatement paramTSqlplusCmdStatement) {}
  
  public void preVisit(TPlsqlCursorDeclStmt paramTPlsqlCursorDeclStmt) {}
  
  public void preVisit(TPlsqlDummyStmt paramTPlsqlDummyStmt) {}
  
  public void preVisit(TPlsqlElsifStmt paramTPlsqlElsifStmt) {}
  
  public void preVisit(TPlsqlExecImmeStmt paramTPlsqlExecImmeStmt) {}
  
  public void preVisit(TPlsqlExitStmt paramTPlsqlExitStmt) {}
  
  public void preVisit(TPlsqlFetchStmt paramTPlsqlFetchStmt) {}
  
  public void preVisit(TPlsqlForallStmt paramTPlsqlForallStmt) {}
  
  public void preVisit(TPlsqlGotoStmt paramTPlsqlGotoStmt) {}
  
  public void preVisit(TPlsqlIfStmt paramTPlsqlIfStmt) {}
  
  public void preVisit(TPlsqlLoopStmt paramTPlsqlLoopStmt) {}
  
  public void preVisit(TPlsqlNullStmt paramTPlsqlNullStmt) {}
  
  public void preVisit(TPlsqlOpenforStmt paramTPlsqlOpenforStmt) {}
  
  public void preVisit(TPlsqlOpenStmt paramTPlsqlOpenStmt) {}
  
  public void preVisit(TPlsqlPipeRowStmt paramTPlsqlPipeRowStmt) {}
  
  public void preVisit(TPlsqlPragmaDeclStmt paramTPlsqlPragmaDeclStmt) {}
  
  public void preVisit(TPlsqlProcedureSpecStmt paramTPlsqlProcedureSpecStmt) {}
  
  public void preVisit(TPlsqlRaiseStmt paramTPlsqlRaiseStmt) {}
  
  public void preVisit(TPlsqlRecordTypeDefStmt paramTPlsqlRecordTypeDefStmt) {}
  
  public void preVisit(TPlsqlReturnStmt paramTPlsqlReturnStmt) {}
  
  public void preVisit(TPlsqlSqlStmt paramTPlsqlSqlStmt) {}
  
  public void preVisit(TPlsqlSubProgram paramTPlsqlSubProgram) {}
  
  public void preVisit(TPlsqlTableTypeDefStmt paramTPlsqlTableTypeDefStmt) {}
  
  public void preVisit(TPlsqlVarDeclStmt paramTPlsqlVarDeclStmt) {}
  
  public void preVisit(TPlsqlVarrayTypeDefStmt paramTPlsqlVarrayTypeDefStmt) {}
  
  public void preVisit(TSqlplusCmdStatement paramTSqlplusCmdStatement) {}
  
  public void preVisit(TSelectSqlStatement paramTSelectSqlStatement) {}
  
  public void postVisit(TSelectSqlStatement paramTSelectSqlStatement) {}
  
  public void preVisit(TAlterTableStatement paramTAlterTableStatement) {}
  
  public void postVisit(TAlterTableStatement paramTAlterTableStatement) {}
  
  public void preVisit(TCreateIndexSqlStatement paramTCreateIndexSqlStatement) {}
  
  public void postVisit(TCreateIndexSqlStatement paramTCreateIndexSqlStatement) {}
  
  public void preVisit(TCreateTableSqlStatement paramTCreateTableSqlStatement) {}
  
  public void postVisit(TCreateTableSqlStatement paramTCreateTableSqlStatement) {}
  
  public void preVisit(TTypeName paramTTypeName) {}
  
  public void postVisit(TTypeName paramTTypeName) {}
  
  public void preVisit(TTypeNameList paramTTypeNameList) {}
  
  public void postVisit(TTypeNameList paramTTypeNameList) {}
  
  public void preVisit(TColumnDefinition paramTColumnDefinition) {}
  
  public void postVisit(TColumnDefinition paramTColumnDefinition) {}
  
  public void preVisit(TColumnDefinitionList paramTColumnDefinitionList) {}
  
  public void postVisit(TColumnDefinitionList paramTColumnDefinitionList) {}
  
  public void preVisit(TConstraint paramTConstraint) {}
  
  public void postVisit(TConstraint paramTConstraint) {}
  
  public void preVisit(TConstraintList paramTConstraintList) {}
  
  public void postVisit(TConstraintList paramTConstraintList) {}
  
  public void preVisit(TMultiTarget paramTMultiTarget) {}
  
  public void postVisit(TMultiTarget paramTMultiTarget) {}
  
  public void preVisit(TMultiTargetList paramTMultiTargetList) {}
  
  public void postVisit(TMultiTargetList paramTMultiTargetList) {}
  
  public void preVisit(TFunctionCall paramTFunctionCall) {}
  
  public void postVisit(TFunctionCall paramTFunctionCall) {}
  
  public void preVisit(TOutputClause paramTOutputClause) {}
  
  public void postVisit(TOutputClause paramTOutputClause) {}
  
  public void preVisit(TReturningClause paramTReturningClause) {}
  
  public void postVisit(TReturningClause paramTReturningClause) {}
  
  public void preVisit(TCreateViewSqlStatement paramTCreateViewSqlStatement) {}
  
  public void postVisit(TCreateViewSqlStatement paramTCreateViewSqlStatement) {}
  
  public void preVisit(TDropIndexSqlStatement paramTDropIndexSqlStatement) {}
  
  public void postVisit(TDropIndexSqlStatement paramTDropIndexSqlStatement) {}
  
  public void preVisit(TDropTableSqlStatement paramTDropTableSqlStatement) {}
  
  public void postVisit(TDropTableSqlStatement paramTDropTableSqlStatement) {}
  
  public void preVisit(TDropViewSqlStatement paramTDropViewSqlStatement) {}
  
  public void postVisit(TDropViewSqlStatement paramTDropViewSqlStatement) {}
  
  public void preVisit(TMergeSqlStatement paramTMergeSqlStatement) {}
  
  public void postVisit(TMergeSqlStatement paramTMergeSqlStatement) {}
  
  public void preVisit(TUnknownSqlStatement paramTUnknownSqlStatement) {}
  
  public void postVisit(TUnknownSqlStatement paramTUnknownSqlStatement) {}
  
  public void preVisit(TDeleteSqlStatement paramTDeleteSqlStatement) {}
  
  public void postVisit(TDeleteSqlStatement paramTDeleteSqlStatement) {}
  
  public void preVisit(TUpdateSqlStatement paramTUpdateSqlStatement) {}
  
  public void postVisit(TUpdateSqlStatement paramTUpdateSqlStatement) {}
  
  public void preVisit(TInsertSqlStatement paramTInsertSqlStatement) {}
  
  public void postVisit(TInsertSqlStatement paramTInsertSqlStatement) {}
  
  public void preVisit(TMssqlCommit paramTMssqlCommit) {}
  
  public void postVisit(TMssqlCommit paramTMssqlCommit) {}
  
  public void preVisit(TMssqlRollback paramTMssqlRollback) {}
  
  public void postVisit(TMssqlRollback paramTMssqlRollback) {}
  
  public void preVisit(TMssqlSaveTran paramTMssqlSaveTran) {}
  
  public void postVisit(TMssqlSaveTran paramTMssqlSaveTran) {}
  
  public void preVisit(TMssqlBlock paramTMssqlBlock) {}
  
  public void postVisit(TMssqlBlock paramTMssqlBlock) {}
  
  public void preVisit(TMssqlCreateProcedure paramTMssqlCreateProcedure) {}
  
  public void postVisit(TMssqlCreateProcedure paramTMssqlCreateProcedure) {}
  
  public void preVisit(TMssqlCreateFunction paramTMssqlCreateFunction) {}
  
  public void postVisit(TMssqlCreateFunction paramTMssqlCreateFunction) {}
  
  public void preVisit(TMssqlCreateTrigger paramTMssqlCreateTrigger) {}
  
  public void postVisit(TMssqlCreateTrigger paramTMssqlCreateTrigger) {}
  
  public void preVisit(TMssqlBulkInsert paramTMssqlBulkInsert) {}
  
  public void postVisit(TMssqlBulkInsert paramTMssqlBulkInsert) {}
  
  public void preVisit(TMssqlUpdateText paramTMssqlUpdateText) {}
  
  public void postVisit(TMssqlUpdateText paramTMssqlUpdateText) {}
  
  public void preVisit(TMssqlDeclare paramTMssqlDeclare) {}
  
  public void postVisit(TMssqlDeclare paramTMssqlDeclare) {}
  
  public void preVisit(TMssqlReturn paramTMssqlReturn) {}
  
  public void postVisit(TMssqlReturn paramTMssqlReturn) {}
  
  public void preVisit(TMssqlIfElse paramTMssqlIfElse) {}
  
  public void postVisit(TMssqlIfElse paramTMssqlIfElse) {}
  
  public void preVisit(TMssqlPrint paramTMssqlPrint) {}
  
  public void postVisit(TMssqlPrint paramTMssqlPrint) {}
  
  public void preVisit(TMssqlUse paramTMssqlUse) {}
  
  public void postVisit(TMssqlUse paramTMssqlUse) {}
  
  public void preVisit(TMssqlGo paramTMssqlGo) {}
  
  public void postVisit(TMssqlGo paramTMssqlGo) {}
  
  public void preVisit(TMssqlContinue paramTMssqlContinue) {}
  
  public void postVisit(TMssqlContinue paramTMssqlContinue) {}
  
  public void preVisit(TMssqlBreak paramTMssqlBreak) {}
  
  public void postVisit(TMssqlBreak paramTMssqlBreak) {}
  
  public void preVisit(TMssqlGrant paramTMssqlGrant) {}
  
  public void postVisit(TMssqlGrant paramTMssqlGrant) {}
  
  public void preVisit(TMssqlFetch paramTMssqlFetch) {}
  
  public void postVisit(TMssqlFetch paramTMssqlFetch) {}
  
  public void preVisit(TMssqlClose paramTMssqlClose) {}
  
  public void postVisit(TMssqlClose paramTMssqlClose) {}
  
  public void preVisit(TMssqlOpen paramTMssqlOpen) {}
  
  public void postVisit(TMssqlOpen paramTMssqlOpen) {}
  
  public void preVisit(TMssqlDeallocate paramTMssqlDeallocate) {}
  
  public void postVisit(TMssqlDeallocate paramTMssqlDeallocate) {}
  
  public void preVisit(TMssqlExecute paramTMssqlExecute) {}
  
  public void postVisit(TMssqlExecute paramTMssqlExecute) {}
  
  public void preVisit(TMssqlExecuteAs paramTMssqlExecuteAs) {}
  
  public void postVisit(TMssqlExecuteAs paramTMssqlExecuteAs) {}
  
  public void preVisit(TMssqlBeginTran paramTMssqlBeginTran) {}
  
  public void postVisit(TMssqlBeginTran paramTMssqlBeginTran) {}
  
  public void preVisit(TMssqlRaiserror paramTMssqlRaiserror) {}
  
  public void postVisit(TMssqlRaiserror paramTMssqlRaiserror) {}
  
  public void preVisit(TMssqlLabel paramTMssqlLabel) {}
  
  public void postVisit(TMssqlLabel paramTMssqlLabel) {}
  
  public void preVisit(TMssqlGoTo paramTMssqlGoTo) {}
  
  public void postVisit(TMssqlGoTo paramTMssqlGoTo) {}
  
  public void preVisit(TMssqlRevert paramTMssqlRevert) {}
  
  public void postVisit(TMssqlRevert paramTMssqlRevert) {}
  
  public void preVisit(TMssqlEndConversation paramTMssqlEndConversation) {}
  
  public void postVisit(TMssqlEndConversation paramTMssqlEndConversation) {}
  
  public void preVisit(TMssqlBeginDialog paramTMssqlBeginDialog) {}
  
  public void postVisit(TMssqlBeginDialog paramTMssqlBeginDialog) {}
  
  public void preVisit(TMssqlSendOnConversation paramTMssqlSendOnConversation) {}
  
  public void postVisit(TMssqlSendOnConversation paramTMssqlSendOnConversation) {}
  
  public void preVisit(TMssqlStmtStub paramTMssqlStmtStub) {}
  
  public void postVisit(TMssqlStmtStub paramTMssqlStmtStub) {}
  
  public void preVisit(TMssqlTruncateTable paramTMssqlTruncateTable) {}
  
  public void postVisit(TMssqlTruncateTable paramTMssqlTruncateTable) {}
  
  public void preVisit(TIntervalExpression paramTIntervalExpression) {}
  
  public void postVisit(TIntervalExpression paramTIntervalExpression) {}
  
  public void preVisit(TQualifyClause paramTQualifyClause) {}
  
  public void postVisit(TQualifyClause paramTQualifyClause) {}
  
  public void preVisit(TCreateMaterializedSqlStatement paramTCreateMaterializedSqlStatement) {}
  
  public void postVisit(TCreateMaterializedSqlStatement paramTCreateMaterializedSqlStatement) {}
  
  public void preVisit(TLimitClause paramTLimitClause) {}
  
  public void postVisit(TLimitClause paramTLimitClause) {}
  
  public void preVisit(TMySQLDeclare paramTMySQLDeclare) {}
  
  public void postVisit(TMySQLDeclare paramTMySQLDeclare) {}
  
  public void preVisit(TMySQLCreateFunction paramTMySQLCreateFunction) {}
  
  public void postVisit(TMySQLCreateFunction paramTMySQLCreateFunction) {}
  
  public void preVisit(TMySQLCreateProcedure paramTMySQLCreateProcedure) {}
  
  public void postVisit(TMySQLCreateProcedure paramTMySQLCreateProcedure) {}
  
  public void preVisit(TMySQLCreateTrigger paramTMySQLCreateTrigger) {}
  
  public void postVisit(TMySQLCreateTrigger paramTMySQLCreateTrigger) {}
  
  public void preVisit(TValueRowItem paramTValueRowItem) {}
  
  public void postVisit(TValueRowItem paramTValueRowItem) {}
  
  public void preVisit(TValueRowItemList paramTValueRowItemList) {}
  
  public void postVisit(TValueRowItemList paramTValueRowItemList) {}
  
  public void preVisit(TValueClause paramTValueClause) {}
  
  public void postVisit(TValueClause paramTValueClause) {}
  
  public void preVisit(TDb2StmtStub paramTDb2StmtStub) {}
  
  public void postVisit(TDb2StmtStub paramTDb2StmtStub) {}
  
  public void preVisit(TMySQLStmtStub paramTMySQLStmtStub) {}
  
  public void postVisit(TMySQLStmtStub paramTMySQLStmtStub) {}
  
  public void preVisit(TTrimArgument paramTTrimArgument) {}
  
  public void postVisit(TTrimArgument paramTTrimArgument) {}
  
  public void preVisit(TLockingClause paramTLockingClause) {}
  
  public void postVisit(TLockingClause paramTLockingClause) {}
  
  public void preVisit(TLockingClauseList paramTLockingClauseList) {}
  
  public void postVisit(TLockingClauseList paramTLockingClauseList) {}
  
  public void preVisit(TParameterDeclaration paramTParameterDeclaration) {}
  
  public void postVisit(TParameterDeclaration paramTParameterDeclaration) {}
  
  public void preVisit(TParameterDeclarationList paramTParameterDeclarationList) {}
  
  public void postVisit(TParameterDeclarationList paramTParameterDeclarationList) {}
  
  public void preVisit(TViewAliasClause paramTViewAliasClause) {}
  
  public void postVisit(TViewAliasClause paramTViewAliasClause) {}
  
  public void preVisit(TViewAliasItem paramTViewAliasItem) {}
  
  public void postVisit(TViewAliasItem paramTViewAliasItem) {}
  
  public void preVisit(TViewAliasItemList paramTViewAliasItemList) {}
  
  public void postVisit(TViewAliasItemList paramTViewAliasItemList) {}
  
  public void preVisit(TPTNodeList paramTPTNodeList) {}
  
  public void postVisit(TPTNodeList paramTPTNodeList) {}
  
  public void preVisit(TMdxSelect paramTMdxSelect) {}
  
  public void postVisit(TMdxSelect paramTMdxSelect) {}
  
  public void preVisit(TMdxAxisNode paramTMdxAxisNode) {}
  
  public void postVisit(TMdxAxisNode paramTMdxAxisNode) {}
  
  public void preVisit(TMdxExpNode paramTMdxExpNode) {}
  
  public void postVisit(TMdxExpNode paramTMdxExpNode) {}
  
  public void preVisit(TMdxBinOpNode paramTMdxBinOpNode) {}
  
  public void postVisit(TMdxBinOpNode paramTMdxBinOpNode) {}
  
  public void preVisit(TMdxCalcPropNode paramTMdxCalcPropNode) {}
  
  public void postVisit(TMdxCalcPropNode paramTMdxCalcPropNode) {}
  
  public void preVisit(TMdxCaseNode paramTMdxCaseNode) {}
  
  public void postVisit(TMdxCaseNode paramTMdxCaseNode) {}
  
  public void preVisit(TMdxEmptyNode paramTMdxEmptyNode) {}
  
  public void postVisit(TMdxEmptyNode paramTMdxEmptyNode) {}
  
  public void preVisit(TMdxFloatConstNode paramTMdxFloatConstNode) {}
  
  public void postVisit(TMdxFloatConstNode paramTMdxFloatConstNode) {}
  
  public void preVisit(TMdxFunctionNode paramTMdxFunctionNode) {}
  
  public void postVisit(TMdxFunctionNode paramTMdxFunctionNode) {}
  
  public void preVisit(TMdxIdentifierNode paramTMdxIdentifierNode) {}
  
  public void postVisit(TMdxIdentifierNode paramTMdxIdentifierNode) {}
  
  public void preVisit(TMdxIntegerConstNode paramTMdxIntegerConstNode) {}
  
  public void postVisit(TMdxIntegerConstNode paramTMdxIntegerConstNode) {}
  
  public void preVisit(TMdxNonEmptyNode paramTMdxNonEmptyNode) {}
  
  public void postVisit(TMdxNonEmptyNode paramTMdxNonEmptyNode) {}
  
  public void preVisit(TMdxPropertyNode paramTMdxPropertyNode) {}
  
  public void postVisit(TMdxPropertyNode paramTMdxPropertyNode) {}
  
  public void preVisit(TMdxSetNode paramTMdxSetNode) {}
  
  public void postVisit(TMdxSetNode paramTMdxSetNode) {}
  
  public void preVisit(TMdxStringConstNode paramTMdxStringConstNode) {}
  
  public void postVisit(TMdxStringConstNode paramTMdxStringConstNode) {}
  
  public void preVisit(TMdxTupleNode paramTMdxTupleNode) {}
  
  public void postVisit(TMdxTupleNode paramTMdxTupleNode) {}
  
  public void preVisit(TMdxUnaryOpNode paramTMdxUnaryOpNode) {}
  
  public void postVisit(TMdxUnaryOpNode paramTMdxUnaryOpNode) {}
  
  public void preVisit(TMdxWhenNode paramTMdxWhenNode) {}
  
  public void postVisit(TMdxWhenNode paramTMdxWhenNode) {}
  
  public void preVisit(TMdxWhereNode paramTMdxWhereNode) {}
  
  public void postVisit(TMdxWhereNode paramTMdxWhereNode) {}
  
  public void preVisit(TMdxWithNode paramTMdxWithNode) {}
  
  public void postVisit(TMdxWithNode paramTMdxWithNode) {}
  
  public void preVisit(TMdxCreateMember paramTMdxCreateMember) {}
  
  public void postVisit(TMdxCreateMember paramTMdxCreateMember) {}
  
  public void preVisit(TMdxCreateSubCube paramTMdxCreateSubCube) {}
  
  public void postVisit(TMdxCreateSubCube paramTMdxCreateSubCube) {}
  
  public void preVisit(TMdxDrillthrough paramTMdxDrillthrough) {}
  
  public void postVisit(TMdxDrillthrough paramTMdxDrillthrough) {}
  
  public void preVisit(TMdxCall paramTMdxCall) {}
  
  public void postVisit(TMdxCall paramTMdxCall) {}
  
  public void preVisit(TMdxDimensionNode paramTMdxDimensionNode) {}
  
  public void postVisit(TMdxDimensionNode paramTMdxDimensionNode) {}
  
  public void preVisit(TMdxMeasureNode paramTMdxMeasureNode) {}
  
  public void postVisit(TMdxMeasureNode paramTMdxMeasureNode) {}
  
  public void preVisit(TMdxGroupNode paramTMdxGroupNode) {}
  
  public void postVisit(TMdxGroupNode paramTMdxGroupNode) {}
  
  public void preVisit(TMdxLevelNode paramTMdxLevelNode) {}
  
  public void postVisit(TMdxLevelNode paramTMdxLevelNode) {}
  
  public void preVisit(TMdxMemberNode paramTMdxMemberNode) {}
  
  public void postVisit(TMdxMemberNode paramTMdxMemberNode) {}
  
  public void preVisit(TMdxDimContentNode paramTMdxDimContentNode) {}
  
  public void postVisit(TMdxDimContentNode paramTMdxDimContentNode) {}
  
  public void preVisit(TMdxLevelContentNode paramTMdxLevelContentNode) {}
  
  public void postVisit(TMdxLevelContentNode paramTMdxLevelContentNode) {}
  
  public void preVisit(TMdxCreateSessionCube paramTMdxCreateSessionCube) {}
  
  public void postVisit(TMdxCreateSessionCube paramTMdxCreateSessionCube) {}
  
  public void preVisit(TMdxScope paramTMdxScope) {}
  
  public void postVisit(TMdxScope paramTMdxScope) {}
  
  public void preVisit(TMdxExpression paramTMdxExpression) {}
  
  public void postVisit(TMdxExpression paramTMdxExpression) {}
  
  public void preVisit(TOracleCommentOnSqlStmt paramTOracleCommentOnSqlStmt) {}
  
  public void postVisit(TOracleCommentOnSqlStmt paramTOracleCommentOnSqlStmt) {}
  
  public void preVisit(TOracleExecuteProcedure paramTOracleExecuteProcedure) {}
  
  public void postVisit(TOracleExecuteProcedure paramTOracleExecuteProcedure) {}
  
  public void preVisit(TArrayAccess paramTArrayAccess) {}
  
  public void postVisit(TArrayAccess paramTArrayAccess) {}
  
  public void preVisit(TGroupingSet paramTGroupingSet) {}
  
  public void postVisit(TGroupingSet paramTGroupingSet) {}
  
  public void preVisit(TGroupingSetItem paramTGroupingSetItem) {}
  
  public void postVisit(TGroupingSetItem paramTGroupingSetItem) {}
  
  public void preVisit(TRollupCube paramTRollupCube) {}
  
  public void postVisit(TRollupCube paramTRollupCube) {}
  
  public void preVisit(TTruncateStatement paramTTruncateStatement) {}
  
  public void postVisit(TTruncateStatement paramTTruncateStatement) {}
  
  public void preVisit(TAlterSessionStatement paramTAlterSessionStatement) {}
  
  public void postVisit(TAlterSessionStatement paramTAlterSessionStatement) {}
  
  public void preVisit(TCreateSynonymStmt paramTCreateSynonymStmt) {}
  
  public void postVisit(TCreateSynonymStmt paramTCreateSynonymStmt) {}
  
  public void preVisit(TCreateSequenceStmt paramTCreateSequenceStmt) {}
  
  public void postVisit(TCreateSequenceStmt paramTCreateSequenceStmt) {}
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TParseTreeVisitor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */