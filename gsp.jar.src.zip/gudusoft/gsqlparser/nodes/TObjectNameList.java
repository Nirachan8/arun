package gudusoft.gsqlparser.nodes;

public class TObjectNameList
  extends TParseTreeNodeList
{
  private int a = 0;
  
  public void setObjectType(int paramInt)
  {
    this.a = paramInt;
  }
  
  public int getObjectType()
  {
    return this.a;
  }
  
  public void addObjectName(TObjectName paramTObjectName)
  {
    if ((this.a != 0) && (this.a != 100) && (paramTObjectName.getObjectType() == 0)) {
      paramTObjectName.setObjectType(this.a);
    }
    addElement(paramTObjectName);
  }
  
  public TObjectName getObjectName(int paramInt)
  {
    if (paramInt < size()) {
      return (TObjectName)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addObjectName((TObjectName)paramObject);
  }
  
  public int searchColumnReference(TObjectName paramTObjectName)
  {
    int i = -1;
    for (int j = 0; j < size(); j++) {
      if (getObjectName(j).toString().compareToIgnoreCase(paramTObjectName.toString()) == 0)
      {
        i = j;
        break;
      }
    }
    return i;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      getObjectName(i).accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TObjectNameList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */