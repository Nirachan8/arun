package gudusoft.gsqlparser.nodes;

public class TDropIndexSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TDropIndexItemList b = null;
  
  public TObjectName getIndexName()
  {
    return this.a;
  }
  
  public TDropIndexItemList getDropIndexItemList()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TObjectName))
    {
      this.a = ((TObjectName)paramObject);
      this.a.setObjectType(15);
      return;
    }
    if ((paramObject instanceof TDropIndexItemList)) {
      this.b = ((TDropIndexItemList)paramObject);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDropIndexSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */