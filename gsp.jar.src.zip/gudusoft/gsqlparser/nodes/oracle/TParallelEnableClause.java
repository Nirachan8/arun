package gudusoft.gsqlparser.nodes.oracle;

import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TObjectNameList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TParallelEnableClause
  extends TParseTreeNode
{
  private TObjectName a;
  private TObjectNameList b;
  private TStreamingClause c;
  
  public void setStreamingClause(TStreamingClause paramTStreamingClause)
  {
    this.c = paramTStreamingClause;
  }
  
  public TStreamingClause getStreamingClause()
  {
    return this.c;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TObjectName)paramObject);
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    init(paramObject1);
    this.b = ((TObjectNameList)paramObject2);
  }
  
  public TObjectName getArgument()
  {
    return this.a;
  }
  
  public TObjectNameList getColumnList()
  {
    return this.b;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\oracle\TParallelEnableClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */