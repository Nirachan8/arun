package gudusoft.gsqlparser.nodes.oracle;

import gudusoft.gsqlparser.nodes.TObjectName;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TInvokerRightsClause
  extends TParseTreeNode
{
  private TObjectName a;
  
  public TObjectName getDefiner()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TObjectName)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\oracle\TInvokerRightsClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */