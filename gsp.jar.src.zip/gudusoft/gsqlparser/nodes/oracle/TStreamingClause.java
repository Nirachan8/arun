package gudusoft.gsqlparser.nodes.oracle;

import gudusoft.gsqlparser.nodes.TExpression;
import gudusoft.gsqlparser.nodes.TObjectNameList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TStreamingClause
  extends TParseTreeNode
{
  private TObjectNameList a;
  private TExpression b;
  
  public TObjectNameList getColumnList()
  {
    return this.a;
  }
  
  public TExpression getExpr()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.b = ((TExpression)paramObject1);
    this.a = ((TObjectNameList)paramObject2);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\oracle\TStreamingClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */