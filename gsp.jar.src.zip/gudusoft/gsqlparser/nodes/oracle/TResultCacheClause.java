package gudusoft.gsqlparser.nodes.oracle;

import gudusoft.gsqlparser.nodes.TObjectNameList;
import gudusoft.gsqlparser.nodes.TParseTreeNode;

public class TResultCacheClause
  extends TParseTreeNode
{
  private TObjectNameList a;
  
  public TObjectNameList getDataSourceList()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TObjectNameList)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\oracle\TResultCacheClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */