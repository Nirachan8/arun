package gudusoft.gsqlparser.nodes;

public class TDatetimeExpression
  extends TParseTreeNode
{}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDatetimeExpression.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */