package gudusoft.gsqlparser.nodes;

public class TOrderByItemList
  extends TParseTreeNodeList
{
  public void addOrderByItem(TOrderByItem paramTOrderByItem)
  {
    addElement(paramTOrderByItem);
  }
  
  public TOrderByItem getOrderByItem(int paramInt)
  {
    if (paramInt < size()) {
      return (TOrderByItem)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addOrderByItem((TOrderByItem)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      getOrderByItem(i).accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TOrderByItemList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */