package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;

public class TTrimArgument
  extends TParseTreeNode
{
  private TExpression a = null;
  private TExpression b = null;
  private TSourceToken c = null;
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    if (paramObject1 != null) {
      this.c = ((TSourceToken)paramObject1);
    }
    if (paramObject2 != null) {
      this.b = ((TExpression)paramObject2);
    }
    this.a = ((TExpression)paramObject3);
  }
  
  public TSourceToken getBoth_trailing_leading()
  {
    return this.c;
  }
  
  public TExpression getStringExpression()
  {
    return this.a;
  }
  
  public TExpression getTrimCharacter()
  {
    return this.b;
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    this.a.accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TTrimArgument.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */