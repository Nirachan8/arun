package gudusoft.gsqlparser.nodes;

public class TDmlSelectItemList
  extends TParseTreeNodeList
{
  public void addDmlSelectItem(TDmlSelectItem paramTDmlSelectItem)
  {
    addElement(paramTDmlSelectItem);
  }
  
  public TDmlSelectItem getDmlSelectItem(int paramInt)
  {
    if (paramInt < size()) {
      return (TDmlSelectItem)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addDmlSelectItem((TDmlSelectItem)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TDmlSelectItemList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */