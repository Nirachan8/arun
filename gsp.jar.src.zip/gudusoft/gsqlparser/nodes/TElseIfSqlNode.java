package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;

public class TElseIfSqlNode
  extends TParseTreeNode
{
  private TExpression a = null;
  private TStatementListSqlNode b = null;
  private TStatementList c = null;
  
  public TExpression getCondition()
  {
    return this.a;
  }
  
  public TStatementList getStmts()
  {
    if (this.c == null) {
      this.c = new TStatementList();
    }
    return this.c;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TExpression)paramObject1);
    this.b = ((TStatementListSqlNode)paramObject2);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
    this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
    for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < this.b.size(); paramTCustomSqlStatement++) {
      getStmts().add(this.b.getStatementSqlNode(paramTCustomSqlStatement).getStmt());
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TElseIfSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */