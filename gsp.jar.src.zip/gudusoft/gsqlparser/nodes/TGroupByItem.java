package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EExpressionType;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class TGroupByItem
  extends TParseTreeNode
{
  private TExpression a = null;
  private TRollupCube b = null;
  private TGroupingSet c = null;
  
  public TExpression getExpr()
  {
    return this.a;
  }
  
  public TGroupingSet getGroupingSet()
  {
    return this.c;
  }
  
  public void setExpr(TExpression paramTExpression)
  {
    this.a = paramTExpression;
  }
  
  public TRollupCube getRollupCube()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TExpression))
    {
      this.a = ((TExpression)paramObject);
      return;
    }
    if ((paramObject instanceof TRollupCube))
    {
      this.b = ((TRollupCube)paramObject);
      return;
    }
    if ((paramObject instanceof TGroupingSet)) {
      this.c = ((TGroupingSet)paramObject);
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null)
    {
      if (((paramTCustomSqlStatement instanceof TSelectSqlStatement)) && (this.a.getExpressionType() == EExpressionType.simple_object_name_t))
      {
        TObjectName localTObjectName = this.a.getObjectOperand();
        TSelectSqlStatement localTSelectSqlStatement = (TSelectSqlStatement)paramTCustomSqlStatement;
        for (int i = 0; i < localTSelectSqlStatement.getResultColumnList().size(); i++)
        {
          Object localObject;
          if (((localObject = localTSelectSqlStatement.getResultColumnList().getResultColumn(i)).getAliasClause() != null) && ((localObject = ((TResultColumn)localObject).getAliasClause()).getAliasName().toString().equalsIgnoreCase(localTObjectName.toString()))) {
            localTObjectName.setObjectType(2);
          }
        }
      }
      this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    }
    if (this.b != null)
    {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    }
    if (this.c != null) {
      this.c.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    if (this.a != null) {
      this.a.accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TGroupByItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */