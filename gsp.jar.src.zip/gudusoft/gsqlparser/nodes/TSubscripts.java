package gudusoft.gsqlparser.nodes;

public class TSubscripts
  extends TParseTreeNode
{
  private TConstant a;
  private TConstant b;
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TConstant)paramObject1);
    this.b = ((TConstant)paramObject2);
  }
  
  public TConstant getFirst()
  {
    return this.a;
  }
  
  public TConstant getLast()
  {
    return this.b;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TSubscripts.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */