package gudusoft.gsqlparser.nodes;

public class TColumnDefinitionList
  extends TParseTreeNodeList
{
  public void addColumn(TColumnDefinition paramTColumnDefinition)
  {
    addElement(paramTColumnDefinition);
  }
  
  public TColumnDefinition getColumn(int paramInt)
  {
    if (paramInt < size()) {
      return (TColumnDefinition)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addColumn((TColumnDefinition)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      getColumn(i).accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TColumnDefinitionList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */