package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EExpressionType;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;

public class TOrderByItem
  extends TParseTreeNode
{
  private TExpression a;
  private int b = 0;
  
  public void TOrderByItem() {}
  
  public int getSortType()
  {
    return this.b;
  }
  
  public void setSortTypeByToken(TSourceToken paramTSourceToken)
  {
    if (paramTSourceToken == null) {
      return;
    }
    if (paramTSourceToken.astext.equalsIgnoreCase("asc"))
    {
      this.b = 1;
      return;
    }
    if (paramTSourceToken.astext.equalsIgnoreCase("desc")) {
      this.b = 2;
    }
  }
  
  public TExpression getSortKey()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TExpression)paramObject);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null)
    {
      if ((paramTCustomSqlStatement != null) && ((paramTCustomSqlStatement instanceof TSelectSqlStatement)) && (this.a.getExpressionType() == EExpressionType.simple_object_name_t) && (this.a.getObjectOperand().getPartToken() != null) && (this.a.getObjectOperand().getObjectToken() == null) && (paramTCustomSqlStatement.getResultColumnList() != null)) {
        for (paramESqlClause = 0; paramESqlClause < paramTCustomSqlStatement.getResultColumnList().size(); paramESqlClause++)
        {
          TResultColumn localTResultColumn;
          if (((localTResultColumn = paramTCustomSqlStatement.getResultColumnList().getResultColumn(paramESqlClause)).getAliasClause() != null) && (localTResultColumn.getAliasClause().getAliasName().toString().equalsIgnoreCase(this.a.toString())))
          {
            this.a.getObjectOperand().setObjectType(2);
            break;
          }
        }
      }
      this.a.doParse(paramTCustomSqlStatement, ESqlClause.orderby);
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    if (this.a != null) {
      this.a.accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TOrderByItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */