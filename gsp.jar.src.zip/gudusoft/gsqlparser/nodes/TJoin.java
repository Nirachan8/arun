package gudusoft.gsqlparser.nodes;

public class TJoin
  extends TNodeWithAliasClause
{
  private int a = 1;
  private TJoin b;
  private TTable c;
  private TJoinItemList d = null;
  
  public void setJoinItems(TJoinItemList paramTJoinItemList)
  {
    this.d = paramTJoinItemList;
  }
  
  public void setJoin(TJoin paramTJoin)
  {
    this.b = paramTJoin;
  }
  
  public void setTable(TTable paramTTable)
  {
    this.c = paramTTable;
  }
  
  public void setKind(int paramInt)
  {
    this.a = paramInt;
  }
  
  public TJoinItemList getJoinItems()
  {
    if (this.d == null) {
      this.d = new TJoinItemList();
    }
    return this.d;
  }
  
  public TJoin getJoin()
  {
    return this.b;
  }
  
  public TTable getTable()
  {
    return this.c;
  }
  
  public int getKind()
  {
    return this.a;
  }
  
  public TAliasClause getAliasClause()
  {
    return super.getAliasClause();
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    getJoinItems().accept(paramTParseTreeVisitor);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TJoin.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */