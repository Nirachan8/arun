package gudusoft.gsqlparser.nodes;

public class TNewVariantTypeArgumentList
  extends TParseTreeNodeList
{
  public void addNewVariantTypeArgument(TNewVariantTypeArgument paramTNewVariantTypeArgument)
  {
    addElement(paramTNewVariantTypeArgument);
  }
  
  public TNewVariantTypeArgument getNewVariantTypeArgument(int paramInt)
  {
    if (paramInt < size()) {
      return (TNewVariantTypeArgument)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addNewVariantTypeArgument((TNewVariantTypeArgument)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TNewVariantTypeArgumentList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */