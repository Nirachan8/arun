package gudusoft.gsqlparser.nodes;

public class TLockingClauseList
  extends TParseTreeNodeList
{
  public void addLockingClause(TLockingClause paramTLockingClause)
  {
    addElement(paramTLockingClause);
  }
  
  public TLockingClause getLockingClause(int paramInt)
  {
    if (paramInt < size()) {
      return (TLockingClause)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addLockingClause((TLockingClause)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      getLockingClause(i).accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TLockingClauseList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */