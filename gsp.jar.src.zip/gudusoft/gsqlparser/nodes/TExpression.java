package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.EExpressionType;
import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.stmt.TSelectSqlStatement;
import java.util.Stack;

public class TExpression
  extends TParseTreeNode
{
  private TObjectAccess a = null;
  private TSourceToken b = null;
  private TSourceToken c = null;
  private Object d = null;
  private TNewVariantTypeArgumentList e = null;
  private TTypeName f;
  private TObjectName g;
  private boolean h;
  private TIndirection i;
  private boolean j;
  private TOutputFormatPhraseList k;
  private TIntervalExpression l = null;
  private TExpressionList m = null;
  private TInExpr n = null;
  private boolean o = false;
  private TExpression p;
  private TExpression q;
  private TExpression r;
  private TArrayAccess s = null;
  private EExpressionType t = EExpressionType.not_initialized_yet_t;
  private TObjectName u;
  private TConstant v;
  private TSourceToken w;
  private TCaseExpression x;
  private TSelectSqlNode y = null;
  private TSelectSqlStatement z = null;
  private boolean A = false;
  private TFunctionCall B;
  private TExpression C;
  private TExpression D;
  private TSourceToken E = null;
  private TSourceToken F = null;
  private Stack G = null;
  private boolean H = true;
  /**
   * @deprecated
   */
  public static final int unknown = 0;
  /**
   * @deprecated
   */
  public static final int PLUS = 1;
  /**
   * @deprecated
   */
  public static final int MINUS = 2;
  /**
   * @deprecated
   */
  public static final int TIMES = 3;
  /**
   * @deprecated
   */
  public static final int DIVIDE = 4;
  /**
   * @deprecated
   */
  public static final int CONCATENATE = 5;
  /**
   * @deprecated
   */
  public static final int MODULO = 6;
  /**
   * @deprecated
   */
  public static final int ASSIGNMENT = 7;
  /**
   * @deprecated
   */
  public static final int BITWISE_AND = 8;
  /**
   * @deprecated
   */
  public static final int BITWISE_OR = 9;
  /**
   * @deprecated
   */
  public static final int BITWISE_XOR = 10;
  /**
   * @deprecated
   */
  public static final int BITWISE_EXCLUSIVE_OR = 11;
  /**
   * @deprecated
   */
  public static final int SCOPE_RESOLUTION = 12;
  /**
   * @deprecated
   */
  public static final int EXPONENTIATE = 13;
  /**
   * @deprecated
   */
  public static final int compoundAssignment = 14;
  /**
   * @deprecated
   */
  public static final int simpleObjectname = 15;
  /**
   * @deprecated
   */
  public static final int simpleConstant = 16;
  /**
   * @deprecated
   */
  public static final int simpleSourcetoken = 17;
  /**
   * @deprecated
   */
  public static final int compoundParenthesis = 18;
  /**
   * @deprecated
   */
  public static final int compoundUnaryPlus = 19;
  /**
   * @deprecated
   */
  public static final int compoundUnaryMinus = 20;
  /**
   * @deprecated
   */
  public static final int compoundPrior = 21;
  /**
   * @deprecated
   */
  public static final int caseExprOperator = 22;
  /**
   * @deprecated
   */
  public static final int cursorExprOperator = 23;
  /**
   * @deprecated
   */
  public static final int funcationCallOperator = 24;
  /**
   * @deprecated
   */
  public static final int datetimeExprOperator = 25;
  /**
   * @deprecated
   */
  public static final int intervalExprOperator = 26;
  /**
   * @deprecated
   */
  public static final int modelExprOperator = 27;
  /**
   * @deprecated
   */
  public static final int subqueryExprOperator = 28;
  /**
   * @deprecated
   */
  public static final int typeconstructorExprOperator = 29;
  /**
   * @deprecated
   */
  public static final int objectaccessExprOperator = 30;
  /**
   * @deprecated
   */
  public static final int placeholderExprOperator = 32;
  /**
   * @deprecated
   */
  public static final int in_expr = 34;
  /**
   * @deprecated
   */
  public static final int expr_list = 35;
  /**
   * @deprecated
   */
  public static final int dummyOperator = 37;
  /**
   * @deprecated
   */
  public static final int simple_comparison_conditions = 40;
  /**
   * @deprecated
   */
  public static final int group_comparison_conditions = 41;
  /**
   * @deprecated
   */
  public static final int in_conditions = 42;
  /**
   * @deprecated
   */
  public static final int floating_point_conditions = 43;
  /**
   * @deprecated
   */
  public static final int pattern_matching_conditions = 45;
  /**
   * @deprecated
   */
  public static final int null_conditions = 46;
  /**
   * @deprecated
   */
  public static final int between_conditions = 47;
  /**
   * @deprecated
   */
  public static final int exists_condition = 48;
  /**
   * @deprecated
   */
  public static final int isoftype_condition = 49;
  /**
   * @deprecated
   */
  public static final int logical_conditions_and = 50;
  /**
   * @deprecated
   */
  public static final int logical_conditions_or = 51;
  /**
   * @deprecated
   */
  public static final int logical_conditions_xor = 52;
  /**
   * @deprecated
   */
  public static final int logical_conditions_not = 53;
  /**
   * @deprecated
   */
  public static final int logical_conditions_is = 54;
  /**
   * @deprecated
   */
  public static final int RANGE = 55;
  /**
   * @deprecated
   */
  public static final int POWER = 56;
  /**
   * @deprecated
   */
  public static final int at_time_zone = 100;
  /**
   * @deprecated
   */
  public static final int at_local = 101;
  /**
   * @deprecated
   */
  public static final int day_to_second = 102;
  /**
   * @deprecated
   */
  public static final int year_to_month = 103;
  /**
   * @deprecated
   */
  public static final int interval_expression = 104;
  /**
   * @deprecated
   */
  public static final int new_structured_type = 110;
  /**
   * @deprecated
   */
  public static final int new_variant_type = 111;
  /**
   * @deprecated
   */
  public static final int period_ldiff = 115;
  /**
   * @deprecated
   */
  public static final int period_rdiff = 117;
  /**
   * @deprecated
   */
  public static final int period_p_intersect = 119;
  /**
   * @deprecated
   */
  public static final int period_p_normalize = 121;
  /**
   * @deprecated
   */
  public static final int until_changed = 123;
  /**
   * @deprecated
   */
  public static final int is_document = 133;
  /**
   * @deprecated
   */
  public static final int is_distinct_from = 135;
  /**
   * @deprecated
   */
  public static final int true_false_unknown = 137;
  /**
   * @deprecated
   */
  public static final int COLLATE = 223;
  /**
   * @deprecated
   */
  public static final int LEFTJOIN_OP = 224;
  /**
   * @deprecated
   */
  public static final int RIGHTJOIN_OP = 225;
  /**
   * @deprecated
   */
  public static final int ref_arrow = 226;
  /**
   * @deprecated
   */
  public static final int typecast = 227;
  /**
   * @deprecated
   */
  public static final int arrayaccess = 228;
  /**
   * @deprecated
   */
  public static final int connect_by_root = 229;
  /**
   * @deprecated
   */
  public static final int sqlserver_proprietary_column_alias = 230;
  /**
   * @deprecated
   */
  public static final int mysql_binary_operator = 300;
  /**
   * @deprecated
   */
  public static final int left_shift = 301;
  /**
   * @deprecated
   */
  public static final int right_shift = 302;
  /**
   * @deprecated
   */
  public static final int multisetExprOperator = 310;
  /**
   * @deprecated
   */
  public static final int fieldSelection = 501;
  /**
   * @deprecated
   */
  public static final int arrayConstructor = 505;
  /**
   * @deprecated
   */
  public static final int rowConstructor = 509;
  /**
   * @deprecated
   */
  public static final int factorial = 515;
  /**
   * @deprecated
   */
  public static final int squareRoot = 517;
  /**
   * @deprecated
   */
  public static final int cubeRoot = 519;
  /**
   * @deprecated
   */
  public static final int factorialPrefix = 521;
  /**
   * @deprecated
   */
  public static final int absoluteValue = 523;
  /**
   * @deprecated
   */
  public static final int BITWISE_SHIFT_LEFT = 525;
  /**
   * @deprecated
   */
  public static final int BITWISE_SHIFT_RIGHT = 527;
  /**
   * @deprecated
   */
  public static final int BITWISE_NOT = 529;
  /**
   * @deprecated
   */
  public static final int compoundUnaryBitwiseNot = 222;
  /**
   * @deprecated
   */
  public static final int member_of = 541;
  /**
   * @deprecated
   */
  public static final int nextValueOf = 601;
  /**
   * @deprecated
   */
  public static final int UnknownOperator = 901;
  /**
   * @deprecated
   */
  public static final int UnknownUnaryOperator = 905;
  /**
   * @deprecated
   */
  public static final int UnknownUnaryOperatorRight = 909;
  
  public void setObjectAccess(TObjectAccess paramTObjectAccess)
  {
    this.a = paramTObjectAccess;
  }
  
  public TObjectAccess getObjectAccess()
  {
    return this.a;
  }
  
  public void setNotToken(TSourceToken paramTSourceToken)
  {
    this.c = paramTSourceToken;
  }
  
  public TSourceToken getNotToken()
  {
    return this.c;
  }
  
  public void init(Object paramObject)
  {
    this.t = ((EExpressionType)paramObject);
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4)
  {
    init(paramObject1);
    this.b = ((TSourceToken)paramObject2);
    switch (1.a[this.t.ordinal()])
    {
    case 1: 
      this.u = ((TObjectName)paramObject3);
      setStartToken(this.u);
      setEndToken(this.u);
      return;
    case 2: 
      this.w = ((TSourceToken)paramObject3);
      setStartToken(this.w);
      setEndToken(this.w);
      return;
    case 3: 
      this.v = ((TConstant)paramObject3);
      setStartToken(this.v);
      setEndToken(this.v);
      return;
    case 4: 
    case 5: 
      this.B = ((TFunctionCall)paramObject3);
      return;
    case 6: 
      this.s = ((TArrayAccess)paramObject3);
      return;
    case 7: 
    case 8: 
    case 9: 
    case 10: 
      this.m = ((TExpressionList)paramObject3);
      return;
    }
    if (paramObject3 != null)
    {
      this.q = ((TExpression)paramObject3);
      this.q.setParentExpr(this);
    }
    if (paramObject4 != null)
    {
      this.r = ((TExpression)paramObject4);
      this.r.setParentExpr(this);
    }
  }
  
  public void setOperatorToken(TSourceToken paramTSourceToken)
  {
    this.b = paramTSourceToken;
    if (getExpressionType() == EExpressionType.unknown_t)
    {
      if (this.b.toString().equalsIgnoreCase("%"))
      {
        this.t = EExpressionType.arithmetic_modulo_t;
        return;
      }
      if (this.b.toString().equalsIgnoreCase("&"))
      {
        this.t = EExpressionType.bitwise_and_t;
        return;
      }
      if (this.b.toString().equalsIgnoreCase("|"))
      {
        this.t = EExpressionType.bitwise_or_t;
        return;
      }
      if (this.b.toString().equalsIgnoreCase("#"))
      {
        this.t = EExpressionType.bitwise_xor_t;
        return;
      }
      if (this.b.toString().equalsIgnoreCase("<<"))
      {
        this.t = EExpressionType.bitwise_shift_left_t;
        return;
      }
      if (this.b.toString().equalsIgnoreCase(">>")) {
        this.t = EExpressionType.bitwise_shift_right_t;
      }
    }
    else if (getExpressionType() == EExpressionType.unary_left_unknown_t)
    {
      if (this.b.toString().equalsIgnoreCase("|/"))
      {
        this.t = EExpressionType.unary_squareroot_t;
        return;
      }
      if (this.b.toString().equalsIgnoreCase("||/"))
      {
        this.t = EExpressionType.unary_cuberoot_t;
        return;
      }
      if (this.b.toString().equalsIgnoreCase("!!"))
      {
        this.t = EExpressionType.unary_factorialprefix_t;
        return;
      }
      if (this.b.toString().equalsIgnoreCase("@"))
      {
        this.t = EExpressionType.unary_absolutevalue_t;
        return;
      }
      if (this.b.toString().equalsIgnoreCase("~")) {
        this.t = EExpressionType.unary_bitwise_not_t;
      }
    }
  }
  
  public TSourceToken getOperatorToken()
  {
    return this.b;
  }
  
  public void setVal(Object paramObject)
  {
    this.d = paramObject;
  }
  
  public Object getVal()
  {
    return this.d;
  }
  
  public TConstant getConstantOperand()
  {
    return this.v;
  }
  
  public void setNewVariantTypeArgumentList(TNewVariantTypeArgumentList paramTNewVariantTypeArgumentList)
  {
    this.e = paramTNewVariantTypeArgumentList;
  }
  
  public TNewVariantTypeArgumentList getNewVariantTypeArgumentList()
  {
    return this.e;
  }
  
  public void setTypeName(TTypeName paramTTypeName)
  {
    this.f = paramTTypeName;
  }
  
  public TTypeName getTypeName()
  {
    return this.f;
  }
  
  public TObjectName getFieldName()
  {
    return this.g;
  }
  
  public void setIndirection(TIndirection paramTIndirection)
  {
    if (paramTIndirection != null)
    {
      if (paramTIndirection.isRealIndices())
      {
        this.h = true;
      }
      else
      {
        setExpressionType(EExpressionType.fieldselection_t);
        this.g = ((TIndices)paramTIndirection.getIndices().getElement(0)).getAttributeName();
        this.g.setObjectType(51);
      }
      this.i = paramTIndirection;
    }
  }
  
  public boolean isSubscripts()
  {
    return this.h;
  }
  
  public TIndirection getIndirection()
  {
    return this.i;
  }
  
  /**
   * @deprecated
   */
  public boolean isNotModifier()
  {
    this.j = (getOperatorToken() != null);
    if (this.j) {
      this.j = (getOperatorToken().tokencode == 321);
    }
    return this.j;
  }
  
  public void setOutputFormatPhraseList(TOutputFormatPhraseList paramTOutputFormatPhraseList)
  {
    this.k = paramTOutputFormatPhraseList;
  }
  
  public TOutputFormatPhraseList getOutputFormatPhraseList()
  {
    return this.k;
  }
  
  public TExpressionList getExprList()
  {
    return this.m;
  }
  
  public void setIntervalExpr(TIntervalExpression paramTIntervalExpression)
  {
    this.l = paramTIntervalExpression;
  }
  
  public TIntervalExpression getIntervalExpr()
  {
    return this.l;
  }
  
  public void setInExpr(TInExpr paramTInExpr)
  {
    this.n = paramTInExpr;
  }
  
  /**
   * @deprecated
   */
  public TInExpr getInExpr()
  {
    return this.n;
  }
  
  public void setExprList(TExpressionList paramTExpressionList)
  {
    this.m = paramTExpressionList;
  }
  
  public void setOracleOuterJoin(boolean paramBoolean)
  {
    this.o = paramBoolean;
  }
  
  public boolean isOracleOuterJoin()
  {
    return this.o;
  }
  
  public TExpression getParentExpr()
  {
    return this.p;
  }
  
  public void setParentExpr(TExpression paramTExpression)
  {
    this.p = paramTExpression;
  }
  
  public void setLeftOperand(TExpression paramTExpression)
  {
    this.q = paramTExpression;
    if (paramTExpression != null) {
      paramTExpression.setParentExpr(this);
    }
  }
  
  public void setRightOperand(TExpression paramTExpression)
  {
    this.r = paramTExpression;
    if (paramTExpression != null) {
      paramTExpression.setParentExpr(this);
    }
  }
  
  public TExpression getRightOperand()
  {
    return this.r;
  }
  
  public TExpression getLeftOperand()
  {
    return this.q;
  }
  
  public TExpression getLikeEscapeOperand()
  {
    return this.D;
  }
  
  public TExpression getBetweenOperand()
  {
    return this.C;
  }
  
  public TArrayAccess getArrayAccess()
  {
    return this.s;
  }
  
  public EExpressionType getExpressionType()
  {
    return this.t;
  }
  
  public void setExpressionType(EExpressionType paramEExpressionType)
  {
    this.t = paramEExpressionType;
  }
  
  public void setObjectOperand(TObjectName paramTObjectName)
  {
    this.u = paramTObjectName;
  }
  
  public TObjectName getObjectOperand()
  {
    return this.u;
  }
  
  public void setConstantOperand(TConstant paramTConstant)
  {
    this.v = paramTConstant;
  }
  
  public TSourceToken getSourcetokenOperand()
  {
    return this.w;
  }
  
  public void setSourcetokenOperand(TSourceToken paramTSourceToken)
  {
    this.w = paramTSourceToken;
  }
  
  public void setCaseExpression(TCaseExpression paramTCaseExpression)
  {
    this.x = paramTCaseExpression;
  }
  
  public TCaseExpression getCaseExpression()
  {
    return this.x;
  }
  
  /**
   * @deprecated
   */
  public void setArrayAccess(TArrayAccess paramTArrayAccess)
  {
    this.s = paramTArrayAccess;
  }
  
  public void setSubQueryNode(TSelectSqlNode paramTSelectSqlNode)
  {
    this.y = paramTSelectSqlNode;
  }
  
  public void setSubQuery(TSelectSqlStatement paramTSelectSqlStatement)
  {
    this.z = paramTSelectSqlStatement;
  }
  
  public TSelectSqlStatement getSubQuery()
  {
    return this.z;
  }
  
  public void setSubQueryInStmt(boolean paramBoolean)
  {
    this.A = paramBoolean;
  }
  
  public TFunctionCall getFunctionCall()
  {
    return this.B;
  }
  
  public void setFunctionCall(TFunctionCall paramTFunctionCall)
  {
    this.B = paramTFunctionCall;
  }
  
  public void setDatetimeExpression(TDatetimeExpression paramTDatetimeExpression) {}
  
  public void setIntervalExpression(TIntervalExpression paramTIntervalExpression) {}
  
  public void setBetweenOperand(TExpression paramTExpression)
  {
    this.C = paramTExpression;
  }
  
  public void setLikeEscapeOperand(TExpression paramTExpression)
  {
    this.D = paramTExpression;
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    switch (1.a[this.t.ordinal()])
    {
    case 1: 
      if (paramESqlClause == ESqlClause.selectInto) {
        this.u.setObjectType(10);
      }
      paramTCustomSqlStatement.linkColumnReferenceToTable(this.u, paramESqlClause);
      return;
    case 11: 
      this.n.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 7: 
    case 8: 
    case 9: 
    case 10: 
      if (this.m != null)
      {
        this.m.doParse(paramTCustomSqlStatement, paramESqlClause);
        return;
      }
      break;
    case 4: 
    case 5: 
    case 12: 
      this.B.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 13: 
    case 14: 
    case 15: 
      if (this.z == null)
      {
        this.z = new TSelectSqlStatement(paramTCustomSqlStatement.dbvendor);
        this.z.rootNode = this.y;
      }
      if (!this.A)
      {
        this.z.doParseStatement(paramTCustomSqlStatement);
        return;
      }
      this.z.parsestatement(paramTCustomSqlStatement, false);
      return;
    case 16: 
      this.x.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 17: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      if (this.D != null)
      {
        this.D.doParse(paramTCustomSqlStatement, paramESqlClause);
        return;
      }
      break;
    case 18: 
      if (this.z == null)
      {
        this.z = new TSelectSqlStatement(paramTCustomSqlStatement.dbvendor);
        this.z.rootNode = this.y;
      }
      if (!this.A)
      {
        this.z.doParseStatement(paramTCustomSqlStatement);
        return;
      }
      this.z.parsestatement(paramTCustomSqlStatement, false);
      return;
    case 19: 
      this.e.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 20: 
    case 21: 
    case 22: 
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 23: 
    case 24: 
    case 25: 
    case 26: 
    case 27: 
    case 28: 
    case 29: 
    case 30: 
    case 31: 
    case 32: 
    case 33: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 34: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 35: 
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 36: 
    case 37: 
    case 38: 
    case 39: 
    case 40: 
    case 41: 
    case 42: 
    case 43: 
    case 44: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 45: 
    case 46: 
    case 47: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 48: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 49: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 50: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 51: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 52: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 53: 
    case 54: 
    case 55: 
    case 56: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 57: 
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 58: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 59: 
      if (this.C != null) {
        this.C.doParse(paramTCustomSqlStatement, paramESqlClause);
      }
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 60: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 61: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 62: 
    case 63: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 64: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 65: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 6: 
      this.s.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 66: 
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 67: 
      this.l.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 68: 
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 69: 
    case 70: 
      this.q.doParse(paramTCustomSqlStatement, paramESqlClause);
      this.r.doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 71: 
      if ((this.y != null) && (this.z == null))
      {
        this.z = new TSelectSqlStatement(paramTCustomSqlStatement.dbvendor);
        this.z.rootNode = this.y;
        this.z.doParseStatement(paramTCustomSqlStatement);
        return;
      }
      if (this.m != null)
      {
        this.m.doParse(paramTCustomSqlStatement, paramESqlClause);
        return;
      }
      break;
    case 72: 
      if (this.m != null)
      {
        this.m.doParse(paramTCustomSqlStatement, paramESqlClause);
        return;
      }
      break;
    case 73: 
    case 74: 
    case 75: 
    case 76: 
    case 77: 
      getRightOperand().doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 78: 
      getLeftOperand().doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 79: 
    case 80: 
      getLeftOperand().doParse(paramTCustomSqlStatement, paramESqlClause);
      getRightOperand().doParse(paramTCustomSqlStatement, paramESqlClause);
      return;
    case 81: 
    case 82: 
    case 83: 
    case 84: 
    case 85: 
    case 86: 
      getLeftOperand().doParse(paramTCustomSqlStatement, paramESqlClause);
      getRightOperand().doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
  
  public TSourceToken getQuantifier()
  {
    return this.F;
  }
  
  public TSourceToken getComparisonOperator()
  {
    return this.E;
  }
  
  public void setComparisonOperator(TSourceToken paramTSourceToken)
  {
    this.E = paramTSourceToken;
    this.b = paramTSourceToken;
  }
  
  public void setQuantifier(TSourceToken paramTSourceToken)
  {
    this.F = paramTSourceToken;
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
  
  public boolean isLeaf()
  {
    return isLeafExpr(this);
  }
  
  public boolean isLeafExpr(TParseTreeNode paramTParseTreeNode)
  {
    boolean bool = true;
    if (paramTParseTreeNode == null) {
      return true;
    }
    if (!(paramTParseTreeNode instanceof TExpression)) {
      return true;
    }
    paramTParseTreeNode = (TExpression)paramTParseTreeNode;
    switch (1.a[paramTParseTreeNode.getExpressionType().ordinal()])
    {
    case 1: 
    case 2: 
    case 3: 
    case 4: 
    case 5: 
    case 6: 
    case 7: 
    case 8: 
    case 9: 
    case 10: 
    case 11: 
    case 12: 
    case 13: 
    case 14: 
    case 15: 
    case 16: 
    case 18: 
    case 19: 
    case 44: 
    case 60: 
    case 67: 
    case 87: 
    case 88: 
      return true;
    }
    if (paramTParseTreeNode.getLeftOperand() != null) {
      bool = !(paramTParseTreeNode.getLeftOperand() instanceof TExpression);
    }
    if (paramTParseTreeNode.getRightOperand() != null) {
      bool = !(paramTParseTreeNode.getRightOperand() instanceof TExpression);
    }
    return bool;
  }
  
  private Stack a()
  {
    if (this.G == null) {
      this.G = new Stack();
    }
    return this.G;
  }
  
  public void setVisitSubTree(boolean paramBoolean)
  {
    this.H = paramBoolean;
  }
  
  public boolean isVisitSubTree()
  {
    return this.H;
  }
  
  private boolean a(TParseTreeNode paramTParseTreeNode)
  {
    boolean bool;
    if ((bool = !isLeafExpr(paramTParseTreeNode) ? 1 : 0) != 0) {
      bool = ((TExpression)paramTParseTreeNode).isVisitSubTree();
    }
    return bool;
  }
  
  public void preOrderTraverse(IExpressionVisitor paramIExpressionVisitor)
  {
    if (isLeaf()) {
      paramIExpressionVisitor.exprVisit(this, true);
    } else {
      a().push(this);
    }
    while (a().size() > 0)
    {
      for (TParseTreeNode localTParseTreeNode = (TParseTreeNode)a().peek(); localTParseTreeNode != null; localTParseTreeNode = (TParseTreeNode)a().peek())
      {
        if (!paramIExpressionVisitor.exprVisit(localTParseTreeNode, isLeafExpr(localTParseTreeNode))) {
          return;
        }
        if (isLeafExpr(localTParseTreeNode)) {
          a().push(null);
        } else if (!a(localTParseTreeNode)) {
          a().push(null);
        } else {
          a().push(((TExpression)localTParseTreeNode).getLeftOperand());
        }
      }
      a().pop();
      if (a().size() > 0)
      {
        localTParseTreeNode = (TParseTreeNode)a().pop();
        if (isLeafExpr(localTParseTreeNode)) {
          a().push(null);
        } else if (!a(localTParseTreeNode)) {
          a().push(null);
        } else {
          a().push(((TExpression)localTParseTreeNode).getRightOperand());
        }
      }
    }
  }
  
  public void inOrderTraverse(IExpressionVisitor paramIExpressionVisitor)
  {
    if (isLeaf()) {
      paramIExpressionVisitor.exprVisit(this, true);
    } else {
      a().push(this);
    }
    while (a().size() > 0)
    {
      for (TParseTreeNode localTParseTreeNode = (TParseTreeNode)a().peek(); localTParseTreeNode != null; localTParseTreeNode = (TParseTreeNode)a().peek()) {
        if (isLeafExpr(localTParseTreeNode)) {
          a().push(null);
        } else {
          a().push(((TExpression)localTParseTreeNode).getLeftOperand());
        }
      }
      a().pop();
      if (a().size() > 0)
      {
        localTParseTreeNode = (TParseTreeNode)a().pop();
        if (!paramIExpressionVisitor.exprVisit(localTParseTreeNode, isLeafExpr(localTParseTreeNode))) {
          return;
        }
        if (isLeafExpr(localTParseTreeNode)) {
          a().push(null);
        } else {
          a().push(((TExpression)localTParseTreeNode).getRightOperand());
        }
      }
    }
  }
  
  public void postOrderTraverse(IExpressionVisitor paramIExpressionVisitor)
  {
    if (isLeaf()) {
      paramIExpressionVisitor.exprVisit(this, true);
    } else {
      a().push(this);
    }
    while (a().size() > 0)
    {
      TParseTreeNode localTParseTreeNode = (TParseTreeNode)a().peek();
      while (localTParseTreeNode != null)
      {
        if (isLeafExpr(localTParseTreeNode)) {
          a().push(null);
        } else {
          a().push(((TExpression)localTParseTreeNode).getLeftOperand());
        }
        if ((localTParseTreeNode = (TParseTreeNode)a().peek()) != null) {
          localTParseTreeNode.setDummyTag(1);
        }
      }
      a().pop();
      for (localTParseTreeNode = (TParseTreeNode)a().peek(); (a().size() > 0) && (localTParseTreeNode.getDummyTag() == 2); localTParseTreeNode = (TParseTreeNode)a().peek())
      {
        (localTParseTreeNode = (TParseTreeNode)a().pop()).setDummyTag(0);
        if (!paramIExpressionVisitor.exprVisit(localTParseTreeNode, isLeafExpr(localTParseTreeNode))) {
          return;
        }
        if (a().size() <= 0) {
          break;
        }
      }
      if (a().size() > 0)
      {
        (localTParseTreeNode = (TParseTreeNode)a().peek()).setDummyTag(2);
        if (isLeafExpr(localTParseTreeNode)) {
          a().push(null);
        } else {
          a().push(((TExpression)localTParseTreeNode).getRightOperand());
        }
      }
    }
  }
  
  public void addANDCondition(String paramString)
  {
    appendString(" and " + paramString);
  }
  
  public void addORCondition(String paramString)
  {
    appendString(" or " + paramString);
  }
  
  public void remove()
  {
    if (this.p == null)
    {
      removeAllMyTokensFromTokenList(null);
      return;
    }
    if ((this.p.getExpressionType() == EExpressionType.logical_and_t) || (this.p.getExpressionType() == EExpressionType.logical_or_t))
    {
      removeAllMyTokensFromTokenList(this.p.getOperatorToken());
      if ((this.p.getLeftOperand().getStartToken() == null) && (this.p.getRightOperand().getStartToken() == null)) {
        this.p.remove();
      }
    }
    else
    {
      if (this.p.getExpressionType() == EExpressionType.parenthesis_t)
      {
        removeAllMyTokensFromTokenList(null);
        this.p.remove();
        return;
      }
      removeAllMyTokensFromTokenList(null);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TExpression.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */