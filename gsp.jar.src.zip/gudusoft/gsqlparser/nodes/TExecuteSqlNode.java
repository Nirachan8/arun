package gudusoft.gsqlparser.nodes;

public class TExecuteSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TObjectName b = null;
  private TExecParameterList c = null;
  private TExpressionList d = null;
  private int e = 0;
  
  public void setExecType(int paramInt)
  {
    this.e = paramInt;
  }
  
  public int getExecType()
  {
    return this.e;
  }
  
  public TExpressionList getStringValues()
  {
    return this.d;
  }
  
  public TObjectName getModuleName()
  {
    return this.a;
  }
  
  public TExecParameterList getParameters()
  {
    return this.c;
  }
  
  public TObjectName getReturnStatus()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    if ((paramObject1 instanceof TObjectName))
    {
      this.a = ((TObjectName)paramObject1);
      this.a.setObjectType(12);
      if (paramObject2 != null) {
        if ((paramObject2 instanceof TExpressionList)) {
          this.d = ((TExpressionList)paramObject2);
        } else {
          this.c = ((TExecParameterList)paramObject2);
        }
      }
      if (paramObject3 != null) {
        this.b = ((TObjectName)paramObject3);
      }
    }
    else if ((paramObject1 instanceof TExpressionList))
    {
      this.d = ((TExpressionList)paramObject1);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TExecuteSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */