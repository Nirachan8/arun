package gudusoft.gsqlparser.nodes;

public class TParameterDeclarationList
  extends TParseTreeNodeList
{
  public void addParameterDeclarationItem(TParameterDeclaration paramTParameterDeclaration)
  {
    addElement(paramTParameterDeclaration);
  }
  
  public TParameterDeclaration getParameterDeclarationItem(int paramInt)
  {
    if (paramInt < size()) {
      return (TParameterDeclaration)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addParameterDeclarationItem((TParameterDeclaration)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    for (int i = 0; i < size(); i++) {
      getParameterDeclarationItem(i).accept(paramTParseTreeVisitor);
    }
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TParameterDeclarationList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */