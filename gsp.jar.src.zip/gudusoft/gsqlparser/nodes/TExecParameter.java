package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TExecParameter
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TExpression b = null;
  private int c = 0;
  
  public int getParameterMode()
  {
    return this.c;
  }
  
  public TObjectName getParameterName()
  {
    return this.a;
  }
  
  public TExpression getParameterValue()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    if (paramObject1 != null) {
      this.a = ((TObjectName)paramObject1);
    }
    this.b = ((TExpression)paramObject2);
    if (paramObject3 != null)
    {
      if ((paramObject1 = (TSourceToken)paramObject3).toString().equalsIgnoreCase("out"))
      {
        this.c = 2;
        return;
      }
      if (((TSourceToken)paramObject1).toString().equalsIgnoreCase("output")) {
        this.c = 4;
      }
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TExecParameter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */