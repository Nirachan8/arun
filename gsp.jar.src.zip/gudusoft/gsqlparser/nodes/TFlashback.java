package gudusoft.gsqlparser.nodes;

public class TFlashback
  extends TParseTreeNode
{}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TFlashback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */