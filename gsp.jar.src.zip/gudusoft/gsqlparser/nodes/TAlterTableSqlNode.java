package gudusoft.gsqlparser.nodes;

public class TAlterTableSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  private TAlterTableOptionList b = null;
  private TTableElementList c = null;
  private TPTNodeList<TMySQLCreateTableOption> d;
  
  public TTableElementList getTableElementList()
  {
    return this.c;
  }
  
  public void setMySQLTableOptionList(TPTNodeList<TMySQLCreateTableOption> paramTPTNodeList)
  {
    this.d = paramTPTNodeList;
  }
  
  public TPTNodeList<TMySQLCreateTableOption> getMySQLTableOptionList()
  {
    return this.d;
  }
  
  public TAlterTableOptionList getAlterTableOptionList()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TObjectName)paramObject1);
    this.a.setObjectType(3);
    if (paramObject2 != null)
    {
      if ((paramObject2 instanceof TTableElementList))
      {
        this.c = ((TTableElementList)paramObject2);
        return;
      }
      this.b = ((TAlterTableOptionList)paramObject2);
    }
  }
  
  public TObjectName getTableName()
  {
    return this.a;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TAlterTableSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */