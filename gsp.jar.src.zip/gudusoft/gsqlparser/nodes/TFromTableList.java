package gudusoft.gsqlparser.nodes;

public class TFromTableList
  extends TParseTreeNodeList
{
  public void addFromTable(TFromTable paramTFromTable)
  {
    addElement(paramTFromTable);
  }
  
  public TFromTable getFromTable(int paramInt)
  {
    if (paramInt < size()) {
      return (TFromTable)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addFromTable((TFromTable)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TFromTableList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */