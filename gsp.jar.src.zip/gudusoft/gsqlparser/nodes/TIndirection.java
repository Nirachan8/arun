package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TIndirection
  extends TParseTreeNode
{
  private TPTNodeList<TIndices> a;
  
  public TPTNodeList<TIndices> getIndices()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TPTNodeList)paramObject);
  }
  
  public boolean isRealIndices()
  {
    boolean bool = false;
    for (int i = 0; i < this.a.size(); i++) {
      if (((TIndices)this.a.elementAt(i)).isRealIndices())
      {
        bool = true;
        break;
      }
    }
    return bool;
  }
  
  public TSourceToken getStartToken()
  {
    if (this.a.size() == 0) {
      return null;
    }
    return ((TIndices)this.a.getElement(0)).getStartToken();
  }
  
  public TSourceToken getEndToken()
  {
    if (this.a.size() == 0) {
      return null;
    }
    return ((TIndices)this.a.getElement(this.a.size() - 1)).getEndToken();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TIndirection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */