package gudusoft.gsqlparser.nodes;

public class TSetSqlNode
  extends TParseTreeNode
{
  private TExpressionList a = null;
  
  public void init(Object paramObject)
  {
    this.a = ((TExpressionList)paramObject);
  }
  
  public TExpressionList getExprList()
  {
    return this.a;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TSetSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */