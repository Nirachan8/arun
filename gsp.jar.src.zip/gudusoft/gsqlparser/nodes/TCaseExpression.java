package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TStatementList;

public class TCaseExpression
  extends TParseTreeNode
{
  private TExpression a = null;
  private TExpression b = null;
  private TWhenClauseItemList c = null;
  private TStatementListSqlNode d = null;
  private TStatementList e = null;
  
  public TExpression getElse_expr()
  {
    return this.b;
  }
  
  public TExpression getInput_expr()
  {
    return this.a;
  }
  
  public TWhenClauseItemList getWhenClauseItemList()
  {
    return this.c;
  }
  
  public TStatementListSqlNode getElse_statement_node_list()
  {
    return this.d;
  }
  
  public TStatementList getElse_statement_list()
  {
    if (this.e == null) {
      this.e = new TStatementList();
    }
    return this.e;
  }
  
  public void init(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    this.a = ((TExpression)paramObject1);
    this.c = ((TWhenClauseItemList)paramObject2);
    if ((paramObject3 instanceof TExpression))
    {
      this.b = ((TExpression)paramObject3);
      return;
    }
    this.d = ((TStatementListSqlNode)paramObject3);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.a != null) {
      this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    this.c.doParse(paramTCustomSqlStatement, paramESqlClause);
    if (this.b != null) {
      this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
    if (this.d != null)
    {
      this.d.doParse(paramTCustomSqlStatement, paramESqlClause);
      for (paramTCustomSqlStatement = 0; paramTCustomSqlStatement < this.d.size(); paramTCustomSqlStatement++) {
        getElse_statement_list().add(this.d.getStatementSqlNode(paramTCustomSqlStatement).getStmt());
      }
    }
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCaseExpression.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */