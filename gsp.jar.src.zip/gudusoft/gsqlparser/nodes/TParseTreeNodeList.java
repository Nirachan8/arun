package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;
import gudusoft.gsqlparser.TSourceToken;
import java.util.ArrayList;

public class TParseTreeNodeList
  extends TParseTreeNode
{
  private ArrayList a = new ArrayList();
  
  public void TParseTreeNodeList() {}
  
  public final int size()
  {
    return this.a.size();
  }
  
  public TParseTreeNode elementAt(int paramInt)
  {
    return (TParseTreeNode)this.a.get(paramInt);
  }
  
  public final void addElement(TParseTreeNode paramTParseTreeNode)
  {
    this.a.add(paramTParseTreeNode);
  }
  
  public final void removeElementAt(int paramInt)
  {
    this.a.remove(paramInt);
  }
  
  public final void removeElement(TParseTreeNode paramTParseTreeNode)
  {
    this.a.remove(paramTParseTreeNode);
  }
  
  final Object a(int paramInt)
  {
    return (TParseTreeNode)this.a.remove(paramInt);
  }
  
  public void init(Object paramObject)
  {
    a(paramObject);
  }
  
  void a(Object paramObject)
  {
    addElement((TParseTreeNode)paramObject);
  }
  
  public void addNode(Object paramObject)
  {
    a((TParseTreeNode)paramObject);
  }
  
  public TParseTreeNode getElement(int paramInt)
  {
    return elementAt(paramInt);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    for (int i = 0; i < size(); i++) {
      if (elementAt(i) != null) {
        elementAt(i).doParse(paramTCustomSqlStatement, paramESqlClause);
      }
    }
  }
  
  public TSourceToken getStartToken()
  {
    if (size() == 0) {
      return null;
    }
    return elementAt(0).getStartToken();
  }
  
  public TSourceToken getEndToken()
  {
    if (size() == 0) {
      return null;
    }
    return elementAt(size() - 1).getEndToken();
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TParseTreeNodeList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */