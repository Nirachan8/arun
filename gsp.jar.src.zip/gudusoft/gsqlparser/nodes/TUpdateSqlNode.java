package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;

public class TUpdateSqlNode
  extends TParseTreeNode
{
  private TSourceToken a = null;
  public TCTEList cteList = null;
  private TTopClause b = null;
  private TOutputClause c = null;
  private TFromTable d = null;
  private TResultColumnList e = null;
  private TFromTableList f = null;
  private TFromTableList g = null;
  private TWhereClause h = null;
  private TReturningClause i = null;
  private TOrderBy j = null;
  private TLimitClause k = null;
  private TIsolationClause l = null;
  
  public void setUpdateToken(TSourceToken paramTSourceToken)
  {
    this.a = paramTSourceToken;
  }
  
  public TSourceToken getUpdateToken()
  {
    return this.a;
  }
  
  public void setTopClause(TTopClause paramTTopClause)
  {
    this.b = paramTTopClause;
  }
  
  public void setOutputClause(TOutputClause paramTOutputClause)
  {
    this.c = paramTOutputClause;
  }
  
  public TOutputClause getOutputClause()
  {
    return this.c;
  }
  
  public TFromTableList getSourceTableList()
  {
    return this.f;
  }
  
  public TWhereClause getWhereCondition()
  {
    return this.h;
  }
  
  public TReturningClause getReturningClause()
  {
    return this.i;
  }
  
  public TResultColumnList getResultColumnList()
  {
    return this.e;
  }
  
  public TFromTable getTargetTable()
  {
    return this.d;
  }
  
  public TTopClause getTopClause()
  {
    return this.b;
  }
  
  public void setTargetTable(TFromTable paramTFromTable)
  {
    this.d = paramTFromTable;
  }
  
  public void setResultColumnList(TResultColumnList paramTResultColumnList)
  {
    this.e = paramTResultColumnList;
  }
  
  public void setSourceTableList(TFromTableList paramTFromTableList)
  {
    this.f = paramTFromTableList;
  }
  
  public void setReferenceTableList(TFromTableList paramTFromTableList)
  {
    this.g = paramTFromTableList;
  }
  
  public TFromTableList getReferenceTableList()
  {
    return this.g;
  }
  
  public void setWhereCondition(TWhereClause paramTWhereClause)
  {
    this.h = paramTWhereClause;
  }
  
  public void setReturningClause(TReturningClause paramTReturningClause)
  {
    this.i = paramTReturningClause;
  }
  
  public void setOrderByClause(TOrderBy paramTOrderBy)
  {
    this.j = paramTOrderBy;
  }
  
  public TOrderBy getOrderByClause()
  {
    return this.j;
  }
  
  public void setLimitClause(TLimitClause paramTLimitClause)
  {
    this.k = paramTLimitClause;
  }
  
  public TLimitClause getLimitClause()
  {
    return this.k;
  }
  
  public void setIsolationClause(TIsolationClause paramTIsolationClause)
  {
    this.l = paramTIsolationClause;
  }
  
  public TIsolationClause getIsolationClause()
  {
    return this.l;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TUpdateSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */