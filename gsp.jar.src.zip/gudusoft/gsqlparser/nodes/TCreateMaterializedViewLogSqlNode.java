package gudusoft.gsqlparser.nodes;

public class TCreateMaterializedViewLogSqlNode
  extends TParseTreeNode
{
  private TObjectName a = null;
  
  public void init(Object paramObject)
  {
    this.a = ((TObjectName)paramObject);
    this.a.setObjectType(16);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TCreateMaterializedViewLogSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */