package gudusoft.gsqlparser.nodes;

public class TUnpivotInClause
  extends TParseTreeNode
{
  private TPTNodeList<TUnpivotInClauseItem> a;
  
  public TPTNodeList<TUnpivotInClauseItem> getItems()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.a = ((TPTNodeList)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TUnpivotInClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */