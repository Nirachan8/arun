package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlStatementType;

public class TStubStmtSqlNode
  extends TParseTreeNode
{
  private ESqlStatementType a;
  private TObjectName b = null;
  private TExpressionList c = null;
  
  public void setSqlStatementType(ESqlStatementType paramESqlStatementType)
  {
    this.a = paramESqlStatementType;
  }
  
  public ESqlStatementType getSqlStatementType()
  {
    return this.a;
  }
  
  public TObjectName getObjectName()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    this.b = ((TObjectName)paramObject);
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    init(paramObject1);
    this.c = ((TExpressionList)paramObject2);
  }
  
  public TExpressionList getExprList()
  {
    return this.c;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TStubStmtSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */