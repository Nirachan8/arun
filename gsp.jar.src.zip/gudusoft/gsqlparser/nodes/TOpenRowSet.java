package gudusoft.gsqlparser.nodes;

public class TOpenRowSet
  extends TParseTreeNode
{
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TOpenRowSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */