package gudusoft.gsqlparser.nodes;

public class TBindArgument
  extends TParseTreeNode
{
  private int a = 0;
  private TExpression b = null;
  
  public void setMode(int paramInt)
  {
    this.a = paramInt;
  }
  
  public int getMode()
  {
    return this.a;
  }
  
  public TExpression getBindArgumentExpr()
  {
    return this.b;
  }
  
  public void init(Object paramObject)
  {
    this.b = ((TExpression)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TBindArgument.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */