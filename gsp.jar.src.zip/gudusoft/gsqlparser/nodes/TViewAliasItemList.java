package gudusoft.gsqlparser.nodes;

public class TViewAliasItemList
  extends TParseTreeNodeList
{
  public void addViewAliasItem(TViewAliasItem paramTViewAliasItem)
  {
    addElement(paramTViewAliasItem);
  }
  
  public TViewAliasItem getViewAliasItem(int paramInt)
  {
    if (paramInt < size()) {
      return (TViewAliasItem)elementAt(paramInt);
    }
    return null;
  }
  
  final void a(Object paramObject)
  {
    addViewAliasItem((TViewAliasItem)paramObject);
  }
  
  public void accept(TParseTreeVisitor paramTParseTreeVisitor)
  {
    paramTParseTreeVisitor.preVisit(this);
    paramTParseTreeVisitor.postVisit(this);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TViewAliasItemList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */