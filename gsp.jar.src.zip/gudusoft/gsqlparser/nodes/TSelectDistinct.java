package gudusoft.gsqlparser.nodes;

public class TSelectDistinct
  extends TParseTreeNode
{
  private int a = 0;
  private TExpressionList b;
  
  public TExpressionList getExpressionList()
  {
    return this.b;
  }
  
  public void setDistinctType(int paramInt)
  {
    this.a = paramInt;
  }
  
  public int getDistinctType()
  {
    return this.a;
  }
  
  public void init(Object paramObject)
  {
    this.b = ((TExpressionList)paramObject);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TSelectDistinct.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */