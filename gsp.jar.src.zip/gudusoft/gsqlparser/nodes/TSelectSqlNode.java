package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.TSourceToken;
import gudusoft.gsqlparser.stmt.teradata.TExpandOnClause;

public class TSelectSqlNode
  extends TParseTreeNode
{
  private TIntoTableClause a;
  private TSourceToken b = null;
  private TResultColumnList c;
  private TSelectDistinct d = null;
  private TTopClause e = null;
  private TComputeClause f = null;
  private TFromTableList g;
  private TWhereClause h;
  private TSelectSqlNode i;
  private TSelectSqlNode j;
  public TCTEList cteList;
  private int k = 0;
  private TOrderBy l;
  private TForUpdate m;
  private THierarchical n;
  private TGroupBy o;
  private TIntoClause p = null;
  private TQualifyClause q = null;
  private TSampleClause r = null;
  private TTeradataWithClause s = null;
  private TLimitClause t = null;
  private TFetchFirstClause u = null;
  private TOptimizeForClause v = null;
  private TIsolationClause w = null;
  private TValueClause x = null;
  private TPTNodeList<TLockingClause> y;
  private TSelectLimit z;
  private TWindowClause A;
  private TExpandOnClause B;
  
  public void setIntoTableClause(TIntoTableClause paramTIntoTableClause)
  {
    this.a = paramTIntoTableClause;
  }
  
  public TIntoTableClause getIntoTableClause()
  {
    return this.a;
  }
  
  public void setSelectToken(TSourceToken paramTSourceToken)
  {
    this.b = paramTSourceToken;
  }
  
  public TSourceToken getSelectToken()
  {
    return this.b;
  }
  
  public TSelectDistinct getSelectDistinct()
  {
    return this.d;
  }
  
  public void setSelectDistinct(TSelectDistinct paramTSelectDistinct)
  {
    this.d = paramTSelectDistinct;
  }
  
  public void setTopClause(TTopClause paramTTopClause)
  {
    this.e = paramTTopClause;
  }
  
  public TTopClause getTopClause()
  {
    return this.e;
  }
  
  public void setComputeClause(TComputeClause paramTComputeClause)
  {
    this.f = paramTComputeClause;
  }
  
  public TComputeClause getComputeClause()
  {
    return this.f;
  }
  
  public TResultColumnList getResultColumnList()
  {
    return this.c;
  }
  
  public TFromTableList getFromTableList()
  {
    return this.g;
  }
  
  public TWhereClause getWhereCondition()
  {
    return this.h;
  }
  
  public void setResultColumnList(TResultColumnList paramTResultColumnList)
  {
    this.c = paramTResultColumnList;
  }
  
  public void setFromTableList(TFromTableList paramTFromTableList)
  {
    this.g = paramTFromTableList;
  }
  
  public void setWhereCondition(TWhereClause paramTWhereClause)
  {
    this.h = paramTWhereClause;
  }
  
  public int getSetOperator()
  {
    return this.k;
  }
  
  public void setSetOperator(int paramInt)
  {
    this.k = paramInt;
  }
  
  public TSelectSqlNode getLeftNode()
  {
    return this.i;
  }
  
  public TSelectSqlNode getRightNode()
  {
    return this.j;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.i = ((TSelectSqlNode)paramObject1);
    this.j = ((TSelectSqlNode)paramObject2);
  }
  
  public boolean isCombinedQuery()
  {
    return this.k > 0;
  }
  
  public TOrderBy getOrderbyClause()
  {
    return this.l;
  }
  
  public void setOrderbyClause(TOrderBy paramTOrderBy)
  {
    this.l = paramTOrderBy;
  }
  
  public TForUpdate getForupdateClause()
  {
    return this.m;
  }
  
  public void setForupdateClause(TForUpdate paramTForUpdate)
  {
    this.m = paramTForUpdate;
  }
  
  public THierarchical getHierarchicalClause()
  {
    return this.n;
  }
  
  public void setHierarchicalClause(THierarchical paramTHierarchical)
  {
    this.n = paramTHierarchical;
  }
  
  public TGroupBy getGroupByClause()
  {
    return this.o;
  }
  
  public void setGroupByClause(TGroupBy paramTGroupBy)
  {
    this.o = paramTGroupBy;
  }
  
  public void setIntoClause(TIntoClause paramTIntoClause)
  {
    this.p = paramTIntoClause;
  }
  
  public TIntoClause getIntoClause()
  {
    return this.p;
  }
  
  public void setQualifyClause(TQualifyClause paramTQualifyClause)
  {
    this.q = paramTQualifyClause;
  }
  
  public TQualifyClause getQualifyClause()
  {
    return this.q;
  }
  
  public void setSampleClause(TSampleClause paramTSampleClause)
  {
    this.r = paramTSampleClause;
  }
  
  public TSampleClause getSampleClause()
  {
    return this.r;
  }
  
  public TTeradataWithClause getWithClause()
  {
    return this.s;
  }
  
  public void setWithClause(TTeradataWithClause paramTTeradataWithClause)
  {
    this.s = paramTTeradataWithClause;
  }
  
  public void setLimitClause(TLimitClause paramTLimitClause)
  {
    this.t = paramTLimitClause;
  }
  
  public TLimitClause getLimitClause()
  {
    return this.t;
  }
  
  public void setFetchFirstClause(TFetchFirstClause paramTFetchFirstClause)
  {
    this.u = paramTFetchFirstClause;
  }
  
  public TFetchFirstClause getFetchFirstClause()
  {
    return this.u;
  }
  
  public void setOptimizeForClause(TOptimizeForClause paramTOptimizeForClause)
  {
    this.v = paramTOptimizeForClause;
  }
  
  public TOptimizeForClause getOptimizeForClause()
  {
    return this.v;
  }
  
  public void setIsolationClause(TIsolationClause paramTIsolationClause)
  {
    this.w = paramTIsolationClause;
  }
  
  public TIsolationClause getIsolationClause()
  {
    return this.w;
  }
  
  public void setValueClause(TValueClause paramTValueClause)
  {
    this.x = paramTValueClause;
    setStartToken(paramTValueClause);
    setEndToken(paramTValueClause);
  }
  
  public TValueClause getValueClause()
  {
    return this.x;
  }
  
  public TPTNodeList<TLockingClause> getLockingClauses()
  {
    return this.y;
  }
  
  public void setLockingClauses(TPTNodeList<TLockingClause> paramTPTNodeList)
  {
    this.y = paramTPTNodeList;
  }
  
  public void setSelectLimit(TSelectLimit paramTSelectLimit)
  {
    this.z = paramTSelectLimit;
  }
  
  public TSelectLimit getSelectLimit()
  {
    return this.z;
  }
  
  public void setWindowClause(TWindowClause paramTWindowClause)
  {
    this.A = paramTWindowClause;
  }
  
  public TWindowClause getWindowClause()
  {
    return this.A;
  }
  
  public TExpandOnClause getExpandOnClause()
  {
    return this.B;
  }
  
  public void setExpandOnClause(TExpandOnClause paramTExpandOnClause)
  {
    this.B = paramTExpandOnClause;
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TSelectSqlNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */