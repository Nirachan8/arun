package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TInsertCondition
  extends TParseTreeNode
{
  private TExpression a;
  private TPTNodeList<TInsertIntoValue> b;
  
  public TExpression getCondition()
  {
    return this.a;
  }
  
  public TPTNodeList<TInsertIntoValue> getInsertIntoValues()
  {
    return this.b;
  }
  
  public void init(Object paramObject1, Object paramObject2)
  {
    this.a = ((TExpression)paramObject1);
    this.b = ((TPTNodeList)paramObject2);
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    this.a.doParse(paramTCustomSqlStatement, paramESqlClause);
    this.b.doParse(paramTCustomSqlStatement, paramESqlClause);
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TInsertCondition.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */