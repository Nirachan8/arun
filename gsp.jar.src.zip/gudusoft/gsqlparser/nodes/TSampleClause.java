package gudusoft.gsqlparser.nodes;

import gudusoft.gsqlparser.ESqlClause;
import gudusoft.gsqlparser.TCustomSqlStatement;

public class TSampleClause
  extends TParseTreeNode
{
  private TDummy a = null;
  private TConstantList b = null;
  private TWhenClauseItemList c = null;
  
  public TWhenClauseItemList getWhenClauseItems()
  {
    return this.c;
  }
  
  public TConstantList getCount_fraction_description_list()
  {
    return this.b;
  }
  
  private void a()
  {
    this.c = ((TWhenClauseItemList)this.a.list1);
    this.b = ((TConstantList)this.a.list2);
  }
  
  public void init(Object paramObject)
  {
    if ((paramObject instanceof TConstantList))
    {
      this.b = ((TConstantList)paramObject);
      return;
    }
    if ((paramObject instanceof TDummy))
    {
      this.a = ((TDummy)paramObject);
      a();
    }
  }
  
  public void doParse(TCustomSqlStatement paramTCustomSqlStatement, ESqlClause paramESqlClause)
  {
    if (this.c != null) {
      this.c.doParse(paramTCustomSqlStatement, paramESqlClause);
    }
  }
}


/* Location:              C:\Users\Arun\Downloads\gsp.jar!\gudusoft\gsqlparser\nodes\TSampleClause.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */